"""Independent raw-packet checks; never imports the prototype or its analyzer."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import socket

ROOT=Path('/private/tmp/tank-jev-action-admission-20261023')
REPO=Path('/Users/zbcjackson/src/tank')
OUT=ROOT/'admission-analysis-v1'
def deny(*args,**kwargs):raise AssertionError('offline independent verifier')
socket.getaddrinfo=deny
socket.socket.connect=deny
socket.socket.connect_ex=deny

def canonical(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
links=json.loads((ROOT/'source-member-bindings.json').read_text())
assert len(links['members'])==98
for name,entry in links['members'].items():assert sha(ROOT/'inputs'/name)==entry['sha256'],name
steps=json.loads((OUT/'steps.json').read_text());candidates=json.loads((OUT/'candidates.json').read_text())
by_step={(s['trial_id'],s['observation_id']):s for s in steps}
by_candidate={(c['trial_id'],c['observation_id'],c['alias']):c for c in candidates}
raw=json.loads((ROOT/'inputs/result.json').read_text())
seen=set();candidate_keys=set();old_yes=0;old_no=0
for trial in raw['rows']:
 rows=[json.loads(line) for line in (ROOT/'inputs'/trial['id']/'calls.jsonl').read_text().splitlines()]
 responses={r['call_id']:r['response'] for r in rows if 'response' in r}
 routes={e['observation_id']:e['reason'] for e in trial['events'] if e['kind']=='computer_use_route'}
 for item in trial['calls']:
  body=item['request'];peer='messages' in body
  packet=json.loads(body['messages'][1]['content'][0]['text']) if peer else body
  state=packet['state'];key=(trial['id'],state['snapshot']['observation_id'])
  if key in seen:continue
  seen.add(key);expected={};options=packet['questions']['next_action']['criteria']
  for alias,value in options.items():
   if alias in ('none','ambiguous','need_more_context','escalate'):continue
   effects=[('checkbox:checked' if value['role']=='checkbox' and
        (f['key'].startswith('dom:checked:') or f['key']=='checkbox:'+value['label'])
        else f['key'],f['value']) for f in value['effect']]
   changes=[state['value_change_checks'][ref] for ref in value.get('change_refs',[])]
   identity=canonical([value['role'],value['label'],value['ancestors'],value['current_value'],
                       value['input_key'],effects,changes])
   expected[alias]=(value,identity)
  counts=collections.Counter(identity for value,identity in expected.values())
  allowed={alias for alias,(value,identity) in expected.items() if counts[identity]==1
           and value['label'].strip() and value['label']!=value['role']}
  row=by_step[key]
  assert row['candidate_count']==len(expected) and row['text_candidate_count']==len(allowed)
  assert row['blocked_candidate_count']==len(expected)-len(allowed)
  original='jev_eligible' if len(allowed)==len(expected) else 'visual_required'
  assert row['old_reason']==routes[key[1]]==original
  assert row['text_attempt_possible']==bool(allowed)
  assert row['newly_text_attempt_possible']==(bool(allowed) and original=='visual_required')
  old_yes+=original=='jev_eligible';old_no+=original=='visual_required'
  response=responses[item['call_id']]
  choice=json.loads(response['choices'][0]['message']['content'])['choice'] if peer else response['choice']
  assert row['legacy_first_call_id']==item['call_id'] and row['legacy_first_choice']==choice
  assert row['legacy_first_provider']==('visual' if peer else 'jev')
  assert row['legacy_choice_in_candidates']==(choice in expected)
  assert row['legacy_choice_passes_text_guard']==(choice in allowed)
  assert row['packet_sha256']==hashlib.sha256(canonical(packet).encode()).hexdigest()
  for alias,(value,identity) in expected.items():
   ck=(*key,alias);candidate_keys.add(ck);reported=by_candidate[ck]
   assert reported['captured_candidate']==value
   assert reported['text_admissible']==(alias in allowed)
   assert reported['duplicate_text_target']==(counts[identity]>1)
   assert reported['generic_label']==(not value['label'].strip() or value['label']==value['role'])
assert len(raw['rows'])==96 and len(seen)==len(by_step)==336 and old_yes==116 and old_no==220
assert len(candidate_keys)==len(by_candidate)==5576
for name in ('steps','candidates','strata'):
 data=json.loads((OUT/f'{name}.json').read_text())
 with (OUT/f'{name}.csv').open(newline='') as stream:rows=list(csv.DictReader(stream))
 assert len(rows)==len(data)
 for actual,expected in zip(rows,data):
  assert actual=={k:canonical(v) if isinstance(v,(dict,list)) else '' if v is None else str(v)
                  for k,v in expected.items()},name
summary=json.loads((OUT/'summary.json').read_text())
def aggregate(rows):
 visual=[s for s in rows if s['old_reason']=='visual_required']
 return {'steps':len(rows),'old_text_eligible_steps':sum(s['old_reason']=='jev_eligible' for s in rows),
 'text_attempt_possible_steps':sum(s['text_attempt_possible'] for s in rows),
 'new_text_attempt_possible_steps':sum(s['newly_text_attempt_possible'] for s in rows),
 'old_visual_required_steps':len(visual),
 'old_visual_choice_passes_text_guard':sum(s['legacy_choice_passes_text_guard'] for s in visual),
 'old_visual_choice_blocked_or_control':sum(not s['legacy_choice_passes_text_guard'] for s in visual),
 'candidates':sum(s['candidate_count'] for s in rows),'text_candidates':sum(s['text_candidate_count'] for s in rows)}
assert summary['all']==aggregate(steps)
assert summary['jt']==aggregate([s for s in steps if s['arm']=='jt'])
for row in summary['strata']:
 subset=[s for s in steps if s['product']==row['product'] and s['arm']==row['arm']
         and (row['phase']=='all' or s['page_phase']==row['phase'])]
 assert {k:row[k] for k in summary['all']}==aggregate(subset)
for folder in ('replicated-v1','replicated-isolated'):
 for p in OUT.iterdir():assert p.read_bytes()==(ROOT/folder/p.name).read_bytes(),(folder,p.name)
old=json.loads((ROOT/'prior-artifacts68-sha256.json').read_text());assert len(old)==68
for name,digest in old.items():assert sha(REPO/name)==digest,name
production=json.loads(Path('/private/tmp/tank-jev-execution-review-20261023/verification-v3.json').read_text())['source_sha256']
for name,digest in production.items():assert sha(REPO/'backend'/name)==digest,name
result={'raw_trials':96,'route_steps':336,'candidates':5576,'all_raw_candidate_values_preserved':True,
        'old_eligible':116,'old_visual_required':220,'independent_csv_cells_verified':True,
        'strata_verified':len(summary['strata']),'independent_replay_outputs_byte_identical':7,
        'original_artifacts_unchanged':68,'frozen_production_sources_unchanged':len(production),
        'new_model_or_asr_requests':0,'network_attempts':0,
        'positive_jt':aggregate([s for s in steps if s['arm']=='jt' and s['positive']]),
        'negative_jt':aggregate([s for s in steps if s['arm']=='jt' and not s['positive']])}
(Path('/private/tmp/tank-jev-admission-review-20261023')/'independent-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
