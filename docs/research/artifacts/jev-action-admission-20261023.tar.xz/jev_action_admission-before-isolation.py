"""Benchmark-only action-level text admission; never registered as a factory mode."""

from dataclasses import replace

from agent_computer_use.action_builder import duplicate_text_target_ids
from agent_computer_use.contracts import ActionSet, DecisionResult, GoalContract, Snapshot
from agent_computer_use.jev import JevSelector, check_eligible
from agent_computer_use.model_selector import ModelSelector
from agent_computer_use.visual_selector import VisualSelector
from tank_backend.agents.subagent import SubAgentContext, SubAgentStopped


def text_candidate_ids(actions: ActionSet) -> frozenset[str]:
    """Mechanical text distinguishability only, never a correctness/authority verdict."""
    ids = {action.id for action in actions.actions}
    if (len(ids) != len(actions.actions) or len(actions.details) != len(actions.actions)
            or {detail.action_id for detail in actions.details} != ids):
        raise SubAgentStopped("ineligible_decision")
    duplicates = duplicate_text_target_ids(actions.details)
    return frozenset(detail.action_id for detail in actions.details
                     if detail.action_id not in duplicates
                     and detail.label.strip() and detail.label != detail.role)


class ActionAdmissionSelector(VisualSelector):
    async def choose(self, goal: GoalContract, snapshot: Snapshot, actions: ActionSet,
                     context: SubAgentContext) -> DecisionResult:
        if actions.reason not in {"jev_eligible", "visual_required"}:
            return await super().choose(goal, snapshot, actions, context)
        ModelSelector.check(context)
        offered = replace(actions, reason="jev_eligible")
        check_eligible(goal, snapshot, offered)
        if any(item.value is None and item.source == "user" for item in goal.inputs):
            raise SubAgentStopped("missing_user_input")
        admissible = text_candidate_ids(actions)
        if not admissible:
            return await super().choose(goal, snapshot, replace(actions, reason="visual_required"),
                                        context)
        decision = await JevSelector().choose(goal, snapshot, offered, context)
        ModelSelector.check(context)
        accepted = decision.choice == "candidate" and decision.candidate_id in admissible
        context.observe("computer_use_action_admission", reason=actions.reason,
                        candidate_set_id=actions.binding.candidate_set_id,
                        candidates=len(actions.actions), text_candidates=len(admissible),
                        selected_id=decision.candidate_id, accepted=accepted,
                        choice=decision.choice)
        if accepted:
            return decision
        return await self._choose_visual(goal, snapshot, actions, context, fallback=True)
