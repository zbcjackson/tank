"""Offline rule replay only. Captured visual choices are not hypothetical Jev answers."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import socket

ROOT = Path(__file__).parent
REPO = Path('/Users/zbcjackson/src/tank')
SOURCE = Path('/private/tmp/tank-jev-route-analysis-20261023')
OUT = ROOT / 'admission-analysis-v1'

def deny(*args, **kwargs):
    raise AssertionError('offline rule replay forbids network')
socket.getaddrinfo = deny
socket.socket.connect = deny
socket.socket.connect_ex = deny

from agent_computer_use.action_builder import duplicate_text_target_ids
from agent_computer_use.contracts import Action, ActionDetails, ActionSet, Binding, Fact, ValueChange
from benchmarks.computer_use.jev_action_admission import text_candidate_ids

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

manifest_path = REPO / 'docs/research/artifacts/jev-calibration-route-analysis-20261023-manifest.json'
manifest = json.loads(manifest_path.read_text())
assert sha(manifest_path.with_name(manifest['archive'])) == manifest['sha256']
assert manifest['sha256'] == '68e6ec113c70fe90c018710e4dde83232965d81906913df5d65b3345650756cf'
# Stage byte-bound copies once; subsequent runs read only these copies.
inputs = ROOT / 'inputs'
inputs.mkdir(exist_ok=True)
bindings = {}
def stage(member, target):
    original = SOURCE / member
    expected = manifest['entries'][member]['sha256']
    assert sha(original) == expected
    path = inputs / target
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.hardlink_to(original)
    assert sha(path) == expected
    bindings[target] = {'archive_member': member, 'sha256': expected}
    return path

raw = json.loads(stage('inputs/live/result.json', 'result.json').read_text())
baseline = json.loads(stage('derived-v2/analysis.json', 'baseline-analysis.json').read_text())
old_steps = {(s['trial_id'], s['observation_id']): s for s in baseline['steps']}
steps, candidates = [], []
seen = set()
for trial in raw['rows']:
    journal = [json.loads(line) for line in stage(
        f"inputs/live/{trial['id']}/calls.jsonl", f"{trial['id']}/calls.jsonl").read_text().splitlines()]
    responses = {r['call_id']: r['response'] for r in journal if 'response' in r}
    routes = {e['observation_id']: e for e in trial['events'] if e['kind'] == 'computer_use_route'}
    for request in trial['calls']:
        body = request['request']
        peer = 'messages' in body
        packet = json.loads(body['messages'][1]['content'][0]['text']) if peer else body
        state = packet['state']
        key = (trial['id'], state['snapshot']['observation_id'])
        if key in seen:
            continue  # Original same-state text-control/visual fallback is one route step.
        seen.add(key)
        prior = old_steps[key]
        options = packet['questions']['next_action']['criteria']
        offered = {alias: candidate for alias, candidate in options.items() if alias.startswith('c')}
        assert list(offered) == [f'c{i}' for i in range(1, len(offered) + 1)]
        before = canonical(packet)
        actions = []
        details = []
        for alias, value in offered.items():
            actions.append(Action(alias, value['target_ref'], value['operation'], value['value']))
            changes = tuple(ValueChange(**state['value_change_checks'][ref])
                            for ref in value.get('change_refs', []))
            details.append(ActionDetails(alias, value['role'], value['label'],
                tuple(tuple(a) for a in value['ancestors']), value['current_value'], value['input_key'],
                tuple(Fact(**f) for f in value['effect']), changes))
        action_set = ActionSet(Binding(**state['binding']), tuple(actions), prior['route_reason'],
                               len(actions), details=tuple(details))
        assert action_set.binding.observation_id == key[1]
        assert routes[key[1]]['reason'] == prior['route_reason']
        duplicates = duplicate_text_target_ids(action_set.details)
        admissible = text_candidate_ids(action_set)
        expected_old = 'jev_eligible' if len(admissible) == len(actions) else 'visual_required'
        assert expected_old == prior['route_reason'], key
        response = responses[request['call_id']]
        choice = (json.loads(response['choices'][0]['message']['content'])['choice'] if peer
                  else response['choice'])
        row = {name: prior[name] for name in ('trial_id', 'case', 'cluster_id', 'product',
               'condition', 'scenario', 'positive', 'arm', 'observation_id', 'page_phase', 'page_path')}
        row.update(old_reason=prior['route_reason'], candidate_count=len(actions),
                   text_candidate_count=len(admissible), blocked_candidate_count=len(actions)-len(admissible),
                   text_attempt_possible=bool(admissible),
                   newly_text_attempt_possible=prior['route_reason']=='visual_required' and bool(admissible),
                   legacy_first_call_id=request['call_id'], legacy_first_provider='visual' if peer else 'jev',
                   legacy_first_choice=choice, legacy_choice_in_candidates=choice in offered,
                   legacy_choice_passes_text_guard=choice in admissible,
                   packet_sha256=hashlib.sha256(before.encode()).hexdigest(),
                   offline_alias_ids_only=True)
        steps.append(row)
        for alias, value in offered.items():
            candidates.append({**{k: row[k] for k in ('trial_id', 'observation_id', 'product',
                               'condition', 'positive', 'arm', 'page_phase')},
                               'alias': alias, 'text_admissible': alias in admissible,
                               'duplicate_text_target': alias in duplicates,
                               'generic_label': not value['label'].strip() or value['label']==value['role'],
                               'captured_candidate': value})
        assert before == canonical(packet), key
assert len(raw['rows']) == 96 and len(steps) == len(old_steps) == 336
assert sum(s['old_reason']=='jev_eligible' for s in steps) == 116
assert sum(s['old_reason']=='visual_required' for s in steps) == 220
assert len(seen) == len(steps)

def aggregate(rows):
    visual = [s for s in rows if s['old_reason']=='visual_required']
    return {'steps': len(rows), 'old_text_eligible_steps': sum(s['old_reason']=='jev_eligible' for s in rows),
            'text_attempt_possible_steps': sum(s['text_attempt_possible'] for s in rows),
            'new_text_attempt_possible_steps': sum(s['newly_text_attempt_possible'] for s in rows),
            'old_visual_required_steps': len(visual),
            'old_visual_choice_passes_text_guard': sum(s['legacy_choice_passes_text_guard'] for s in visual),
            'old_visual_choice_blocked_or_control': sum(not s['legacy_choice_passes_text_guard'] for s in visual),
            'candidates': sum(s['candidate_count'] for s in rows),
            'text_candidates': sum(s['text_candidate_count'] for s in rows)}

strata = []
for product in ('sqlite-web','linkding'):
    for arm in ('v','jt'):
        rows = [s for s in steps if s['product']==product and s['arm']==arm]
        strata.append({'product':product,'arm':arm,'phase':'all', **aggregate(rows)})
        for phase in sorted({s['page_phase'] for s in rows}):
            strata.append({'product':product,'arm':arm,'phase':phase,
                           **aggregate([s for s in rows if s['page_phase']==phase])})
summary = {'source_trials':96,'seed_clusters':24,'matched_conditions':48,
           'scope':'Offline mechanical rule replay; observed visual choice compatibility is not a new Jev prediction or quality/latency measurement.',
           'all':aggregate(steps), 'jt':aggregate([s for s in steps if s['arm']=='jt']), 'strata':strata,
           'new_model_or_asr_requests':0, 'network_attempts':0,'packet_mutations':0,
           'metadata':'Reconstructed action IDs use captured model aliases solely for classification; no executable action binding or GUI dispatch is reconstructed.',
           'limits':['Potential text attempts may still choose an ambiguous/wrong action or abstain.',
                     'A unique target is not proof that the action fits the goal.',
                     'Additional Jev calls may add latency on steps that still require visual.',
                     'V eligibility is a common guard observation; V never calls Jev.']}
OUT.mkdir(exist_ok=False)
for name, value in [('summary',summary),('steps',steps),('candidates',candidates),('strata',strata)]:
    (OUT/f'{name}.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
for name, rows in [('steps',steps),('candidates',candidates),('strata',strata)]:
    with (OUT/f'{name}.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader()
        for row in rows:writer.writerow({k:canonical(v) if isinstance(v,(dict,list)) else v for k,v in row.items()})
(ROOT/'source-member-bindings.json').write_text(json.dumps({'archive':manifest['archive'],
    'archive_sha256':manifest['sha256'],'members':bindings},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
