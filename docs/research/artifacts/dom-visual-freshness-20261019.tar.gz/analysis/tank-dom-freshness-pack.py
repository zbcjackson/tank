import hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank');artifacts=root/'docs/research/artifacts';sha=lambda b:hashlib.sha256(b).hexdigest()
old={}
for p in sorted(artifacts.glob('jev-*-manifest.json')):
 tracked=subprocess.run(['git','show','3ee33eb4:'+str(p.relative_to(root))],cwd=root,check=True,capture_output=True).stdout
 assert tracked==p.read_bytes()
 m=json.loads(tracked);archive=p.with_name(p.name.replace('-manifest.json','.tar.gz'))
 assert sha(archive.read_bytes())==m['archive_sha256'];old[archive.name]=m['archive_sha256']
assert len(old)==9
files={}
for phase in ('before','after'):
 p=Path('/private/tmp/tank-dom-freshness-'+phase+'-20261019')
 for q in p.rglob('*'):
  if q.is_file():files[phase+'/'+str(q.relative_to(p))]=q
 p=Path('/private/tmp/tank-dom-freshness-source-'+phase+'-20261019')
 for q in p.rglob('*'):
  if q.is_file():files['source-'+phase+'/'+str(q.relative_to(p))]=q
for n in ('analyze.py','summary.json','pack.py'):
 p=Path('/private/tmp/tank-dom-freshness-'+n);files['analysis/'+p.name]=p
for p in sorted(Path('/private/tmp').glob('tank-dom-freshness-*.log')):files['verification/'+p.name]=p
files['verification/navigation-trace.jsonl']=Path('/private/tmp/tank-dom-freshness-navigation-trace.jsonl')
files['verification/pw-nav-probe.py']=Path('/private/tmp/pw_nav_probe.py')
values={**dotenv_values(root/'backend/core/.env'),**os.environ};secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)]
for name,p in files.items():assert not any(s in p.read_bytes()for s in secrets),name
archive=artifacts/'dom-visual-freshness-20261019.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tf:
 for n,p in sorted(files.items()):tf.add(p,arcname=n,recursive=False)
manifest={'date':'2026-10-19','baseline_commit':'3ee33eb4','plan_commit':'54ddfb47','implementation_commit':'c70bc305','source_binding':'exact before/after source bytes match respective freeze hashes',
 'archive_sha256':sha(archive.read_bytes()),'old_archives_unchanged':old,'credential_values_scanned':len(secrets),
 'files':{n:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for n,p in sorted(files.items())}}
with tarfile.open(archive,'r:gz')as tf:
 assert set(tf.getnames())==set(files)
 for m in tf.getmembers():
  data=tf.extractfile(m).read();assert sha(data)==manifest['files'][m.name]['sha256']and len(data)==manifest['files'][m.name]['bytes']
archive.with_name('dom-visual-freshness-20261019-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'old_archives':len(old),'credential_values':len(secrets)}))
