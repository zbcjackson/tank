"""Independent PNG/hash/refusal checks, using preserved before/after source bytes."""
import hashlib,json,sys
from pathlib import Path
from PIL import Image,ImageChops
h=lambda b:hashlib.sha256(b).hexdigest()
summary={'phases':[],'checks':[],'models':0,'task_inputs':0}
for phase in ('before','after'):
 root=Path('/private/tmp/tank-dom-freshness-'+phase+'-20261019');src=Path('/private/tmp/tank-dom-freshness-source-'+phase+'-20261019')
 f=json.loads((root/'freeze.json').read_text());r=json.loads((root/'result.json').read_text());assert r['model_calls']==r['task_inputs']==0
 assert len(r['contexts'])==6 and len(r['checks'])==48
 assert all(h((src/n).read_bytes())==v for n,v in f['source_sha256'].items())
 assert all(c['cleanup_confirmed']and not c['cleanup_errors']for c in r['contexts'])
 assert len({c['id']for c in r['contexts']})==6
 for context in r['contexts']:
  assert len(context['frames'])==9
  folder=root/context['id'];expected=folder/context['initial_frame']['path'];assert h(expected.read_bytes())==context['initial_frame']['sha256']
  checks=[c for c in r['checks']if c['context']==context['id']];assert len(checks)==8
  assert [c['scheduled_seconds']for c in checks]==f['delays_seconds']
  for index,c in enumerate(checks,1):
   image=folder/c['frame']['path'];assert c['frame']==context['frames'][index]
   assert h(image.read_bytes())==c['current_sha256']==c['frame']['sha256']
   assert c['expected_sha256']==context['initial_frame']['sha256']
   assert c['current']==(c['expected_sha256']==c['current_sha256'])
   assert c['dom_unchanged']
   with Image.open(expected)as a,Image.open(image)as b:
    diff=ImageChops.difference(a.convert('RGB'),b.convert('RGB'));bbox=diff.getbbox();colors=diff.getcolors(diff.width*diff.height);assert colors is not None
    changed=sum(count for count,color in colors if color!=(0,0,0))
   assert (list(bbox)if bbox else None)==c['diff_bbox']and changed==c['changed_pixels']
   if c['current']:assert not c['refusals']and changed==0
   else:
    assert len(c['refusals'])==1;event=c['refusals'][0]
    assert event['stage']=='frame_scene'and event['channel']=='dom'
    assert event['expected_sha256']==c['expected_sha256']and event['current_sha256']==c['current_sha256']
    assert event['action_id']=='save'and event['observation_id']==context['snapshot']['observation_id']
    assert changed==23 and bbox[2]-bbox[0]==1 and bbox[3]-bbox[1]==23
   summary['checks'].append({'phase':phase,**c})
 stats=[{'phase':phase,'policy':policy,'checks':16,'passed':sum(c['current']for c in r['checks']if c['policy']==policy),'refused':sum(not c['current']for c in r['checks']if c['policy']==policy)}for policy in ('initial','hide','production')]
 summary['phases'].extend(stats)
 summary[phase+'_browsers']=sorted({c['browser_version']for c in r['contexts']})
 assert len(list(root.glob('*/*.png')))==54
summary['cleanup_contexts']=12;summary['pngs']=108
Path(sys.argv[1]).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='checks'},indent=2))
