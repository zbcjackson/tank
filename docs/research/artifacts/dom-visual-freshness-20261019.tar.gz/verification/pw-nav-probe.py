import asyncio,json,time
from pathlib import Path
import pytest

@pytest.fixture(autouse=True)
def nav_probe(monkeypatch):
    from playwright.async_api import Page
    original=Page.goto
    async def goto(self,url,*args,**kwargs):
        if not url.startswith('http://127.0.0.1:'):
            return await original(self,url,*args,**kwargs)
        start=time.monotonic();events=[];handlers=[]
        def attach(name,fn):
            self.on(name,fn);handlers.append((name,fn))
        attach('request',lambda q:events.append({'event':'request','t':time.monotonic()-start,'url':q.url}))
        attach('response',lambda q:events.append({'event':'response','t':time.monotonic()-start,'status':q.status,'url':q.url}))
        attach('requestfinished',lambda q:events.append({'event':'finished','t':time.monotonic()-start,'url':q.url}))
        attach('requestfailed',lambda q:events.append({'event':'failed','t':time.monotonic()-start,'url':q.url,'failure':q.failure}))
        attach('domcontentloaded',lambda:events.append({'event':'domcontentloaded','t':time.monotonic()-start}))
        attach('load',lambda:events.append({'event':'load','t':time.monotonic()-start}))
        record={'url':url,'options':kwargs,'events':events}
        try:
            response=await original(self,url,*args,**kwargs);record['result']='returned';return response
        except Exception as exc:
            record['error']=str(exc)
            try:
                record['page']=await asyncio.wait_for(self.evaluate("""() => ({ready:document.readyState,url:location.href,nav:performance.getEntriesByType('navigation').map(n=>({responseStart:n.responseStart,domContentLoaded:n.domContentLoadedEventEnd,load:n.loadEventEnd}))})"""),1)
            except Exception as secondary:record['probe_error']=type(secondary).__name__
            raise
        finally:
            record['elapsed']=time.monotonic()-start
            for name,fn in handlers:self.remove_listener(name,fn)
            with Path('/private/tmp/tank-dom-freshness-navigation-trace.jsonl').open('a')as f:f.write(json.dumps(record)+'\n')
    monkeypatch.setattr(Page,'goto',goto)
