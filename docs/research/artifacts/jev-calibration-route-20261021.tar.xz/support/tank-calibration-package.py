"""Preserve calibration phases; deduplicate verified, unchanged app source only."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile

from dotenv import dotenv_values

REPO = Path('/Users/zbcjackson/src/tank')
TMP = Path('/private/tmp')
sha = lambda data: hashlib.sha256(data).hexdigest()
roots = {
    'fake-prototype': TMP/'tank-calibration-fake-pytest-20261021-v1/test_calibration_all_96_trials0/calibration',
    'fake-first-full': TMP/'tank-calibration-full-pytest-20261021-final/test_calibration_all_96_trials0/calibration',
    'fake-final-full': TMP/'tank-calibration-full-pytest-20261021-final-v2/test_calibration_all_96_trials0/calibration',
    'qualification-before-r1': TMP/'tank-calibration-qualification-20261021-reviewed',
    'qualification-r1': TMP/'tank-calibration-qualification-20261021-r1',
    'fake-r1': TMP/'tank-calibration-r1-full-pytest/test_calibration_all_96_trials0/calibration',
    'live': TMP/'tank-calibration-live-20261021-r1',
}
red_roots = json.loads((TMP/'tank-calibration-r1-regression-preservation.json').read_text())
for row in red_roots:
    copied = Path(row['copy'])
    roots['r1-regression/'+str(copied.relative_to(TMP/'tank-calibration-r1-regression-raw'))] = copied
items = {}
inventory = {}
expected = None
source_root = None

def add(path, name):
    assert name not in items, name
    items[name] = path

for label, root in roots.items():
    assert root.is_dir(), str(root)
    freeze = root/('calibration/freeze.json' if label.startswith('r1-regression/') else
                  'qualification-freeze.json' if label.startswith('qualification') else 'freeze.json')
    f = json.loads(freeze.read_text())
    manifest = f['apps']['linkding']['source_files']
    assert expected is None or manifest == expected
    expected = manifest
    source_root = Path(f['apps']['linkding']['root'])
    for app in root.glob('**/app'):
        if not app.is_dir():
            continue
        sources = {str(p.relative_to(app)): sha(p.read_bytes()) for p in app.rglob('*')
                   if p.is_file() and not set(p.relative_to(app).parts) & {'data', '__pycache__'} and p.suffix != '.pyc'}
        assert sources == manifest, str(app)
        inventory[label+'/'+str(app.relative_to(root))] = sources
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if '__pycache__' in relative.parts or path.suffix == '.pyc':
            continue
        if 'app' in relative.parts:
            after = relative.parts[relative.parts.index('app')+1:]
            if not after or after[0] != 'data':
                continue
        add(path, label+'/'+str(relative))

assert expected is not None and source_root is not None
for name, digest in sorted(expected.items()):
    path = source_root/name
    assert sha(path.read_bytes()) == digest
    add(path, 'official-linkding-source/'+name)

for path in sorted(TMP.glob('tank-calibration-*')):
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.patch'} and path.name != 'tank-calibration-package.log':
        add(path, 'support/'+path.name)
canvas = Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-calibration-route.canvas.tsx')
add(canvas, 'presentation/'+canvas.name)

old = json.loads((TMP/'tank-calibration-old-artifacts.json').read_text())
assert len(old) == 38
assert all(sha((REPO/name).read_bytes()) == value['sha256'] for name, value in old.items())
values = {**dotenv_values(REPO/'backend/core/.env'), **os.environ}
credentials = {v.encode() for k,v in values.items() if v and len(v) >= 8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)', k, re.I)}
assert len(credentials) == 21
extra = {
    'verification/product-source-copy-inventory.json': (json.dumps(inventory, indent=2)+'\n').encode(),
    'verification/preservation.json': (json.dumps({
        'old_archive_manifest_files':len(old), 'old_files_unchanged':True,
        'source_copies_deduplicated':len(inventory),
        'deduplication':'Each unchanged per-trial app source is represented by its complete hash inventory plus one 446-file official source set. All per-trial app/data files, physical before/after DB, HTTP, PNG, SDK/audit/usage and failed phases are retained; byte-identical members use tar hardlinks. Each regular member is read back and hashed; each hardlink resolves to an already verified regular member. Generated __pycache__/pyc are excluded.',
        'linkding_environment':'Pinned environment hash inventory in every freeze; original environment bytes remain in immutable jev-linkding-route-20261020.tar.gz.',
        'actual_credentials_scanned':len(credentials), 'credential_matches':0,
    },indent=2)+'\n').encode(),
}
members = []
for name in sorted(set(items)|set(extra)):
    data = extra[name] if name in extra else items[name].read_bytes()
    assert not any(value in data for value in credentials), name
    members.append({'name':name,'bytes':len(data),'sha256':sha(data)})

target = REPO/'docs/research/artifacts/jev-calibration-route-20261021.tar.gz'
manifest_path = target.with_name('jev-calibration-route-20261021-manifest.json')
assert not target.exists() and not manifest_path.exists()
with target.open('xb') as stream, gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed,mode='w') as archive:
    stored = {}
    for member in members:
        name = member['name']
        data = extra[name] if name in extra else items[name].read_bytes()
        assert sha(data) == member['sha256'], name
        info = tarfile.TarInfo(name)
        info.mode=0o644; info.mtime=0
        key = (member['sha256'],member['bytes'])
        if key in stored:
            info.type=tarfile.LNKTYPE; info.linkname=stored[key]
            member['hardlink_to']=stored[key]
            archive.addfile(info)
        else:
            stored[key]=name
            info.size=len(data)
            archive.addfile(info,io.BytesIO(data))
with tarfile.open(target,mode='r|gz') as archive:
    verified = {}
    count = 0
    for actual in archive:
        member = members[count]
        assert actual.name == member['name']
        if actual.islnk():
            assert actual.linkname == member['hardlink_to']
            assert verified[actual.linkname] == (member['bytes'],member['sha256'])
        else:
            stream = archive.extractfile(actual)
            assert stream is not None
            data = stream.read()
            assert len(data) == member['bytes'] and sha(data) == member['sha256']
            assert not any(value in data for value in credentials), member['name']
        verified[actual.name] = (member['bytes'],member['sha256'])
        count += 1
    assert count == len(members)
manifest = {'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),
            'baseline':'9ee84cde','old_archive_manifest_files':len(old),
            'actual_credentials_scanned':len(credentials),'credential_matches':0,
            'source_copies_deduplicated':len(inventory),
            'byte_identical_hardlinks':sum('hardlink_to' in m for m in members),'members':members}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
print('members',len(members))
