"""Render final audited calibration data inline; no browser fetch or invented evidence."""
import base64
import json
from pathlib import Path

root=Path('/private/tmp/tank-calibration-live-20261021-r1')
audit=json.loads(Path('/private/tmp/tank-calibration-live-independent.json').read_text())
diagnostics=json.loads(Path('/private/tmp/tank-calibration-diagnostics.json').read_text())
assert audit['mode']=='live' and audit['sha256']==diagnostics['sha256']
assert len(audit['arms'])==2 and {a['arm'] for a in audit['arms']}=={'v','jt'}
rows=[]
for r in audit['rows']:
    calls=[c for c in r['calls'] if c['attempted']]
    rows.append({'id':r['id'],'product':r['product'],'condition':r['condition'],'group':r['group'],'arm':r['arm'],
        'positive':r['positive'],'success':r['strict'] if r['positive'] else r['negative_passed'],
        'status':r['status'],'elapsed':r.get('elapsed_ms',None),'capped':r['capped_ms'],
        'cleanup':r['cleanup'],'calls':len(calls),'images':sum(c['image'] for c in calls),
        'jev':sum(c['model']=='jev' for c in calls),'fallbacks':sum(bool(c['fallback_from']) for c in calls),
        'reason':r.get('reason') or r['status']})
gallery=[]
for product in ('sqlite-web','linkding'):
    choices=[r for r in audit['rows'] if r['product']==product and r['positive'] and r['strict'] and (root/r['id']/'final.png').exists()]
    if choices:
        selected=next((r for r in choices if r['arm']=='jt'),choices[0])
        path=root/selected['id']/'final.png'
        gallery.append({'id':selected['id'],'product':product,'image':'data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()})
data={'rows':rows,'arms':audit['arms'],'clusters':audit['clusters'],'gallery':gallery,
    'calls':audit['SDK_calls'],'images':audit['image_calls'],'tokens':audit['known_tokens'],
    'unknown':len(audit['unknown_calls']),'cleanup':audit['cleanup'],'stop':audit['stop_reason'],
    'fallbacks':len(audit['fallbacks']),'controls':audit['controls'],
    'digest':audit['sha256'],'negativeBounds':diagnostics['negative_cluster_bounds'],
    'models':diagnostics['models'],'served':diagnostics['served_model_fields']}
template=r'''import { Stack, Row, H1, H2, Text, Stat, Table, Select, Callout, BarChart, useState, useHostTheme } from "cursor/canvas";
type Trial={id:string;product:string;condition:string;group:string;arm:string;positive:boolean;success:boolean;status:string;elapsed:number|null;capped:number;cleanup:boolean;calls:number;images:number;jev:number;fallbacks:number;reason:string};
type Arm={arm:string;positive_planned:number;positive_strict:number;negative_planned:number;negative_passed:number;mean_capped_s:number;median_capped_s:number;p95_capped_s:number;SDK_calls:number;image_calls:number;known_tokens:number;estimate_usd:string|null;reported_peer_cost_usd:string|null};
type Cluster={id:string;product:string;v_s:number;jt_s:number;difference_s:number;v_all_success:boolean;jt_all_success:boolean};
type Bound={arm:string;negative_seed_clusters:number;clusters_with_any_incorrect_exit:number;one_sided_95_upper_under_IID_seed_assumption:number};
type Model={model:string;SDK_calls:number;SDK_timing_including_network_service:{n:number;mean_s:number;median_s:number;p95_s:number}|null;invalid_response:number;control_choices:Record<string,number>};
const DATA:{rows:Trial[];arms:Arm[];clusters:Cluster[];gallery:{id:string;product:string;image:string}[];calls:number;images:number;tokens:number;unknown:number;cleanup:number;stop:string|null;fallbacks:number;controls:{call_id:string;choice:string;model:string}[];digest:string;negativeBounds:Bound[];models:Model[];served:Record<string,number>}=__DATA__;
const names:Record<string,string>={v:"V · Gemini图片",jt:"JT · Jev文本＋Gemini图片"};
const seconds=(v:number|null)=>v===null?"未执行":(v/1000).toFixed(2);
export default function CalibrationRoute(){
 const theme=useHostTheme();const [product,setProduct]=useState("all");const [condition,setCondition]=useState("all");const [group,setGroup]=useState("all");const [arm,setArm]=useState("all");const [outcome,setOutcome]=useState("all");const [selectedImage,setSelectedImage]=useState(DATA.gallery[0]?.id??"");
 const rows=DATA.rows.filter(r=>(product==="all"||r.product===product)&&(condition==="all"||r.condition===condition)&&(group==="all"||r.group===group)&&(arm==="all"||r.arm===arm)&&(outcome==="all"||(outcome==="pass"?r.success:!r.success)));
 const image=DATA.gallery.find(r=>r.id===selectedImage)??DATA.gallery[0];
 const failureCount=DATA.rows.filter(r=>!r.success).length;const v=DATA.arms.find(r=>r.arm==="v")!;const jt=DATA.arms.find(r=>r.arm==="jt")!;
 return <Stack gap={24} style={{maxWidth:1180,margin:"0 auto",padding:24,background:theme.bg.editor,color:theme.text.primary}}>
 <Stack gap={8}><Text size="small" tone="secondary">2026-10-21 · 原版 sqlite-web / linkding · 真实模型校准</Text><H1>JT {jt.positive_strict}/{jt.positive_planned}，V {v.positive_strict}/{v.positive_planned}：四行真实校准</H1><Text>预先冻结24个seed、两启动条件、两臂，共96项。80项正例和16项负例分列；失败不补跑。当前是校准，正式确认N仍未冻结。冷条件使用新fixture/server；预热仅增加本地GET，两者均为新浏览器上下文，供应方及系统缓存不受控。</Text></Stack>
 <Row gap={32} wrap><Stat value={`${jt.positive_strict}/${jt.positive_planned}`} label="JT正例严格完成"/><Stat value={`${v.positive_strict}/${v.positive_planned}`} label="V正例严格完成"/><Stat value={`${DATA.rows.filter(r=>!r.positive&&r.success).length}/16`} label="负例正确退出"/><Stat value={`${DATA.cleanup}/96`} label="清理确认"/></Row>
 <Callout tone={DATA.stop||failureCount?"warning":"info"}>{DATA.stop?`批次停止：${DATA.stop}。未执行项仍保留在96项分母；本图不把早停当作速度收益。`:`完整批次结束；共${failureCount}项未通过对应验收。正例速度使用全部80项，失败/未执行按120秒封顶。`} 参考视觉模型固定为Gemini 3.8 Flash；JT的Jev 1.14只读取文字；需要图片的可用候选由同一Gemini通道处理，直接视觉路径与文本控制后的兜底分别核账。本轮没有Jev图片/Box生成。</Callout>
 <Stack gap={8}><H2>两臂质量、时间与资源：全批次</H2><Table headers={["策略","正例严格完成","负例正确退出","封顶均时(s)","中位数 / p95(s)","SDK / 图片","已知tokens","冻结费率估算(USD)"]} rows={DATA.arms.map(r=>[names[r.arm],`${r.positive_strict}/${r.positive_planned}`,`${r.negative_passed}/${r.negative_planned}`,r.mean_capped_s.toFixed(2),`${r.median_capped_s.toFixed(2)} / ${r.p95_capped_s.toFixed(2)}`,`${r.SDK_calls} / ${r.image_calls}`,r.known_tokens.toLocaleString(),r.estimate_usd===null?"用量未定":Number(r.estimate_usd).toFixed(6)])}/><Text size="small" tone="secondary">时间从fixture设置前开始，包含本地预热、动作、清理和业务回读；回执序列化、离线分析及批次前置冻结核验在任务时钟外。全部正例失败按120秒计；负例不混入均时。费用是冻结历史费率×已知tokens，包含失败和恢复调用；不是Jev账单或供应方发票，未知用量不视为免费。</Text></Stack>
 <Stack gap={8}><H2>按产品看，收益不一致</H2><Table headers={["产品","策略","正例严格完成","封顶均时(s)","全场景SDK / 图片 / Jev"]} rows={["sqlite-web","linkding"].flatMap(p=>["v","jt"].map(a=>{const all=DATA.rows.filter(r=>r.product===p&&r.arm===a);const pos=all.filter(r=>r.positive);return [p,names[a],`${pos.filter(r=>r.success).length}/${pos.length}`,(pos.reduce((sum,r)=>sum+r.capped,0)/pos.length/1000).toFixed(2),`${all.reduce((sum,r)=>sum+r.calls,0)} / ${all.reduce((sum,r)=>sum+r.images,0)} / ${all.reduce((sum,r)=>sum+r.jev,0)}`]}))}/><Text size="small" tone="secondary">每产品每臂20项正例（10个seed×两启动条件）。整体平均不代表每个产品都有速度收益；两款固定应用和布局不能外推为通用视觉能力结论。</Text></Stack>
 <Stack gap={8}><H2>正例封顶完成耗时均值（秒）</H2><Text size="small" tone="secondary">横轴：策略；纵轴：秒。每臂40项正例；同一seed的冷/预热条件保持相关。</Text><BarChart categories={DATA.arms.map(r=>names[r.arm])} series={[{name:"全部正例封顶均值（秒）",data:DATA.arms.map(r=>r.mean_capped_s),tone:"info"}]} height={230} valueSuffix=" s" showValues/><Text size="small" tone="tertiary">来源：本批次真实SDK回执、独立物理DB/UI/HTTP核验；2026-10-21。仅描述校准数据，未作正式采用或非劣确认。</Text></Stack>
 <Stack gap={8}><H2>实际模型参与与异常回复</H2><Table headers={["模型通道","SDK次数","SDK均值 / 中位数(s)","SDK p95(s)","无效回复","控制选项"]} rows={DATA.models.map(r=>[r.model==="jev"?"Jev文本":"Gemini图片",r.SDK_calls,r.SDK_timing_including_network_service?`${r.SDK_timing_including_network_service.mean_s.toFixed(2)} / ${r.SDK_timing_including_network_service.median_s.toFixed(2)}`:"未记录",r.SDK_timing_including_network_service?.p95_s.toFixed(2)??"未记录",r.invalid_response,Object.entries(r.control_choices).map(([k,v])=>`${k}: ${v}`).join("；")||"无"])} /><Text>共{DATA.images}次图片调用，{DATA.fallbacks}次同一绑定的文本控制选项→图片兜底。SDK耗时包含网络与供应方服务，不是模型内部推理时间；不同通道承担的页面和任务不同，不能直接当作同题视觉能力对照。</Text><Text size="small" tone="secondary">请求固定profile；响应model字段：{Object.entries(DATA.served).map(([k,v])=>`${k} (${v})`).join("；")||"供应方未返回model字段"}。图片固定1280×720，候选bounds由宿主DOM取得，位置有效性已逐张核验。</Text></Stack>
 <Stack gap={8}><H2>全部96项明细</H2><Row gap={8} wrap><Select value={product} onChange={setProduct} options={[{value:"all",label:"两个产品"},...Array.from(new Set(DATA.rows.map(r=>r.product))).map(value=>({value,label:value}))]}/><Select value={condition} onChange={setCondition} options={[{value:"all",label:"两启动条件"},{value:"cold",label:"冷启动"},{value:"prewarmed",label:"本地预热"}]}/><Select value={group} onChange={setGroup} options={[{value:"all",label:"全部场景"},{value:"normal",label:"正常"},{value:"recovery",label:"已标定GET恢复"},{value:"negative",label:"预注册负例"}]}/><Select value={arm} onChange={setArm} options={[{value:"all",label:"两策略"},{value:"v",label:"V"},{value:"jt",label:"JT"}]}/><Select value={outcome} onChange={setOutcome} options={[{value:"all",label:"所有结果"},...(DATA.rows.some(r=>r.success)?[{value:"pass",label:"通过验收"}]:[]),...(failureCount?[{value:"fail",label:"未通过验收"}]:[])]}/></Row>
 {rows.length>0&&<Table headers={["任务","验收","实际耗时(s)","正例封顶(s)","SDK/图/Jev","兜底","清理","退出原因"]} rows={rows.map(r=>[r.id,r.success?"通过":r.status==="not_run"?"未执行":"未通过",seconds(r.elapsed),r.positive?seconds(r.capped):"负例单列",`${r.calls}/${r.images}/${r.jev}`,r.fallbacks,r.cleanup?"确认":"未确认",r.reason])} rowTone={rows.map(r=>r.success?undefined:"warning")}/>}<Text size="small" tone="tertiary">筛选仅作用明细。无论筛选结果如何，全批次分母始终为96；成功须DB全部字段/记录、正确编辑器历史、实际返回列表、路径约束及清理均通过。负例撤权由宿主派发守卫执行，不等于模型主动识别授权变化。</Text></Stack>
 <Stack gap={8}><H2>20个正例seed的配对均时</H2><Table headers={["seed / 产品","V均时(s)","JT均时(s)","JT−V(s)","两条件均成功：V/JT"]} rows={DATA.clusters.map(r=>[r.id,r.v_s.toFixed(2),r.jt_s.toFixed(2),r.difference_s.toFixed(2),`${r.v_all_success?"是":"否"} / ${r.jt_all_success?"是":"否"}`])}/><Text size="small" tone="secondary">每行先在同一seed的冷/预热条件内取均值，再保留V/JT配对；失败仍按120秒封顶。24个seed＝20正例＋4负例，不能把96次执行当作96个独立样本。</Text></Stack>
 {image&&<Stack gap={8}><H2>实际执行后的返回列表</H2><Select value={image.id} onChange={setSelectedImage} options={DATA.gallery.map(r=>({value:r.id,label:r.id}))}/><img src={image.image} alt={`${image.id} 真实返回列表`} style={{display:"block",width:"100%",height:"auto",border:`1px solid ${theme.stroke.secondary}`}}/><Text size="small" tone="secondary">{image.id} · 原始1280×720 PNG按比例展示。完整图片、对应候选bounds、前后物理DB、HTTP及SDK原文均在逐成员哈希归档中。</Text></Stack>}
 <Stack gap={8}><H2>资格、模拟与真实结果分开解释</H2><Text>执行前无模型资格24/24、104/104图片；真实Controller＋模拟SDK矩阵为80正例/16负例通过、96清理。完整后端6528通过/1跳过，E2E21场景83步骤通过，R1修复完成。模拟用量/速度不参与上面的真实模型结果。</Text><Text>负例每臂只有4个独立seed，两启动条件不拆簇：{DATA.negativeBounds.map(r=>`${r.arm.toUpperCase()}有${r.clusters_with_any_incorrect_exit}/${r.negative_seed_clusters}簇出现至少一次错误退出，若假设seed独立同分布，单侧95%坏簇率上界${(100*r.one_sided_95_upper_under_IID_seed_assumption).toFixed(1)}%`).join("；")}。这些是选定合成案例，不能当作部署风险保证。</Text><Text>下一步用配对cluster方差、质量discordance及全部采用门核算正式N，冻结新的holdout和主终点；当前24个seed不进入正式确认，生产默认保持原样。</Text><Text size="small" tone="tertiary">执行冻结SHA256：{DATA.digest}。来源：live/result.json、calls/audit/spend、before/after DB、PNG、冻结任务及无宿主评分器导入的独立分析。</Text></Stack>
 </Stack>;
}
'''
target=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-calibration-route.canvas.tsx')
assert not target.exists()
target.write_text(template.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':'))))
print('canvas',str(target),'bytes',target.stat().st_size)
