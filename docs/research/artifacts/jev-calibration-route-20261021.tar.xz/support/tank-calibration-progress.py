"""Read-only progress; final scoring uses the independent audit."""
from pathlib import Path
import json
from collections import Counter

path=Path('/private/tmp/tank-calibration-live-20261021-r1/result.json')
try:
    result=json.loads(path.read_text())
except json.JSONDecodeError:
    print('result write in progress')
else:
    rows=result['rows'];finished=[r for r in rows if r['status']=='finished']
    print(json.dumps({'status':dict(Counter(r['status'] for r in rows)),
        'positive_strict':sum(r['strict_completed'] for r in finished),
        'negative_passed':sum(r.get('negative_passed',False) for r in finished),
        'cleanup':sum(r.get('cleanup_confirmed',False) for r in rows),
        'started':[r['id'] for r in rows if r['status']=='started'],
        'failures':[{'id':r['id'],'reason':r.get('result',{}).get('reason'),'error_type':r.get('error_type')} for r in finished if not r.get('calibration_success')],
        'stop_reason':result['spend']['stop_reason'],
        'known_tokens':result['spend']['batch']['known_tokens']},ensure_ascii=False))
