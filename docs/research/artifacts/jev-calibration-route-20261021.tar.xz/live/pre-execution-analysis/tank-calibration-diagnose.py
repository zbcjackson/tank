"""Descriptive calibration breakdowns; repeated conditions remain within seed clusters."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

root, independent_path, output = map(Path, sys.argv[1:])
freeze = json.loads((root/'freeze.json').read_text())
independent = json.loads(independent_path.read_text())
raw = json.loads((root/'result.json').read_text())
assert independent['mode'] == 'live'
assert independent['sha256'] == raw['sha256'] == freeze['sha256']
assert len(independent['rows']) == len(raw['rows']) == 96
cases = {c['id']:c for c in freeze['cases']}
rows = independent['rows']

def mean(values):
    return statistics.mean(values) if values else None

def timing(values):
    values = sorted(values)
    return {'n':len(values),'mean_s':mean(values),'median_s':statistics.median(values),'p95_s':values[math.ceil(.95*len(values))-1]} if values else None

breakdowns = []
for product in ('sqlite-web','linkding'):
    for condition in ('cold','prewarmed'):
        for group in ('normal','recovery','negative'):
            for arm in ('v','jt'):
                subset = [r for r in rows if r['product']==product and r['condition']==condition and r['group']==group and r['arm']==arm]
                assert subset
                positive = [r for r in subset if r['positive']]
                negative = [r for r in subset if not r['positive']]
                calls = [c for r in subset for c in r['calls'] if c['attempted']]
                breakdowns.append({'product':product,'condition':condition,'group':group,'arm':arm,
                    'planned':len(subset),'attempted':sum(r['attempted'] for r in subset),
                    'strict':sum(r['strict'] for r in positive),'negative_passed':sum(r['negative_passed'] for r in negative),
                    'capped_mean_s':mean([r['capped_ms']/1000 for r in positive]),
                    'negative_actual_timing':timing([r['elapsed_ms']/1000 for r in negative if 'elapsed_ms' in r]),
                    'SDK_calls':len(calls),'image_calls':sum(c['image'] for c in calls),
                    'jev_calls':sum(c['model']=='jev' for c in calls)})
clusters = []
for cluster in independent['clusters']:
    subset = [r for r in rows if r['cluster_id']==cluster['id']]
    clusters.append({**cluster, **{arm+'_success_fraction':mean([int(r['strict']) for r in subset if r['arm']==arm]) for arm in ('v','jt')}})

models = []
all_calls = [c for r in rows for c in r['calls'] if c['attempted']]
for model in ('jev','peer'):
    calls = [c for c in all_calls if c['model']==model]
    if calls:
        models.append({'model':model,'SDK_calls':len(calls),'SDK_timing_including_network_service':timing([c['sdk_ms']/1000 for c in calls if c['sdk_ms'] is not None]),
                      'invalid_response':sum(bool(c.get('invalid_response')) or c.get('valid_choice') is False for c in calls),
                      'control_choices':dict(Counter(c['choice'] for c in calls if c['choice'] in ('none','ambiguous','need_more_context','escalate')))})

negative_clusters = []
for arm in ('v','jt'):
    by_seed = []
    for cluster_id in sorted({r['cluster_id'] for r in rows if not r['positive']}):
        subset = [r for r in rows if r['cluster_id']==cluster_id and r['arm']==arm]
        assert len(subset)==2
        by_seed.append(all(r['negative_passed'] for r in subset))
    k,n = sum(not q for q in by_seed),len(by_seed)
    lo,hi = 0.0,1.0
    if k==n:
        upper = 1.0
    else:
        for _ in range(80):
            mid = (lo+hi)/2
            cdf = sum(math.comb(n,j)*mid**j*(1-mid)**(n-j) for j in range(k+1))
            if cdf>.05:lo=mid
            else:hi=mid
        upper = (lo+hi)/2
    negative_clusters.append({'arm':arm,'negative_seed_clusters':n,'clusters_with_any_incorrect_exit':k,
        'one_sided_95_upper_under_IID_seed_assumption':upper,
        'limitation':'Calibration seeds are selected synthetic cases. This conditional binomial bound is not a deployment-risk guarantee; cold/prewarmed are not independent samples.'})

served = Counter()
for path in sorted(root.glob('*/calls.jsonl')):
    for line in path.read_text().splitlines():
        record = json.loads(line)
        reply = record.get('response')
        if isinstance(reply,dict) and isinstance(reply.get('model'),str):served[reply['model']]+=1
failure_rows = []
for observed, native in zip(rows,raw['rows']):
    assert observed['id']==native['id']
    if not (observed['strict'] if observed['positive'] else observed['negative_passed']):
        failure_rows.append({'id':observed['id'],'positive':observed['positive'],'status':observed['status'],
            'reason':observed.get('reason'),'error_type':native.get('error_type'),
            'database_changed':native.get('database_before')!=native.get('database') if 'database_before' in native and 'database' in native else None,
            'business':observed.get('business'),'posts':observed.get('posts'),
            'elapsed_ms':observed.get('elapsed_ms'),'capped_ms':observed['capped_ms']})

result = {'analysis_kind':'Calibration descriptive only; no formal N or adoption claim',
    'sha256':freeze['sha256'],'independent_sha256':hashlib.sha256(independent_path.read_bytes()).hexdigest(),
    'breakdowns':breakdowns,'models':models,'clusters':clusters,
    'negative_cluster_bounds':negative_clusters,'served_model_fields':dict(served),
    'failures':failure_rows,
    'fallback_trial_outcomes':[{'id':r['id'],'strict':r['strict'],'negative_passed':r['negative_passed'],'calls':sum(bool(c['fallback_from']) for c in r['calls'])} for r in rows if any(c['fallback_from'] for c in r['calls'])],
    'formal_confirmation_N':None}
output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'breakdowns':len(breakdowns),'failures':len(failure_rows),'served_model_fields':dict(served),'models':models},ensure_ascii=False))
