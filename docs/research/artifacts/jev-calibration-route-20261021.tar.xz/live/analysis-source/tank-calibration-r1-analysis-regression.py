"""Exercise malformed captured replies without editing any raw evidence."""
import ast
import contextlib
import io
import json
import runpy
import sys
from pathlib import Path
from unittest.mock import patch

script = Path('/private/tmp/tank-calibration-analyze.py')
root = Path('/private/tmp/tank-calibration-full-pytest-20261021-final-v2/test_calibration_all_96_trials0/calibration')
result = json.loads((root / 'result.json').read_text())
first = result['rows'][0]['id']
read_text = Path.read_text
cases = ['truncated {', '{}', '[]', '{"choice": []}', '{"choice":"c1","choice":"c2"}']
summaries = []
for index, content in enumerate(cases):
    def overlay(path, *args, **kwargs):
        text = read_text(path, *args, **kwargs)
        if path == root / 'result.json':
            value = json.loads(text)
            row = value['rows'][0]
            row.update(strict_completed=False, calibration_success=False)
            row['result'].update(status='stopped', reason='invalid_decision')
            return json.dumps(value)
        if path.name == 'calls.jsonl' and path.parent.name == first:
            lines = [json.loads(line) for line in text.splitlines()]
            for item in lines:
                if 'response' in item:
                    item['response']['choices'][0]['message']['content'] = content
                    break
            return '\n'.join(json.dumps(item) for item in lines)
        return text

    output = Path(f'/private/tmp/tank-calibration-r1-invalid-analysis-{index}.json')
    sys.argv = ['analyze', str(root), str(output), '--mode', 'fake']
    with patch.object(Path, 'read_text', overlay), contextlib.redirect_stdout(io.StringIO()):
        runpy.run_path(str(script), run_name='__main__')
    checked = json.loads(output.read_text())
    invalid = [call for row in checked['rows'] for call in row['calls'] if call.get('invalid_response')]
    assert checked['planned'] == 96 and checked['SDK_calls'] == 336
    assert checked['known_tokens'] == 3360 and checked['positive_strict'] == 79
    assert len(invalid) == 1 and invalid[0]['choice'] is None and not invalid[0]['valid_choice']
    assert invalid[0]['known_tokens'] == 10
    summaries.append({'content': content, 'planned': checked['planned'], 'calls': checked['SDK_calls'],
                      'known_tokens': checked['known_tokens'], 'invalid': len(invalid)})

# The same independent parser accepts ordinary replies and rejects incomplete SDK envelopes.
tree = ast.parse(script.read_text())
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'response_choice')
scope = {'json': json}
exec(compile(ast.Module(body=[function], type_ignores=[]), str(script), 'exec'), scope)
choose = scope['response_choice']
for reply in [{'choices': []}, {'choices': [{'finish_reason': 'length', 'message': {'content': '{"choice":"c1"}'}}]},
              {'choices': [{'finish_reason': 'stop', 'message': {'content': None}}]}, {'choice': []}]:
    assert choose(reply, 'choices' in reply) == (None, 'invalid_response')
assert choose({'choice': 'none'}, False) == ('none', None)
print(json.dumps({'cases': summaries, 'additional_envelopes': 4, 'all_passed': True}))
