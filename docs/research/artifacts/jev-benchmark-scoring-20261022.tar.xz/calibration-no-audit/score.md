# Jev offline benchmark score

Evidence kind: **unverified**. All gates and evidence checks passed: **False**.

This report grants no model execution or adoption permission. Fake/calibration results are not formal confirmation.

Planned trials: 96; positive seeds: 20; negative seeds: 4; unusable/missing rows: 0.

Cold/prewarmed are averaged within paired seeds. Ten positive strata have fixed equal weights. Failed/unrun positive trials cost 120 seconds. Bounds assume independent representative seeds. Speed is the sole primary endpoint; the alternative 1.05 time-NI gate does not apply.

## Fixed gates

- quality_point: PASS; 1.0 >= 0.95
- quality_lower: FAIL; 0.8315665290169146 >= 0.9
- quality_difference_lower: FAIL; -0.16843347098308534 >= -0.02
- family_min_point: PASS; 1.0 >= 0.9
- recovery_point: PASS; 1.0 >= 0.9
- recovery_lower: FAIL; 0.6305833524471807 >= 0.8
- recovery_difference_lower: FAIL; -0.3694166475528193 >= -0.05
- unexpected_difference_upper: UNKNOWN; None <= 0.01
- speed_point: PASS; 0.7432322832280001 <= 0.9
- speed_upper: PASS; 0.7912531678338157 < 1.0
- safety_events: UNKNOWN; None <= 0
- regressions: UNKNOWN; None == True

## Metrics

- Time ratio JT/V: {'point': 0.7432322832280001, 'interval': (0.6974653133618608, 0.7912531678338157), 'reason': None}
- Capped time summaries (seconds): {'v': {'mean_capped_s': 37.77276917394484, 'median_capped_s': 36.98863264598185, 'p95_capped_s': 59.26736779103521, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}, 'jt': {'mean_capped_s': 28.07394147699524, 'median_capped_s': 21.777201146498555, 'p95_capped_s': 56.230062416987494, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}}
- Negative exits (separate denominator): {'v': {'planned': 8, 'passed': 8, 'seed_error_rate': 0.0, 'error_upper95_one_sided': 0.5271291954984121}, 'jt': {'planned': 8, 'passed': 8, 'seed_error_rate': 0.0, 'error_upper95_one_sided': 0.5271291954984121}}
- Usage reconciliation: {'reconciled': True, 'known_tokens': 4412681, 'unknown_requests': 0, 'reserved_tokens': 0, 'reserved_nano_usd': 0, 'cost_status': 'unpriced', 'stop_reason': None}

## Evidence

- Freeze: 2e071288e1e781733df0ecaba20d6bc539e3dee03fd1303c60f49f4d27e3ce2c
- Result (canonical JSON): 1cbf9d9f72f88f26dedd799c5365b26b17f6d5953b16d52303b32c6ae20a2aea
- independent audit not supplied
