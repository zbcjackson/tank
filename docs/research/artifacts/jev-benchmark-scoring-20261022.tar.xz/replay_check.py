"""Read-only replay against independently archived calibration and qualification."""
import argparse
import hashlib
import json
import runpy
from pathlib import Path

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--calibration', type=Path, required=True)
parser.add_argument('--qualification', type=Path, required=True)
parser.add_argument('--design', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
scorer = runpy.run_path(str(args.repo/'backend/benchmarks/computer_use/jev_scoring.py'))
reference = runpy.run_path(str(args.design/'design.py'))
inputs = {}
def read(path):
    data = path.read_bytes()
    inputs[str(path)] = hashlib.sha256(data).hexdigest()
    return data

cal_freeze = json.loads(read(args.calibration/'freeze.json'))
cal_result = json.loads(read(args.calibration/'result.json'))
old_independent = json.loads(read(args.design/'inputs/calibration-independent.json'))
cal_score = scorer['score'](cal_freeze, cal_result)
assert cal_score['counts'] == dict(planned_trials=96, positive_seeds=20, negative_seeds=4,
                                  recovery_seeds=8, missing_rows=0)
assert all(row['strict'] if row['positive'] else row['negative_passed']
           for row in old_independent['rows'])
_, _, _, _, pairs, _ = reference['load_inputs']()
old_speed = reference['bca'](np.ones((10, 2), dtype=int), pairs, np.random.default_rng(20261021))
assert abs(cal_score['metrics']['time_ratio']['point']-old_speed['point']) < 1e-14
assert np.allclose(cal_score['metrics']['time_ratio']['interval'], old_speed['interval'],
                   rtol=0, atol=1e-14)

fake_freeze = json.loads(read(args.qualification/'freeze.json'))
fake_result = json.loads(read(args.qualification/'fake/result.json'))
fake_cases = read(args.qualification/'cases.json')
fake_score = scorer['score'](fake_freeze, fake_result, cases_json=fake_cases)
assert fake_score['counts'] == dict(planned_trials=192, positive_seeds=40, negative_seeds=8,
                                   recovery_seeds=16, missing_rows=0)
for label, score, tokens, exits in [('calibration', cal_score, 4412681, 8),
                                   ('fake', fake_score, 6720, 16)]:
    assert all(score['metrics']['quality'][arm]['point'] == 1 for arm in ('v','jt'))
    assert all(score['negative'][arm]['passed'] == exits for arm in ('v','jt'))
    assert score['usage']['reconciled'] and score['usage']['known_tokens'] == tokens
    assert score['usage']['cost_status'] == 'unpriced'
    assert score['evidence']['issues'] == ['independent audit not supplied']
    assert not score['all_gates_passed'] and not score['model_execution_eligible']
    assert all(score['gates'][k]['passed'] is None for k in
               ('safety_events', 'unexpected_difference_upper', 'regressions'))
    reordered = dict(cal_result if label == 'calibration' else fake_result)
    reordered['rows'] = list(reversed(reordered['rows']))
    reordered_score = scorer['score'](cal_freeze if label == 'calibration' else fake_freeze,
                                      reordered, cases_json=None if label == 'calibration' else fake_cases)
    assert reordered_score['metrics'] == score['metrics']
    assert reordered_score['gates'] == score['gates']
    expected = json.loads((args.output/(label+'-no-audit')/'score.json').read_text())
    # Public Python estimates use tuple intervals; the CLI emits JSON arrays.
    assert {k:v for k,v in expected.items() if k!='inputs'} == json.loads(json.dumps(score))

assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha
           for path, sha in inputs.items())
record = dict(inputs=inputs, input_bytes_unchanged=True, row_order_invariant=True,
              archived_calibration_BCa_matches=True, counts_match=True,
              calibration_speed=cal_score['metrics']['time_ratio'],
              fake_counts=fake_score['counts'], model_calls_added=0,
              missing_audit_remains_unknown=True, formal_N=None, model_execution_eligible=False,
              scorer_sha256=hashlib.sha256(Path(scorer['__file__']).read_bytes()).hexdigest())
with (args.output/'replay-check.json').open('x') as output:
    json.dump(record, output, indent=2)
    output.write('\n')
print('Both archived replays agree; inputs unchanged; missing audit gates remain unknown.')
