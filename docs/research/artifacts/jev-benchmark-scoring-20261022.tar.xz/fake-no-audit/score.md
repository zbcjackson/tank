# Jev offline benchmark score

Evidence kind: **unverified**. All gates and evidence checks passed: **False**.

This report grants no model execution or adoption permission. Fake/calibration results are not formal confirmation.

Planned trials: 192; positive seeds: 40; negative seeds: 8; unusable/missing rows: 0.

Cold/prewarmed are averaged within paired seeds. Ten positive strata have fixed equal weights. Failed/unrun positive trials cost 120 seconds. Bounds assume independent representative seeds. Speed is the sole primary endpoint; the alternative 1.05 time-NI gate does not apply.

## Fixed gates

- quality_point: PASS; 1.0 >= 0.95
- quality_lower: PASS; 0.9119026971211976 >= 0.9
- quality_difference_lower: FAIL; -0.0880973028788024 >= -0.02
- family_min_point: PASS; 1.0 >= 0.9
- recovery_point: PASS; 1.0 >= 0.9
- recovery_lower: FAIL; 0.7940927857921772 >= 0.8
- recovery_difference_lower: FAIL; -0.20590721420782274 >= -0.05
- unexpected_difference_upper: UNKNOWN; None <= 0.01
- speed_point: FAIL; 0.9461844862210679 <= 0.9
- speed_upper: PASS; 0.9515629496185392 < 1.0
- safety_events: UNKNOWN; None <= 0
- regressions: UNKNOWN; None == True

## Metrics

- Time ratio JT/V: {'point': 0.9461844862210679, 'interval': (0.9404974736571349, 0.9515629496185392), 'reason': None}
- Capped time summaries (seconds): {'v': {'mean_capped_s': 3.4726718489640915, 'median_capped_s': 3.487510729493806, 'p95_capped_s': 4.54463575000409, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}, 'jt': {'mean_capped_s': 3.285788229226455, 'median_capped_s': 3.388886916509364, 'p95_capped_s': 4.224595874955412, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}}
- Negative exits (separate denominator): {'v': {'planned': 16, 'passed': 16, 'seed_error_rate': 0.0, 'error_upper95_one_sided': 0.3123439780663679}, 'jt': {'planned': 16, 'passed': 16, 'seed_error_rate': 0.0, 'error_upper95_one_sided': 0.3123439780663679}}
- Usage reconciliation: {'reconciled': True, 'known_tokens': 6720, 'unknown_requests': 0, 'reserved_tokens': 0, 'reserved_nano_usd': 0, 'cost_status': 'unpriced', 'stop_reason': None}

## Evidence

- Freeze: 096472b203217a388dc5cec6f4fad001851156be0699d15b670a5fdd2ccd5026
- Result (canonical JSON): f36d444f208e6b6d3adf44d9781f806c3c9d73150618cfc508d1189971b88952
- independent audit not supplied
