Feature: Chat mode

  Background:
    Given the app is open
    And the user switches to chat mode

  Scenario: Empty state shows placeholder
    When the user clicks the conversations button
    And the user clicks new conversation
    Then the empty state text "开始对话吧" is visible

  Scenario: User message appears in conversation
    When the user types "你好" and sends it
    Then the user message "你好" is visible in the conversation

  @requires-active-conversation
  Scenario: Sending a message triggers assistant response
    When the user types "现在几点" and sends it
    Then the typing indicator is visible
    And eventually an assistant message appears
    And the typing indicator disappears

  @requires-active-conversation
  Scenario: Stop button replaces send button during processing
    When the user types "你好" and sends it
    Then the stop button is visible
    And eventually the send button is visible

  # P0-5: sentence-level TTS streaming — first audio must land while the
  # LLM text is still streaming (not after the whole turn finishes).
  @requires-active-conversation @streaming-audio
  Scenario: Long answer audio starts before text finishes streaming
    When the user sends a long-answer prompt with audio streaming tracked
    Then the first audio frame arrives before the response text completes

  Scenario Outline: Split desktop orchestration preserves dispatch and stop contracts
    When the isolated split desktop contract "<contract>" is exercised
    Then the split desktop contract passes without live model or desktop input

    Examples:
      | contract |
      | dispatch |
      | stop     |

  Scenario Outline: Plugin task delegation preserves structured input and outcomes
    When the isolated plugin task contract "<contract>" is exercised
    Then the plugin task contract passes without live model or desktop input

    Examples:
      | contract |
      | input    |
      | outcomes |
      | resume   |
      | lifecycle |

  Scenario Outline: Computer Use host loop and image probes preserve offline task contracts
    When the isolated computer use host contract "<contract>" is exercised
    Then the computer use host contract passes without live model or desktop input

    Examples:
      | contract |
      | loop     |
      | plugin   |
      | visual   |
      | scoring  |

  @managed-chromium
  Scenario: Managed Chromium preserves configuration, stop, fallback, Advisor, same-task resume and goal-driven actions
    When the isolated managed Chromium contract is exercised
    Then the managed Chromium contract passes without paid model calls or personal browser access

  Scenario: Native AX preserves task scope, Advisor planning, readback and stop boundaries
    When the isolated native AX contract is exercised
    Then the native AX contract passes without real desktop input or paid model calls
