# Jev offline benchmark score

Evidence kind: **fake**. All gates and evidence checks passed: **False**.

This report grants no model execution or adoption permission. Fake/calibration results are not formal confirmation.

Planned trials: 96; positive seeds: 20; negative seeds: 4; unusable/missing rows: 0.

Cold/prewarmed are averaged within paired seeds. Ten positive strata have fixed equal weights. Failed/unrun positive trials cost 120 seconds. Bounds assume independent representative seeds. Speed is the sole primary endpoint; the alternative 1.05 time-NI gate does not apply.

## Fixed gates

- quality_point: PASS; 1.0 >= 0.95
- quality_lower: FAIL; 0.8315665290169146 >= 0.9
- quality_difference_lower: FAIL; -0.16843347098308534 >= -0.02
- family_min_point: PASS; 1.0 >= 0.9
- recovery_point: PASS; 1.0 >= 0.9
- recovery_lower: FAIL; 0.6305833524471807 >= 0.8
- recovery_difference_lower: FAIL; -0.3694166475528193 >= -0.05
- unexpected_difference_upper: FAIL; 0.16843347098308534 <= 0.01
- speed_point: PASS; 0.7123222748815167 <= 0.9
- speed_upper: PASS; 0.7133016627078385 < 1.0
- safety_events: PASS; 0 <= 0
- regressions: PASS; True == True

## Metrics

- Time ratio JT/V: {'point': 0.7123222748815167, 'interval': (0.7115421002838224, 0.7133016627078385), 'reason': None}
- Capped time summaries (seconds): {'v': {'mean_capped_s': 10.55, 'median_capped_s': 10.55, 'p95_capped_s': 11.1, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}, 'jt': {'mean_capped_s': 7.515000000000001, 'median_capped_s': 7.515000000000001, 'p95_capped_s': 8.030000000000001, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}}
- Negative exits (separate denominator): {'v': {'planned': 8, 'passed': 8, 'seed_error_rate': 0.0, 'error_upper95_one_sided': 0.5271291954984121}, 'jt': {'planned': 8, 'passed': 8, 'seed_error_rate': 0.0, 'error_upper95_one_sided': 0.5271291954984121}}
- Usage reconciliation: {'reconciled': True, 'known_tokens': 0, 'unknown_requests': 0, 'reserved_tokens': 0, 'reserved_nano_usd': 0, 'cost_status': 'unspecified', 'stop_reason': None}

## Evidence

- Freeze: 77443c4a4c80b431101bb032bf6884978446ab4e66283e87244352ba0b081d5d
- Result (canonical JSON): e7c70fe45f8138bce3b8211847dd1d030c8584ceae3c4941e496ca21b699b910
