"""Supplemental offline reconciliation; no model calls or imports from run.py."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
r=Path(__file__).resolve().parent
f=json.loads((r/'freeze.json').read_text())
assert sha256((r/'run.py').read_bytes()).hexdigest()==f['driver_sha256']
assert sha256((r/'audit.py').read_bytes()).hexdigest()==f['auditor_sha256']
for name,expected in f['sources'].items():
    assert sha256((r/'sources'/name).read_bytes()).hexdigest()==expected
reports=[]
for mode in ('fake','live'):
    subprocess.run([sys.executable,str(r/'audit.py'),mode],check=True,stdout=subprocess.DEVNULL)
    batch=json.loads((r/mode/'result.json').read_text())
    diagnostics=[json.loads(s) for s in (r/mode/'sdk-diagnostics.jsonl').read_text().splitlines()]
    calls=[d['call_id'] for d in diagnostics if d['phase']=='invoke_started']
    closed=[d for d in diagnostics if d['phase']=='call_returned']
    assert Counter(calls)==Counter(d['call_id'] for d in closed)==Counter(batch['spend']['requests'].keys())
    assert not any(d['phase'].endswith('error') for d in diagnostics)
    for row in batch['rows']:
        p=r/mode/row['id'];events=json.loads((p/'events.json').read_text())
        audit=json.loads((p/'audit.json').read_text())
        ids={a['call_id'] for a in audit}
        for call in ids:
            sequence=[a for a in audit if a['call_id']==call]
            assert [a['phase'] for a in sequence]==['prepared','dispatch','finished']
            assert sequence[-1]['status']=='returned'
        receipts=row['result']['details']['receipts']
        dispatched=[e['metadata'] for e in events if e['kind']=='computer_use_dispatch']
        finished=[a for a in audit if a['operation']=='computer_use.dispatch' and a['phase']=='finished']
        accepted=[e['metadata'] for e in events if e['kind']=='computer_use_action_admission']
        proposals=[e['metadata'] for e in events if e['kind']=='computer_use_proposal']
        decisions=[e['metadata'] for e in events if e['kind']=='computer_use_decision']
        n=3 if row['id']=='edit-title' else 4
        assert len(receipts)==len(dispatched)==len(finished)==len(accepted)==len(proposals)==len(decisions)==n
        assert all(x['status']=='sent' for x in receipts+dispatched)
        assert all(x['accepted'] is True and x['next_route']=='text_candidate' for x in accepted)
        assert all(x['candidates']<=32 for x in decisions)
        assert all(x['call_id'] in batch['spend']['requests'] for x in closed if x['task_id']==mode+'-'+row['id'])
        reports.append(dict(mode=mode,id=row['id'],actions=n,all_execution_calls_closed=True,
            all_action_choices_admitted=True,max_candidates=max(x['candidates'] for x in decisions)))
(r/'evidence-verification.json').write_text(json.dumps(dict(all_passed=True,checks=reports),indent=2)+'\n')
print('Offline evidence reconciliation: PASS; both fake/live batches, 14 SDK calls, 14 actions, sources byte-identical.')
