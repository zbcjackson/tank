"""Read-only audit. Does not import or trust run.py's conclusions."""
import json
from pathlib import Path
import sqlite3
import sys
from html.parser import HTMLParser
from hashlib import sha256

ROOT=Path(__file__).resolve().parent
mode=sys.argv[1]
output=ROOT/mode
f=json.loads((ROOT/'freeze.json').read_text())
batch=json.loads((output/'result.json').read_text())
assert batch['freeze_sha256']==sha256((ROOT/'freeze.json').read_bytes()).hexdigest()

class Tables(HTMLParser):
    def __init__(self):super().__init__();self.tables=[];self.rows=None;self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='table':self.rows=[]
        elif tag=='tr' and self.rows is not None:self.row=[]
        elif tag in ('th','td') and self.row is not None:self.cell=[]
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag in ('th','td') and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        elif tag=='tr' and self.row is not None:self.rows.append(self.row);self.row=None
        elif tag=='table' and self.rows is not None:self.tables.append(self.rows);self.rows=None

reports=[]
for case,row in zip(f['cases'],batch['rows']):
    if len(sys.argv)>2 and case['id']!=sys.argv[2]:continue
    if not row['attempted']:continue
    p=output/case['id']
    def read(n):return json.loads((p/n).read_text())
    before=read('database-before.json')
    with sqlite3.connect((p/'fixture.db').as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row
        actual=[dict(r) for r in db.execute('SELECT * FROM work_items ORDER BY id')]
        writes=[dict(r) for r in db.execute('SELECT * FROM _writes ORDER BY rowid')]
        schema=[list(r) for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
    expected=[{**r,case['field']:case['value']} if r['id']==case['record'] else r for r in before['records']]
    saved=actual==expected and len(writes)==1
    untouched=actual==before['records'] and not writes
    assert schema==before['schema'] and (saved or untouched),'unexpected business mutation'
    if saved:
        assert writes[0]['operation']=='update' and writes[0]['id']==case['record']
        for field in ('title','notes'):
            old=next(r for r in before['records'] if r['id']==case['record'])[field]
            assert writes[0]['old_'+field]==old
            assert writes[0]['new_'+field]==(case['value'] if field==case['field'] else old)
    initial=read('initial-public-dom.json')
    facts=[x for x in initial['facts'] if x['key'].startswith('status:DOM table:')]
    assert len(facts)==1
    public=json.loads(facts[0]['value']);columns=json.loads(facts[0]['key'].split('status:DOM table:',1)[1])
    assert columns==['id','title','notes']
    public_rows=[list(r) for r in public['rows']]
    # DB only cross-checks public evidence here, never constructs the Runner task.
    assert public_rows==[[str(r[c]) for c in columns] for r in before['records']]
    for r in public_rows:
        if r[0]==str(case['record']):r[columns.index(case['field'])]=case['value']
    goal=read('goal.json');completion=goal['completion']
    assert len(completion)==1 and completion[0]['key']==facts[0]['key']
    target=json.loads(completion[0]['value'])
    assert target=={**public,'rows':public_rows}
    final=read('final-table.json');final_table=json.loads(final['value'])
    actual_rows=[[str(r[c]) for c in columns] for r in actual]
    assert final_table=={**public,'rows':actual_rows}
    parser=Tables();parser.feed((p/'final-list.html').read_text())
    matching=[]
    for t in parser.tables:
        if not t:continue
        indexes=[i for i,c in enumerate(t[0]) if c in columns]
        if [t[0][i] for i in indexes]==columns:
            matching.append([[r[i] for i in indexes] for r in t[1:] if len(r)==len(t[0])])
    assert matching==[actual_rows],'raw HTML differs from DB and public DOM'
    http=[json.loads(s) for s in (p/'http.jsonl').read_text().splitlines()]
    posts=[i for i,r in enumerate(http) if r['method']=='POST']
    if saved:
        assert len(posts)==1
        token='WzFd' if case['record']==1 else 'WzJd'
        assert http[posts[0]]['path']=='/work_items/update/'+token+'/'
        assert sum(r['method']=='GET' and r['path']=='/work_items/content/' for r in http[posts[0]+1:])>=2
    else:assert not posts
    result=read('task-result.json')
    if result['status']=='completed':assert saved and result['details']['reason']=='goal_verified'
    assert result['cleanup']=='confirmed' and not result['details']['pending_effect']
    cleanup=read('cleanup.json');assert cleanup['server_exit'] is not None and cleanup['runner_cleanup']=='confirmed'
    captures=read('captures.json');events=read('events.json')
    reqs={r['call_id']:r for r in captures if 'request' in r}
    responses={r['call_id']:r['response'] for r in captures if 'response' in r}
    starts=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='started']
    ends=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='finished']
    spent={k:v for k,v in batch['spend']['requests'].items() if v['trial']==case['id']}
    assert set(reqs)==set(responses)=={m['call_id'] for m in starts}=={m['call_id'] for m in ends}==set(spent)
    assert len(starts)==len(ends)==len(reqs)
    tokens=0;models={};decisions=[]
    for m in ends:
        key=m['call_id'];r=reqs[key];s=spent[key];response=responses[key]
        assert m['status']=='returned' and s['status']=='known'
        a,b=m['prompt_tokens'],m['completion_tokens']
        assert type(a) is int and type(b) is int and a>=0 and b>=0
        assert (s['input_tokens'],s['output_tokens'])==(a,b)
        if r['model']==f['jev']['model']:
            assert r['url']==f['jev']['url'] and r['purpose']=='computer_use.jev'
            assert (response['input_tokens'],response['output_tokens'])==(a,b)
            packet=r['request'];assert packet['state']['goal']['goal_id']==case['id']
            # State contains only normal plugin evidence; no benchmark DB/complete/progress enrichment.
            assert all(not x['key'].startswith(('status:Records','status:List rows','status:Editor seen')) for x in packet['state']['snapshot']['facts'])
            choice=response.get('choice');candidate=packet['questions']['next_action']['criteria'].get(choice)
            decisions.append(dict(choice=choice,label=candidate.get('label') if isinstance(candidate,dict) else candidate,
                                  operation=candidate.get('operation') if isinstance(candidate,dict) else None))
        else:
            assert r['model']==f['vision']['model'] and r['url'].startswith(f['vision']['url'])
        models[r['model']]=models.get(r['model'],0)+1;tokens+=a+b
    assert batch['spend']['stop_reason'] is None
    assert not row['blocked_network']
    if mode=='fake':assert saved and result['status']=='completed'
    report=dict(id=case['id'],business_saved=saved,goal_verified=result['status']=='completed',sdk_calls=len(reqs),models=models,tokens=tokens,
                decisions=decisions,post_count=len(posts),cleanup_confirmed=True,checks_passed=True)
    write=lambda path,value:path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    write(p/'independent-audit.json',report);reports.append(report)
print(json.dumps(reports,ensure_ascii=False))
if len(sys.argv)==2:
    assert len(reports)==2 and batch['completed']
    assert sum(r['sdk_calls'] for r in reports)==batch['spend']['batch']['admitted_requests']
    assert sum(r['tokens'] for r in reports)==batch['spend']['batch']['known_tokens']
    (output/'independent-audit.json').write_text(json.dumps(dict(all_passed=True,reports=reports),ensure_ascii=False,indent=2)+'\n')
