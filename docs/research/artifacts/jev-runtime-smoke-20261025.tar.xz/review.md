# 原始DOM两项真实模型试跑：完成审查

- 日期：2026-10-25。
- 模式：review-and-refactor；第1轮；此前无问题。未参与待审实现的评审者执行，未递归委派。
- 基线：441e2e327c18345f3a17b88cf21ce2de41281a57；审查HEAD：a28f6558（含e4e0f701）。完整审查baseline..HEAD，非仅最后提交。
- 范围：docs/README.md、docs/backlog.md、主计划、jev-runtime-smoke计划/研究及证据归档；工作区开始/结束均干净。无用户未提交修改。
- 已加载：agents/code-reviewer.md、根ARCHITECTURE.md，以及相关backend架构/编码/开发/测试说明；采用项目docs-only验证和gitmoji签名提交约定。

## 结论

未发现确认的可操作问题或待解决旧问题；第1轮结束，不追加无变化的复审。
两次真实模型单次路径成功的结论有原始证据支持，范围限制清楚。没有需要实施的修复、重构或新提交。
本报告不构成无缺陷证明，也不验证视觉、拒绝泛化、模型排序或默认采用。

## 独立复核

从仓库归档独立安全解包至/private/tmp/tank-jev-runtime-smoke-review-20261025-extracted，未使用工作驱动的现成输出作为唯一判断依据。

1. 归档SHA256为05fc9d281a13ca5325fd11e9a51dffe56d8dc8c7f3854d0a8216132ae5f665e2；499普通成员，无路径越界/链接；manifest498项逐文件SHA及成员集合完全一致。
2. freeze SHA256为21fc86b638c6ae60aca3c71b6d2e6c0242e30b2654f4911c8dec36f04d342b7c。driver/auditor和352源码原字节均匹配；352项同时与git基线和当前工作区一致。旧76工件及默认config SHA保持不变。
3. 当前独立产品环境652项清单文件均与冻结相符，未声称旧已清理环境与新环境字节相同；固定10个版本与已记录限制一致。
4. 阅读冻结run.py、audit.py、verify_evidence.py及其调用的生产/既有诊断、记账路径。live分支未安装假HTTP；使用生产AgentRunner/插件/ManagedChromiumChannel，未用ProductChannel或DB构造goal。公开DOM只应用明确目标修改，保留全表其余行列；真实批次一次且两项各一次。
5. 系统Python运行python3 verify_evidence.py：PASS。内部分别执行fake/live audit.py；共14次SDK、14动作、账本/调用/执行闭合通过。核验前后逐文件哈希再次相同，生成的派生文件可重复。
6. 额外手工检查两项真实TaskResult与batch中的result逐字节结构一致，均completed/goal_verified、pending_effect=false；真实HTTP每项唯一正确POST及随后GET，数据库/触发器、初始/最终DOM和原始HTML符合指定行字段变化、其他公开数据保持。清理均confirmed，产品进程exit=-15为主动终止。
7. 原始捕获、model_call事件和SDK诊断为3+4次TypeSafe jev-1.14.0；请求只含model/state/questions，无图片调用。返回整数tokens分别38,227与53,280，合计91,507；无未知用量或未结预留，7个动作都准入。金额未定价，账面0不是免费；SDK跨度和驱动墙钟的不同统计口径已清楚限定。
8. 首两次假资格失败及未执行冻结保留；修复后最终冻结下两项假资格通过再进入真实。早期环境恢复/启动错误无独立日志这一证据缺口已明确披露，不影响已保存的两项实测证据。

## 实际验证

- python3 verify_evidence.py（独立解包目录）：PASS；未读取凭据或启动SDK/模型/产品。
- 自写临时只读哈希/结果核对：归档manifest、freeze、源码git基线/当前、652产品文件、76旧工件、config、TaskResult/capture对齐：PASS。
- python3 scripts/check_docs.py：OK，118 files under docs/。
- git diff --check 441e2e32..HEAD：PASS。
- 使用既有allowed-signers只读验签：e4e0f701及a28f6558均G；未变更Git签名配置。
- 未重新运行生产单元/E2E套件：本片仅docs/变化，适用项目docs-only例外；不把前轮38定向、6801后端/1跳过及E2E24/95当作本轮检查。

## 限制与后续边界

仅两个已知真实产品/两行公开合成数据的正例可行性；不证明视觉兜底、Jev图片/Box、拒绝泛化、统计准确率、模型优劣、隐藏数据/完整数据库持久性或真实用户写入准入。
没有重跑真实模型。冻结原始证据未改动；没有评审者自修的待独立复核修改。
协调者可核查本报告和diff后闭合计划并将原始报告归档；如封包变化，需同步新的归档SHA/成员数与文档，不重写已冻结结果。
