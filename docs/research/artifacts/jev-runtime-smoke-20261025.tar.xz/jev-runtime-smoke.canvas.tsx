import { H1, H2, Text, Stack, Row, Pill, Table, Callout, Divider, useHostTheme } from "cursor/canvas";

const trials = [
  { task: "编辑页改标题", change: "id=1 · Nora → Miro", calls: 3, tokens: 38227, sdk: "2.268", steps: "启用 title → 填写 Miro → Update" },
  { task: "列表进入后改备注", change: "id=2 · Keep B → Checked B", calls: 4, tokens: 53280, sdk: "2.288", steps: "记录2 Edit → 启用 notes → 填写 Checked B → Update" },
];

export default function RuntimeSmoke() {
  const theme = useHostTheme();
  return <Stack gap={20} style={{ padding: 28, maxWidth: 1100, color: theme.text.primary, background: theme.bg.editor }}>
    <Row justify="space-between" align="center"><H1>普通 DOM 的两条真实模型路径已跑通</H1><Pill tone="success">2026-10-25 · 2次单次试跑</Pill></Row>
    <Text>原版 sqlite-web 0.8.1；生产 AgentRunner、jev-action-vision、显式表格 GET 读回。没有数据库完成事实补强。</Text>
    <Table headers={["任务 / 修改", "生产结果", "Jev调用（次）", "已知token（个）", "SDK跨度之和（秒）"]}
      rows={trials.map(t => [<Stack gap={4}><Text weight="semibold">{t.task}</Text><Text size="small" tone="secondary">{t.change}</Text></Stack>, "goal_verified + 独立业务核验", t.calls, t.tokens.toLocaleString(), t.sdk])}
      columnAlign={["left", "left", "right", "right", "right"]} />
    <Text size="small" tone="secondary">来源：本轮 live 原始模型事件、捕获、账本与独立审计。SDK跨度为各次事件 elapsed_ms 之和，包含本地调用边界开销，不是纯服务端时延或完整任务时延。每任务仅一次，无统计比较。</Text>
    <H2>实际动作与核验链</H2>
    {trials.map(t => <Stack key={t.task} gap={6}><Text weight="semibold">{t.task}：{t.steps}</Text><Text tone="secondary">一次正确记录 POST → 新 GET 的完整公开表格 → goal_verified；只读数据库、原始 HTML、执行日志交叉核对正确行和保护字段。</Text></Stack>)}
    <Divider />
    <Row gap={12} wrap><Pill>7次 Jev · jev-1.14.0</Pill><Pill>Gemini / PNG：0次</Pill><Pill>91,507已知token</Pill><Pill>2次清理确认</Pill></Row>
    <Callout tone="info" title="这轮证明的范围">真实模型可以通过当前生产路径完成这两条操作。视觉兜底、Jev图片/Box、拒绝泛化、模型优劣及默认采用仍未由本轮验证。金额未定价，不表示免费。</Callout>
    <Text size="small" tone="secondary">冻结：21fc86b638c6ae60aca3c71b6d2e6c0242e30b2654f4911c8dec36f04d342b7c。每任务120秒/6动作/24观察/10万已记账token，全批24次SDK上限；7次用量均已知、无未结预留。原76工件与默认配置不变。</Text>
  </Stack>;
}
