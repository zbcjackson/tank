"""Fixed two-case production Runner smoke; no DB-derived task facts or model ranking."""
from __future__ import annotations
import asyncio
from contextlib import nullcontext
from dataclasses import asdict
from hashlib import sha256
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from unittest.mock import MagicMock
import urllib.request

os.environ['LANGFUSE_TRACING_ENABLED'] = 'false'
os.environ['OTEL_SDK_DISABLED'] = 'true'
import httpx
import pytest
from agent_computer_use.channels.dom import BrowserConfig, ManagedChromiumChannel, dom_table_fact
from tank_backend.agents.approval import PendingToolCallStore, ToolApprovalPolicy
from tank_backend.agents.definition import parse_agent_file
from tank_backend.agents.resources import DesktopResource
from tank_backend.agents.runner import AgentRunner
from tank_backend.agents.subagent import SubAgentAuthorization, SubAgentBudget, SubAgentContext
from tank_backend.benchmarks.model_policy import BenchmarkModelPolicy
from tank_backend.benchmarks.spend_ledger import SpendLedger, SpendLimit
from tank_backend.config.app_config import AppConfig
from tank_backend.pipeline.bus import Bus
from tank_backend.plugin.manifest import read_manifest_from_yaml
from tank_backend.plugin.registry import ExtensionRegistry
from benchmarks.computer_use import jev_real_product_route as product
from benchmarks.computer_use.jev_sdk_diagnostics import sdk_diagnostics

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/zbcjackson/src/tank')
APP = Path('/private/tmp/tank-sqlite-web-smoke-20261025-env/bin/python')
JEV = {'url':'https://api.typesafe.ai/v1/systemone','model':'jev-1.14.0'}
VISION = {'url':'https://openrouter.ai/api/v1','model':'google/gemini-3.8-flash','max_tokens':4096}
SEED = [{'id':1,'title':'Nora','notes':'Keep A'}, {'id':2,'title':'Tavi','notes':'Keep B'}]
CASES = [dict(id='edit-title', record=1, field='title', old='Nora', value='Miro', start='/work_items/update/WzFd/'),
         dict(id='list-notes', record=2, field='notes', old='Keep B', value='Checked B', start='/work_items/content/')]

def write(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=list)+'\n')

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def sources():
    paths = subprocess.check_output(['git','ls-files','backend/core/src','backend/plugins/agent-computer-use/src',
        'backend/plugins/agent-computer-use/plugin.yaml','backend/uv.lock',
        'backend/benchmarks/computer_use/jev_real_product_route.py',
        'backend/benchmarks/computer_use/jev_sdk_diagnostics.py','backend/core/tests/sdk_http.py'],cwd=REPO,text=True).splitlines()
    return {p:digest(REPO/p) for p in paths}

def prepare():
    assert not (ROOT/'freeze.json').exists()
    f = dict(baseline='441e2e327c18345f3a17b88cf21ce2de41281a57',cases=CASES,seed=SEED,jev=JEV,vision=VISION,
        selector='jev-action-vision',readback_tables=True,seconds=120,actions=6,observations=24,
        token_budget_per_task=100000,request_limit=24,request_bytes=4*1024*1024,
        cost_status='unpriced',token_limit='host accounted usage, not a provider reservation ceiling',
        sources=sources(),driver_sha256=digest(Path(__file__)),auditor_sha256=digest(ROOT/'audit.py'),app=product.app_manifest(APP),
        versions={n:metadata.version(n) for n in ('typesafe-sdk','openai','playwright','pillow')},
        completion_recipe='initial public DOM table, replace only specified record/field; bind runtime loopback URL',
        model_data='synthetic goal, public DOM state/candidates/history; bound PNG only on natural visual fallback')
    write(ROOT/'freeze.json',f)
    old={str(p.relative_to(REPO)):digest(p) for p in (REPO/'docs/research/artifacts').iterdir() if p.is_file()}
    write(ROOT/'preservation-before.json',dict(artifacts=old,config_sha256=digest(REPO/'backend/core/config.yaml')))
    print('freeze',digest(ROOT/'freeze.json'), 'sources',len(f['sources']),flush=True)

def check():
    f=json.loads((ROOT/'freeze.json').read_text())
    assert f['sources']==sources() and f['driver_sha256']==digest(Path(__file__))
    assert f['auditor_sha256']==digest(ROOT/'audit.py')
    assert f['app']==product.app_manifest(APP)
    assert f['cases']==CASES and f['seed']==SEED and f['jev']==JEV and f['vision']==VISION
    return f

async def public_table(origin, output, name):
    ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event())
    ctx.runtime.bind(name)
    browser=ManagedChromiumChannel(BrowserConfig(scope='runtime-smoke',url=origin+'/work_items/content/',readback_tables=True))
    try:
        snapshot=await browser.observe('runtime-smoke',ctx)
        write(output/(name+'.json'),asdict(snapshot))
        assert snapshot.ready and snapshot.complete
        found=[f for f in snapshot.facts if f.key.startswith('status:DOM table:')]
        assert len(found)==1
        return found[0]
    finally:
        await browser.aclose()
        await ctx.runtime.aclose()

async def trial(case, output, mode, credential, ledger):
    output.mkdir(exist_ok=False)
    database=output/'fixture.db'
    product.create_database(database,SEED)
    # This snapshot is evidence only, never passed to goal construction or the Runner.
    write(output/'database-before.json',product.database_state(database))
    events=[]; captures=[]; audits=[]; calls=[]; blocked=[]
    result=None; server=None; error=None
    started=time.monotonic()
    class Observer:
        def on_event(self,kind,metadata):
            events.append(dict(kind=kind,metadata=metadata))
            write(output/'events.json',events)
    class Capture:
        async def request(self,call_id,request):
            captures.append(dict(call_id=call_id,url=request.url,model=request.model,purpose=request.purpose,request=request.parameters))
            write(output/'captures.json',captures)
        async def response(self,call_id,response):
            captures.append(dict(call_id=call_id,response=response))
            write(output/'captures.json',captures)
    async def audit(record):
        audits.append(asdict(record));write(output/'audit.json',audits)
    class HTTP(httpx.AsyncBaseTransport):
        async def handle_async_request(self,request):
            data=json.loads(request.content); calls.append(data)
            native='questions' in data
            packet=data if native else json.loads(data['messages'][1]['content'][0]['text'])
            criteria=packet['questions']['next_action']['criteria']
            facts={f['key']:f['value'] for f in packet['state']['snapshot']['facts']}
            chosen='none'
            for key,c in criteria.items():
                if not isinstance(c,dict):continue
                label=c.get('label','')
                if case['id']=='list-notes' and c.get('role')=='link' and any(
                    e.get('value','').endswith('/work_items/update/WzJd/') for e in c.get('effect',[])):
                    chosen=key;break
                if 'chk_'+case['field'] in label and c.get('current_value')=='false':chosen=key;break
                if c.get('operation')=='fill' and label==case['field'] and c.get('current_value')!=case['value']:chosen=key;break
                if label=='Update' and facts.get('textbox:'+case['field'])==case['value']:chosen=key;break
            write(output/'fake-http.json',calls)
            if native:
                return httpx.Response(200,json={'model':JEV['model'],'answers':{'next_action':{'type':'choice','choice':chosen,'confidence':1,
                    'probabilities':{k:int(k==chosen) for k in criteria}}},'usage':{'input_tokens':12,'output_tokens':0}})
            return httpx.Response(200,json={'id':'fixture','object':'chat.completion','created':1,'model':VISION['model'],
                'choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':json.dumps({'choice':chosen})}}],
                'usage':{'prompt_tokens':10,'completion_tokens':2,'total_tokens':12}})
    original_connect=socket.socket.connect
    def connect(sock,address):
        if isinstance(address,tuple) and address[0] not in {'127.0.0.1','::1','localhost'}:
            blocked.append(str(address[0]));raise OSError('non-loopback socket denied')
        return original_connect(sock,address)
    try:
        with (output/'server.log').open('w') as log:
            server=await asyncio.create_subprocess_exec(str(APP),str(Path(product.__file__)),
                '--serve','--database',str(database),'--output',str(output),
                env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1'},stdout=log,stderr=asyncio.subprocess.STDOUT)
            async with asyncio.timeout(10):
                while not (output/'ready.json').is_file():
                    assert server.returncode is None
                    await asyncio.sleep(.05)
            origin='http://127.0.0.1:'+str(json.loads((output/'ready.json').read_text())['port'])
            initial=await public_table(origin,output,'initial-public-dom')
            table=json.loads(initial.value)
            columns=json.loads(initial.key.removeprefix('status:DOM table:'))
            rows=[list(r) for r in table['rows']]
            target=[r for r in rows if r[columns.index('id')]==str(case['record'])]
            assert len(target)==1 and target[0][columns.index(case['field'])]==case['old']
            target[0][columns.index(case['field'])]=case['value']
            expected=dom_table_fact(origin+'/work_items/content/',tuple(columns),tuple(tuple(r) for r in rows))
            intent=(f"Starting at {'the work_items list' if case['id']=='list-notes' else 'record 1 edit page'}, "
                f"change only work_items record id {case['record']} {case['field']} from {case['old']!r} to {case['value']!r}. "
                'Save the change; preserve all other fields and records. Confirm the returned public list.')
            goal=dict(schema_version=2,goal_id=case['id'],scope='runtime-smoke',authorization_ref='current_task',
                intent=intent,objective=intent,allowed_operations=['click','fill'],
                constraints=['Do not delete records, change schema or execute SQL.'],
                inputs=[dict(key=case['field'],purpose='Requested new '+case['field'],field_label=case['field'],value=case['value'])],
                completion=[expected.model_dump()])
            write(output/'goal.json',goal)
            definition_path=output/'agent.md'
            definition_path.write_text('---\nname: runtime-smoke\nextension: agent-computer-use:agent\nmodel: default\ndecision-model: jev\nvisual-model: vision\n---\nExecute the declared goal.\n')
            definition=parse_agent_file(definition_path)
            registry=ExtensionRegistry()
            manifest=read_manifest_from_yaml(REPO/'backend/plugins/agent-computer-use/plugin.yaml')
            for extension in manifest.extensions:registry.register(manifest.plugin_name,extension)
            config=AppConfig.from_raw_dict({'llm':{
                'default':{'api_key':'unused','model':'unused','base_url':VISION['url']},
                'vision':{'api_key':credential['vision'],'model':VISION['model'],'base_url':VISION['url'],'max_tokens':4096}},
                'decision_models':{'jev':{**JEV,'credential_env':'SMOKE_JEV_KEY'}},
                'subagents':{'agent-computer-use:agent':{'config':{'selector':'jev-action-vision',
                    'browser':{'scope':'runtime-smoke','url':origin+case['start'],'readback_tables':True}}}}})
            runner=AgentRunner(MagicMock(),MagicMock(),Bus(),ToolApprovalPolicy(computer_mode='allow'),PendingToolCallStore(),
                {definition.name:definition},registry=registry,app_config=config,desktop_resource=DesktopResource())
            with pytest.MonkeyPatch.context() as mp:
                mp.setenv('SMOKE_JEV_KEY',credential['jev'])
                if mode=='fake':
                    sys.path.insert(0,str(REPO/'backend/core/tests'))
                    from sdk_http import install_typesafe_fake_http
                    mp.setattr(httpx,'AsyncHTTPTransport',HTTP);install_typesafe_fake_http(mp)
                    mp.setattr(socket.socket,'connect',connect)
                async for event in runner.run_agent(definition,[],task_id=mode+'-'+case['id'],task_input=goal,
                    authorization=SubAgentAuthorization(frozenset({'desktop','network'})),deadline=time.monotonic()+120,
                    token_budget=100000,max_actions=6,max_observations=24,observer=Observer(),audit=audit,
                    model_capture=Capture(),model_policy=BenchmarkModelPolicy(ledger,())):
                    if 'task_result' in event.metadata:result=event.metadata['task_result'];write(output/'task-result.json',result)
            final=await public_table(origin,output,'final-public-dom')
            write(output/'final-table.json',final.model_dump())
            def html():
                with urllib.request.urlopen(origin+'/work_items/content/',timeout=10) as response:
                    return response.read()
            (output/'final-list.html').write_bytes(await asyncio.to_thread(html))
    except BaseException as exc:
        error=type(exc).__name__
        import traceback
        write(output/'error.json',dict(type=error,frames=[dict(file=x.filename,line=x.lineno,function=x.name) for x in traceback.extract_tb(exc.__traceback__)]))
    finally:
        write(output/'database-after.json',product.database_state(database))
        write(output/'events.json',events);write(output/'captures.json',captures);write(output/'audit.json',audits)
        if server is not None and server.returncode is None:
            server.terminate()
            try:await asyncio.wait_for(server.wait(),5)
            except TimeoutError:server.kill();await server.wait()
        cleanup=dict(server_exit=None if server is None else server.returncode,
            runner_cleanup=None if result is None else result.get('cleanup'))
        write(output/'cleanup.json',cleanup)
    return dict(id=case['id'],attempted=True,status='returned' if result else 'error',error_type=error,
                elapsed_seconds=time.monotonic()-started,result=result,cleanup=cleanup,blocked_network=blocked)

async def batch(mode):
    f=check()
    if mode=='live':
        fake=json.loads((ROOT/'fake'/'result.json').read_text())
        audit=json.loads((ROOT/'fake'/'independent-audit.json').read_text())
        assert fake['freeze_sha256']==digest(ROOT/'freeze.json') and fake['completed'] and audit['all_passed']
    output=ROOT/mode;output.mkdir(exist_ok=False)
    credential={'jev':'fixture-only','vision':'fixture-only'}
    if mode=='live':
        from dotenv import dotenv_values
        values={**dotenv_values(REPO/'backend/core/.env'),**os.environ}
        credential={'jev':values.get('TYPESAFE_API_KEY') or '', 'vision':values.get('OPENROUTER_API_KEY') or ''}
        assert all(credential.values()),'required credentials missing'
    ledger=SpendLedger(SpendLimit(0,0),record_only=True,request_limit=24,journal=output/'spend.jsonl')
    result=dict(mode=mode,freeze_sha256=digest(ROOT/'freeze.json'),completed=False,
                rows=[dict(id=c['id'],attempted=False,status='not_run') for c in CASES],formal_N=None)
    def persist():
        result['spend']=ledger.snapshot();write(output/'result.json',result)
    persist()
    try:
        with sdk_diagnostics(output/'sdk-diagnostics.jsonl'):
            for row,case in zip(result['rows'],CASES):
                check();ledger.start_trial(case['id'],SpendLimit(0,0))
                row.update(await trial(case,output/case['id'],mode,credential,ledger))
                ledger.finish_trial();persist()
                # The separate auditor gates the next task; it does not import this driver.
                proc=await asyncio.create_subprocess_exec(sys.executable,str(ROOT/'audit.py'),mode,case['id'],stdout=asyncio.subprocess.PIPE)
                stdout,_=await proc.communicate();print(stdout.decode().strip(),flush=True)
                assert proc.returncode==0,'independent audit stopped batch'
                r=row.get('result') or {}
                assert not row['error_type'] and row['cleanup']['runner_cleanup']=='confirmed'
                assert r.get('status')!='unknown' and not r.get('details',{}).get('pending_effect')
                assert ledger.snapshot()['stop_reason'] is None
            result['completed']=True
    finally:
        ledger.close();persist()
    print(json.dumps(dict(mode=mode,completed=result['completed'],rows=[dict(id=r['id'],status=r['status'],result=r.get('result',{}).get('status')) for r in result['rows']],spend=result['spend']['batch'])),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1] in {'fake','live'}:asyncio.run(batch(sys.argv[1]))
    else:raise SystemExit('prepare|fake|live')
