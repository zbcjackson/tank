"""Compare preserved model-input/final pictures; not the internal refusal frame."""
import json,sys
from pathlib import Path
from PIL import Image,ImageChops
p=Path(sys.argv[1]);r=json.loads((p/'result.json').read_text());out=[]
for row in r['rows']:
 if row['status']=='not_run' or (row['scenario']=='positive' and row['strict_completed']) or row['scenario'] not in ('positive','no_effect') or (row['scenario']=='no_effect' and row['negative_passed']):continue
 raw=[json.loads(l)for l in (p/row['id']/'calls.jsonl').read_text().splitlines()];requests=[x for x in raw if 'request'in x];responses={x['call_id']:x['response']for x in raw if 'response'in x};last=requests[-1];reply=responses[last['call_id']];packet=json.loads(last['request']['messages'][1]['content'][0]['text']);choice=json.loads(reply['choices'][0]['message']['content'])['choice'];candidate=packet['questions']['next_action']['criteria'][choice]
 a=Image.open(p/row['id']/last['images'][0]['path']).convert('RGB');b=Image.open(p/row['id']/'final.png').convert('RGB');diff=ImageChops.difference(a,b);bbox=diff.getbbox();pixels=sum(v!=(0,0,0)for v in diff.getdata())
 out.append({'id':row['id'],'reason':row['result']['reason'],'last_model_choice':choice,'last_model_candidate':candidate,'trail':row['page_state']['trail'],'fields':row['page_state']['fields'],'preserved_model_vs_final_diff_bbox':bbox,'different_pixels':pixels,'boundary':'final.png is after controller return, not the exact internal refusal-time capture'})
Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
