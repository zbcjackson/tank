"""Independent route result, raw usage and fixture-path audit."""
import base64,hashlib,json,statistics,sys
from pathlib import Path
p=Path(sys.argv[1]); out=Path(sys.argv[2]); f=json.loads((p/'freeze.json').read_text()); r=json.loads((p/'result.json').read_text())
h=lambda b:hashlib.sha256(b).hexdigest()
root=Path('/Users/zbcjackson/src/tank/backend');assert all(h((root/n).read_bytes())==v for n,v in f['source_sha256'].items())
assert f['sha256']==r['sha256'];cases={c['id']:c for c in f['cases']};assert len(r['rows'])==len(f['schedule'])==24
assert [(x['id'],x['case'],x['arm'])for x in r['rows']]==[(x['id'],x['case'],x['arm'])for x in f['schedule']]
assert r['spend']==json.loads((p/'spend.jsonl').read_text().splitlines()[-1]);calls=[];rows=[];ids=set()
for row in r['rows']:
 c=cases[row['case']];d={'id':row['id'],'case':row['case'],'arm':row['arm'],'layout':c['layout'],'scenario':c['scenario'],'status':row['status']}
 if row['status']=='not_run':
  d.update(strict_completed=False,negative_passed=False,capped_completion_ms=120000 if c['scenario']=='positive'else None);rows.append(d);continue
 disk=json.loads((p/row['id']/'row.json').read_text());assert disk==row
 raw=[json.loads(l)for l in (p/row['id']/'calls.jsonl').read_text().splitlines()];reqs=[q for q in raw if 'request'in q];resp={q['call_id']:q['response']for q in raw if 'response'in q}
 assert reqs==row['calls'];assert len(reqs)==len(resp)
 it=ot=0; sequence=[];reported_cost=0.0
 for q in reqs:
  cid=q['call_id'];assert cid not in ids;ids.add(cid);a=resp[cid];req=q['request'];peer='messages'in req;model='peer'if peer else 'jev';sequence.append(model)
  ledger=r['spend']['requests'][cid];assert ledger['trial']==row['id']and ledger['status']=='known'
  if peer:
   assert req['model']==f['models']['peer']['model'] and req['response_format']=={'type':'json_object'}
   u=a['usage'];prompt,completion=u['prompt_tokens'],u['completion_tokens'];reported_cost+=u.get('cost')or 0
   parts=req['messages'][1]['content'];packet=json.loads(parts[0]['text']);png=base64.b64decode(parts[1]['image_url']['url'].split(',',1)[1]);info=q['images'][0];assert h(png)==info['sha256']and png==(p/row['id']/info['path']).read_bytes()
  else:
   packet=req;prompt,completion=a['input_tokens'],a['output_tokens'];assert not q['images']
  assert 'oracle' not in packet['state'] and 'html' not in packet['state']
  assert not any(tag in packet['state']['goal']['goal_id']for tag in ('positive','stale','no_effect','absent'))
  assert ledger['input_tokens']==prompt and ledger['output_tokens']==completion
  it+=prompt;ot+=completion
  calls.append({'row':row['id'],'call_id':cid,'model':model,'input_tokens':prompt,'output_tokens':completion,'estimate_nano_usd':prompt*f['price_nano_usd'][model][0]+completion*f['price_nano_usd'][model][1]})
 assert row['usage']['prompt_tokens']==it and row['usage']['completion_tokens']==ot and not row['usage']['unknown_calls']
 state=row['page_state'];res=row['result'];trail=state['trail'];clean=row['cleanup_confirmed'];positive=c['scenario']=='positive'
 strict=bool(clean and row['elapsed_ms']<=120000 and positive and res['status']=='completed'and trail==c['oracle']['events']and state['result']==c['goal']['completion'][0]['value'])
 if strict and c['layout']!='grid':assert state['fields']=={'work':'Launch','archive':'Draft'}
 negative=False
 if c['scenario']=='absent':negative=bool(clean and not trail and res['reason']in('none','no_progress'))
 if c['scenario']=='stale':negative=bool(clean and row['mutation_applied']and not trail and res['reason']=='stale_reference')
 if c['scenario']=='no_effect':negative=bool(clean and trail==c['oracle']['events']and res['reason']=='effect_unknown'and res['details']['pending_effect']and state['result']=='idle')
 assert strict==row['strict_completed']and negative==row['negative_passed']
 cap=(row['elapsed_ms']if strict else 120000)if positive else None;assert cap==row['capped_completion_ms']
 finished=[e for e in row['events']if e['kind']=='model_call'and e.get('phase')=='finished'];assert len(finished)==len(reqs)and all(e['task_id']==row['task_id']for e in finished)
 assert [e['call_id']for e in finished]==[q['call_id']for q in reqs]
 captures=sum(e['kind']=='task_execution'and e.get('operation')=='computer_use.capture'and e.get('phase')=='finished'for e in row['events']);assert captures==row['visual_captures']
 rules=sum(e['kind']=='computer_use_dispatch'and e.get('selected_by')=='rules'for e in row['events']);assert rules==row['rules_actions']
 d.update(strict_completed=strict,negative_passed=negative,cleanup_confirmed=clean,reason=res['reason'],task_status=res['status'],elapsed_ms=row['elapsed_ms'],capped_completion_ms=cap,sequence=sequence,input_tokens=it,output_tokens=ot,captures=captures,rules=rules,trail=trail,reported_peer_cost_usd=reported_cost,visual_fallbacks=sum(e.get('purpose')=='computer_use.visual_fallback'for e in finished),returned_to_jev=any(sequence[i]=='peer'and'jev'in sequence[i+1:]for i in range(len(sequence))))
 rows.append(d)
assert len(calls)==len(r['spend']['requests'])
assert sum(c['input_tokens']+c['output_tokens']for c in calls)==r['spend']['batch']['known_tokens']
def aggregate(ds):
 pos=[d for d in ds if d['scenario']=='positive'];neg=[d for d in ds if d['scenario']!='positive'];called=[d for d in ds if'sequence'in d];lat=[d['capped_completion_ms']for d in pos]
 return {'planned':len(ds),'run':len(called),'positive':len(pos),'strict_completed':sum(d['strict_completed']for d in pos),'negative':len(neg),'negative_passed':sum(d['negative_passed']for d in neg),'mean_capped_completion_ms':statistics.mean(lat)if lat else None,'mean_actual_ms':statistics.mean(d['elapsed_ms']for d in called)if called else None,'calls':sum(len(d['sequence'])for d in called),'image_calls':sum(d['sequence'].count('peer')for d in called),'jev_calls':sum(d['sequence'].count('jev')for d in called),'captures':sum(d['captures']for d in called),'rules':sum(d['rules']for d in called),'returns_to_jev':sum(d['returned_to_jev']for d in called),'fallbacks':sum(d['visual_fallbacks']for d in called),'cleanup_confirmed':sum(d.get('cleanup_confirmed',False)for d in ds)}
s={'sha256':f['sha256'],'completed':r['completed'],'stop_reason':r['spend']['stop_reason'],'source_files':len(f['source_sha256']),'rows':rows,'calls':calls,'arms':[{'arm':a,**aggregate([d for d in rows if d['arm']==a])}for a in('v','jt')],'groups':[{'arm':a,'scenario':scenario,'layout':layout,**aggregate([d for d in rows if d['arm']==a and d['scenario']==scenario and d['layout']==layout])}for a in('v','jt')for scenario,layout in [('positive','form'),('positive','grid'),('positive','drawer'),('absent','grid'),('stale','form'),('no_effect','form')]],'model_usage':[{'model':m,'calls':sum(c['model']==m for c in calls),'input_tokens':sum(c['input_tokens']for c in calls if c['model']==m),'output_tokens':sum(c['output_tokens']for c in calls if c['model']==m),'estimate_nano_usd':sum(c['estimate_nano_usd']for c in calls if c['model']==m)}for m in('jev','peer')],'reported_peer_cost_usd':sum(d.get('reported_peer_cost_usd',0)for d in rows),'total_tokens':sum(c['input_tokens']+c['output_tokens']for c in calls),'unknown_requests':[cid for cid,q in r['spend']['requests'].items()if q['status']!='known'],'cost_status':r['spend']['cost_status']}
pairs=[]
for cid in cases:
 ds={d['arm']:d for d in rows if d['case']==cid};pairs.append({'case':cid,'scenario':cases[cid]['scenario'],'v_completed':ds['v']['strict_completed'],'jt_completed':ds['jt']['strict_completed'],'v_passed':ds['v']['negative_passed'],'jt_passed':ds['jt']['negative_passed'],'v_capped_ms':ds['v']['capped_completion_ms'],'jt_capped_ms':ds['jt']['capped_completion_ms']})
s['pairs']=pairs
for a in s['arms']:
 selected=[c for c in calls if c['row'].endswith('-'+a['arm'])]
 a['input_tokens']=sum(c['input_tokens']for c in selected)
 a['output_tokens']=sum(c['output_tokens']for c in selected)
 a['estimate_nano_usd']=sum(c['estimate_nano_usd']for c in selected)
out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items()if k not in('rows','calls','pairs')},indent=2))
