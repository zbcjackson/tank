"""Archive completed evidence after scanning actual configured credential bytes."""
import hashlib,json,os,re,tarfile,sys
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank'); live=Path(sys.argv[1]); artifacts=root/'docs/research/artifacts'
h=lambda b:hashlib.sha256(b).hexdigest()
old={
'jev-image-capability-pilot-20261018.tar.gz':'b650b6b0b2f4061aa08f9f24f3f1635ab6eadd797e1dbd01707980b950f3179f',
'jev-image-capability-v2-pilot-20261018.tar.gz':'8b570058ae2f9da9bce985953c2b52c8dcc8a97e4c6b624714e2bf9247622ba5',
'jev-image-native-pilot-20261019.tar.gz':'b123f319a4d3d04eb4249b817f8e6b28c783ce46afa4f0c620e7d9bc721f4a34',
'jev-image-real-app-ablation-20261019.tar.gz':'7f66fe802897fc04f6a4557a88a69507cda9ddc16286ce734e163aebeef8182e',
'jev-frame-freshness-diagnostics-20261019.tar.gz':'ae33eb256844ac57bc36e763e7c9956c2b877feaa30b1e17cdb37e6e3623c381',
'jev-bound-frame-capture-20261019.tar.gz':'d9235bc413b6ef984e85b611c06b4e9661be3a2e13d21739e1a9539a0622dc6f',
'jev-post-crop-live-validation-20261019.tar.gz':'4c22fba4b5c3cb5b86d3625875f2bd2f78bd4d3d3e352f82ab97e76d2144e361',
'jev-box-crop-comparison-20261019.tar.gz':'5558b83d92adda445342d244b3f630fb744d55d1549c13462dd1f60226a9b94e'}
assert all(h((artifacts/n).read_bytes())==sha for n,sha in old.items())
result=json.loads((live/'result.json').read_text())
files={'live/'+str(p.relative_to(live)):p for p in live.rglob('*')if p.is_file()}
for name in ('analyze.py','summary.json','pack.py','frame-diagnostic.py','frame-diagnostic.json'):
 p=Path('/private/tmp/tank-route-'+name);files['analysis/'+p.name]=p
for p in sorted(Path('/private/tmp').glob('tank-route-*.log')):files['verification/'+p.name]=p

values={**dotenv_values(root/'backend/core/.env'),**os.environ}
secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)]
assert len(secrets)>0
for name,p in files.items():
 data=p.read_bytes();assert not any(s in data for s in secrets),f'credential found: {name}'
archive=artifacts/'jev-vision-route-pilot-20261019.tar.gz'
assert not archive.exists(),'preserve existing archive'
with tarfile.open(archive,'w:gz')as tf:
 for n,p in sorted(files.items()):tf.add(p,arcname=n,recursive=False)
manifest={'date':'2026-10-19','baseline_commit':'e58e6bec','implementation_commit':'4aca2a92','review_commit':sys.argv[2],'freeze_sha256':result['sha256'],'archive_sha256':h(archive.read_bytes()),'credential_values_scanned':len(secrets),'old_archives_unchanged':old,'files':{n:{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for n,p in sorted(files.items())}}
with tarfile.open(archive,'r:gz')as tf:
 assert set(tf.getnames())==set(files)
 for m in tf.getmembers():
  b=tf.extractfile(m).read();assert h(b)==manifest['files'][m.name]['sha256'] and len(b)==manifest['files'][m.name]['bytes']
manifest_path=archive.with_name('jev-vision-route-pilot-20261019-manifest.json');manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'credentials_scanned':len(secrets),'old_archives_unchanged':len(old)}))
