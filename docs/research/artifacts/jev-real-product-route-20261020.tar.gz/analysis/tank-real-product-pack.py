"""Pack exact closed-task evidence, app bytes and source after credential scanning."""
import hashlib,io,json,os,re,subprocess,sys,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank');artifacts=root/'docs/research/artifacts';live=Path(sys.argv[1]);h=lambda b:hashlib.sha256(b).hexdigest();old={}
for p in sorted(artifacts.glob('*-manifest.json')):
 if not(p.name.startswith('jev-')or p.name.startswith('dom-visual-freshness-')):continue
 prior=subprocess.run(['git','show','3429b1ef:'+str(p.relative_to(root))],cwd=root,capture_output=True)
 if prior.returncode:continue
 assert prior.stdout==p.read_bytes();m=json.loads(prior.stdout);archive=p.with_name(p.name.replace('-manifest.json','.tar.gz'));assert h(archive.read_bytes())==m['archive_sha256'];old[archive.name]=m['archive_sha256']
assert len(old)==11
f=json.loads((live/'freeze.json').read_text());r=json.loads((live/'result.json').read_text());assert f['sha256']==r['sha256'];files={'live/'+str(p.relative_to(live)):p for p in live.rglob('*')if p.is_file()}
for name,sha in f['source_sha256'].items():
 p=root/'backend'/name;assert h(p.read_bytes())==sha;files['source/'+name]=p
appenv=Path(f['app']['python']).parent.parent
for name,sha in f['app']['files'].items():
 p=appenv/name;assert h(p.read_bytes())==sha;files['app/'+name]=p
for name in('analyze.py','summary.json','pack.py','failure-diagnostic.py','failure-diagnostic.json'):
 p=Path('/private/tmp/tank-real-product-'+name);files['analysis/'+p.name]=p
for p in sorted(Path('/private/tmp').glob('tank-real-product-*.log')):
 if p.name!='tank-real-product-pack-result.log':files['verification/'+p.name]=p
probe=Path('/private/tmp/tank-sqlite-web-probe-20261020')
for name in('probe.json','after-links.json','probe.py'):
 p=probe/name
 if p.exists():files['probe/'+name]=p
for p in probe.glob('*.png'):files['probe/latest-controls/'+p.name]=p
values={**dotenv_values(root/'backend/core/.env'),**os.environ};secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)];assert secrets
for name,p in files.items():assert not any(s in p.read_bytes()for s in secrets),f'credential found: {name}'
archive=artifacts/'jev-real-product-route-20261020.tar.gz';assert not archive.exists()
manifest={'date':'2026-10-20','baseline_commit':'3429b1ef','plan_commit':'8bda2b23','implementation_commit':sys.argv[3],'first_review_commit':sys.argv[2],'freeze_sha256':f['sha256'],'credential_values_scanned':len(secrets),'old_archives_unchanged':old,'files':{}}
with tarfile.open(archive,'w:gz')as tf:
 for name,p in sorted(files.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data));manifest['files'][name]={'bytes':len(data),'sha256':h(data)}
manifest['archive_sha256']=h(archive.read_bytes())
with tarfile.open(archive,'r:gz')as tf:
 assert set(tf.getnames())==set(files)
 for m in tf.getmembers():
  data=tf.extractfile(m).read();assert len(data)==manifest['files'][m.name]['bytes']and h(data)==manifest['files'][m.name]['sha256']
archive.with_name('jev-real-product-route-20261020-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(files),'app_files':len(f['app']['files']),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'old_archives':len(old),'credential_values':len(secrets)}))
