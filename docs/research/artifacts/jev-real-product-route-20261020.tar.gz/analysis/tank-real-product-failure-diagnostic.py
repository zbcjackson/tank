"""Read-only paired first-observation comparison; no model calls or host imports."""
import hashlib,json,re
from pathlib import Path
p=Path('/private/tmp/tank-real-product-live-20261020');cases={}
for arm in('v','jt'):
 d=p/('update-1-normal-'+arm);raw=[json.loads(l)for l in(d/'calls.jsonl').read_text().splitlines()];requests=[q for q in raw if'request'in q];replies={q['call_id']:q['response']for q in raw if'response'in q}
 q=next(q for q in requests if'messages'in q['request']);packet=json.loads(q['request']['messages'][1]['content'][0]['text']);refs={e['ref']:'e'+str(i)for i,e in enumerate(packet['state']['snapshot']['elements'])}
 def norm(v):
  if isinstance(v,str):return refs.get(v,re.sub(r'http://127\.0\.0\.1:\d+','http://loopback',v))
  if isinstance(v,list):return[norm(x)for x in v]
  if isinstance(v,dict):return{k:norm(x)for k,x in v.items()if k not in('binding','observation_id','frame_id')}
  return v
 canonical=norm(packet);offered={k:v for k,v in packet['questions']['next_action']['criteria'].items()if isinstance(v,dict)};elements=packet['state']['snapshot']['elements'];a=replies[q['call_id']]
 choice=json.loads(a['choices'][0]['message']['content'])['choice'];selected=offered.get(choice)
 cases[arm]={'canonical_packet':canonical,'input_image_sha256':q['images'][0]['sha256'],'choice':choice,'selected_label':selected.get('label')if selected else None,'selected_role':selected.get('role')if selected else None,'candidate_count':len(offered),'offered_checkboxes':[{'label':v['label'],'current_value':v['current_value'],'effect':v['effect']}for v in offered.values()if v['role']=='checkbox'],'unoffered_checkboxes':[{'role':e['role'],'label':e['label'],'kind':e['kind'],'value':e['value']}for e in elements if e['role']=='checkbox'and not e['actions']]}
 if arm=='jt':cases[arm]['text_choices']=[replies[t['call_id']]['choice']for t in requests if'messages'not in t['request']]
s={'case':'update-1-normal','same_input_image':cases['v']['input_image_sha256']==cases['jt']['input_image_sha256'],'same_canonical_packet':cases['v']['canonical_packet']==cases['jt']['canonical_packet'],'canonicalization':'Map DOM refs by snapshot order; normalize loopback port; omit binding, observation_id and frame_id only. Retain goals, facts, candidates, progress, instructions and pixel boxes.','arms':{a:{k:v for k,v in c.items()if k!='canonical_packet'}for a,c in cases.items()}}
for a,c in cases.items():s['arms'][a]['canonical_sha256']=hashlib.sha256(json.dumps(c['canonical_packet'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
Path('/private/tmp/tank-real-product-failure-diagnostic.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
