import asyncio,json
from dataclasses import asdict
from pathlib import Path
from agent_computer_use.channels.dom import ManagedChromiumChannel,BrowserConfig
from agent_computer_use.action_builder import ActionBuilder
from agent_computer_use.contracts import GoalContract
from tank_backend.agents.subagent import SubAgentAuthorization,SubAgentBudget,SubAgentContext
async def main():
 ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event())
 ctx.runtime.bind('real-app-probe')
 ch=ManagedChromiumChannel(BrowserConfig(scope='real-app-probe',url='http://127.0.0.1:59371/'))
 records=[]
 try:
  for path in ('/','/work_items/content/','/work_items/insert/','/work_items/update/WzFd/'):
   await ch.start(ctx);await ch.page.goto('http://127.0.0.1:59371'+path)
   s=await ch.observe('real-app-probe',ctx)
   g=GoalContract.from_input({'schema_version':2,'goal_id':'probe','scope':'real-app-probe','authorization_ref':'current_task','intent':'Create a work item','objective':'Create a work item','allowed_operations':['click','fill'],'inputs':[],'completion':[{'key':'status:Record','value':'created'}]})
   a=ActionBuilder(visual=True).build('probe',1,g,s)
   records.append({'path':path,'url':ch.page.url,'complete':s.complete,'elements':[asdict(e)for e in s.elements],'facts':[f.model_dump()for f in s.facts],'candidate_count':len(a.actions),'reason':a.reason})
   await ch.page.screenshot(path='/private/tmp/tank-sqlite-web-probe-20261020/'+str(len(records))+'.png',full_page=True)
 finally:await ch.aclose();await ctx.runtime.aclose()
 Path('/private/tmp/tank-sqlite-web-probe-20261020/after-links.json').write_text(json.dumps(records,indent=2,default=lambda v:v.model_dump()))
 print(json.dumps([{k:r[k]for k in ('path','url','complete','candidate_count','reason')}for r in records],indent=2))
asyncio.run(main())
