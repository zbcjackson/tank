"""Repeat the approved isolated E2E profile and restore the development pane."""
import json
import os
import signal
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path('/Users/zbcjackson/src/tank')
env = dict(os.environ, UV_CACHE_DIR='/private/tmp/tank-uv-cache', DYLD_LIBRARY_PATH='/opt/homebrew/Cellar/opus/1.6.1/lib')

def healthy():
    try:
        with urllib.request.urlopen('http://127.0.0.1:8000/api/health', timeout=1) as response:
            return response.status == 200
    except (OSError, urllib.error.URLError):
        return False

def wait_health(expected, timeout=45):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if healthy() == expected:
            return
        time.sleep(0.5)
    raise RuntimeError(f'health did not become {expected}')

subprocess.run(['tmux','send-keys','-t','%0','C-c'], check=True)
service = None
passed = False
try:
    wait_health(False)
    with (ROOT/'server.log').open('w') as log:
        service = subprocess.Popen(['uv','run','--no-sync','python',str(ROOT/'offline_e2e_server_v2.py')], cwd=REPO/'backend/core', env=env, stdout=log, stderr=subprocess.STDOUT)
        wait_health(True)
        effective = json.loads((ROOT/'offline-e2e-effective-config.json').read_bytes())
        assert effective['asr'] == 'asr-sherpa:asr'
        assert effective['llm_url'].startswith('http://127.0.0.1:')
        assert str(ROOT/'offline-e2e.db') in effective['database']
        assert effective['local_credential_asserted'] is True
        assert effective['tts_enabled'] is False and effective['jobs_enabled'] is False
        print('Verified actual local Sherpa, loopback LLM and isolated DB; running E2E.', flush=True)
        with (ROOT/'cucumber.log').open('w') as output:
            result = subprocess.run(['pnpm','test'], cwd=REPO/'test', env=env, stdout=output, stderr=subprocess.STDOUT, timeout=600)
        assert result.returncode == 0, f'E2E failed: {result.returncode}'
        passed = True
finally:
    if service is not None:
        pid_path = ROOT/'offline-e2e-server.pid'
        if pid_path.exists():
            pid = int(pid_path.read_text())
            try:
                os.kill(pid, signal.SIGINT)
            except ProcessLookupError:
                pass
        service.wait(timeout=45)
        wait_health(False)
    subprocess.run(['tmux','send-keys','-t','%0','UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync tank-backend --reload','Enter'], check=True)
    wait_health(True)
    (ROOT/'dev-service-restored.json').write_text(json.dumps({'healthy':True, 'command':'UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync tank-backend --reload', 'cwd':str(REPO/'backend/core')}, indent=2)+'\n')
    print('Original dev service restored and healthy.', flush=True)
if passed:
    egress = json.loads((ROOT/'offline-e2e-egress.json').read_bytes())
    assert egress['external_python_socket_attempts'] == []
    print('E2E passed; isolated server recorded no external socket attempts.', flush=True)
