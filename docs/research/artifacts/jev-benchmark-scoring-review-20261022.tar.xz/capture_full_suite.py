"""Preserve complete regression receipts and source bytes, excluding per-task apps/DB/PNGs."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT=Path('/Users/zbcjackson/src/tank')
OUT=Path(__file__).parent/'full-suite-calibration'
SOURCE=Path('/private/var/folders/py/dh2pmb9j0yg47_58kb1bh5pw0000gn/T/pytest-of-zbcjackson/pytest-820/test_calibration_all_96_trials0/calibration')
frozen=json.loads((SOURCE/'freeze.json').read_bytes())
result=json.loads((SOURCE/'result.json').read_bytes())
assert result['sha256']==frozen['sha256']
assert result['completed'] is True and len(result['rows'])==96
assert sum(r['strict_completed'] for r in result['rows'])==80
assert sum(r['negative_passed'] for r in result['rows'])==16
assert all(r['status']=='finished' and r['calibration_success'] and r['cleanup_confirmed'] for r in result['rows'])
assert result['spend']['stop_reason'] is None
files=['freeze.json','result.json','spend.jsonl','started.json']
for name, expected in frozen['source_sha256'].items():
    archived=SOURCE/'source'/name
    assert hashlib.sha256(archived.read_bytes()).hexdigest()==expected
    assert archived.read_bytes()==(ROOT/'backend'/name).read_bytes()
    files.append('source/'+name)
OUT.mkdir()
members=[]
for name in files:
    source=SOURCE/name
    target=OUT/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert target.read_bytes()==source.read_bytes()
    members.append({'path':name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
summary={'source_directory':str(SOURCE),'freeze_sha256':frozen['sha256'],'completed':True,'rows':96,'strict_completed':80,'negative_passed':16,'source_files_verified':len(frozen['source_sha256']),'members':members,'evidence_kind':'fake-regression','paid_model_calls':0,'excluded':'Per-trial application copies, DB files and PNGs remain in pytest temporary output'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(f"Preserved {len(files)} original source/receipt files; 96 finished rows, 80 strict, 16 negative, all cleanup confirmed.")
