# Backend Testing Guidelines

This document provides testing guidelines for the Tank Backend API Server.

For cross-cutting principles, see [../TESTING.md](../TESTING.md).

## Framework

- **Framework**: `pytest` with `pytest-asyncio`
- **Location**: `core/tests/`, `contracts/*/tests/`, `plugins/*/tests/`
- **Config**: workspace 根目录 `pyproject.toml` — `asyncio_mode = "auto"`

从 `backend/` 执行 `uv run pytest` 会运行整个 workspace 的测试。统一配置使用
`--import-mode=importlib`，并将 `core/tests` 加入测试 helper 的导入路径。
插件测试目录不添加 `__init__.py`：同名 `tests` 包会让不同插件的测试模块冲突，
即使 importlib 模式也可能重复收集另一个插件的测试。

## Testing Commands

```bash
uv run pytest                                    # All tests
uv run pytest -v                                 # Verbose
uv run pytest core/tests/test_brain.py          # Specific file
uv run pytest core/tests/test_brain.py::test_name # Specific test
uv run pytest --cov=core/src/tank_backend       # With coverage
uv run pytest --cov=core/src/tank_backend --cov-report=html
```

## TDD Workflow

1. Write a failing test describing the desired behavior
2. Implement the minimal code to make it pass
3. Refactor while keeping tests green
4. Run the full suite before committing

The four-record calibration coverage is in the existing Computer Use `test_dom.py`:
actual applications/Chromium/SDK with fake model HTTP, all 96 scheduled trials,
current-list completion, public-identity acceptance, authorization revocation and
retained batch denominators. Set `TANK_REQUIRE_CHROMIUM=1`,
`TANK_REAL_PRODUCT_PYTHON=<qualified-sqlite-web-python>` and
`TANK_LINKDING_ROOT=<qualified-linkding-root>` for the full verification run.
`test_calibration_all_96_trials_through_real_controller` is a wiring test, not
real-model quality or latency evidence. Preserve its source freeze and raw output
when using it as an implementation-review artifact. Browser-only contracts include
rendered text/whitespace, explicit candidate budgets and real navigation during
observation; stale references remain refused. No new feature file is needed.

## What to Mock

Always mock:
- **LLM API** (`httpx.AsyncClient`, `openai.AsyncOpenAI`)
- **Audio hardware** (`sounddevice.InputStream`, `sounddevice.play`)
- **ML model loading** (Whisper, Silero VAD)
- **External APIs** (web search, weather)
- **System time** — use fixed timestamps
- **Langfuse** — mock or disable via env vars
- **Docker sandbox** — mock subprocess calls for code execution tools

Use real implementations for:
- Pure logic (tool calculations, text processing, echo detection)
- Data structures and event types (Bus, BusMessage, AgentState)
- Pipeline primitives (ThreadedQueue, FlowReturn)
- Approval policy logic (no I/O)
- Fast, deterministic components (< 100ms)

## Key Patterns

### Async Tests

All async tests run automatically with `asyncio_mode = "auto"`:

```python
async def test_brain_processes_input():
    brain = Brain(config=mock_config)
    result = await brain.process_input("hello")
    assert result is not None
```

### Mocking LLM

```python
from unittest.mock import AsyncMock, patch

async def test_llm_call():
    with patch("tank_backend.llm.llm.AsyncOpenAI") as mock_openai:
        mock_client = AsyncMock()
        mock_openai.return_value = mock_client
        mock_client.chat.completions.create.return_value = make_completion("Hello!")

        llm = LLM(config)
        result = await llm.complete([{"role": "user", "content": "hi"}])
        assert result == "Hello!"
```

### Mocking Audio Hardware

```python
from unittest.mock import patch, MagicMock

def test_mic_capture():
    with patch("sounddevice.InputStream") as mock_stream:
        mock_stream.return_value.__enter__ = MagicMock(return_value=mock_stream.return_value)
        mock_stream.return_value.__exit__ = MagicMock(return_value=False)
        # Test mic component without real hardware
```

### Mocking Whisper

```python
with patch("tank_backend.audio.input.asr_whisper.WhisperModel") as mock_model_cls:
    mock_model = MagicMock()
    mock_model.transcribe.return_value = (
        [MagicMock(text="hello world")],
        MagicMock(language="en", language_probability=0.99)
    )
    mock_model_cls.return_value = mock_model
    asr = WhisperASR(config)
    text, lang, conf = asr.transcribe(audio_data, 16000)
    assert text == "hello world"
```

### Generating Audio Test Data

```python
import numpy as np

def make_audio_frame(sample_rate=16000, duration_ms=20, frequency=440):
    n = int(sample_rate * duration_ms / 1000)
    t = np.linspace(0, duration_ms / 1000, n)
    return (0.3 * np.sin(2 * np.pi * frequency * t)).astype(np.float32)

def make_silence(sample_rate=16000, duration_ms=20):
    return np.zeros(int(sample_rate * duration_ms / 1000), dtype=np.float32)
```

### Fixed Timestamps

```python
BASE_TIME = 1000.0  # Fixed, not time.time()

frames = [
    AudioFrame(data=make_audio_frame(), timestamp_s=BASE_TIME + i * 0.02)
    for i in range(10)
]
```

### Module Constant for Patch Targets

```python
MODULE = "tank_backend.audio.output.tts_engine_edge"

with patch(f"{MODULE}.shutil.which", return_value=None), \
     patch(f"{MODULE}.edge_tts") as mock_et:
    ...
```

### Shared Mock Helpers

```python
def make_llm_completion(content: str):
    """Build a minimal mock ChatCompletion."""
    choice = MagicMock()
    choice.message.content = content
    choice.message.tool_calls = None
    completion = MagicMock()
    completion.choices = [choice]
    completion.usage.prompt_tokens = 10
    completion.usage.completion_tokens = 5
    return completion
```

### Async Stream Collection

```python
async def collect_chunks(engine, text, **kwargs):
    chunks = []
    async for chunk in engine.generate_stream(text, **kwargs):
        chunks.append(chunk)
    return chunks
```

## Test Organization

```
tests/
├── conftest.py                    # Shared fixtures (config, audio helpers)
├── test_brain.py                  # Brain / conversation logic
├── test_llm.py                    # LLM client
├── test_tools.py                  # Tool execution
├── test_asr.py                    # ASR components
├── test_tts_engine_edge.py        # TTS engine
├── test_segmenter.py              # VAD + segmenter
├── test_api.py                    # FastAPI routes / WebSocket
├── test_pipeline.py               # Pipeline primitives (Bus, Queue, FlowReturn)
├── test_processors.py             # Individual processor tests
├── test_agents.py                 # Agent orchestration (AgentGraph)
├── test_approval.py               # Approval system (policy, manager, API)
├── test_echo_guard.py             # Echo guard (Layer 2 text detection)
├── test_checkpointer.py           # Conversation persistence
└── test_observers.py              # Observer tests (latency, health, alerting)
```

## Testing Pipeline Components

### Testing Processors

Test `process()` in isolation with mock inputs — no real audio or LLM:

```python
from tank_backend.pipeline.processor import FlowReturn

async def test_echo_guard_detects_self_echo():
    guard = EchoGuard(config={"similarity_threshold": 0.6, "window_seconds": 10.0})
    guard.record_tts("The weather today is sunny and warm")

    # Simulate ASR transcript that echoes TTS
    result = guard.is_echo("the weather today is sunny and warm")
    assert result is True

async def test_echo_guard_passes_new_speech():
    guard = EchoGuard(config={"similarity_threshold": 0.6, "window_seconds": 10.0})
    guard.record_tts("The weather today is sunny and warm")

    result = guard.is_echo("what time is it")
    assert result is False
```

### Testing the Bus

```python
from tank_backend.pipeline.bus import Bus, BusMessage

def test_bus_delivers_to_subscribers():
    bus = Bus()
    received = []
    bus.subscribe("metric", lambda msg: received.append(msg))

    bus.post(BusMessage(type="metric", source="test", payload={"value": 42}, timestamp=1000.0))
    bus.poll()

    assert len(received) == 1
    assert received[0].payload["value"] == 42
```

### Testing ThreadedQueue

```python
from tank_backend.pipeline.queue import ThreadedQueue

def test_queue_backpressure():
    q = ThreadedQueue(name="test", maxsize=2)
    assert q.push("a") == FlowReturn.OK
    assert q.push("b") == FlowReturn.OK
    # Queue is full — next push should indicate backpressure
```

## Testing Agents

### Testing Agents

Mock the LLM and tool manager — test the agent's streaming output:

```python
from unittest.mock import AsyncMock, MagicMock
from tank_backend.agents.base import AgentState, AgentOutputType

async def test_chat_agent_streams_tokens():
    mock_llm = AsyncMock()
    mock_tool_manager = MagicMock()
    agent = ChatAgent(llm=mock_llm, tool_manager=mock_tool_manager)

    state = AgentState(messages=[{"role": "user", "content": "hi"}])
    outputs = [o async for o in agent.run(state, mock_llm)]

    assert any(o.type == AgentOutputType.TOKEN for o in outputs)
```

### Testing Approval System

```python
from tank_backend.agents.approval import ApprovalPolicy, ApprovalManager

def test_approval_policy():
    policy = ApprovalPolicy(
        always_approve={"weather", "time"},
        require_approval={"run_command"},
        require_approval_first_time={"web_search"},
    )
    assert not policy.needs_approval("weather")
    assert policy.needs_approval("run_command")
    assert policy.needs_approval("web_search")

async def test_approval_manager_resolves():
    manager = ApprovalManager()
    request = ApprovalRequest(tool_name="run_command", tool_args={}, description="Run code")

    # Simulate approval in background
    import asyncio
    async def approve_later():
        await asyncio.sleep(0.01)
        pending = manager.get_pending()
        manager.resolve(pending[0].id, approved=True)

    asyncio.create_task(approve_later())
    result = await manager.request_approval(request)
    assert result.approved is True
```

## Testing Observability

### Testing Observers

```python
from tank_backend.pipeline.bus import Bus, BusMessage
from tank_backend.pipeline.observers.latency import LatencyObserver

def test_latency_observer_tracks_metrics():
    bus = Bus()
    observer = LatencyObserver(bus)

    # Simulate processor start/end
    observer.on_processor_start("asr", 1000.0)
    observer.on_processor_end("asr", 1000.050, 50.0)

    bus.poll()
    # Verify metric was posted to bus
```

### Testing Health Monitoring

```python
from tank_backend.pipeline.health import HealthAggregator

async def test_health_aggregator():
    aggregator = HealthAggregator()
    aggregator.register("llm", lambda: {"status": "healthy"})
    aggregator.register("asr", lambda: {"status": "degraded", "detail": "high latency"})

    result = await aggregator.check_all()
    assert result["status"] == "degraded"  # worst of all components
```

## Testing FastAPI Routes

```python
from fastapi.testclient import TestClient
from tank_backend.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200

async def test_websocket():
    with client.websocket_connect("/ws/test-session") as ws:
        ws.send_json({"type": "text", "content": "hello"})
        data = ws.receive_json()
        assert data["type"] in ("signal", "text")
```

## Performance Targets

- Unit tests: < 1 second each
- Integration tests: < 2 seconds each
- Full suite: < 30 seconds total

## Quality Checklist

- [ ] LLM, audio hardware, and ML models are mocked
- [ ] Tests verify observable behavior, not internals
- [ ] No access to private methods or internal attributes
- [ ] Fixed timestamps used instead of `time.time()`
- [ ] Audio data generated programmatically (numpy)
- [ ] Async tests run without real I/O
- [ ] Each test completes in < 2 seconds
- [ ] Shared helpers used to avoid duplication (MODULE constant, `make_*`, `collect_*`)
- [ ] Pipeline processors tested in isolation (mock upstream/downstream)
- [ ] Agent tests mock LLM and verify streaming output types
- [ ] Approval tests verify policy logic and async resolve flow
- [ ] Observer tests verify Bus message delivery
- [ ] Tool tests verify `ToolResult` return types and content completeness

## Tool Testing

### Unit Tests

Every tool must verify:
1. `execute()` returns `ToolResult` (not dict) on success and error paths
2. `ToolResult.content` contains all data the LLM needs (parse with `json.loads`)
3. `ToolResult.display` is a concise human-readable summary
4. `ToolResult.error` is `True` for error paths, `False` for success

```python
async def test_my_tool_success():
    tool = MyTool()
    result = await tool.execute(param="value")

    assert isinstance(result, ToolResult)
    assert not result.error

    data = json.loads(result.content)
    assert "expected_key" in data
    assert data["expected_key"] == "expected_value"

    assert len(result.display) < 300  # Concise summary
```

### Integration Tests

Test that tool results flow correctly to the LLM via `_tool_result_to_str()`:

```python
from tank_backend.llm.llm import _tool_result_to_str

def test_tool_result_extraction():
    result = ToolResult(
        content='{"key": "value"}',
        display="Summary",
    )
    llm_content, ui_display = _tool_result_to_str(result)
    assert llm_content == '{"key": "value"}'  # LLM sees full data
    assert ui_display == "Summary"             # UI sees summary
```

### Mocking Patterns

```python
# Mock a tool that returns ToolResult
tm = MagicMock()
tm.execute_openai_tool_call = AsyncMock(
    return_value=ToolResult(
        content='{"result": 42}',
        display="Result: 42",
    )
)

# Mock a skill tool that returns str
tm.execute_openai_tool_call = AsyncMock(
    return_value="SKILL ACTIVATED: test\nInstructions here"
)
```

## Integration Testing Requirements

Every feature must have integration tests that cover the **seams between components** — not just individual units in isolation. Unit tests with mocks can pass while the real system is broken at the integration points.

### What Integration Tests Must Cover

For each feature, test the full flow across component boundaries:

1. **Input → Processing → Output** — verify the end-to-end path produces the expected result
2. **Error paths** — verify failures are recorded/reported correctly across boundaries
3. **State synchronization** — verify that state changes in one component are visible to others

### Policy & Approval System (`test_policy_integration.py`)

| Test | What it verifies |
|------|-----------------|
| Gate + file tool REQUIRE_APPROVAL | `ToolApprovalPolicy` evaluates file tools, gate parks the call |
| Gate + file tool DENY | Gate hard-blocks, tool never executes |
| Gate + network tool | Same three-way flow for web_fetch/web_search |
| AlwaysApproveResolver + file tool | Autonomous `always_approve` executes file writes |
| AlwaysDenyResolver + file tool | Autonomous `always_deny` blocks file writes |
| InteractiveResolver parks all tools | Interactive mode parks command, file, and network tools |
| DENY ignores resolver | Hard blocks can't be overridden by any resolver |
| Policy routing per tool type | Command → CommandSecurityPolicy, file → FileAccessPolicy, etc. |

### Cron Job System (`test_jobs_integration.py`)

| Test | What it verifies |
|------|-----------------|
| Trigger → execute → deliver → history | Full end-to-end: output file created, run history recorded |
| Trigger via scheduler | `scheduler.trigger_job()` runs the full flow |
| Timeout enforcement | `asyncio.TimeoutError` recorded as status="timeout" |
| Failure recording | Exceptions recorded as status="failed" with error message |
| Seed sync + APScheduler | Seed file creates job AND registers APScheduler schedule |
| Seed removal + APScheduler | Removing from seed deletes from DB AND APScheduler |
| manage_jobs create → sync | Tool creates job AND syncs to APScheduler |
| manage_jobs delete → sync | Tool deletes job AND removes APScheduler schedule |
| manage_jobs disable → sync | Tool disables job AND removes APScheduler schedule |
| Approval mode → resolver | `always_deny` builds AlwaysDenyResolver, `always_approve` builds AlwaysApproveResolver |

### Writing New Integration Tests

When adding a new feature, ask these questions to identify missing integration tests:

1. **Does component A's output feed into component B?** → Test A→B together
2. **Does a state change in A need to be visible in B?** → Test the sync
3. **Does the feature have an approval/policy gate?** → Test all three verdicts (ALLOW, REQUIRE_APPROVAL, DENY)
4. **Does the feature have error/timeout paths?** → Test that errors are recorded across boundaries
5. **Can the feature be triggered from multiple entry points?** → Test each entry point (REST API, voice tool, seed file)

### Anti-patterns to Avoid

- **Mocking the boundary you're testing** — if you mock `_run_agent` to test timeout, you bypass the `asyncio.timeout()` inside it. Mock at a lower level or raise the expected exception directly.
- **Testing only the happy path** — DENY and REQUIRE_APPROVAL paths are where bugs hide.
- **Testing components in isolation when the bug is at the seam** — the `ApprovalCallback` was `None` for years because no integration test verified file tools actually got a working callback.

## Plugin subagents and Computer Use

`core/tests/test_subagent.py` exercises the generic contract and the real
AgentTool → Supervisor → Runner seam, including missing grants, scoped approval,
terminal errors, cleanup quarantine and lock-wait timeouts. Install all workspace
packages before running all plugin tests: `uv sync --all-packages --all-groups`,
then `uv run --no-sync pytest`. Add `--extra browser --extra vision` for the
Computer Use optional adapters. Yutori and cua-driver are no longer dependencies.

The existing chat.feature covers isolated structured plugin dispatch, outcomes,
cancellation and managed Chromium, with live client transport scenarios separately.
Old engine frontmatter is rejected rather than silently dispatched as an LLM agent.
Fake tests do not establish physical macOS input cleanup or model effectiveness.

Benchmark regression tests verify per-trial capture/token isolation, rejection of
stale tabs/late requests, correct PNG/WebP MIME, tool-call step boundaries,
smoke exclusion and suite abortion after unconfirmed cleanup.

## macOS coordinate chain

Bound native frames additionally retain backing pixels until after the window crop.
`test_vision.py` checks adjacent outside pixels cannot change the PNG or scene hash,
inside single-pixel changes still fail the actual native freshness gate, and logical
mapping survives 1x/1.5x/2x, odd/full-display crops and negative display origins.
Mismatched dimensions and invalid crops refuse. `test_computer_use_macos.py` exercises
the actual screenshot function with fake OS commands to ensure opt-in backing capture
does not downscale the whole display; existing default screenshot tests remain active.

`core/tests/test_computer_use_macos.py` covers backing-to-logical sizing, crop
and upscale pixels, image serialization through the actual OpenAI SDK HTTP
boundary, fragmented SSE arguments and final Quartz event coordinates. Only OS
and HTTP boundaries are mocked. Recorded synthetic model replies are replayed
without network calls; malformed replies must not inject mouse events.

For opt-in real desktop calibration, run from backend:
`uv run --no-sync python scripts/calibrate_macos_coordinates.py --output /tmp/tank-calibration-new`.
Use a fresh output directory, grant Screen Recording and Accessibility to the
host application, and leave the mouse idle. It opens its own target window,
checks visible target pixels before clicking, records down/up events and cursor
positions, and restores the cursor. Full desktop PNG stays local; do not upload
it as part of synthetic-only model tests. Only the main display is supported.

See [coordinate investigation](../docs/research/macos-coordinate-chain.md) for
conversion contracts, synthetic-model evidence and limits of the acceptance.

The macOS calc-open validator has unit and real-shell integration tests in
`core/tests/test_calc_validator.py`; only osascript is substituted in the shell
test. `test_bench_task.py` checks platform-specific strict/GUI-only scoring.
Real verification used the actual benchmark trial runner with deterministic
Calculator keyboard input: 5×7 fails, 7×8 passes, and setup clears prior results.
The result checker needs macOS Accessibility and permission for System Events.

`core/tests/test_grounding_probe.py` verifies the coordinate-hypothesis scorer.
`scripts/probe_grounding_contract.py` is an opt-in paid model diagnostic using
only generated calculator images; it never captures the desktop or executes
model actions. `--point-only` isolates tool schema from the original bbox schema.
Use fresh output directories; compare repeated images and positions rather than
inferring one global correction factor from a single response.

The same probe accepts `--model` (request-only model override on the configured
provider; does not edit production configuration), `--prompt-style agent|minimal|formula|bbox`,
`--thinking default|on|off`, `--high-resolution`, `--plain-json`, and
`--case-set all|hard|holdout`. `bbox` requests native `bbox_2d` JSON without
tools; it is a diagnostic, not a production coordinate protocol. The hard set
contains four existing images targeting 7; the holdout set uses new 1600×900
and 900×1600 images, two new placements, and AC/7. Responses are saved as raw
SSE and buffered before SDK parsing, so these runs are not latency benchmarks.
The HTTP hook verifies every transmitted PNG hash. Tests cover actual SDK
serialization of provider parameters and images, JSON/fenced JSON decoding,
and replay a captured malformed provider response through SDK, LLM and tool
rejection. Format decoding never repairs invalid JSON or executes model actions.

`scripts/probe_grounding_matrix.py` extends this with Qwen, DeepSeek and GPT via
OpenRouter, request-only provider selection, integer point/pixel/bbox protocols,
nullable-schema controls, strict flags, crop/resize/history/marker/shuffle and
agent/tool-context controls. It uses the actual OpenAI SDK without Tank's agent
loop; `full-tools` includes production desktop tool schemas but executes none.
Every SDK HTTP request is checked against the bound PNG hashes and their order.
Native DashScope replay has a separate, tested payload adapter. Its artifact
script checks payload image bytes before HTTP serialization, not via that SDK hook.

The matrix defaults to integer fields. `found=false` requires all zeros in this
explicit protocol; nullable controls require all nulls. No string coercion,
coordinate-unit guessing, duplicate JSON keys or inverted boxes are accepted.
Host code computes box centers and reverses crop/resize transforms; hit scores
use the rendered rounded-button mask separately from center distance. Unit tests
cover these contracts and real SDK serialization; paid calls remain opt-in.
`--max-tokens` sets the probe output budget (default 4000; reasoning may consume
this budget). `--thinking on|off` overrides the thinking setting for every variant;
without it, only the `no-thinking` variant disables thinking. These are diagnostic
request overrides, not production profile changes. DeepSeek sends the SDK
`extra_body={"thinking": {"type": "disabled"}}` for `--thinking off`.
CLI-to-HTTP tests verify independent budget/thinking controls, default behavior,
unchanged images and coordinate schemas, and retention of token-limit failures.
See the [protocol isolation results](../docs/research/macos-coordinate-chain.md#2026-09-19-跨提供方与严格协议隔离)
for model scores and the limits of synthetic, static-screen acceptance.


`core/tests/test_subagent.py` also sends the built-in desktop agent through the
real Runner → LLMAgent → OpenAI SDK with a fake HTTP transport. It checks the
final system prompt for self-delegation conflicts and checks clarification
instructions against the actual serialized tool schemas (missing, available,
allowlisted, excluded and named-toolset cases). `test_prompt_assembler.py`
retains main-agent delegation while shared security stays available to both.
These tests make no model requests or desktop actions and do not measure model
success rates.


M1 input/evidence regressions cover explicit macOS `type_text(mode="paste")`,
invalid-mode zero input, default IME compatibility and paste → Enter batch
semantics. Calculator tests run the actual shell validator through the trial
runner and preserve strict failures alongside separate business/mouse evidence.
They reject answer-only insertion, old-trial evidence and unfinished input.
Trace tests use the real SDK with fake HTTP to verify image hashes without
storing credentials or image bytes in request events. Additional regressions
cover ASCII text under a non-ASCII input source, native input-source reference
release and shifted physical keys (`shift+8`). The
[M1 acceptance report](benchmarks/computer_use/reports/20260920-m1-acceptance/README.md)
records real TextEdit/Calculator input, verified cleanup, local screenshot review
and synthetic prompt-only A/B. Generic pixel grading remains `unknown`: local
OCR misreads some isolated digits, and independent visual review is kept separate.
Unit tests and saved-image SDK replay do not establish real-model closed-loop
accuracy or live screenshot freshness.


M2 opt-in frame-coordinate tests extend `test_computer_use_common.py` and
`test_computer_use_macos.py`: immutable PNG identity, actual crop/window mapping,
strict image-point rejection, display/session/window freshness, batch frame
binding, and cancellation during validation. Real SDK HTTP tests compare the
transmitted PNG hash with the observation and exercise fragmented image-coordinate
responses through ToolManager to Quartz. Legacy interfaces remain covered.
`calibrate_macos_coordinates.py --coordinate-space image --window --output <new-dir>`
uses its own window and checks nine real click targets, release events and cursor
restoration. The [M2 report](benchmarks/computer_use/reports/20260920-m2-observation/README.md)
records 9/9 hits with zero per-axis error and the initial rejected full-screen
attempt. Scene checks are conservative and do not prove dynamic-UI reliability,
model accuracy, physical drag/scroll or the M6 stop/cleanup matrix.


M3 shared-adapter regressions extend `core/tests/test_grounding_probe.py` with
actual LLMProfile → LLM → SDK HTTP serialization for Qwen, DeepSeek and OpenRouter,
image/hash/size binding, image-to-M2 mapping, distinct explicit outcomes, invalid
configuration, and refusal/truncation rejection. Ten archived M3 responses replay
through the production adapter with request/image checks (only the documented
unique-match prompt delta is allowed); malformed
arrays remain failures and legal misses retain their scores. Floating distance
comparisons allow only arithmetic roundoff. Cancellation propagates and a 429
causes exactly one HTTP request (wrapper and SDK retries both disabled).

The matrix now rejects `finish_reason=length` even with syntactically complete
tool arguments, retaining raw arguments and usage. This is tested via real SDK
HTTP, not a mock completion. Existing LLM retry/profile/trace tests cover the
unchanged `complete()` text API. M4 planner dispatch and shared accounting are covered by the split-mode tests
below; physical cancellation remains M6 acceptance work. These tests use no paid
model calls or desktop actions.

`run_grounding_holdout.py` consumes a frozen request schedule with the production
adapter, verifies image/source/body hashes, preserves raw HTTP before parsing,
and never reads scoring truth. It defaults to a fake transport; `--live` requires
a reviewed price manifest. `test_grounding_probe.py` covers visible-mask rounding
and occlusion, invalid-response refusal scoring, request/token reservations,
429/no retry, timeout, cancellation, missing usage and retained truncations.
Unknown usage retains the full request reservation and stops the batch. Real
model quality is scored separately after execution, never inferred from mocks.


The legacy found prompt now requires exactly one unambiguous match; duplicates
must abstain. SDK tests cover the transmitted rule and point/pixel/bbox integer
and nullable sentinels. Historical manifests remain immutable: old-source
holdout freezes fail validation after the prompt change. HTTP failure tests use
temporary current-contract freezes rather than rewriting historical evidence.


M4 `core/tests/test_computer_locate.py` exercises actual Runner → LLMAgent →
ToolManager → GroundingAdapter → SDK, replacing only HTTP and macOS boundaries.
It verifies current-image bytes, absence of planner history in locator requests,
same-model and separate-profile selection, reference-only actions, single shared
accounting, refusal/invalid/truncated responses, unknown usage, display/frame/window
changes, retry/backend-switch limits, drag references and batch failure feedback.
Cancellation/deadline tests interrupt HTTP and stop input at frame validation.
The existing `chat.feature` runs selected dispatch/stop contracts through Cucumber;
these isolated scenarios reuse pytest and do not claim browser/WS dispatch coverage.
No paid model call or physical desktop event occurs in these tests.

On this host, full pytest needs the installed Opus library search path:
`uv run --no-sync env DYLD_LIBRARY_PATH=/opt/homebrew/Cellar/opus/1.6.1/lib pytest`.
This is an environment setting, not an audio-code workaround.


M5 benchmark split-mode regressions extend `test_computer_locate.py` through
`SubAgentDriver.create` → real Runner/SDK with fake HTTP/macOS. Same-model and
separate-profile cases check four token budgets, current image bytes, initial
and feedback screenshot archives, actual request count, GUI classification and
single accounting of planner plus locator usage. `test_bench_runner.py` also
checks missing/cancelled locator usage and excludes nested locator time from
planner intervals. These are measurement-contract tests, not paid A/B/C/D
results. Integrated B and batch accounting now have the additional coverage below.


M5 integrated cases in `test_computer_locate.py` exercise actual streamed SDK
requests through Runner and the benchmark driver: four protocols × host restoration
on/off × single/batch × complete/truncated/duplicate-key replies. Successful cases
use exactly one model and archive initial/feedback images; truncated/duplicate
arguments stop before input while retaining usage. Missing/ambiguous/invalid/stale
or changed-display batches stop before typing. Schema pairing verifies that host
restoration changes no tool schema, adapted locations share GroundingAdapter, and
batch schemas preserve the tool allowlist. Config tests preserve split defaults
and reject unsupported integrated locator/fallback/strict settings. These fake
HTTP/OS checks do not establish real model effectiveness or a frozen A/B/C/D run.

M5 raw-response tests in `test_bench_runner.py` run the real HTTPX/OpenAI SDK
boundaries against fake transports. They retain malformed JSON and 429/502 bodies
before SDK errors, verify incremental streaming without prefetch, preserve partial
read-error/cancelled/early-close bodies, label compressed versus already-decoded
bytes, and finalize missing/in-flight responses when a trace closes. Late bytes
and headers cannot alter a closed trace. `test_computer_locate.py` also verifies
request/response pairing through `SubAgentDriver.create` for shared and independent
locator profiles. These checks do not establish semantic failure attribution,
physical cleanup, live request budgets or model effectiveness.

Split-locator outcome tests add structured rejection coverage for refusals, wrong
tools, zero/multiple choices and duplicate JSON fields, plus SDK connection-failure
accounting and context reset. Existing tests now check stages for stale/changed
frames, invalid output, truncation, unknown usage, budget stops and cancellation.
The real benchmark create/Runner/SDK path joins outcome, usage and HTTP attempt IDs
for both shared and independent locator profiles, and leaves planner requests
unassociated. Reported model statuses and parsed coordinates remain unscored;
these offline tests do not prove target-selection or coordinate correctness.

M5 request admission tests add 13 real create/Runner/SDK cases with fake HTTP/OS
for legacy, integrated and independent-locator split modes. They cover planner,
locator and shared limits, zero allowance, 429/503 failures without retries, exact
admitted request/trace counts, fresh allowances on driver reuse and late requests
from closed trial contexts. Refused requests cannot supply new actions, and cleanup
remains unknown. Seven `test_request_budget.py` cases cover counter validation,
latched/closed budgets and rejection of uninstrumented extension transports.
`test_llm_retry.py` adds a real SDK 429 regression proving one HTTP attempt with
both retry layers disabled. These tests do not establish token/cost reservations,
batch-wide enforcement, real model effectiveness or physical desktop cleanup.

`core/tests/test_spend_ledger.py` includes 61 reservation/persistence cases without
model HTTP or desktop operations. They cover trial/batch token and cost limits, exact boundaries,
known-usage release, unknown/partial/invalid-usage retention, observed bound
violations, duplicate settlement/IDs, serial lifecycle, unfinished-request closure,
cross-trial spending, integer monetary arithmetic and detached JSON snapshots.
Persistence cases use real files and process exit, inject fsync failures, verify
pending reservations survive exit, and refuse reopening an existing journal.
These test the offline ledger API only; HTTP integration has the additional
coverage below. Actual provider bounds/prices and physical stopping remain unverified.

`test_spend_http.py` includes 58 cases through real LLM/SDK/HTTP hooks or request
contract validation. They check pre-transport reservation/refusal, fragmented SSE
without prefetch, settlement before tool execution, raw usage validation despite
SDK coercion, missing/inconsistent/over-bound usage, cancellation and read failures.
Contract tests reject mismatched parameters, malformed JSON and missing evidence.
The 13 create/Runner/SDK request-gate cases in `test_computer_locate.py` also run
with spend control enabled, covering legacy/integrated/split and independent
locator clients, 429/503 without retry, shared accounting and driver reuse.
Model HTTP and desktop boundaries are fake. Synthetic ceilings/prices exercise the gate;
they do not establish usable input bounds for the proposed live M5 batch.

The 22 serial-batch cases in `test_bench_runner.py` use the real suite orchestration
with fake drivers/shell/IME boundaries. They verify explicit order, one shared
durable ledger, no replay of an existing directory, cancellation accounting,
budget/unknown-usage/unconfirmed-cleanup stops and invalid schedule preflight.
The HTTP cases also cover durable reservation visibility at transport entry,
sync failure causing zero HTTP sends/tool actions, and driver context cleanup
when final journal sync fails. No test establishes automatic recovery, a global
desktop lock or machine power-loss durability.

Batch count cases verify persisted admission across trial boundaries, no refund
for zero-token settlement, invalid limits, zero HTTP sends at a zero ceiling,
and no next driver after exhaustion. Existing separate-locator cases also assert
shared batch counts for both SDK clients, including HTTP failures and driver reuse.
Eight `test_comparison_freeze.py` cases check file hashes, inventory changes,
required coverage and invalid pins. Batch regressions reject changed config,
suite/task, assets, `.env`, explicitly pinned agent files, added tasks, missing
config pins and mutations during driver construction or between trials.
The initial construction-drift red test omitted IME isolation and reached a host
API (connection errors); all IME/page-server/shell boundaries were then isolated
before the passing run. This is not physical cleanup or desktop-effect evidence.


### M5 resolved comparison configuration

`test_comparison_freeze.py` adds 31 cases: seven production-parser round trips,
16 resolved-drift/credential cases, refusal before client/tool construction, and
seven generated-config → real driver/Runner/SDK checks. SDK HTTP transport is
mocked; screenshot, click and Quartz boundaries explicitly reject host access.
The SDK checks compare model, tool schemas and generation settings with the
exported first request. Existing export tests additionally verify deterministic
runtime files and absence of credentials. These are offline contract tests, not
physical desktop cleanup or live model acceptance.


The offline batch proposal adds 11 cases in `test_comparison_freeze.py`: the
fixed 17-trial order and aggregate budgets, record-only budget selection, no driver construction, refusal to overwrite, and ten
mutation cases (order, cost/request limits, live flag, missing pin, config,
manifest, agent, adjacent credentials and extra agent). Production parsers and
frozen file checks run normally. No setup/validator, model or desktop is invoked;
this does not test pilot acceptance or a live phase-aware batch executor.


Record-only budget regressions add 11 cases: one ledger case admitting 408,000
actual tokens despite zero token/cost limits while preserving the HTTP ceiling;
seven generated-config/real Runner/SDK cases accepting 400,003 tokens and an
effective agent budget of zero; two actual SDK HTTP 402 cases preserving failures
without retry; and a serial batch with zero nominal spend limits recording all
three trials. Existing strict-mode tests still pass. All HTTP/OS boundaries are
fake, so these are enforcement/accounting tests, not observed model usage or
provider balance checks.


The [first real M5 A-control pilot](benchmarks/computer_use/reports/20260922-m5-a-control-pilot/README.md)
passed local nine-point and deterministic Calculator preparation but failed the
model task (final display zero, 15 steps, 16 requests, 295443 tokens). Post-run
Command key 55 required explicit operator release. This is failed live acceptance
evidence; it does not replace regression tests or establish automatic cleanup.

The [local paste recovery](benchmarks/computer_use/reports/20260922-m5-paste-recovery/README.md)
reproduces key 55 remaining down after a successful numeric paste and verifies
the corrected balanced Command/V sequence leaves no held keys. Three stateful
unit cases cover success and partial dispatch failures; two integrated protocol
cases replay the pilot's unsupported batch argument and string location, preserving
zero-click rejection with accurate errors. A local replay of the six text inputs
still ends at zero because Calculator ignores pasted operators/expressions.
No model requests were added. Scene-rejection attribution and general physical
cleanup remain unverified.


The [local scene-scope diagnosis](benchmarks/computer_use/reports/20260922-m5-scene-scope/README.md)
retains exact observation/validation images: five full-screen idle rejections
with only menu-bar changes, three accepted unchanged window crops, and one
rejected changed Calculator window. Four deterministic tests cover inside/outside
single-pixel changes under full/window scope and assert no clicks on rejection.
This characterizes existing exact-hash behavior; it does not change image scope,
prove the historical pilot rejection cause, or certify timeout/cancel cleanup.


Pixel equality is no longer an admission check (2026-09-22). The four pixel-change
cases now permit input for full/window observations with inside/outside changes
and assert validation takes no new screenshot. Integrated and split-locator cases
permit full image repaints, including during locator HTTP. Stale/session/window,
display changes, batch stopping and cancellation/deadline/revocation remain
covered; stop injection now occurs during geometry validation. Historical scene
reports above describe the prior implementation and are not current policy.


`test_desktop_cleanup.py` covers opt-in native input cleanup: physical-state
release/readback with fake Quartz, stuck input and pre-existing user input,
repeated cancellation joining, Runner lock ownership and driver cleanup results
for normal/error/timeout/cancel paths, failure quarantine, and exception handling.
`test_bench_runner.py` verifies batch option forwarding and retains stop-on-unknown
cleanup. The [native acceptance](benchmarks/computer_use/reports/20260924-m5-input-cleanup/README.md)
uses actual Command/left-button events in four deterministic exit cases without
an LLM. Input cleanup leaves application output for scoring and does not certify
clipboard/window restoration or all M6 cancellation scenarios.


The refreshed single-pilot entry has five cases in `test_comparison_freeze.py`:
missing consent makes no batch call; a checked call forwards exactly one A-control
entry, 16 requests, record-only accounting and input cleanup; modified cleanup,
runtime, order or proposal bytes during preflight stop before execution. HTTP and
desktop execution are replaced at the batch boundary. The
[local preview](benchmarks/computer_use/reports/20260924-m5-pilot-ready/README.md)
ran the default preview-only harness and verified restoration without credentials
or model requests. It does not establish task success or full-batch readiness.


The [Sept24 argument replay](benchmarks/computer_use/reports/20260924-m5-argument-replay/README.md)
adds six archived failure cases to `test_computer_locate.py`. The exact argument
strings and messages are trace-hash-bound; real ToolManager/IntegratedSession/
FrameTool execution with fake native boundaries verifies rejection without input
and recovery using a newly observed frame. The 48 existing integrated SDK cases
check the corrected batch description and explicit prompt rules across protocols
and restoration factors. This does not replay historical desktop state or prove
that the model follows the revised instructions; old source freezes remain stale.


The fixed B-protocol-only entry reuses the A-control execution checks. Five
additional parameterized cases in `test_comparison_freeze.py` cover missing
consent, exact one-row scope and parsed model/grounding factors, runtime/order/
cleanup drift, and proposal mutation during preflight. Both entries preserve
record-only accounting, input cleanup and 16 planner/zero locator requests.
Only the batch boundary is replaced, so these are offline entry-contract tests.
The [B-protocol preparation](benchmarks/computer_use/reports/20260924-m5-b-protocol-ready/README.md)
reuses the exact previous runtime and updates only the proposal's script pin.


M5 IME regression tests in `test_bench_runner.py` use real helper subprocesses
with fake native behavior to cover worker callers, original-source IDs, hard exit,
timeout, malformed responses and retryable restoration. `test_desktop_cleanup.py`
checks the outer recovery supervisor with real files/processes and fake desktop
boundaries: durable baseline/PID before execution, restrictive permissions, child
exit/timeout/reaping, fsync refusal, failed recovery, accessory foreground apps and
loginwindow preflight refusal. The [local acceptance record](benchmarks/computer_use/reports/20260924-m5-ime-recovery/README.md)
confirms native IME calls and application-switch repinning without model requests;
the initial desktop recovery remained unconfirmed. The subsequent
[readback correction](benchmarks/computer_use/reports/20260924-m5-recovery-readback/README.md)
adds five cases for run-loop refresh, delayed/failed visibility restoration,
missing Finder launchDate and changed process identity. Real normal, hard-exit
and timeout recovery now pass; historical loginwindow readings do not prove
lock state. This does not complete the M6 physical stop matrix.


### M6–M8 coverage and closeout

M6 agent-budget enforcement tests in `test_bench_runner.py` keep the ledger
record-only while forcing the agent `token_budget` through the runner check
(A arm) or the shared SubAgentContext ledger including locate calls (B/C/D).
`SubAgentStopped` surfaces as a controlled TOKEN stop with `stop_reason`
metadata instead of a generic agent error. The physical stop/cleanup matrix
(planner/locate in-flight cancel, key-hold join, batch and drag mid-action
cancel) is accepted locally against a loopback mock with a strict ten-second
zero-event window; it does not model provider latency.

M7 adds `test_computer_ax.py`: candidate enumeration (orientation
self-calibration, role filter, same-name retention, depth/element caps),
strict index selection (out-of-range, wrong status, sentinel, non-integer),
quartz dispatch through the M2 frame checks, AXPress action boundaries,
stale/window-move/ambiguous/missing zero-input rejections, and real
Runner→SDK flows for both dispatch modes. The NSArray iteration-protocol fix
and the AXPress PerformAction return-code regression are included. M7 live
fixes — omitted-`window_id` frame binding, host-injected AX window id, and
recoverable invalid tool-call JSON with zero dispatch — have first-red tests
in `test_computer_locate.py`.

M8 changes no production behavior: the closeout is documentation plus report
aggregation. The full suite (5116 passed / 1 skipped on 2026-09-25, including
legacy N2 and SDK regressions) is the deterministic transform/protocol/
cancel/budget/cleanup evidence cited by the
[closeout report](benchmarks/computer_use/reports/20260925-m8-closeout/README.md).


## S0 shared task governance acceptance

`core/tests/test_subagent.py::test_retained_callers_share_governance` runs the
same assertions through real Runner paths for a non-GUI SubAgent, Computer Use
with an injected Advisor, and LLMAgent. Only HTTP/native OS
boundaries are replaced. It verifies one context/call identity per task, usage counted
once, revoked response handling and optional-observer failure isolation. Sequential
tasks have independent runtimes, ledgers and call IDs; task closure leaves the host
LLM pool open. Native execution audit is checked separately before dispatch in
`test_task_runtime.py`; SDK model calls use call-level accounting and telemetry,
not the native execution-audit path.

Run from backend: `uv run pytest core/tests/test_subagent.py -k retained_callers -q`.
Domain loop fixtures remain in `plugins/agent-computer-use/tests`; task/model
regressions cover cancellation, closed-task refusal and request admission.
The G3 common entry is:
`uv run --no-sync pytest core/tests/test_subagent.py core/tests/test_task_model.py core/tests/test_task_runtime.py core/tests/test_plugin_manifest.py core/tests/test_model_calls.py -q`.
It also covers wrong-task/closed/revoked model-view binding, closing one task while
another model call remains in flight, cleanup failure/quarantine, borrowed leases
and cancellation. The existing chat.feature lifecycle case runs this entry. Real
isolated Chromium tests additionally exercise two tasks on one Runner with disjoint
document references and independent server readback. Current native fake-GUI and
synthetic Vision evidence and the explicit unsupported capabilities are listed in
the [G3 resource inventory](../docs/design/computer-use.md#g3-能力与资源接线清单2026-10-17).
These are host/lifecycle contracts and fake-model wiring evidence, not model quality
or OS-sandbox claims; persistent cross-process resume remains unsupported.


## S1 observation adapters

`test_vision.py` additionally exercises the explicit Jev image factory/controller
path through the actual SDK multipart boundary with fake native OS/HTTP: admitted
candidate execution, same-image bounded review, scale/padding geometry, receiver and
task scope refusal, changed/unstable frames, revocation, unknown usage, malformed
choices and unknown effects. The real Calculator recipe's preparation refuses
client/app allocation and detects frozen-input drift; setup/cleanup failures retain
both planned rows and zero-send evidence. Actual Calculator runs are separate
explicit artifacts, never part of ordinary pytest or model-quality claims from mocks.
The TextEdit ablation additionally checks paired real-SDK JSON/multipart behavior,
private completion non-disclosure, both replacement alternatives, one-fill limits
for wrong answers, abstentions/stale/authority/usage refusals, all task/Box denominators,
shared known/unknown reservations, header-only selection setup and independent cleanup.
`test_native.py` checks seeded RTF versus default empty-text fixture allocation and
cleanup after failed launch. Ordinary tests still replace OS/HTTP boundaries.
The post-crop extension covers record-only uncapped batch accounting (with unknown
usage still stopping), explicit named-line text controls, private completion
invariance and persistence of every capture, including Box response checks.
Native stage-event tests retain zero input on all refusals even when observers fail.
The existing vision tests also exercise `jev_box_crop` preparation and the real Jev/
OpenAI SDKs with fake external HTTP: paired crop/padding inverse mapping and strict
0–1000 conversion, frozen input tampering, no-client preparation, control-gate refusal,
known invalid replies, unknown usage, all 70 planned rows and client cleanup. This
uses saved pictures only; no desktop authority or coordinate executor is configured.

The image development recipe's separate `jev_image_eval` executor is covered in
the existing `test_vision.py` and chat.feature visual contract. Tests exercise the
real Jev/OpenAI SDKs with external HTTP replaced: all five arms and 260 requests,
40 excluded rows, independent candidate/cardinality/interior-point scoring,
frozen-preview equality, file tampering, known malformed answers, unknown usage,
no retries on HTTP failure, budget/audit refusal, cancellation and cleanup failure.
Every stopped batch retains all 300 planned records. No paid API or GUI dispatch
is performed; the results prove executor behavior, not real model accuracy.
Revision-2 regressions assert Qwen JSON-mode preview/SDK equality, fixed 0–1000
conversion and rejection of aliases, markdown, invalid geometry and non-unique
boxes. `core/tests/test_task_model.py` exercises explicit visual JSON output over
the real SDK, unchanged plain completion and shared usage, plus denied image scope,
closed-task and capture failure with zero outbound requests or unknown usage.

Jev offline image capability tests extend the existing decision/model-data/vision
tests. Real SDK 0.7.5 fake HTTP checks default-compression multipart, actual PNG
parts/references/header, same-call cardinality+Box, immutable capture snapshots,
shared usage and rejection before SDK allocation. Runner config tests cover the
explicit recipient image allowance. Invalid Choice questions stop before capture
or usage recording; successful text/image/Box traces retain decision evidence.
Parameter-byte boundaries include raw file
parts separately from compact JSON. Vision tests cover all eight inverse EXIF
orientations, crop/resize/padding, read-only Box probes with absent/multiple
targets, missing scope/recipient, revocation, stale readback and unknown usage.
The existing chat.feature lifecycle entry also runs decision-model tests; its
visual entry covers the new probe and development preparation. The new recipe
test forbids SDK client creation, poisons labels without changing requests and
rejects file/source freeze drift. No tests imply live model or GUI effectiveness.

The opt-in hybrid path in `test_vision.py` exercises real Controller, TaskRuntime,
Jev SDK and visual SDK with fake OS/HTTP: Jev → image → Jev, semantic bypass,
bounded repeated-state recovery (including with an Advisor), crop/bounds admission,
missing/denied images, stale pixels/window, invalid replies, revoked authority,
unknown image usage and readback-only unknown effects. `test_task_model.py` checks
separate text/image services, shared ledger/cleanup, explicit profile parsing and
purpose/capture/call-ID correlation. The Runner candidate-strategy test in
`test_dom.py` also runs `jev-vision` through real Chromium and independent page
readback. The existing chat.feature covers visual host and managed-browser paths.
No paid calls, model accuracy measurements or Box capability are involved.
`test_s5_paired.py` checks failed intake attempts, SDK invocation identity,
not-started policy/capture/data refusals, incomplete-trace missingness and both
summary harnesses' frozen metric-source tamper detection.

`plugins/agent-computer-use/tests/test_observation.py` covers native identity,
whole-scope candidate admission, frozen AX fixtures, controller/runtime read gates,
and text-only current-snapshot HTTP through the real SDK. `test_vision.py` replaces
only the native Vision boundary to check bound PNGs, crop/negative-display mapping,
output limits, dependency absence and stop checks after capture. Core AX tests also
cover subtree/text truncation, native action names and ambiguous window geometry.
The [S1 acceptance](benchmarks/computer_use/reports/20260930-s1-observation/README.md)
archives a local Vision run against frozen synthetic PNGs, without desktop input or
model network requests. Run `uv run --no-sync python -m benchmarks.computer_use.s1_acceptance`
from backend after installing the optional plugin `vision` extra on macOS.

## S2 managed Chromium acceptance

`plugins/agent-computer-use/tests/test_dom.py` runs real ephemeral Chromium against
controlled loopback pages through the existing Controller/TaskRuntime and Runner.
It covers Chinese fill/click/readback, stale/replaced/navigation references,
duplicates, disabled/covered controls, bounded observations, explicit iframe scope,
task stops/quotas, lost replies and cleanup during pending input/driver creation.
`test_plugin.py` also rejects missing optional dependencies without launching a browser.

Install the plugin `browser` extra and Chromium, then require the acceptance:
`TANK_REQUIRE_CHROMIUM=1 uv run --no-sync pytest plugins/agent-computer-use/tests/test_dom.py -q`.
The manual Backend CI workflow has a dedicated job that installs both and forbids
skips. Ordinary pytest may skip if they are missing; that is not S2 acceptance.
The managed-Chromium scenario in the existing chat.feature requires the same setup.
See the [plugin instructions](plugins/agent-computer-use/README.md#s2-managed-chromium)
for configuration, supported DOM semantics and the limits of page-fact verification.


## S3 configured Jev integration

`core/tests/test_subagent.py` covers core decision profiles, extension-only agent
references, network approval and refusal before the SubAgent factory. The plugin's
`test_dom.py` exercises YAML → Runner → real managed Chromium with fake HTTP,
including nested observation facts, structured completion and resource cleanup.
It also verifies the three-case smoke harness using fake HTTP (including malformed
no-target replies and the per-case one-request limit). No paid API calls run in pytest.
Use `TANK_REQUIRE_CHROMIUM=1` to require the optional browser extra and executable.

The explicitly paid harness and frozen evidence are documented in
[the S3 smoke record](benchmarks/computer_use/reports/20261003-s3-jev-smoke/README.md).


## S3 frozen selector replay

`plugins/agent-computer-use/tests/test_jev.py` additionally tests the benchmark
[replay harness](benchmarks/computer_use/s3_replay.py): deterministic frozen inputs,
no label leakage, paired public requests, malformed reply denominators, shared
usage/unknown-stop behavior, audit journals, freeze tamper rejection and held-out
threshold application. The full test suite uses fake HTTP; no paid calls run.
[The prepared protocol](benchmarks/computer_use/fixtures/s3/README.md) describes the
synthetic-data limits. Live execution requires a separately approved freeze digest.


## S3 v2 diagnostics

The existing `plugins/agent-computer-use/tests/test_jev.py` now also covers
[s3_replay_v2](benchmarks/computer_use/s3_replay_v2.py): binary abstention scoring,
compact inputs, counterbalanced target positions, cold/pool ownership, missing trace
values, real localhost HTTP keep-alive reuse, frozen HTTP versions, audit/usage stop,
cleanup-failure evidence and cancellation. Model endpoints are fake in these tests;
only the keep-alive test opens a loopback socket. No paid API or desktop action runs.
[V2 protocol](benchmarks/computer_use/fixtures/s3-v2/README.md) states timing limits.


## S3 v3 refusal factors

The existing `plugins/agent-computer-use/tests/test_jev.py` additionally tests
[s3_replay_v3](benchmarks/computer_use/s3_replay_v3.py): legacy/2x2 input isolation,
constant candidates/host contract, rejection of structured oracle markers, evidence-
aware scoring, counterbalanced order, tamper refusal, complete-grid contrasts and
fake HTTP through the reused guarded call. Unknown usage, mandatory audit failure,
cancellation and journal reuse are covered without paid calls. See
[the v3 protocol](benchmarks/computer_use/fixtures/s3-v3/README.md) for scoring limits.

## Selector evidence contract

`test_jev.py` checks the actual governed HTTP payload keeps task/Advisor declarations
and desired outcomes separate from conflicting current observation reports, sends
only the new snapshot on the next request, and preserves `need_more_context` output.
Existing Controller tests verify all four refusal controls prevent dispatch and
successful proposals require effect verification. These fake-HTTP checks establish
serialization and control handling, not model obedience or business authenticity.
The held-out protocol is in the plugin README; no paid calls run during tests.

## S3 new synthetic holdout preparation

`test_jev.py` adds seven offline holdout checks: actual selector HTTP payload equality,
label-independent request construction, paired state/action equality, balanced target
positions and within-condition order, coverage/scoring denominators, source/label
mutation refusal, exclusive output creation and preparation without HTTP clients or
credentials. `choice_payload` is shared with the admitted production selector; host
admission and four control outcomes remain covered by existing integration tests.
See [the holdout protocol](benchmarks/computer_use/fixtures/s3-holdout/README.md).
These tests establish preparation contracts, not model effectiveness; no live executor
or business-evidence provider is added.

## S3 holdout governed execution

`test_jev.py` adds 11 fake-HTTP execution checks for `s3_holdout_live.py`: exact frozen
payloads, production four-control parsing, shared ledger/audit conservation, known-
usage invalid replies, unknown usage/HTTP failure/cancellation stops, zero-send audit
and budget rejection, cleanup failures, existing-artifact refusal, tampered recipe
rejection and scoring from frozen labels despite changed later source reads. All 48
planned rows survive controlled stop paths. No real model requests run in pytest.

## S3 real DOM multilayout control-loop acceptance

The existing `test_dom.py` adds 15 real-Chromium cases: toolbar, table and open HTML
dialog layouts, each with sufficient identity, missing identity, conflicting reports,
replacement after selection and click-without-observable-effect scenarios. Only model
HTTP is replaced. Actual snapshots enter JevSelector/TaskModelTransport; real click
handlers and page-event logs independently check dispatch and fresh effect readback.
Scripted refusal controls cause zero dispatch; this does not test actual model refusal
or independent host verification of missing/conflicting business facts.

Run with `TANK_REQUIRE_CHROMIUM=1 uv run --no-sync pytest plugins/agent-computer-use/tests/test_dom.py -k real_dom_multilayout -q`.
Set `TANK_DOM_EVIDENCE_DIR` to a new output directory to retain 15 JSON records (source
HTML, actual requests/responses, audit, results and final snapshots) and three positive
screenshots. Existing filenames are refused. Without that variable artifacts use each
test's temporary directory. Actual browser connection closure is checked; retained
Python Browser objects are not mistaken for still-connected browser processes.

## S3 real-model DOM execution preparation

`test_dom.py` adds ten checks for `benchmarks/computer_use/s3_dom_live.py`, with real
isolated Chromium and fake model HTTP. They cover the full 15-case workflow, wrong
selection, invalid response, HTTP failure without retry, unknown usage, cancellation,
audit/budget rejection, reported cleanup failure and offline/tampered-freeze rejection.
Every stopped batch retains all 15 planned rows. HTML and goals are reused from the
archived fixed-model acceptance; the live request is built from newly observed DOM.
The live CLI requires an approved executable digest before loading the credential.
No paid model requests run during these tests.

## Prospective DOM refusal follow-up

`test_dom.py` adds eight checks for `s3_dom_followup.py`: all four valid control
outputs versus strict refusal classification, actual zero-click verification, rejection
of invalid replies and unsafe guesses (even when a guess happens to complete the page),
11 real-Chromium/fake-HTTP cases, full planned-row retention, immutable prior failure
and tampered-protocol rejection. The shared executor's original entry still defaults
to its original strict evaluator; the previous operational failure tests remain active.
No paid requests run during tests. The new protocol preserves category misses in
separate fields instead of silently relabeling them as correct classifications.

## S3 bounded F fallback and paired strategy pilot

`test_jev.py` verifies identical semantic inputs through real host Jev/text transports,
Jev-direct and F fallback, strict single-choice parsing, shared usage and hard-stop
propagation. `test_task_model.py` covers the sole allowed non-thinking flag, immutable
assembly and rejected parameter overrides. `test_dom.py` runs YAML/Runner → both host
models → real Chromium, including F completion followed by a rule step; the existing
managed Chromium cucumber scenario now exercises these two cases as well.

The same domain tests exercise the 48-trial H3/J3 pilot with fake HTTP, direct success
and forced fallback (42/54 captured requests), zero model calls on rules, cost and full
planned denominators, paired rows, cancellation/unknown/audit/cleanup stops and recipe
tampering. The decision-rule tests reject apparent savings from failure, a slower
cost-only tradeoff, or no displacement of F. No pytest model calls are paid.


## S3-M core Jev SDK migration

`test_task_model.py` verifies the real official TypeSafe SDK through task-call
wrappers, task-owned cleanup, token accounting, no retry on 429/503, no redirect,
and explicit configuration overriding SDK environment defaults. Old JSON config
and agent references fail with migration guidance. `test_subagent.py` exercises a
non-GUI decision caller without a provider plugin and checks credential isolation
and failures before the SubAgent factory.

Existing `test_jev.py` hard-stop/invalid-reply/shared-ledger cases now use the real
SDK; `test_dom.py` covers Runner/YAML/Chromium and both direct/fallback strategies.
Only the network boundary is fake. Historical protocol diagnostic replays retain a
benchmark-only raw client; current smoke/DOM/strategy execution uses the SDK.
Frozen recipes detect code changes; do not edit source while a frozen-recipe test
is running. No S4 behavior or paid requests are part of this regression.


## SDK model-call simplification (2026-10-05)

Task data admission (`ModelDataScope`, 2026-10-17) is checked before experimental
reservation/capture and SDK entry. `test_model_calls.py` covers exact UTF-8 JSON
parameter byte limits, streaming, unsupported/mixed content, and capture mutation
or revocation. `test_task_model.py` exercises real AsyncOpenAI with fake HTTP:
text-only services reject image blocks even in image-enabled tasks; bound LLMs
respect the host allowance. `test_decision_model.py` checks the same scope before
the lazy official Jev SDK client is created. The shared three-caller conformance
test includes denied data/zero byte allowance with zero requests and usage.

Extension contexts default to text/4 MiB; Runner explicitly preserves text/image
for built-in multimodal tasks with a 32 MiB ceiling. These are compact UTF-8 JSON
parameter limits, separate from output bytes and tokens; SDK serialization and
HTTP overhead are not claimed to be measured here. Static image diagnostics
declare image scope explicitly. All new tests replace external network boundaries;
this does not validate real model quality or enable Jev image/Box support.

`test_model_transport.py` is retired with the removed HTTP-level contract; it is
replaced by `test_model_calls.py` for invocation identity, known/unknown/error usage,
parallel calls, cancellation/deadline, late results, paused/closed streams, SDK
buffered chunks, borrowed-client ownership and repeated-cancellation cleanup.
`test_decision_model.py` covers standalone official SDK use with no task context and
Langfuse disabled/failing at enter/update/exit. Existing task/Runner/Chromium tests
continue to exercise real SDKs with fake external HTTP.

Old raw-protocol/size/redirect-interception and model execution-audit assertions
were removed because those guarantees are no longer part of production model calls.
SDK retries/configuration and UI/tool execution audit retain separate coverage.
Experiment policies observe normalized SDK-call records; raw replay has one explicit
admission record per trial rather than the retired three transport audit phases.
Do not compare the new suite count directly with older transport-test counts as an
implementation-coverage metric. No paid model calls or S4 behavior are involved.


## Model-call naming and SDK-owned HTTP defaults

`test_decision_model.py` verifies that the official SDK receives no http_client or
transport injection, owns lazy creation/close, and keeps the configured timeout and
zero retries. Invalid credentials now allocate no HTTP client. The test-only network
fixture preserves real SDK creation and substitutes only its external transport;
production follows the SDK's default environment proxy/certificate behavior.
Existing stream, request-budget, desktop and strategy tests use ModelResponseStream,
TaskModelCallRunner and model_request/model_response names. Old report artifacts are
unchanged. No paid model calls or S4 changes are part of this refactor.

The existing `test_dom.py` route-pilot tests run real Chromium and the real SDKs,
replacing only external HTTP. They cover V/JT multi-step return, a shared rule,
actual PNG color-based mock decisions, private-oracle isolation, all 24 rows,
absent targets, replaced controls, no-effect refusal without replay, known invalid
choices, unknown usage, cancellation and cleanup failure. The existing managed
Chromium cucumber entry includes both V/JT return tests. This is functional
wiring evidence on synthetic HTML, not model quality or real-product acceptance.

DOM freshness regressions in `test_dom.py` use real native caret blinking and
actual canvas/value/node/navigation changes. They preserve exact-hash refusal,
zero dispatch after stale/revoked references, capture-race stages and refusal even
when observers raise. The no-model diagnostic tests forbid HTTP model clients and
check all 48 scheduled checks, 54 immediate PNGs, stable DOM and six cleanups.
The managed Chromium cucumber entry includes the native-caret regression.

The same entry's `observe_navigation` filter includes a controlled streamed HTTP
response: observation waits for DOMContentLoaded after both a changed URL and a
same-URL reload. A withheld body verifies timeout refusal and invalidation of old
capture/dispatch references; cancellation, revocation and the original deadline
interrupt the wait. These tests use real Chromium and no model clients.
Real-product projection regressions additionally mutate DOM revision without
navigation during business readback, covering both products and the legacy SQLite
workflow. A changed view is discarded before selection, then safely observed again.

The route follow-up tests in `test_dom.py` cover optional 36-task preparation while
preserving the default 24-task recipe, real-SDK text abstention then same-binding
visual fallback/return, reply-before-fallback evidence, unknown usage with no
picture capture, and preserving a lucky unsupported guess instead of rewriting it.
A complete real-Chromium/fake-HTTP matrix retains all 36 tasks and 66 SDK calls.
The existing managed Chromium cucumber contract includes both abstention cases.
These tests establish wiring and scoring, not actual model abstention quality.

Real-product route qualification uses the unmodified sqlite-web 0.8.1 installation
in an isolated external environment; it is not a default application dependency.
Set `TANK_REAL_PRODUCT_PYTHON=/absolute/venv/bin/python` when running the existing
`test_dom.py -k real_product` cases to require it. Preparation forbids SDK/server
allocation; the real product/server/Chromium and real SDKs run with only external
model HTTP replaced. Tests cover all 12 tasks, one injected GET refusal/recovery,
read-only database receipts, exactly one write, wrong-record non-completion,
private-oracle isolation, unknown usage, cancellation and cleanup-stop denominators.
They also verify per-family order balance on ordinary tasks and that another
cancellation during cleanup still closes the app/browser and records a cancelled,
unsuccessful task even when the database write already completed.
Without that explicit environment the product qualification tests skip; production
DOM regressions and managed-Chromium E2E do not require sqlite-web. They cover
same-origin navigation, checked-state readback, URL spoof/malformed links, loading
documents, finite transitions and refusing continuing motion. No paid calls run.

Same-label checkbox regressions in the existing `test_dom.py` cover node-bound
readback, semantic ambiguity despite different opaque effect keys, distinct authored
form names, annotation collisions, page-role forgery, prevented defaults and replaced
nodes. The managed Chromium E2E entry includes these generic contracts. The optional
real-product fixture also exercises no-model checkbox diagnostics: 4 manual paths,
4 Controller/scripted-proposal paths, SQL column receipts, one write/POST, model-client
construction refusal, repeated cancellation and frozen-recipe tampering. Set the same
TANK_REAL_PRODUCT_PYTHON variable to require the app cases. None calls a paid model.

Native table-row context tests in the same file cover visible row text, exclusion
of hidden text, preserving ambiguity for repeated/empty row context, oversize
observation refusal and rejecting an action after its row text changes. The
existing managed Chromium E2E entry includes these generic contracts.

Hidden-pseudo animation regressions in the same file use real Chromium CSS effects,
imports/adopted sheets and public capture/is_current interfaces. Empty hidden
before/after transform/opacity animations keep running while capture succeeds;
visible/visibility-changing, text/marker, layout/custom-property, ordinary-element
and programmatic animations remain refused. Actual CSS definitions guard against
Chromium omitting custom properties from getKeyframes. Failed imports and the
4096-rule cap fail closed; CSSOM-only reveals/pixel changes and node replacement
invalidate a captured frame. The managed Chromium E2E entry includes these contracts.

The same `test_dom.py` real-product fixture covers `--workflow` preparation and
all eight list/edit/return cases with real SDKs and fake model HTTP. It checks
record-row context, actual editor-seen history and returned DOM cells/path, one
correct UPDATE/POST, the first-edit GET503 recovery, private-oracle isolation,
wrong-record writes, missing/wrong/wrong-page list returns, and eight-row stop
denominators for unknown usage, cancellation and cleanup failure. The default
twelve-case schedule and its original guards remain covered. These are functional
tests, not real model quality measurements.

The same domain file adds 20 linkding cases, enabled by
`TANK_LINKDING_ROOT=/absolute/qualified/linkding-1.47.0`. Full qualification also sets
`TANK_REQUIRE_CHROMIUM=1`; no product dependency is added to the backend environment.
They exercise qualified-provenance/source/dependency preparation without clients,
both arms/positions through actual product/Controller/SDKs with fake external model
HTTP, physical before/after SQLite receipts, SDK facts versus actual per-observation
records/editor history, and final DOM/schema/whole-bookmark-table verification.
Wrong records, poisoned private oracles and actual missing/wrong/wrong-page final
DOM cannot become strict success. Unknown usage, cancellation, failed audit/cleanup
and fixture IO retain all four scheduled rows; known invalid choices never dispatch.
Application tampering is rejected before clients, and repeated cancellation drains
an in-flight source copy. These are wiring/governance tests, not real model scores.

## Jev offline benchmark scoring

`benchmarks/computer_use/jev_scoring.py` reads frozen V/JT schedules and receipts;
it does not import model clients, change execution policy, or run tasks. Run from
`backend/` with the existing dev dependencies:

```bash
uv run --no-sync python benchmarks/computer_use/jev_scoring.py \
  --freeze /absolute/freeze.json --result /absolute/result.json \
  --audit /absolute/audit.json --output /absolute/new-score-directory
```

It accepts inline frozen cases or a sibling `cases.json` whose byte digest is in
`freeze.files`. The output directory must be new. `score.json` contains input byte
hashes, estimates, all twelve fixed gates, evidence issues and separate negative
exits; `score.md` is a short companion. Missing/duplicate/misbound rows remain in
the frozen denominator as failures. Failed/unrun positive tasks cost 120 seconds.
Cold/prewarmed conditions are averaged within each paired seed; ten balanced
product/family strata retain equal weight. The fixed method is bounded-seed
Chernoff-KL and stratified paired BCa with 20,000 resamples, seed 20261021. Undefined
intervals cannot pass a gate. Speed is the sole primary endpoint; the alternative
1.05 time noninferiority branch is not used. The methods assume independent,
representative seeds and do not certify generalization beyond the frozen domain.

The optional audit is an independently prepared JSON object, not model self-report:
`schema_version: 1` (integer), `freeze_sha256`, `result_sha256`, `evidence_kind`
(`fake`, `calibration`, or `confirmation`), `regressions_passed` (boolean), and
`trials` keyed by **every** frozen trial id. Each trial has exact booleans
`strict_verified`, `negative_verified`, `recovery_verified`, `unexpected_action`,
plus nonnegative integer `critical_events`. These labels must come from the full
goal/constraint/path/cleanup and governance audit. Merely copying runner flags
does not establish independent verification. The audit result hash uses canonical
JSON (`ensure_ascii=False`, sorted keys, separators `(',', ':')`, no NaN), exposed
by `digest()`; it is distinct from a file byte hash. Success requires both runner
and independent verification; discrepancies block acceptance. Missing/invalid
audit makes safety, extra actions and regressions unknown, never measured zero.

Known request usage is reconciled against trial and batch totals. Unknown or
estimated usage, unreleased reservations, early stop and evidence gaps prevent
`all_gates_passed`. Unpriced cost remains unpriced. Negative exit errors use a
separate seed denominator and one-sided 95% bound, without inventing a new cutoff.
Numerical gate passage alone never authorizes execution/adoption: the output
always retains `model_execution_eligible: false`; fake/calibration is not formal
confirmation.

`core/tests/test_jev_scoring.py` covers pairing, denominators, boundary equality,
degeneracy, independent SciPy BCa, identity/audit/usage corruption and read-only
CLI output. Its CLI subprocess denies socket connections and model imports. The
existing `chat.feature` `scoring` example runs that subprocess contract through
Cucumber. Existing calibration and fake receipts are only replayed offline;
these checks do not add live model-performance evidence.
