"""Review-only integrity, replay and independent KL checks; no model or socket I/O."""
import hashlib
import json
import math
import runpy
import subprocess
import tarfile
from pathlib import Path

import numpy as np
from scipy.optimize import brentq
from scipy.special import rel_entr

ROOT = Path('/Users/zbcjackson/src/tank')
OUT = Path(__file__).parent
BASE = 'a006e5a1'
REVIEW = '0c7e2a15'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(revision, path):
    return subprocess.check_output(['git', 'show', f'{revision}:{path}'], cwd=ROOT)

manifest_path = ROOT / 'docs/research/artifacts/jev-benchmark-scoring-20261022-manifest.json'
manifest = json.loads(manifest_path.read_bytes())
archive = manifest_path.with_name(manifest['archive'])
assert sha(archive.read_bytes()) == manifest['sha256']
assert archive.stat().st_size == manifest['bytes']
with tarfile.open(archive) as tf:
    members = {m.name: m for m in tf.getmembers() if m.isfile()}
    assert set(members) == {m['path'] for m in manifest['members']}
    archived = {}
    for entry in manifest['members']:
        data = tf.extractfile(members[entry['path']]).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
        archived[entry['path']] = data
for name, data in archived.items():
    if name.startswith('scoring-source/'):
        assert data == blob(REVIEW, name.removeprefix('scoring-source/'))
    if name.startswith('full-suite-calibration/source/'):
        path = 'backend/' + name.removeprefix('full-suite-calibration/source/')
        assert data == blob(REVIEW, path)
assert json.loads(archived['e2e/offline-e2e-egress.json'])['external_python_socket_attempts'] == []
assert b'6572 passed, 1 skipped' in archived['backend-pytest.log']
assert b'22 scenarios (22 passed)' in archived['e2e/cucumber.log']
assert b'87 steps (87 passed)' in archived['e2e/cucumber.log']

paths = subprocess.check_output(
    ['git', 'ls-tree', '-r', '--name-only', BASE, 'docs/research/artifacts'], cwd=ROOT
).decode().splitlines()
old = paths
for path in old:
    assert (ROOT / path).read_bytes() == blob(BASE, path)

module = runpy.run_path(str(ROOT / 'backend/benchmarks/computer_use/jev_scoring.py'))
replays = {}
input_hashes = {}
for kind, base, result_name, cases_name in (
    ('calibration', Path('/private/tmp/tank-calibration-live-20261021-r1'), 'result.json', None),
    ('fake', Path('/private/tmp/tank-navigation-observation-20261022/run-v2'), 'fake/result.json', 'cases.json'),
):
    def read(name):
        path = base / name
        data = path.read_bytes()
        input_hashes[str(path)] = sha(data)
        return data
    frozen = json.loads(read('freeze.json'))
    result = json.loads(read(result_name))
    cases = read(cases_name) if cases_name else None
    score = module['score'](frozen, result, cases_json=cases)
    old_score = json.loads(archived[f'{kind}-no-audit/score.json'])
    assert json.loads(json.dumps(score)) == {k:v for k,v in old_score.items() if k != 'inputs'}
    expected_counts = 96 if kind == 'calibration' else 192
    assert score['counts']['planned_trials'] == expected_counts
    assert score['all_gates_passed'] is False
    assert score['model_execution_eligible'] is False
    assert score['evidence']['issues'] == ['independent audit not supplied']
    assert all(score['gates'][key]['passed'] is None for key in ('safety_events', 'regressions', 'unexpected_difference_upper'))
    replays[kind] = {'counts': score['counts'], 'speed': score['metrics']['time_ratio'], 'usage': score['usage']}
for path, expected in input_hashes.items():
    assert sha(Path(path).read_bytes()) == expected

checks = []
for count in (20, 40, 640):
    for mean in (0, 0.01, 0.2, 0.5, 0.99, 1):
        for tail in (0.025, 0.05):
            actual = module['kl_upper'](mean, count, tail)
            if mean == 0:
                reference = 1 - tail ** (1/count)
            elif mean == 1:
                reference = 1.0
            else:
                reference = brentq(lambda p: count * float(rel_entr(mean,p) + rel_entr(1-mean,1-p)) + math.log(tail), mean, 1, xtol=1e-14)
            assert math.isclose(actual, reference, rel_tol=0, abs_tol=1e-12)
            checks.append({'n':count,'mean':mean,'tail':tail,'difference':actual-reference})

record = {
    'baseline': BASE, 'reviewed_head': REVIEW,
    'archive_sha256': manifest['sha256'], 'archive_members_verified': len(archived),
    'old_artifacts_byte_identical': len(old),
    'source_snapshots_match_reviewed_head': True,
    'prior_full_suite_and_offline_e2e_evidence_verified': True,
    'replays': replays, 'input_byte_hashes': input_hashes,
    'independent_scipy_brent_KL_cases': len(checks), 'KL_details': checks,
    'new_external_model_calls': 0,
}
(OUT/'independent-checks.json').write_text(json.dumps(record, indent=2)+'\n')
print(f"PASS: {len(archived)} archive members, {len(old)} old artifacts, 2 replays, {len(checks)} independent KL cases")
