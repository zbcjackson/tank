"""Compare the initial reviewed code and the minimal audit-version repair."""
import json
import runpy
import subprocess
from pathlib import Path

ROOT = Path('/Users/zbcjackson/src/tank')
OUT = Path(__file__).parent
source = subprocess.check_output(['git','show','0c7e2a15:backend/benchmarks/computer_use/jev_scoring.py'], cwd=ROOT)
(OUT/'initial_jev_scoring.py').write_bytes(source)
initial = runpy.run_path(str(OUT/'initial_jev_scoring.py'))
fixed = runpy.run_path(str(ROOT/'backend/benchmarks/computer_use/jev_scoring.py'))
fixture = runpy.run_path(str(ROOT/'backend/core/tests/test_jev_scoring.py'))
frozen, result, audit = fixture['_batch'](64)
records = {}
for label, module, version in [('before_bool',initial,True),('after_bool',fixed,True),('after_integer',fixed,1),('after_float',fixed,1.0)]:
    report = module['score'](frozen, result, {**audit,'schema_version':version})
    records[label] = {key:report[key] for key in ('all_gates_passed','evidence_kind','model_execution_eligible','evidence')}
assert records['before_bool']['all_gates_passed'] is True
assert records['before_bool']['evidence']['independent_audit'] is True
assert records['after_integer']['all_gates_passed'] is True
for label in ('after_bool','after_float'):
    assert records[label]['all_gates_passed'] is False
    assert records[label]['evidence']['independent_audit'] is False
    assert records[label]['evidence']['issues'] == ['unbound or invalid audit header']
(OUT/'version-boundary-check.json').write_text(json.dumps(records, indent=2)+'\n')
print('PASS: malformed boolean header previously passed; repaired bool/float fail closed; integer 1 preserves valid gate passage.')
