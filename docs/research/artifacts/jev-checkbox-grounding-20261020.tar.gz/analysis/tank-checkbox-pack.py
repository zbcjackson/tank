"""Package no-model evidence and immutable previous archive verification."""
import hashlib,io,json,os,re,subprocess,sys,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank');artifacts=root/'docs/research/artifacts';h=lambda b:hashlib.sha256(b).hexdigest();old={};files={}
for p in sorted(artifacts.glob('*-manifest.json')):
 if not(p.name.startswith('jev-')or p.name.startswith('dom-visual-freshness-')):continue
 prior=subprocess.run(['git','show','3ecbe7f0:'+str(p.relative_to(root))],cwd=root,capture_output=True)
 if prior.returncode:continue
 assert prior.stdout==p.read_bytes();m=json.loads(prior.stdout);archive=p.with_name(p.name.replace('-manifest.json','.tar.gz'));assert h(archive.read_bytes())==m['archive_sha256'];old[archive.name]=m['archive_sha256']
assert len(old)==12
for phase in('before','after'):
 p=Path('/private/tmp/tank-checkbox-'+phase+'-20261020')
 for q in p.rglob('*'):
  if q.is_file():files[phase+'/'+str(q.relative_to(p))]=q
f=json.loads(Path('/private/tmp/tank-checkbox-after-20261020/freeze.json').read_text());appenv=Path(f['app']['python']).parent.parent
for name,sha in f['app']['files'].items():
 p=appenv/name;assert h(p.read_bytes())==sha;files['app/'+name]=p
ready=Path('/private/tmp/tank-checkbox-route-ready-20261020');assert not any((ready/n).exists()for n in('started.json','result.json','spend.jsonl'));files['prepared-route/freeze.json']=ready/'freeze.json'
for name in('analyze.py','summary.json','pack.py'):
 p=Path('/private/tmp/tank-checkbox-'+name);files['analysis/'+p.name]=p
for p in sorted(Path('/private/tmp').glob('tank-checkbox-*.log')):
 if p.name!='tank-checkbox-pack-result.log':files['verification/'+p.name]=p
values={**dotenv_values(root/'backend/core/.env'),**os.environ};secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)];assert secrets
for n,p in files.items():assert not any(s in p.read_bytes()for s in secrets),f'credential found: {n}'
archive=artifacts/'jev-checkbox-grounding-20261020.tar.gz';assert not archive.exists()
manifest={'date':'2026-10-20','baseline_commit':'3ecbe7f0','plan_commit':'b30d2de8','implementation_commit':sys.argv[1],'model_calls':0,'archive_sha256':None,'old_archives_unchanged':old,'credential_values_scanned':len(secrets),'files':{}}
with tarfile.open(archive,'w:gz')as tf:
 for n,p in sorted(files.items()):
  data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data));manifest['files'][n]={'bytes':len(data),'sha256':h(data)}
manifest['archive_sha256']=h(archive.read_bytes())
with tarfile.open(archive,'r:gz')as tf:
 assert set(tf.getnames())==set(files)
 for m in tf.getmembers():
  b=tf.extractfile(m).read();assert h(b)==manifest['files'][m.name]['sha256']and len(b)==manifest['files'][m.name]['bytes']
archive.with_name('jev-checkbox-grounding-20261020-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'old_archives':len(old),'credential_values':len(secrets)}))
