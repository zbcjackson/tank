"""Independent no-model diagnostic audit, without host/scoring imports."""
import hashlib,json,sqlite3,sys
from pathlib import Path
h=lambda b:hashlib.sha256(b).hexdigest();enc=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
paths=[Path(sys.argv[1]),Path(sys.argv[2])];out=Path(sys.argv[3]);phases=[];all_rows=[];app=None;initial_images={};images=0
for phase,p in zip(('before','after'),paths):
 f=json.loads((p/'freeze.json').read_text());r=json.loads((p/'result.json').read_text());raw=dict(f);raw.pop('sha256');assert h(enc(raw).encode())==f['sha256']==r['sha256'];assert f['no_models']and r['completed']and not r['client_attempts']and r['model_calls']==0
 assert len(f['cases'])==len(r['rows'])==(4 if phase=='before'else 8)
 assert all(h((p/'source'/n).read_bytes())==sha for n,sha in f['source_sha256'].items())
 if app is None:app=f['app']
 else:assert app==f['app']
 assert [c['id']for c in f['cases']]==[x['id']for x in r['rows']]
 summaries=[]
 for c,row in zip(f['cases'],r['rows']):
  d=p/row['id'];assert row==json.loads((d/'row.json').read_text());assert row['status']=='finished'and row['cleanup_confirmed']and row['app_unchanged']
  assert row['model_calls']==0 and row['usage']['total_tokens']==0 and not row['usage']['unknown_calls'];assert not any(e['kind']=='model_call'for e in row['events']);assert not (d/'calls.jsonl').exists()
  db=sqlite3.connect((d/'fixture.db').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
  try:
   actual={'records':[dict(x)for x in db.execute('SELECT * FROM work_items ORDER BY id')],'writes':[dict(x)for x in db.execute('SELECT * FROM _writes ORDER BY rowid')],'column_writes':[dict(x)for x in db.execute('SELECT * FROM _column_writes ORDER BY column_name,rowid')],'schema':[list(x)for x in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]}
  finally:db.close()
  assert actual==row['evidence']and actual['schema']==row['initial_evidence']['schema'];assert row['initial_evidence']['records']==c['seed']and not row['initial_evidence']['writes']and not row['initial_evidence']['column_writes']
  target=c['order']+1;before=next(x for x in c['seed']if x['id']==target);expected=json.loads(json.dumps(c['seed']));after=next(x for x in expected if x['id']==target);after['title']=c['goal']['inputs'][0]['value'];assert expected==c['oracle']['rows']==actual['records']
  assert actual['writes']==[{'operation':'update','id':target,'old_title':before['title'],'new_title':after['title'],'old_notes':before['notes'],'new_notes':after['notes']}]
  columns=['id','notes','title']if c['mode']=='all'else['title'];assert actual['column_writes']==[{'column_name':name,'id':target,'old_value':str(before[name]),'new_value':str(after[name])}for name in columns]
  assert row['value_success']and row['column_success']==(columns==['title'])and row['input_attempts']==len(row['inputs'])==3
  http=[json.loads(l)for l in(d/'http.jsonl').read_text().splitlines()];assert row['http']==http and sum(x['method']=='POST'for x in http)==1
  assert http[0]['path']==c['start_path']and all(not x['injected']and x['status'].startswith('200'if x['method']=='GET'else'302')for x in http)
  for cap in row['captures']:
   png=(d/(cap['stage']+'.png')).read_bytes();assert png.startswith(b'\x89PNG\r\n\x1a\n')and h(png)==cap['image_sha256'];images+=1
   packet=cap['packet'];g={**c['goal'],'scope':'checkbox-diagnostic','outcomes':c['goal'].get('outcomes',[])};g['inputs']=[{'field_scope':None,'field_label':None,'value':None,'source':'user','input_type':'text',**v}for v in g['inputs']];assert packet['state']['goal']==g
   assert not any(k in packet['state']for k in('oracle','column_writes','seed'))
   if phase=='after'and cap['stage']!='final':
    offered={k:v for k,v in packet['questions']['next_action']['criteria'].items()if isinstance(v,dict)};fields=[v for v in offered.values()if v['role']=='checkbox'and v['label'].startswith('Allow updating this column.')]
    assert len(fields)==3;facts={x['key']:x['value']for x in packet['state']['snapshot']['facts']}
    for field in fields:
     key='dom:checked:'+h(field['target_ref'].encode());assert field['effect']==[{'key':key,'value':'false'if field['current_value']=='true'else'true'}]and facts[key]==field['current_value']
    assert sorted(x['label']for x in fields)==['Allow updating this column. [name=chk_id]','Allow updating this column. [name=chk_notes]','Allow updating this column. [name=chk_title]']
  first=row['captures'][0];assert first['column_candidates']==(0 if phase=='before'else 3);assert first['reason']=='jev_eligible'
  if c.get('actor','manual')=='host':
   assert row['host_result']['reason']==('goal_verified'if c['mode']=='title'else'effect_unknown')and len(row['proposals'])==3
   assert row['host_result']['status']==('completed'if c['mode']=='title'else'unknown')
   assert row['proposals'][0]['label']==('include all columns'if c['mode']=='all'else'Allow updating this column. [name=chk_title]')
   audit=[json.loads(l)for l in(d/'audit.jsonl').read_text().splitlines()];assert all(x['category']=='execution'for x in audit)
  else:
   key=(c['mode'],c['order'])
   if phase=='before':initial_images[key]=first['image_sha256']
   else:assert initial_images[key]==first['image_sha256']
  x={'phase':phase,'id':c['id'],'actor':c.get('actor','manual'),'mode':c['mode'],'order':c['order'],'values_unchanged_except_title':True,'written_columns':columns,'title_only':columns==['title'],'initial_column_candidates':first['column_candidates'],'initial_reason':first['reason'],'input_attempts':row['input_attempts'],'host_reason':row.get('host_result',{}).get('reason'),'cleanup_confirmed':row['cleanup_confirmed'],'local_pngs':len(row['captures'])};summaries.append(x);all_rows.append(x)
 phases.append({'phase':phase,'sha256':f['sha256'],'contexts':len(r['rows']),'inputs':sum(x['input_attempts']for x in r['rows']),'model_calls':0,'source_files':len(f['source_sha256']),'column_candidates':0 if phase=='before'else 3})
assert app is not None;env=Path(app['python']).parent.parent;assert all(h((env/n).read_bytes())==sha for n,sha in app['files'].items())
s={'date':'2026-10-20','phases':phases,'app_files':len(app['files']),'model_calls':0,'client_attempts':0,'all_contexts':len(all_rows),'all_inputs':sum(x['input_attempts']for x in all_rows),'all_cleanup_confirmed':all(x['cleanup_confirmed']for x in all_rows),'task_pngs':images,'same_manual_initial_images':True,'rows':all_rows}
out.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items()if k!='rows'},indent=2))
