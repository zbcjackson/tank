# Navigation observation fix evidence

Baseline: 1ec85dae. All qualification model HTTP uses explicit MockTransport;
no real provider credentials are loaded. The previous task's authentication-denied
invocation and unknown_usage remain in its unchanged archive.

Two separate red/green slices are retained:

1. A local streaming HTTP fixture commits a document but withholds its form body.
   The old channel immediately returned an observation. The fix waits at most
   500 ms for DOMContentLoaded and polls existing task stop checks while waiting;
   timeout invalidates previous references. Generic tests cover different-URL
   navigation, same-URL reload, unavailable capture/dispatch, and cancel/revoke/deadline.
   Test fixture mistakes (frozen deadline assignment / reused URL variable) were
   fixed, not treated as product failures. Earlier interrupted suite logs are not
   claimed as passing verification.
2. Waiting alone was insufficient: run/fake stopped after the first V case with
   no_viable_actions; one attempted, 191 not_run, two simulated SDK/image responses.
   That source and all receipts are retained. Product projection red tests then
   mutate DOM revision during async business readback without changing navigation.
   All three projection paths failed. A shared read-only current-snapshot check
   re-reads DOM and validates both the view and navigation before publishing facts;
   all six DOM/reload projection combinations pass. No action is replayed.

Final runtime source digest: dde7db9a13a2e4f5f32cc1b9914b184fcbc76ecdad917d5d55f47430600bf901.
Final qualification digest: 096472b203217a388dc5cec6f4fad001851156be0699d15b670a5fdd2ccd5026.
Only dom.py and the three product projection benchmark modules changed among the
36 frozen runtime sources. Tests and current design documentation also changed.

Both run and run-v2 preserve the same fixed 48 seed clusters / 96 condition goals
and 192 arm schedule. New freeze follows source changes; results are not pooled,
failed cases are not replaced, and replays do not count as model measurements.
Original product manifests and all 46 prior archive/manifest files are retained.

Final native qualification: 96/96, 80 positive and 8 missing/8 revoked, 416 PNGs.
Final fake qualification: 160 positive + 32 negative, 192 cleanup, 160 POSTs,
672 SDK / 556 image calls, 6720 synthetic tokens. Both arms: 80 positive / 16 negative.
All are wiring/acceptance evidence, not model performance, real token usage or prices.

Independent audit_native.py and audit_fake.py query physical before/after DBs and
HTTP journals without importing Controller scoring. They verify complete bookmark
business tables / SQL write logs, schema and all unchanged fields, returned-list
and public input identities, original PNG checksums/decoding, arm order and usage.
The full bank and master seed are referenced from the unchanged prior design
archive; this package carries the fixed prefix and exact execution sources.
