"""Offline-only fixed-prefix qualification, not a confirmation runner."""
import json
from pathlib import Path
ROOT = Path(__file__).parent
BANK = Path('/private/tmp/tank-jev-confirmation-design-20261022/reserved-bank')
def select_cases():
    return [c for line in (BANK / "cases.jsonl").open()
            if (c := json.loads(line))["reserved_rank"] < (2 if c["negative"] else 4)]

def choose(packet):
    """Synthetic answer from public identity and offered actions only."""
    import re
    offered = {k:v for k,v in packet['questions']['next_action']['criteria'].items() if isinstance(v,dict)}
    identity = packet['state']['goal']['outcomes'][0]['conditions'][0]['key'].removeprefix('status:Editor seen:')
    target = identity.rsplit('/',1)[-1]
    predicates = (
        lambda v:v['label']=='Retry',
        lambda v:v['operation']=='fill',
        lambda v:v['label']=='Allow updating this column. [name=chk_title]' and v['current_value']=='false',
        lambda v:v['role']=='button' and v['label'] in ('Save','Update'),
        lambda v:v['label']=='Edit' and (any(kind=='row' and name.split()[0]==target for kind,name in v['ancestors']) or any(re.search(r'/bookmarks/'+re.escape(target)+r'/edit(?:\?|$)',f['value']) for f in v['effect'])),
    )
    return next((key for predicate in predicates for key,value in offered.items() if predicate(value)), 'none')

REPO = Path('/Users/zbcjackson/src/tank')
DESIGN = BANK.parent
SQLPY = Path('/private/tmp/tank-sqlite-web-20261020-env/bin/python')
LINKROOT = Path('/private/tmp/linkding-1.47.0')

def sha(p):
    import hashlib
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def digest(value):
    import hashlib
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def save(p,value):
    Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def prepare(root):
    import copy, shutil
    from benchmarks.computer_use import jev_calibration_route as calibration
    root=Path(root); root.mkdir(parents=True,exist_ok=False)
    prior=json.loads((DESIGN/'inputs/calibration-freeze.json').read_text())
    if sha(BANK/'cases.jsonl')!='150d6900a90fbcdd8f42908a9d4e8c6e46fa46650d618a2b04ed0ddbffd2592d':
        raise ValueError('bank changed')
    actual=calibration.freeze_inputs(SQLPY,LINKROOT)
    if actual['apps'] != prior['apps']:
        raise ValueError('qualified products changed')
    prior = actual
    source=root/'source';source.mkdir()
    for name,value in prior['source_sha256'].items():
        original=REPO/'backend'/name
        if sha(original)!=value:raise ValueError('runtime drift')
        dest=source/'runtime'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,dest)
    for name in ('qualify.py','native.py','tank-jev-confirmation-proxy.py'):
        shutil.copyfile(ROOT/name,source/name)
    cases=select_cases();save(root/'cases.json',cases)
    native=[]
    for c in cases:
        row=copy.deepcopy(c);row['public_goal']=row['goal'];row['private_acceptance']={'records':row['oracle']['rows']}
        native.append(row)
    save(root/'calibration-tasks.json',native)
    save(root/'protocol.json',{'kind':'offline-qualification','formal_N':None,'model_execution_eligible':False,'model_calls':0,'selected_seed_clusters':48,'native_goals':96,'fake_trials':192,'selection':'first4 positive/first2 negative ranks in each frozen stratum; no replacement','provider_cache':'not controlled; prewarm is service GET only','scope':'bank prefix qualification only, no real model outputs or prompt tuning'})
    save(root/'executable-freeze.json',prior)
    files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
    schedule=[{'id':c['id']+'-'+arm,'case':c['id'],'arm':arm,'cluster_id':c['cluster_id'],'condition':c['condition']} for c in cases for arm in c['reserved_arm_order']]
    f={'mode':'offline-only','formal_N':None,'model_execution_eligible':False,'files':files,'runtime_sources':prior['source_sha256'],'apps':prior['apps'],'input_bank_sha256':sha(BANK/'cases.jsonl'),'schedule':schedule}
    f['sha256']=digest(f);save(root/'freeze.json',f);return f

def verify(root,approved):
    from benchmarks.computer_use import jev_calibration_route as calibration
    root=Path(root);f=json.loads((root/'freeze.json').read_text())
    if f['sha256']!=approved or digest({k:v for k,v in f.items() if k!='sha256'})!=approved or f['mode']!='offline-only' or f['formal_N'] is not None or f['model_execution_eligible']:
        raise ValueError('offline freeze required')
    for name,value in f['files'].items():
        if sha(root/name)!=value:raise ValueError('file drift: '+name)
    if sha(BANK/'cases.jsonl')!=f['input_bank_sha256']:raise ValueError('bank drift')
    if calibration.freeze_inputs(SQLPY,LINKROOT)!=json.loads((root/'executable-freeze.json').read_text()):raise ValueError('runtime/product drift')
    return f

async def run_fake(root,approved,*,failure=None):
    import asyncio, base64, io
    import httpx, httpx2, pytest
    from PIL import Image
    from benchmarks.computer_use import jev_calibration_route as calibration
    from tank_backend.benchmarks.spend_ledger import SpendLedger,SpendLimit
    root=Path(root);f=verify(root,approved);output=root/'fake';output.mkdir(exist_ok=False)
    cases={c['id']:c for c in json.loads((root/'cases.json').read_text())}
    frozen=json.loads((root/'executable-freeze.json').read_text())
    rows=[{**s,'attempted':False,'status':'not_run','calibration_success':False,'cleanup_confirmed':False} for s in f['schedule']]
    ledger=SpendLedger(SpendLimit(0,0),record_only=True,journal=output/'spend.jsonl')
    result={'sha256':approved,'mode':'fake-only','formal_N':None,'external_model_requests':0,'rows':rows,'completed':False}
    def persist():
        result['spend']=ledger.snapshot();save(output/'result.json',result)
    calls=[]
    def respond(payload):
        visual='messages' in payload
        packet=json.loads(payload['messages'][1]['content'][0]['text']) if visual else payload
        assert 'oracle' not in packet and 'private_acceptance' not in packet and 'seed' not in packet
        images=[]
        if visual:
            for message in payload['messages']:
                if isinstance(message.get('content'),list):
                    for part in message['content']:
                        if part['type']=='image_url':
                            png=base64.b64decode(part['image_url']['url'].split(',',1)[1]);Image.open(io.BytesIO(png)).verify();images.append({'sha256':__import__('hashlib').sha256(png).hexdigest(),'bytes':len(png)})
            assert len(images)==1
        selected=choose(packet)
        if failure=='invalid':selected='not-offered'
        calls.append({'provider':'peer' if visual else 'jev','goal_id':packet['state']['goal']['goal_id'],'choice':selected,'images':images})
        with (output/'transport.jsonl').open('a') as stream:stream.write(json.dumps(calls[-1])+'\n')
        if failure=='exception':raise RuntimeError('synthetic external transport failure')
        if visual:
            answer={'id':'fixture','object':'chat.completion','created':1,'model':calibration.base.PEER['model'],'choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':json.dumps({'choice':selected})}}],'usage':{'prompt_tokens':7,'completion_tokens':3,'total_tokens':10}}
        else:
            answer={'model':calibration.base.JEV['model'],'answers':{'next_action':{'type':'choice','choice':selected,'confidence':1,'probabilities':{k:float(k==selected) for k in packet['questions']['next_action']['criteria']}}},'usage':{'input_tokens':7,'output_tokens':3}}
        if failure=='unknown':answer.pop('usage')
        return answer
    with offline_http(respond):
        persist()
        try:
            for row in rows:
                try:
                    verify(root,approved);row.update(attempted=True,status='started');persist()
                    row.update(await calibration.run_task(cases[row['case']],row['arm'],output,frozen=frozen,jev_credential='qualification-fake',peer_credential='qualification-fake',ledger=ledger))
                except asyncio.CancelledError:
                    row.update(status='cancelled');ledger.stop('cancelled');raise
                except Exception as exc:
                    row.update(status='error',error_type=type(exc).__name__);ledger.stop('operational_error')
                if not row['calibration_success']:
                    ledger.stop('qualification_failure')
                persist()
                print(json.dumps({k:row.get(k) for k in ('id','status','calibration_success','cleanup_confirmed','error_type')}),flush=True)
                if ledger.snapshot()['stop_reason']:break
            result['completed']=not ledger.snapshot()['stop_reason'] and all(r['status']=='finished' for r in rows)
        finally:
            ledger.close();result['fake_sdk_calls']=len(calls);result['fake_image_calls']=sum(c['provider']=='peer' for c in calls);persist()
    verify(root,approved)
    return result


from contextlib import contextmanager
@contextmanager
def offline_http(answer):
    """Supply both SDKs explicit fake HTTP transports; keep SDK clients real."""
    import httpx,httpx2,pytest,socket
    real2=httpx2.AsyncClient
    class Client(real2):
        def __init__(self,*args,**kwargs):
            kwargs['transport']=httpx2.MockTransport(lambda request:httpx2.Response(200,json=answer(json.loads(request.content))))
            super().__init__(*args,**kwargs)
    original_connect=socket.socket.connect
    def loopback_only(sock,address):
        if isinstance(address,tuple) and address[0] not in ('127.0.0.1','::1','localhost'):
            raise AssertionError('external Python socket denied')
        return original_connect(sock,address)
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(httpx,'AsyncHTTPTransport',lambda **kwargs:httpx.MockTransport(lambda request:httpx.Response(200,json=answer(json.loads(request.content)))))
        patch.setattr(httpx2,'AsyncClient',Client)
        patch.setattr(socket.socket,'connect',loopback_only)
        yield

if __name__=='__main__':
    import argparse,asyncio
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('prepare','fake'))
    parser.add_argument('root',type=Path)
    parser.add_argument('--approved-sha256')
    args=parser.parse_args()
    if args.stage=='prepare':
        if args.approved_sha256:parser.error('prepare cannot approve execution')
        print(json.dumps({'sha256':prepare(args.root)['sha256']}))
    else:
        if not args.approved_sha256:parser.error('offline digest required')
        r=asyncio.run(run_fake(args.root,args.approved_sha256))
        print(json.dumps({k:v for k,v in r.items() if k not in ('rows','spend')}))
        raise SystemExit(0 if r['completed'] and all(x['calibration_success'] for x in r['rows']) else 1)
