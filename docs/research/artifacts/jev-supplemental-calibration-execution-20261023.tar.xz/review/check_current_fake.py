import hashlib,json,socket,sys
from pathlib import Path
from unittest.mock import patch
repo=Path('/Users/zbcjackson/src/tank')
review=Path('/private/tmp/tank-jev-execution-review-20261023')
root=review/'study-v3'
sys.path.insert(0,str(repo/'backend'))
from benchmarks.computer_use import jev_execution as execution,jev_audit as audit
frozen=json.loads((root/'qualification-freeze.json').read_text())
full=json.loads((root/'freeze.json').read_text())
result=json.loads((root/'fake/result.json').read_text())
saved=json.loads((root/'fake/audit.json').read_text())
wire=[json.loads(l) for l in (root/'fake/transport.jsonl').read_text().splitlines()]
verification=review/'verification-v3.json'
attempts=[]
def deny(*args,**kwargs):
    attempts.append('network_or_credential_access')
    raise AssertionError('independent artifact audit must be offline')
with patch.object(socket.socket,'connect',deny),patch.object(socket,'getaddrinfo',deny),patch('dotenv.dotenv_values',deny):
    execution.load_freeze(root,full['sha256'])
    execution.verify_checks(full,verification)
    cases={c['id']:c for c in frozen['cases']}
    labels={}
    for slot,row in zip(frozen['schedule'],result['rows']):
        assert all(row[k]==v for k,v in slot.items())
        path=root/'fake'/row['id']
        labels[row['id']]=audit.audit_trial(cases[row['case']],row,path)
        execution.audit_usage(row,result['spend'],path)
        audit.audit_usage(row,result['spend'],[x for x in wire if x['trial_id']==row['id']])
    host=json.loads((root/'qualified-input/freeze.json').read_text())
    native=json.loads((root/'qualified-input/native/result.json').read_text())
    assert len(native['rows'])==96
    for case,row in zip(host['cases'],native['rows']):
        assert row['id']==case['id']
        assert audit.audit_native_trial(case,row,root/'qualified-input/native'/case['id']) is True
    rebuilt=execution.build_audit(root,frozen['sha256'],verification,fake=True)
    assert rebuilt==saved and labels==saved['trials']
    preview=execution.preflight(root,full['sha256'],verification)
assert attempts==[]
assert result['completed'] is True and result['qualified'] is True
assert len(result['rows'])==192 and len(labels)==192
assert all(x['attempted'] is True and x['status']=='finished' for x in result['rows'])
assert all(x['cleanup_confirmed'] is True for x in result['rows'])
assert len(wire)==result['fake_sdk_calls']==result['logical_sdk_calls']
assert all(r['status']=='known' for r in result['spend']['requests'].values())
assert result['spend']['stop_reason'] is None
assert result['spend']['batch']['reserved_tokens']==result['spend']['batch']['reserved_nano_usd']==0
assert result['external_model_requests']==0 and result['blocked_external_attempts']==[]
old=json.loads((review/'prior-artifact-sha256.json').read_text())
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
    return h.hexdigest()
assert len(old)==62 and all(sha(repo/name)==value for name,value in old.items())
receipt=json.loads(verification.read_text())
assert len(receipt['task_file_sha256'])==13
assert all(sha(repo/name)==value for name,value in receipt['task_file_sha256'].items())
summary={'execution_sha256':full['sha256'],'qualification_sha256':frozen['sha256'],'current_host_sha256':rebuilt['current_host_sha256'],'native_raw_proof_sha256':rebuilt['native_raw_proof_sha256'],'runtime_sources':42,'task_files':13,'protected_old_artifacts':62,'native_raw_reaudited':96,'fake_raw_reaudited':192,'strict_verified':sum(x['strict_verified'] for x in labels.values()),'negative_verified':sum(x['negative_verified'] for x in labels.values()),'recovery_verified':sum(x['recovery_verified'] for x in labels.values()),'critical_events':sum(x['critical_events'] for x in labels.values()),'unexpected_actions':sum(x['unexpected_action'] for x in labels.values()),'cleanup_confirmed':192,'logical_sdk_calls':result['logical_sdk_calls'],'fake_sdk_calls':len(wire),'fake_image_calls':sum(x['provider']=='peer' for x in wire),'known_tokens':result['spend']['batch']['known_tokens'],'unknown_requests':sum(x['status']!='known' for x in result['spend']['requests'].values()),'reserved_tokens':0,'reserved_nano_usd':0,'external_model_requests':0,'blocked_external_attempts':[],'readonly_audit_network_or_credential_attempts':attempts,'ready_for_authorization':preview['ready_for_authorization'],'model_execution_eligible':preview['model_execution_eligible'],'formal_N':preview['formal_N'],'all_checks_byte_bound':True,'native_and_fake_saved_audit_exact_match':True,'live_run_invoked':False}
assert preview['ready_for_authorization'] is True and preview['model_execution_eligible'] is False and preview['formal_N'] is None
(review/'postrun-independent-v3.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False),flush=True)
