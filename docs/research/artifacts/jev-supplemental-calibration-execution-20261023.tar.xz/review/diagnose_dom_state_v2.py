"""One fixed, instrumented local failure-path diagnostic; never qualification."""
import asyncio
import importlib.util
import json
import socket
import sys
import time
from pathlib import Path
from unittest.mock import patch
import pytest
from playwright.async_api import BrowserContext

repo = Path('/Users/zbcjackson/src/tank')
review = Path('/private/tmp/tank-jev-execution-review-20261023')
output = review / 'dom-state-diagnostic-v2'
sys.path.insert(0, str(repo / 'backend'))
from benchmarks.computer_use import jev_calibration_route as pilot, jev_fake_http
from agent_computer_use.channels.dom import ManagedChromiumChannel
spec = importlib.util.spec_from_file_location('review_original_dom_tests', repo / 'backend/plugins/agent-computer-use/tests/test_dom.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
mutations = r"""(() => {
  new MutationObserver(records => {
    for (const m of records) {
      const short = n => (n.outerHTML || n.textContent || n.nodeName || '').slice(0, 500);
      console.debug('TANK_MUTATION ' + JSON.stringify({at:performance.now(), url:location.href,
        type:m.type, target:m.target.nodeName, id:m.target.id || '', attribute:m.attributeName,
        old:m.oldValue, value:m.type === 'attributes' ? m.target.getAttribute(m.attributeName) : null,
        added:[...m.addedNodes].map(short), removed:[...m.removedNodes].map(short)}));
    }
  }).observe(document, {subtree:true, childList:true, attributes:true, characterData:true,
    attributeOldValue:true, characterDataOldValue:true});
})();"""
network_attempts = []
connect = socket.socket.connect
resolve = socket.getaddrinfo

def guarded_connect(sock, address):
    if isinstance(address, tuple) and address[0] not in ('127.0.0.1', '::1', 'localhost'):
        network_attempts.append(str(address))
        raise AssertionError('external model/network is forbidden in this diagnostic')
    return connect(sock, address)

def guarded_resolve(host, *args, **kwargs):
    if host not in ('127.0.0.1', '::1', 'localhost', b'127.0.0.1', b'::1', b'localhost'):
        network_attempts.append(str(host))
        raise AssertionError('external DNS is forbidden in this diagnostic')
    return resolve(host, *args, **kwargs)

async def main():
    frozen = pilot.prepare(output, sql_python=Path('/private/tmp/tank-sqlite-web-20261020-env/bin/python'), link_root=Path('/private/tmp/linkding-1.47.0'))
    identity = 'cal-linkding-recovery-editor-4-prewarmed'
    case = next(c for c in frozen['cases'] if c['id'] == identity)
    old = json.loads((review / 'failed-96-calibration/freeze.json').read_text())
    assert case == next(c for c in old['cases'] if c['id'] == identity)
    (output / 'diagnostic-only.json').write_text(json.dumps({'purpose':'causal diagnosis of one preserved full-suite failure; not qualification, not a test pass or model-quality result', 'case':identity, 'arm':'jt', 'case_unchanged':True}, indent=2)+'\n')
    reads = []
    checks = []
    original_page = BrowserContext.new_page
    original_read = ManagedChromiumChannel.read
    original_current = ManagedChromiumChannel.is_current
    with (output / 'mutations.jsonl').open('x') as journal:
        async def new_page(context, *args, **kwargs):
            page = await original_page(context, *args, **kwargs)
            def observe(message):
                if message.text.startswith('TANK_MUTATION '):
                    record = json.loads(message.text.removeprefix('TANK_MUTATION '))
                    record['host_monotonic'] = time.monotonic()
                    journal.write(json.dumps(record, ensure_ascii=False)+'\n')
                    journal.flush()
            page.on('console', observe)
            await page.add_init_script(mutations)
            return page
        async def read(channel, frame, context):
            value = await original_read(channel, frame, context)
            record = {'host_monotonic':time.monotonic(), 'view':value.model_dump(mode='json')}
            reads.append(record)
            with (output / 'reads.jsonl').open('a') as capture:
                capture.write(json.dumps(record, ensure_ascii=False)+'\n')
            return value
        async def current(channel, binding, action, context, **kwargs):
            expected = channel.view.model_dump(mode='json') if channel.view else None
            first = len(reads)
            passed = await original_current(channel, binding, action, context, **kwargs)
            record = {'host_monotonic':time.monotonic(),'action':action.model_dump(mode='json') if hasattr(action,'model_dump') else {'id':action.id,'operation':action.operation,'value':action.value},'current':passed,'expected':expected,'reads':reads[first:]}
            checks.append(record)
            with (output / 'checks.jsonl').open('a') as capture:
                capture.write(json.dumps(record,ensure_ascii=False)+'\n')
            return passed
        with pytest.MonkeyPatch.context() as monkeypatch:
            calls, packets = module.install_product_http(monkeypatch)
            monkeypatch.setattr(BrowserContext, 'new_page', new_page)
            monkeypatch.setattr(ManagedChromiumChannel, 'read', read)
            monkeypatch.setattr(ManagedChromiumChannel, 'is_current', current)
            import httpx
            original_test_transport = httpx.AsyncHTTPTransport()
            def same_answer(payload):
                return original_test_transport.handle_request(httpx.Request('POST', 'https://fake.invalid', json=payload)).json()
            with patch.object(socket.socket,'connect',guarded_connect), patch.object(socket,'getaddrinfo',guarded_resolve), jev_fake_http.offline_http(same_answer, output/'fake-transport.jsonl') as transport:
                transport['active_trial'] = identity + '-jt'
                row = await pilot.run_task(case, 'jt', output, frozen=frozen, jev_credential='diagnostic-fake', peer_credential='diagnostic-fake')
                network_attempts.extend(transport['blocked_external'])
    summary = {'purpose':'diagnostic only; not qualification or pass evidence','case':identity,'arm':'jt','status':row['status'],'reason':row.get('result',{}).get('reason'),'strict_completed':row['strict_completed'],'cleanup_confirmed':row['cleanup_confirmed'],'fake_sdk_calls':len(calls),'read_count':len(reads),'failed_checks':[x for x in checks if not x['current']],'network_attempts':network_attempts}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='failed_checks'},ensure_ascii=False),flush=True)
    assert row['cleanup_confirmed'] is True
    assert not network_attempts

asyncio.run(main())
