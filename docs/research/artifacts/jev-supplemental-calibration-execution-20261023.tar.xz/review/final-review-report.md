# 执行准备审查交接（2026-10-23）

结论：review-and-refactor gate 实际完成 **2 轮**，最多3轮。第1轮确认并修复 R1、R2；第1轮的全部必要验证完成后，第2轮对两项修复及其接线作自检，无新增可操作或遗留代码问题，立即结束，不进入第3轮。R1/R2是问题ID，不是轮次。最初对原作者实现的审查是职责分离审查；本评审者实施的修复及第2轮复核均是**自行复核**，不是由另一执行者独立验收，也未递归调度审查。

本报告取代早期 reviewer-evidence-check.json、interim-review-state.json、current-validation-state.json、dom-state-causal-summary.json 中的阶段性“未修复/未运行/无发现”等状态；保留这些文件及所有失败日志作为历史，不覆盖它们。

基线 `f139c421`；原计划/实现签名提交 `ed0266c2`、`9cc8b4a4` 纳入完整任务差异。初始没有用户改动；父代理在评审范围内暂停编辑。按父代理明确授权从原9文件扩至13文件，完整清单及字节在 `scope-final-sha256.json`、`scope-final/`；`task-final.diff` 包含基线以来提交、工作区文档及 untracked research 的完整内容。遵守 root/Backend/test 文档、固定24项smell参考、DbC、DRY/KISS/YAGNI、项目全验证与签名提交规则。

## 确认问题与处置

**R1 / P2 / 已修复**：`backend/benchmarks/computer_use/jev_execution.py:530` 的预检对 strict_completed/negative_passed/recovery_completed 使用 truthiness。隔离首版资格副本中将true改为整数1，更新闭合摘要并重建公开audit，物理验收仍过且预检ready，但现有评分器按严格布尔将该回执判为invalid。影响是执行准入与结果契约不一致（Primitive Obsession、DbC），不是任意root全面伪造攻击模型。最小修复对三字段要求精确bool，包括非活动false字段；六项RED后26项GREEN，全部日志保留。原始 study-v1 未改。

**R2 / P2 / 已修复确定性就绪缺口，历史Save因果未定**：`backend/plugins/agent-computer-use/src/agent_computer_use/channels/dom.py:362` 仅等DOMContentLoaded，会在Turbo已发布新编辑URL、晚到CSS/body尚未替换、根节点aria-busy=true时，把旧Retry DOM标complete。固定一次仅bundles.css延迟0.65秒的控制诊断证实该问题，记录expected/current读取及MutationObserver时间线；这是隐式生命周期顺序/竞态与DbC缺口。

最小修复：观察冻结前在500ms总有界、可取消等待内处理DOMContentLoaded及文档声明busy，复用原250ms有限动画收尾规则，再双读DOMView并核对navigation。超时无候选；取消/撤权/期限仍停止；原revision、引用、图片、派发、动作/目标门不放宽。共享 `_SETTLE` 从原capture代码按字节提取，保守CSS/未知动画判定不变，`dom-settlement-equivalence.json`保存一致证据（DRY而非复制算法）。六项确定性RED；新增fixture标签失配和17项旧动画测试因拒绝提前而失败的记录保留。只调整新fixture标签及旧动画测试的前置建立方式：先断言observe拒绝、Animation API暂停后取得有效快照、恢复后保留原capture/freshness断言。最终50项相关守卫通过。

必要资格接线：显式修订DOM与jev_qualification.py两个旧宿主源，其余39源严格等于固定旧hash；旧固定归档只导入JSON并作provenance，旧96不再资格化当前宿主。当前42源冻结显式输出两源修订与当前host；fake启动及预检/审计必须重读当前固定96原生结果、保存row、六类raw seal、原始DB/HTML/HTTP/PNG/events/observations和清理，复用不变的 audit_native_trial。缺失、旧host、次序、严格回执类型、原始证明或审计不符均拒绝，不回退。当前host/native结果及原始证明摘要在audit/preview公开。14项初始RED和2项保存row类型RED保留；最终execution43+既有qualification29共72项通过。实际隔离原生PNG篡改被原审计拒绝，未重放资格。

原完整suite曾在 `cal-linkding-recovery-editor-4-prewarmed-jt` 填Title后、Save前以dom_state/stale_reference拒绝；未派发Save，清理确认。历史expected/current DOMView差值未捕获，**不能断言它就是R2造成或已归因解决**。自然未重现不是修复。一次固定Retry GET延迟产生另一个effect_unknown，也没有混作同因。原失败96及所有控制诊断保留。当前相同完整96严格路径业务80正/16负、清理96均通过，是当前回归验证，不能反推历史因果。父代理已接受按条件backlog交接：复发时停批，保全Save前后expected/current DOMView、精确变更差值/MutationObserver与HTTP/CSS/Turbo时间线；不重放、不挑样本、不放宽门。旧cf402 unknown/not_sent原因仍未定。

## 轮次与设计复核边界

第1轮包含R1修复、完整suite失败处置、授权控制诊断、R2最小宿主修复、必要当前96接线及全部验证，未因扩大范围/新冻结重置轮次。第2轮在所有适用验证通过后复核旧问题和新增变更：当前/旧source等式、typed回执、raw证明传递绑定、fake/live模式隔离、先准入后凭据、同一顺序批次、目录不可复用、异常/取消/部分成功、全账本与清理停批路径。没有新增可操作发现，因此结束。没有为函数长度/参数数量机械重构，也没有新增扩展框架。不同信任边界的核验继续保留；不把同责核验强行合并。没有未复核的最后源码修改；报告和交接元数据由本评审者自检，没有额外独立审查。

## 当前冻结及证据

- 完整执行SHA：`6830e2d759bb9ee9db83b03d75f0afabb4886be0298e6994f13e802f95c2d494`。
- 固定192资格SHA：`1ea452def8851be240155b401055d5bb82f18b81032171adfc202c3e6e87cb81`。
- 当前41源host SHA：`f46fdb2764277fff39fd032e6f3573c5b23d1f960e27770b888d3d09bc63cf4c`。
- native结果字节SHA：`42988ed2fce544919927ed6da40eb81e7e945725e44595b5663cfc5af12c3cc5`。
- native完整raw证明SHA：`8f189e76c7f4e048f00e30453f01b28d9b3fb1bf00a78944f0dd9856ce8c9d30`。
- 九项验证receipt字节SHA：`54662f5b2e1a2266327d582feb9d3f7f141d569b4978ac597151d10e8b4cc9cd`。
- 资格audit结构摘要：`a20f748bb668edca07c2599d8d36b7aee85d32fc19833d16905173985b891efe`。

`study-v3`准备后运行源码不变；当前96原生和当前192假HTTP各只完成一批，不对同冻结续跑/重放/抽样。保留原study-v1和仅准备未运行的study-v2。原62工件最终逐文件SHA仍完全相同，见 `postrun-independent-v3.json`。原旧41中的两源改动明确失效旧native资格，其他39源不变；不声称“原41保持不变”。

192：160正例、32负例、64恢复槽全部通过，192清理；672显式fake SDK/556图片、6720已知tokens，unknown/reserved为0，critical/extra/external-model为0，blocked[]、unresolved{}。`postrun-independent-v3.json/.log`以禁止DNS/socket/dotenv读取的上下文逐行重读192 raw和当前96 raw，对比保存与重建audit完全一致并核对13文件/旧62文件。此处“独立”指物理/原始数据复算，不宣称另一个reviewer独立验收自己的修复。

实际audit/check/score CLI均exit0。preflight `ready_for_authorization=true`、`model_execution_eligible=false`，准确912 seed/1824目标/3648槽；预算record-only、无固定批次request/token/金额上限、unpriced不等于免费，未知用量/预留仍停批。TypeSafe Jev1.14文字/结构及OpenRouter Gemini3.8 Flash合成1280×720 PNG范围保持；无Jev图片或Box。score independent_audit/complete_batch/usage_reconciled均true、issues[]；五个数值门未过：quality_difference_lower、recovery_lower、recovery_difference_lower、unexpected_difference_upper、speed_point。没有修改阈值，fake置信界/时钟不是模型性能或采用测量，formal_N=null。SDK捕获仍不冒称物理HTTP发送证明，fake另有实际假transport核验。

## 实际验证命令与结果

以下以仓库 `/Users/zbcjackson/src/tank` 为根，E=`/private/tmp/tank-jev-execution-review-20261023`，所有最终日志在关闭后才绑定。`verification-v3.json` schema_version为整数1，绑定42源、13任务文件及九项exit0/日志SHA。文档在绑定时处于交接收尾快照；父代理后续生命周期/归档文字另作docs-only检查，不覆盖此receipt及九份日志。

1. backend目录，完整suite：`UV_CACHE_DIR=/private/tmp/tank-uv-cache TANK_REQUIRE_CHROMIUM=1 TANK_REAL_PRODUCT_PYTHON=/private/tmp/tank-sqlite-web-20261020-env/bin/python TANK_LINKDING_ROOT=/private/tmp/linkding-1.47.0 caffeinate -is uv run --no-sync env DYLD_LIBRARY_PATH=/opt/homebrew/Cellar/opus/1.6.1/lib pytest`。exit0，6671 passed、1 skipped、21 warnings，1636.45秒；`r2-backend-pytest-current.log`。1 skip在既有 test_tool_metadata.py::TestConditionalRegistration::test_unavailable_tool_not_registered 的“ToolManager requires full config”分支；没有新增skip、没有关闭Chromium。原96严格路径原始工件另保存在passed-96-calibration。
2. backend目录：`UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync ruff check core/src/ core/tests/ plugins/ benchmarks/computer_use/jev_execution.py benchmarks/computer_use/jev_qualification.py`，exit0，`r2-backend-ruff-closed.log`。
3. backend目录：`UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync pyright benchmarks/computer_use/jev_execution.py benchmarks/computer_use/jev_qualification.py plugins/agent-computer-use/src/agent_computer_use/channels/dom.py core/tests/test_jev_execution.py plugins/agent-computer-use/tests/test_dom.py`，exit0/0 errors，`r2-pyright-closed.log`。
4. web目录：`pnpm lint`，exit0，`r2-web-lint-closed.log`。
5. web目录：`npx tsc -b --noEmit`，exit0，`r2-web-tsc-b-closed.log`。
6. cli目录：`UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync ruff check src/ tests/`，exit0，`r2-cli-ruff-closed.log`。
7. 经owned临时服务停止、原%0命令恢复后，`tmux capture-pane -t %0 -p -S -50` / `%1`并筛error/traceback/exception，均空；`/api/health`200、egress[]，exit0，`r2-dev-logs.log`、e2e-v2/restore.json。
8. test目录：`pnpm test`，在 `run_local_e2e_v2.py`已核验effective本地配置后执行，exit0，24场景/95步骤，226.191秒，`r2-e2e.log`；`r2-e2e-lifecycle-v2.log` exit0。copied offline_e2e_server_v2.py SHA `9c9c9c8fe4a38fefd3d1cc1f4613305c1bf14a00eb3e5ccdc4543d04a161ab5e`；实际本地Sherpa、回环LLM、独立DB、TTS/jobs false，实际模型凭据未用于测试，结束owned PID SIGINT/ wrapper0、原服务已恢复。
9. 根目录：`python3 scripts/check_docs.py`，exit0，102 docs，`r2-docs-final.log`；`git diff --check f139c421` exit0，`r2-diff-check-final.log`。协议/生成物未变，protocol sync不适用。

定向最终：backend目录同uv/DYLD环境，`pytest core/tests/test_jev_execution.py core/tests/test_jev_qualification.py -q`，72 passed/199.95秒，`r2-execution-and-qualification-final.log`；50项就绪/原动画守卫，`r2-readiness-and-guards-v2.log`，57.09秒。所有RED/中间失败保留，没有删断言或靠随机重跑追绿。

当前资格（backend目录，同uv/DYLD环境）：

- `python -m benchmarks.computer_use.jev_qualification native --root E/study-v3/qualified-input --approved-sha f46fdb2764277fff39fd032e6f3573c5b23d1f960e27770b888d3d09bc63cf4c`，exit0，96/96、model_calls0，`r2-native-v3.log`；原始逐行复算 `native-independent-v3.log` exit0。
- `python -m benchmarks.computer_use.jev_execution fake --root E/study-v3 --approved-sha 1ea452def8851be240155b401055d5bb82f18b81032171adfc202c3e6e87cb81`，exit0，192/192，`r2-fake-v3.log`。
- `python -m benchmarks.computer_use.jev_execution audit --root E/study-v3 --approved-sha 1ea452def8851be240155b401055d5bb82f18b81032171adfc202c3e6e87cb81 --verification E/verification-v3.json --fake`，exit0，`audit-v3.log`。
- `python -m benchmarks.computer_use.jev_execution check --root E/study-v3 --approved-sha 6830e2d759bb9ee9db83b03d75f0afabb4886be0298e6994f13e802f95c2d494 --verification E/verification-v3.json`，exit0，`preflight-v3.json/.log`。
- `python benchmarks/computer_use/jev_scoring.py --freeze E/study-v3/qualification-freeze.json --result E/study-v3/fake/result.json --audit E/study-v3/fake/audit.json --output E/score-v3`，exit0，`score-v3.log`、score-summary-v3.json。
- `python E/check_current_fake.py`，exit0，postrun-independent-v3.json/.log。只读复算与CLIcheck未发模型请求或读取凭据。

## 所有失败的实际处理

`r1-backend-pytest.log`沙箱loopback EPERM导致广泛E/F，owned任务中止退出143；focused diagnostic 1error证明环境问题，随后获准非沙箱运行，不绕过沙箱或改产品逻辑。`r1-backend-pytest-authorized.log`完整退出1（6647通过/1失败/1跳过），保留失败96工件；经父代理授权控制诊断/最小R2修复后当前完整suite一次通过。

R1六项RED、R2六项RED、当前native准入14+2项RED，均经对应最小实现变绿。中间fixture标签、早拒绝导致旧测试前置失效、Ruff E501记录都保留并修正，pyright零错误。首次临时诊断没有包住两官方SDK，假key的Typesafe DNS被固定guard阻止（没有建立外部socket/真实模型调用）；原失败保留，后续诊断改为显式fake HTTP，不能宣称所有尝试均没有外部意图。

首次E2E生命周期错误地探测 `/health` 返回404，启动/恢复等待超时，场景**没有运行**；保留r2-e2e-lifecycle.log和e2e/全部配置/DB/停止记录。查明正确 `/api/health`200，独立目录e2e-v2按同字节harness成功测试并恢复。一次seal脚本在异步docs检查未退出时提前读取日志而拒绝（AssertionError docs），没有写verification；待docs实际exit0后成功封存，seal-premature-attempt.json记录。没有把运行中、失败、中止或未运行结果记作通过。

## 提交与剩余交接

- `c432bafe2e7e3f33c818e0fb778c1972f105ee38` — `:bug: Require boolean execution receipts`，正常SSH签名，verify-commit G。
- `4ea720d32110e9d03dafd5884534da32692724f1` — `:bug: Qualify current browser readiness`，正常SSH签名，verify-commit G。

沿用global 1Password配置及hooks，未unsigned/改config/推送；verify仅使用父代理给定临时allowed-signers。`reviewer-signed-commits.json`、各commit/verify日志保留；hooks后当前13文件字节等于验证版本。

评审者现已停止编辑仓库及执行任务。无剩余失败必需检查；历史Save原因未定是已明确接受的条件诊断交接，不冒称已解决。父代理接手：核验最终diff和证据；按已约定把Save/dom_state复发条件及精确证据需求补入现有backlog行，保留旧unknown/not_sent边界；统一归档、生命周期状态/路径/签名元数据，完成docs-only检查与文档签名提交。不要覆盖九份源绑定日志、verification-v3或已保存失败。真实3648测量由主active计划直接承接，不移backlog。

本片未运行真实模型/远端ASR，未读取实际API凭据，未调用真实run成功路径，未启动3648槽。未来真实运行仍需新的精确完整SHA授权；ready不是执行许可。能力、质量、速度、费用与生产采用没有从这些fake数据获得新测量结论。
