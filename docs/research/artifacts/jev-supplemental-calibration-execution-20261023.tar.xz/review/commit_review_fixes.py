"""Commit only reviewed logical fixes, using existing signing and hooks."""
import hashlib,json,subprocess
from pathlib import Path
repo=Path('/Users/zbcjackson/src/tank')
review=Path('/private/tmp/tank-jev-execution-review-20261023')
trust='/private/tmp/tank-jev-execution-20261023/git-allowed-signers'
paths=json.loads((review/'current-scope-files.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before={name:sha(repo/name) for name in paths}
def run(args):
    result=subprocess.run(args,cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if result.returncode:
        print(result.stdout,flush=True)
        raise subprocess.CalledProcessError(result.returncode,args,output=result.stdout)
    return result.stdout
assert subprocess.run(['git','diff','--cached','--quiet'],cwd=repo).returncode==0,'preserve existing staged work'
entries=[]
def commit(name,subject,body,files):
    staged=set(run(['git','diff','--cached','--name-only']).splitlines())
    assert staged==set(files),(staged,files)
    message=review/(name+'-commit-message.txt')
    message.write_text(subject+'\n\n'+body+'\n')
    output=run(['git','commit','-F',str(message)])
    (review/(name+'-commit.log')).write_text(output)
    commit_sha=run(['git','rev-parse','HEAD']).strip()
    verified=run(['git','-c','gpg.ssh.allowedSignersFile='+trust,'verify-commit',commit_sha])
    (review/(name+'-verify-signature.log')).write_text(verified)
    status=run(['git','-c','gpg.ssh.allowedSignersFile='+trust,'log','-1','--format=%G?']).strip()
    assert status=='G',status
    assert all(sha(repo/path)==value for path,value in before.items()),'hook changed validated bytes'
    entries.append({'sha':commit_sha,'signature':status,'subject':subject,'files':files})
    (review/'reviewer-signed-commits.json').write_text(json.dumps({'commits':entries,'validated_file_bytes_unchanged':True,'existing_global_signing':True,'pushed':False},indent=2)+'\n')
    print(json.dumps(entries[-1]),flush=True)
entry_files=['backend/benchmarks/computer_use/jev_execution.py','backend/core/tests/test_jev_execution.py']
run(['git','apply','--cached',str(review/'r1-fix.diff')])
commit('r1-bool',':bug: Require boolean execution receipts','Reject integer success claims before calibration admission.\nKeep the physical audit and explicit authorization requirements.',entry_files)
host_files=['backend/plugins/agent-computer-use/src/agent_computer_use/channels/dom.py','backend/plugins/agent-computer-use/tests/test_dom.py','backend/benchmarks/computer_use/jev_qualification.py','docs/design/computer-use.md']
r2_files=host_files+entry_files
run(['git','add','--',*r2_files])
commit('r2-readiness',':bug: Qualify current browser readiness','Wait for busy state and finite teardown while retaining exact\nfreshness and capture gates. Require and bind a fresh 96-goal native\naudit for the explicit host amendment before fake/live admission.',r2_files)
