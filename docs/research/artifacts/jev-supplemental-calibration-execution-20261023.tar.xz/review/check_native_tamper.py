import hashlib,json,os,shutil,socket,sys
from pathlib import Path
from unittest.mock import patch
review=Path('/private/tmp/tank-jev-execution-review-20261023')
source=review/'study-v3'
clone=review/'native-raw-tamper-v3'
sys.path.insert(0,'/Users/zbcjackson/src/tank/backend')
from benchmarks.computer_use import jev_execution as execution
shutil.copytree(source,clone,copy_function=os.link)
host=json.loads((clone/'qualified-input/freeze.json').read_text())
case=host['cases'][0]['id']
relative=Path('qualified-input/native')/case
observations=json.loads((clone/relative/'observations.json').read_text())
observation=observations[0]
png=clone/relative/observation['png']
original=source/relative/observation['png']
old=hashlib.sha256(original.read_bytes()).hexdigest()
assert old==observation['png_sha256']
replacement=png.with_suffix('.tampered')
replacement.write_bytes(png.read_bytes()+b'controlled corruption')
replacement.replace(png)
assert hashlib.sha256(original.read_bytes()).hexdigest()==old
frozen=json.loads((clone/'freeze.json').read_text())
attempts=[]
def deny(*args,**kwargs):
    attempts.append('network_or_credentials')
    raise AssertionError('raw tamper test is offline')
with patch.object(socket.socket,'connect',deny),patch.object(socket,'getaddrinfo',deny),patch('dotenv.dotenv_values',deny):
    try:
        execution.verify_native(clone,frozen)
    except ValueError as error:
        refusal=str(error)
        assert 'native PNG changed' in refusal, refusal
    else:
        raise AssertionError('corrupt native PNG admitted')
assert not attempts
summary={'source_study_untouched':True,'isolated_copy':str(clone),'trial':case,'tampered_file':str(relative/observation['png']),'rejected':True,'reason':refusal,'network_or_credential_attempts':attempts,'qualification_rerun':False}
(review/'native-raw-tamper-v3.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False),flush=True)
