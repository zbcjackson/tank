import json
import socket
import sys
from pathlib import Path
from unittest.mock import patch
repo=Path('/Users/zbcjackson/src/tank')
review=Path('/private/tmp/tank-jev-execution-review-20261023')
root=review/'study-v3'
sys.path.insert(0,str(repo/'backend'))
from benchmarks.computer_use import jev_execution as execution
attempts=[]
def deny(*args,**kwargs):
    attempts.append('network_or_credential_access')
    raise AssertionError('native proof recheck is read-only and offline')
with patch.object(socket.socket,'connect',deny),patch.object(socket,'getaddrinfo',deny),patch('dotenv.dotenv_values',deny):
    frozen=execution.load_freeze(root,'6830e2d759bb9ee9db83b03d75f0afabb4886be0298e6994f13e802f95c2d494')
    binding=execution.verify_native(root,frozen)
result=json.loads((root/'qualified-input/native/result.json').read_text())
host=json.loads((root/'qualified-input/freeze.json').read_text())
assert result['completed'] is True and len(result['rows'])==96
assert all(x['qualified'] is True and x['cleanup'] is True and type(x['model_calls']) is int and x['model_calls']==0 for x in result['rows'])
summary={**binding,'independently_reaudited':96,'positive_goals':sum(not c['negative'] for c in host['cases']),'negative_goals':sum(bool(c['negative']) for c in host['cases']),'recovery_goals':sum(bool(c['recovery']) for c in host['cases']),'model_calls':0,'cleanup_confirmed':96,'network_or_credential_attempts':attempts,'execution_sha256':frozen['sha256'],'runtime_sources':len(frozen['source_sha256']),'formal_N':None,'model_execution_eligible':False}
assert attempts==[]
(review/'native-independent-v3.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False),flush=True)
