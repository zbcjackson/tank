"""Temporary local-only E2E service: actual Sherpa ASR, local SDK response fixture."""
import json,os,socket,threading,time
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path(__file__).parent
(ROOT/'offline-e2e-server.pid').write_text(str(os.getpid()))
# No real telemetry credentials or endpoints are used by this isolated service.
for name in ('LANGFUSE_PUBLIC_KEY','LANGFUSE_SECRET_KEY','LANGFUSE_HOST'):
    os.environ[name]=''
os.environ['LANGFUSE_TRACING_ENABLED']='false'
os.environ['OTEL_SDK_DISABLED']='true'
network_connect=socket.socket.connect
blocked=[]
def loopback_only(sock,address):
    if isinstance(address,tuple) and address[0] not in ('127.0.0.1','::1','localhost'):
        blocked.append(str(address));raise PermissionError('offline E2E: external socket denied')
    return network_connect(sock,address)
socket.socket.connect=loopback_only
class Provider(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        request=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
        with (ROOT/'offline-e2e-provider.jsonl').open('a') as log:
            log.write(json.dumps({'path':self.path,'stream':request.get('stream',False)})+'\n')
        if request.get('stream'):
            chunks=[{'id':'local','object':'chat.completion.chunk','created':0,'model':'local-e2e','choices':[{'index':0,'delta':{'role':'assistant','content':'收到。'},'finish_reason':None}]},{'id':'local','object':'chat.completion.chunk','created':0,'model':'local-e2e','choices':[{'index':0,'delta':{},'finish_reason':'stop'}]}]
            body=(''.join('data: '+json.dumps(c,ensure_ascii=False)+'\n\n' for c in chunks)+'data: [DONE]\n\n').encode()
            content_type='text/event-stream'
        else:
            body=json.dumps({'id':'local','object':'chat.completion','created':0,'model':'local-e2e','choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':'收到。'}}],'usage':{'prompt_tokens':1,'completion_tokens':1,'total_tokens':2}},ensure_ascii=False).encode();content_type='application/json'
        self.send_response(200);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
provider=ThreadingHTTPServer(('127.0.0.1',0),Provider)
threading.Thread(target=provider.serve_forever,daemon=True).start()
from tank_backend.config import AppConfig
from tank_backend.plugin.manager import PluginManager
raw={'llm':{'default':{'api_key':'local-e2e-only','model':'local-e2e','base_url':f'http://127.0.0.1:{provider.server_port}/v1'}},'asr':{'enabled':True,'extension':'asr-sherpa:asr','config':{'model_dir':'/Users/zbcjackson/src/tank/backend/models/sherpa-onnx-zipformer-en-zh','num_threads':4,'sample_rate':16000}},'tts':{'enabled':False},'speaker':{'enabled':False},'database':{'url':'sqlite+pysqlite:///'+str(ROOT/'offline-e2e.db')},'jobs':{'enabled':False},'memory':{'enabled':False},'preferences':{'enabled':False},'consolidation':{'enabled':False},'sandbox':{'enabled':False},'connectors':{}}
(ROOT/'offline-e2e-config.json').write_text(json.dumps(raw,indent=2)+'\n')
# server constructs its application context at import time.
AppConfig.load=classmethod(lambda cls,config_path,registry=None:cls.from_raw_dict(raw))
from tank_backend.api import server
assert server.app_config.asr.extension=='asr-sherpa:asr'
assert server.app_config.get_llm_profile().base_url.startswith('http://127.0.0.1:')
assert server.app_config.get_llm_profile().api_key=='local-e2e-only'
assert str(ROOT/'offline-e2e.db') in server.app_config.database.url
assert not server.app_config.tts.enabled and not server.app_config.jobs.enabled
(ROOT/'offline-e2e-effective-config.json').write_text(json.dumps({'asr':server.app_config.asr.extension,'llm_url':server.app_config.get_llm_profile().base_url,'database':server.app_config.database.url,'tts_enabled':server.app_config.tts.enabled,'jobs_enabled':server.app_config.jobs.enabled,'local_credential_asserted':True},indent=2)+'\n')
import uvicorn
try:
    uvicorn.run(server.app,host='127.0.0.1',port=8000,log_level='info')
finally:
    provider.shutdown();provider.server_close()
    (ROOT/'offline-e2e-egress.json').write_text(json.dumps({'external_python_socket_attempts':blocked,'ASR':'actual local Sherpa','LLM':'local HTTP fixture','TTS':False,'real_provider_credentials':False},indent=2)+'\n')
