from pathlib import Path
import json
import sys

repo = Path('/Users/zbcjackson/src/tank')
root = Path('/private/tmp/tank-jev-execution-20261023')
study = root / 'study-v1'
sys.path.insert(0, str(repo / 'backend'))
from benchmarks.computer_use import jev_execution as execution
from benchmarks.computer_use import jev_audit as audit
from benchmarks.computer_use import jev_qualification as qualification

def read(path):
    return json.loads(path.read_text())

frozen = read(study / 'qualification-freeze.json')
execution.load_freeze(study, frozen['sha256'], fake=True)
full = read(study / 'freeze.json')
execution.load_freeze(study, full['sha256'])
output = study / 'fake'
result = read(output / 'result.json')
closed = read(output / 'closed.json')
started = read(output / 'started.json')
assert started['planned_ids'] == [slot['id'] for slot in frozen['schedule']]
assert closed['result_sha256'] == qualification.digest(result)
assert closed['driver_context_ended'] is True and closed['fake_http_context_ended'] is True
assert len(result['rows']) == 192
assert [row['id'] for row in result['rows']] == started['planned_ids']
assert all(row['attempted'] is True and row['status'] == 'finished' for row in result['rows'])
transport = [json.loads(line) for line in (output / 'transport.jsonl').read_text().splitlines()]
cases = {case['id']: case for case in frozen['cases']}
labels = {}
for row in result['rows']:
    case = cases[row['case']]
    path = output / row['id']
    label = audit.audit_trial(case, row, path)
    assert label['critical_events'] == 0 and label['unexpected_action'] is False
    assert label['negative_verified'] if case['negative'] else label['strict_verified']
    assert not case['recovery'] or label['recovery_verified']
    execution.audit_usage(row, result['spend'], path)
    audit.audit_usage(row, result['spend'], [t for t in transport if t['trial_id'] == row['id']])
    assert row['cleanup_confirmed'] is True
    labels[row['id']] = label
assert qualification.digest(labels) == qualification.digest(read(output / 'audit-evidence.json')['trials'])
assert read(output / 'audit-evidence.json')['unresolved'] == {}
calls = [call['call_id'] for row in result['rows'] for call in row['calls']]
assert len(calls) == len(set(calls)) == len(transport) == len(result['spend']['requests']) == 672
assert set(calls) == set(result['spend']['requests'])
tokens = 0
for item in transport:
    raw = item['usage']
    counts = ((raw['prompt_tokens'], raw['completion_tokens']) if item['provider'] == 'peer'
              else (raw['input_tokens'], raw['output_tokens']))
    assert all(type(count) is int and count >= 0 for count in counts)
    tokens += sum(counts)
assert tokens == result['spend']['batch']['known_tokens'] == 6720
assert all(request['status'] == 'known' for request in result['spend']['requests'].values())
assert result['spend']['stop_reason'] is None
assert result['spend']['batch']['reserved_tokens'] == result['spend']['batch']['reserved_nano_usd'] == 0
assert result['external_model_requests'] == 0 and result['blocked_external_attempts'] == []
assert result['completed'] is True and result['qualified'] is True
assert len(full['cases']) == 1824 and len(full['schedule']) == 3648
body = {
    'execution_sha256': full['sha256'], 'qualification_sha256': frozen['sha256'],
    'runtime_sources': len(full['source_sha256']), 'planned': 192, 'attempted': 192,
    'independently_audited': len(labels), 'cleanup_confirmed': 192,
    'strict_successes': sum(label['strict_verified'] for label in labels.values()),
    'negative_successes': sum(label['negative_verified'] for label in labels.values()),
    'recovery_successes': sum(label['recovery_verified'] for label in labels.values()),
    'critical_events': 0, 'unexpected_business_actions': 0, 'unresolved': {},
    'fake_sdk_calls': len(calls), 'fake_image_calls': sum(t['provider'] == 'peer' for t in transport),
    'known_tokens': tokens, 'unknown_requests': 0, 'reserved_tokens': 0, 'reserved_nano_usd': 0,
    'external_model_requests': 0, 'blocked_external': [],
    'host_native_provenance': execution.QUALIFIED_SHA, 'model_execution_eligible': False,
    'formal_N': None, 'labels': labels,
}
(root / 'postrun-independent.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in body.items() if k != 'labels'}, ensure_ascii=False))
