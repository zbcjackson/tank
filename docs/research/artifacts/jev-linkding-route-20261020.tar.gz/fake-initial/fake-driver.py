"""Retain one full real-product/real-SDK run with fake external model HTTP."""
import asyncio,hashlib,importlib.util,json,sys
from pathlib import Path
import pytest
from benchmarks.computer_use import jev_linkding_route as pilot
ROOT=Path('/Users/zbcjackson/src/tank');OUT=Path('/private/tmp/tank-linkding-route-fake-20261020')
helper=ROOT/'backend/plugins/agent-computer-use/tests/test_dom.py';spec=importlib.util.spec_from_file_location('linkding_boundary_helpers',helper);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
f=pilot.prepare(OUT,app_root=Path('/private/tmp/linkding-1.47.0'))
for name,sha in f['source_sha256'].items():
 p=ROOT/'backend'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;target=OUT/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
(OUT/'fake-helper.py').write_bytes(helper.read_bytes());(OUT/'fake-driver.py').write_bytes(Path(__file__).read_bytes())
with pytest.MonkeyPatch.context()as patch:
 calls,packets=module.install_product_http(patch)
 result=asyncio.run(pilot.run_batch(OUT,f['sha256'],jev_credential='fixture',peer_credential='fixture'))
assert result['completed']and len(result['rows'])==4 and all(r['strict_completed']and r['cleanup_confirmed']for r in result['rows'])
(OUT/'fake-boundary.json').write_text(json.dumps({'calls':calls,'packets':packets,'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sha256':f['sha256'],'rows':4,'strict_completed':4,'fake_SDK_calls':len(calls),'peer':calls.count('peer'),'jev':calls.count('jev'),'cleanup':4}))
