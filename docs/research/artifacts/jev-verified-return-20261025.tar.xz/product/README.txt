Offline-only qualification of the same upstream linkding task.
No live CLI, no real credential loading, fake credentials and SDK HTTP plus external socket denial only.
Run after the full backend browser suite completes; do not overlap browser-heavy jobs.
Original paid evidence is unchanged; this does not measure model quality or real latency.
