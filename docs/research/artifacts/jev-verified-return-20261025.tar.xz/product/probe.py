"""No-model qualification of upstream preview pixels and ordinary DOM actions."""
from __future__ import annotations
import asyncio
from dataclasses import asdict
from hashlib import sha256
import importlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from benchmarks.computer_use import jev_linkding_route as link
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/zbcjackson/src/tank')
APP=Path('/private/tmp/tank-linkding-spatial-20261025')
PYTHON=APP/'.venv/bin/python'
START='/bookmarks?q=Entry'
SEED=[dict(id=n,url=f'https://example.test/item-{n}',title=f'Entry {n}',description='Keep description',notes='',unread=False,shared=False,is_archived=False,owner_id=1,tag_names=['keep']) for n in (1,2)]
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False,default=lambda x:x.model_dump(mode="json") if hasattr(x,"model_dump") else sorted(x))+'\n')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def goal(origin):
    intent=('In the current filtered bookmark list, find the bookmark whose preview shows a red triangle. '
      'Open that bookmark using its Edit link, inspect the editor without changing fields, then Cancel. '
      'Finally click the capitalized Keep link in the right-hand Tags section to filter the list by that tag. '
      'Do not edit or save data, remove, archive, share, log out, or open external websites. '
      'Identify the bookmark from the preview pixels, not from an assumed item order or numeric identifier.')
    return dict(schema_version=2,goal_id='pixel-task',scope='pixel-task',authorization_ref='current_task',
      intent=intent,objective=intent,allowed_operations=['click'],
      constraints=['Read-only inspection. Do not save or mutate any bookmark. Do not infer preview content from item order or identifier.'],
      inputs=[],
      completion=[dict(key='status:Page URL',value=origin+'/bookmarks?q=Entry+%23keep')])
def previews(app,variant):
    from PIL import Image, ImageDraw
    for n in (1,2):
        image=Image.new('RGB',(240,160),'white');draw=ImageDraw.Draw(image)
        red = n == (2 if variant==0 else 1)
        if red:draw.polygon([(120,20),(30,140),(210,140)],fill=(210,30,35))
        else:draw.ellipse((55,15,185,145),fill=(30,80,210))
        image.save(app/'data/previews'/f'entry-{n}.png')
def configure(app,output):
    sys.path.insert(0,str(app));os.environ['DJANGO_SETTINGS_MODULE']='bookmarks.settings'
    os.environ['LD_DISABLE_BACKGROUND_TASKS']='true'
    import django;django.setup()
    from bookmarks.models import Bookmark,UserProfile
    from django.contrib.auth.models import User
    from django.test import Client
    from django.utils import timezone
    from datetime import datetime
    for n in (1,2):
        Bookmark.objects.filter(id=n).update(preview_image_file=f'entry-{n}.png',date_added=datetime(2026,10,24,tzinfo=timezone.get_default_timezone()),date_modified=datetime(2026,10,24,tzinfo=timezone.get_default_timezone()))
    UserProfile.objects.all().update(enable_preview_images=True)
    client=Client();client.force_login(User.objects.get(username='qualification-user'))
    assert client.get('/bookmarks?q=Entry').status_code==200
    from django.conf import settings
    write(output/'auth.json',dict(name=settings.SESSION_COOKIE_NAME,value=client.cookies[settings.SESSION_COOKIE_NAME].value))
def serve(app,output):
    # Synthetic owned-session setup only. Original WSGI response/body is unchanged.
    sys.path.insert(0,str(app));os.environ['DJANGO_SETTINGS_MODULE']='bookmarks.settings';os.environ['LD_DISABLE_BACKGROUND_TASKS']='true'
    from django.core import wsgi
    original=wsgi.get_wsgi_application
    auth=json.loads((output/'auth.json').read_text());cookie=auth['name']+'='+auth['value']
    def configured():
        application=original()
        def authenticated(environ,start_response):
            current=environ.get('HTTP_COOKIE','')
            if not any(part.strip().startswith(auth['name']+'=') for part in current.split(';')):
                environ['HTTP_COOKIE']='; '.join(part for part in (current,cookie) if part)
            return application(environ,start_response)
        return authenticated
    wsgi.get_wsgi_application=configured
    link.serve_product(app,output)
def normalized(packet,snapshot,origin):
    refs={e.ref:f'element-{n}' for n,e in enumerate(snapshot.elements)}
    def norm(v):
        if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k not in {'observation_id','candidate_set_id'}}
        if isinstance(v,list):return [norm(x) for x in v]
        if isinstance(v,tuple):return [norm(x) for x in v]
        if isinstance(v,str):
            v=v.replace(origin,'<origin>')
            for key,val in refs.items():v=v.replace(key,val)
            return re.sub(r'\b[0-9a-f]{32}\b','<uuid>',v)
        return v
    return norm(packet)
def initialize(output):
    output.mkdir(exist_ok=False)
    manifest=link.app_manifest(PYTHON);write(output/'product-manifest.json',manifest)
    app=output/'app';app.mkdir()
    for name in manifest['source_files']:
        dst=app/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(APP/name,dst)
    write(output/'seed.json',SEED)
    env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1','PYTHONPATH':str(REPO/'backend')}
    with (output/'seed.log').open('wb') as log:
        subprocess.run([str(PYTHON),str(Path(link.__file__)),'--seed','--app-root',str(app),'--output',str(output),'--seed-file',str(output/'seed.json')],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    with (output/'configure.log').open('wb') as log:
        subprocess.run([str(PYTHON),str(Path(__file__)),'configure',str(app),str(output)],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    previews(app,0)
    write(output/'database-before.json',link.database_state(app/'data/db.sqlite3'))
    return app
async def main():
    from agent_computer_use.channels.dom import BrowserConfig, ManagedChromiumChannel
    from agent_computer_use.action_builder import ActionBuilder
    from agent_computer_use.contracts import GoalContract
    from agent_computer_use.model_view import decision_question
    from agent_computer_use.visual_selector import VisualSelector
    from tank_backend.agents.subagent import SubAgentContext, SubAgentAuthorization, SubAgentBudget, ModelDataScope
    output=ROOT/'qualification'
    app=initialize(output)
    manifest=json.loads((output/'product-manifest.json').read_text())
    env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1','PYTHONPATH':str(REPO/'backend')}
    server=None;packets=[];records=[]
    try:
        with (output/'server.log').open('wb') as log:
            server=await asyncio.create_subprocess_exec(str(PYTHON),str(Path(__file__)),'serve',str(app),str(output),cwd=app,env=env,stdout=log,stderr=asyncio.subprocess.STDOUT)
            async with asyncio.timeout(15):
                while not (output/'ready.json').exists():
                    assert server.returncode is None;await asyncio.sleep(.05)
            origin='http://127.0.0.1:'+str(json.loads((output/'ready.json').read_text())['port'])
            for variant in (0,1):
                previews(app,variant)
                ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event(),model_data_scope=ModelDataScope(frozenset({'text','image'})));ctx.runtime.bind('zero-model')
                browser=ManagedChromiumChannel(BrowserConfig(scope='pixel-task',url=origin+START,observe_bounds=True))
                path=output/f'variant-{variant}';path.mkdir()
                try:
                    await browser.observe('pixel-task',ctx)
                    await browser.page.wait_for_function("[...document.querySelectorAll('img.preview-image')].length===2 && [...document.querySelectorAll('img.preview-image')].every(x=>x.complete&&x.naturalWidth>0)")
                    snapshot=await browser.observe('pixel-task',ctx)
                    contract=GoalContract.from_input(goal(origin));actions=ActionBuilder(visual=True).build('pixel-task',1,contract,snapshot)
                    packet=decision_question(contract,snapshot,actions)
                    selector=VisualSelector(browser);selector.register(ctx);frame=await selector.capture_frame(snapshot,actions,ctx)
                    write(path/'snapshot.json',asdict(snapshot));write(path/'packet.json',packet);(path/'frame.png').write_bytes(frame.png)
                    write(path/'bounds.json',dict(frame.bounds));write(path/'goal.json',contract.model_dump(mode='json'))
                    (path/'page.html').write_text(await browser.page.content())
                    public=await browser.page.locator('li[data-bookmark-id]').evaluate_all("nodes=>nodes.map(n=>({id:n.dataset.bookmarkId,text:n.innerText,preview:n.querySelector('img.preview-image')?.getAttribute('src'),alt:n.querySelector('img.preview-image')?.alt,edit:n.querySelector('a[href*=\"/edit\"]')?.href}))")
                    write(path/'public-rows.json',public)
                    packets.append(normalized(packet,snapshot,origin));write(path/'normalized-packet.json',packets[-1])
                    records.append(dict(variant=variant,complete=snapshot.complete,ready=snapshot.ready,candidates=len(actions.actions),reason=actions.reason,png_sha256=sha256(frame.png).hexdigest()))
                finally:await browser.aclose();await ctx.runtime.aclose()
            write(output/'comparison.json',dict(variants=records,model_state_equal=packets[0]==packets[1],zero_model_calls=True,credentials_loaded=False))
            assert packets[0]==packets[1], 'pixel swap changed public structural evidence'
            assert all(r['complete'] and r['ready'] and 0<r['candidates']<=32 for r in records)
            assert records[0]['png_sha256']!=records[1]['png_sha256']
    finally:
        if server is not None and server.returncode is None:server.terminate();await server.wait()
        write(output/'database-after.json',link.database_state(app/'data/db.sqlite3'))
        write(output/'cleanup.json',dict(server_exit=None if server is None else server.returncode))
    assert link.source_files(app)==manifest['source_files']
    assert json.loads((output/'database-before.json').read_text())==json.loads((output/'database-after.json').read_text())
    print(json.dumps(json.loads((output/'comparison.json').read_text())))
if __name__=='__main__':
    if len(sys.argv)>1:
        if sys.argv[1]=='configure':configure(Path(sys.argv[2]),Path(sys.argv[3]))
        elif sys.argv[1]=='serve':serve(Path(sys.argv[2]),Path(sys.argv[3]))
        else:raise SystemExit('unsupported')
    else:asyncio.run(main())
