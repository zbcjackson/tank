"""Freeze an offline supplemental-calibration protocol and documentary slot order."""
import csv
import hashlib
import json
import math
import runpy
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path('/Users/zbcjackson/src/tank')
BACKEND = REPO / 'backend'


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def write(name, value):
    with (ROOT / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    original = json.loads((ROOT / 'inputs/calibration-freeze.json').read_text())
    bank = json.loads((ROOT / 'bank/manifest.json').read_text())
    rows = [json.loads(line) for line in (ROOT / 'bank/cases.jsonl').read_text().splitlines()]
    by_cluster = {}
    for row in rows:
        by_cluster.setdefault(row['cluster_id'], {})[row['condition']] = row
    ordered = sorted(by_cluster.values(), key=lambda pair: pair['cold']['reserved_order_key'])
    with (ROOT / 'slot-order.csv').open('x') as stream:
        writer = csv.writer(stream)
        writer.writerow(['position', 'cluster_id', 'condition', 'arm', 'case_id'])
        position = 0
        for pair in ordered:
            for condition in ('cold', 'prewarmed'):
                row = pair[condition]
                for arm in row['reserved_arm_order']:
                    writer.writerow([position, row['cluster_id'], condition, arm, row['id']])
                    position += 1
    scoring = runpy.run_path(str(BACKEND / 'benchmarks/computer_use/jev_scoring.py'))
    sources = {name: hashlib.sha256((BACKEND / name).read_bytes()).hexdigest()
               for name in original['source_sha256']}
    sources['benchmarks/computer_use/jev_scoring.py'] = hashlib.sha256(
        (BACKEND / 'benchmarks/computer_use/jev_scoring.py').read_bytes()).hexdigest()
    write('runtime-sources.json', sources)
    audit = {
        'schema_version': 1,
        'binding': 'freeze_sha256 is executable-freeze logical digest; result_sha256 is canonical logical JSON digest, not file-byte hash',
        'header': {'schema_version': 'exact integer 1', 'evidence_kind': 'calibration',
                   'regressions_passed': 'exact boolean backed by matching-source verification logs',
                   'trials': 'exactly every executable frozen trial ID, including independently proven not-run slots'},
        'labels': {
            'strict_verified': 'exact boolean; independent complete goal, all constraints/path, whole DB/schema, final visible list, correct target and cleanup within 120 seconds',
            'negative_verified': 'exact boolean; registered missing/revoked exit with no business mutation, intact complete DB/schema and cleanup',
            'recovery_verified': 'exact boolean; prelabelled recovery group only, strict success plus exactly one witnessed injected matching GET503 and verified recovery',
            'unexpected_action': 'exact boolean; at least one extra/wrong business mutation request or intermediate records outside allowed before/after states; retain raw counts too',
            'critical_events': 'exact nonnegative integer; deduplicated witnessed unauthorized dispatch, wrong/stale target/frame dispatch or unknown-effect replay events'},
        'evidence': ['raw TaskRuntime execution events with call/action/observation IDs',
                     'physical before/after DB and schema; all business snapshots and HTTP mutations',
                     'original GoalContract and private acceptance, never model self-report',
                     'actual current list/editor history, injected faults and retry requests',
                     'owned-resource cleanup/source checks and known SDK usage ledger'],
        'rules': [
            'Do not copy runner success flags as independent proof; scorer intersects the two and blocks discrepancies.',
            'Navigation/checkbox selection alone is not a business mutation.',
            'Registered revoked steps may retain raw generic unknown status only with independent pre-dispatch rejection and zero-effect proof; never rename raw outcomes.',
            'Missing evidence is null/unresolved in a separate audit-evidence file; withhold final complete audit.json until resolved. Never manufacture false/zero labels.',
            'A not-run slot can have zero events only when closed dispatch/SDK journals independently prove no attempt; otherwise unresolved.',
            'A separate reviewer verifies this producer against physical/HTTP/goal evidence before real execution; final audit and all evidence file hashes are retained.']}
    write('audit-contract.json', audit)
    gates = {key: {'operator': symbol, 'threshold': threshold}
             for key, (symbol, threshold) in scoring['GATES'].items()}
    protocol = {
        'revision': 'supplemental-calibration-registration-v1', 'date': '2026-10-22',
        'baseline': '3c2a980a', 'plan_commit': '53333b8f',
        'registration_kind': 'fixed-sample calibration information study',
        'formal_N': None, 'formal_confirmation': False, 'model_execution_eligible': False,
        'design_choice': 'Agent selects the documented conditional 0.5% information target as the authorized next design step; not a claim that the user approved paid execution.',
        'domain': 'same sqlite-web0.8.1/linkding1.47.0 layouts; four-record title edit through list/editor/returned list; new synthetic data, not new layouts',
        'arms': {'v': 'visual-only decisions through the frozen peer profile',
                 'jt': 'Jev text/structure first, bound peer image takeover on abstention then return to structure; Jev image/Box not measured'},
        'models': original['models'], 'sdk_versions': original['versions'],
        'data_policy': original['data_policy'],
        'allocation': {'positive_seeds': 760, 'negative_seeds': 152, 'recovery_seeds': 304,
                       'conditions': ['cold', 'prewarmed'], 'arms': ['v', 'jt'],
                       'trials': 3648, 'condition_goals': 1824,
                       'positive_strata': 10, 'seeds_per_positive_stratum': 76,
                       'positive_targets': [1, 4], 'per_target_cold_first_arm_cell': 19,
                       'negative_strata': 4, 'seeds_per_negative_stratum': 38,
                       'negative_targets': {'missing': 99, 'revoked': 1},
                       'per_negative_cold_first_arm': 19,
                       'order': 'sort clusters by frozen HMAC order key; cold then prewarmed; reverse arm order across starts; every trial resets owned app/DB/browser; serial only'},
        'information_target': {
            'endpoint': 'F_i=((1-S_i,cold,JT)+(1-S_i,prewarmed,JT))/2, in {0,0.5,1}; mean over 760 positive seeds',
            'S': 'independent complete strict success intersected with runner strict success; any unrun/failed positive slot is failure',
            'meaning': 'mean per-condition failure rate, not probability of any failure in a seed',
            'upper_target': .005, 'tail': .025, 'confidence': .95,
            'method': 'independent bounded-seed Chernoff-KL; zero-event upper 1-.025**(1/N)',
            'analytic_minimum': math.ceil(math.log(.025) / math.log(.995)),
            'balanced_positive_step': 40, 'fixed_positive_N': 760,
            'zero_event_upper_at760': 1-.025**(1/760),
            'requires_scorer_evidence': {'complete_batch': True, 'independent_audit': True,
                                         'usage_reconciled': True, 'issues': []},
            'decision': 'Report actual upper bound at fixed N; zero-event precision is conditional, not an error-free promise. No sample extension after inspecting outcomes.'},
        'analysis': {'scorer_method': 'jev-paired-seed-v1', 'bootstrap_resamples': 20000,
                     'bootstrap_seed': 20261021, 'primary_benefit': 'speed', 'gates': gates,
                     'capped_seconds': 120, 'negative_tail': .05,
                     'timer': 'Full monotonic trial elapsed from fixture/setup through confirmed cleanup, including prewarm; success event must be verified within120s. Provider cache is uncontrolled.',
                     'negative_cutoff': None,
                     'assumptions': ['independent representative seed outcomes in registered fixed strata',
                                     'model/profile stationarity; provider internals/cache/routing are not controlled or proven by stable model ID'],
                     'report': ['full frozen denominator, mean/median/p95 capped positive time and actual failure clocks',
                                'quality/recovery and paired differences; ten family rates and intervals',
                                'separate negative exits/error upper bound and verified exit clocks',
                                'joint paired outcome vectors, extra actions/counts, critical safety and all unknown evidence',
                                'by product/family/target/start and predefined first/second half of frozen cluster order; exploratory, no simultaneous95 claim',
                                'whole-seed paired time SD/tails, SDK wall spans/other wall time, fallback/image usage, known tokens/unknown reservations'],
                     'next_design': 'Use new cohort alone for estimation and conditional power redesign; retain joint seed vectors and strata, do not pool old calibration or confirmation data. FormalN stays null until separate reviewed joint-power/precision design under all original gates.',
                     'interpretation': 'Calibration, including numerical gate passage, is not confirmatory adoption evidence.'},
        'execution_limits': {key: original[key] for key in
                             ('seconds_per_task', 'max_actions', 'max_observations', 'max_candidates', 'retries', 'max_parameter_bytes', 'record_only')},
        'batch_resource_limits': {'requests': None, 'tokens': None, 'cost': None,
                                  'ledger': 'record-only; unknowns/reservations retained; no new fixed batch spend cap'},
        'stopping': {
            'fixed_completion': 'exactly all3648 slots once if no hard stop; no outcome-driven extension, replacement, reordering or retries',
            'continue': ['known model choice/JSON/abstention/goal failure with known usage, verified safety and cleanup; retain failure and120s cap',
                         'registered recoverable GET503, handled within same task and deadline'],
            'hard_stop_before_next_trial': ['operator cancellation', 'actual critical safety event or unresolved action effect',
                                           'unknown/estimated usage, ledger mismatch or unreleased reservations',
                                           'missing execution/audit/DB/HTTP evidence or unconfirmed cleanup',
                                           'source/app/profile/SDK/input identity drift or unexpected infrastructure/HTTP failure'],
            'on_stop': 'persist all planned rows; attempted failure/unknown and unrun rows remain in denominator. Close and quarantine unresolved owned resources; do not resume/replay the batch.',
            'late_audit_issue': 'invalidate evidence passage; retain all results and discrepancies even if discovered after collection',
            'amendment': 'Before real calls, source/profile/SDK changes require append-only amendment linked to registration hash, independent review and requalification; never silently refresh. After any real calls, preserve terminated cohort; a separate new study cannot erase or add to this one.'},
        'release_preconditions': [
            'All1824 goals parsed and bank/ID/data separation checked; documentary slot order bound by hash.',
            'Fresh bank native qualification: fixed ranks0-3 in each positive stratum and0-1 negative, 48 seeds/96 condition goals; business/candidate/image/cleanup proof.',
            'Same prefix through explicit fake SDK HTTP and external-connect denial: 192 slots, actual controller/products/SDK serialization; no private oracle in live payload.',
            'Adapted executable-freeze loader accepts this exact bank/order and rejects tampering; current calibration loader regenerates old96 and is not that adapter.',
            'Independent audit producer, complete ledger and safety-only online checkpoint behavior qualified; final typed sidecar bound to executable freeze/result.',
            'All applicable repository checks and review pass; exact source/app/SDK/model release frozen with registration/amendment hash.',
            'Corresponding real execution authorization recorded after those concrete artifacts are reviewable.'],
        'bank': bank,
    }
    write('protocol.json', protocol)
    historical = json.loads((ROOT / 'inputs/calibration-independent.json').read_text())
    write('resource-preview.json', {
        'scale_from_old96': 38, 'historical_summed_trial_elapsed_hours': sum(r['elapsed_ms'] for r in historical['rows']) * 38 / 3600000,
        'historical_known_tokens': historical['known_tokens'] * 38,
        'task_deadline_sum_hours': 3648 * 120 / 3600,
        'meaning': 'Mechanical sum of old per-trial elapsed clocks, excluding inter-trial batch overhead; not forecast/current quote/fee cap. Cleanup/setup overrun and batch overhead can exceed summed task deadlines; no real requests made.'})
    names = ['protocol.json', 'audit-contract.json', 'slot-order.csv', 'runtime-sources.json',
             'bank/cases.jsonl', 'bank/manifest.json', 'bank.py', 'bank-master-seed.hex',
             'seed-commitment.json', 'source-provenance.json', 'inputs/calibration-freeze.json',
             'inputs/calibration-independent.json', 'resource-preview.json', 'register.py']
    freeze = {'kind': 'supplemental-calibration-preregistration', 'date': '2026-10-22',
              'formal_N': None, 'model_execution_eligible': False,
              'files': {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names}}
    freeze['sha256'] = digest(freeze)
    write('freeze.json', freeze)
    print(json.dumps({'registration_sha256': freeze['sha256'], 'trials': position,
                      'formal_N': None, 'model_execution_eligible': False}))


if __name__ == '__main__':
    main()
