# Supplemental calibration registration evidence

This package freezes a design and synthetic bank. No new model measurements or
native/fake qualification runs were performed. The protocol's formal_N is null
and model_execution_eligible is false. slot-order.csv is documentary order, not a
freeze accepted by the current calibration runner.

protocol.json and audit-contract.json contain the fixed sample, endpoint, original
12 diagnostic gates, stopping/amendment rules and evidence obligations. freeze.json
binds their canonical content and the generation inputs. bank-master-seed.hex is a
public experimental random seed, not a credential. cases.jsonl uses a fresh
namespace and preserves original four-record application layouts.

Reproduce from backend/ with the installed workspace dependencies:

```bash
UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync pytest /absolute/extracted/test_registration.py -q
UV_CACHE_DIR=/private/tmp/tank-uv-cache uv run --no-sync python /absolute/working-copy/verify_registration.py
```

Use an isolated copy for the verifier and retain/rename its prior validation.json
before invoking it: it creates that evidence file exclusively. It requires the
repository at the recorded REPO path and the original confirmation-design archive;
it denies socket connections. Repository runtime source hashes and installed SDK
versions must match. It rebuilds the actual master in a separate temporary bank,
parses all goals and independently checks arithmetic/allocation/data isolation.

register.py writes outputs exclusively. To reproduce registration, use a separate
copy of inputs/, bank/, bank.py and master/provenance files with its generated
protocol/audit/order/runtime/resource/freeze outputs absent. Compare outputs to the
preserved originals; never overwrite this package. ROOT follows the script path;
REPO is the recorded local checkout. The old calibration and reserve are read-only.

versions/draft-1 records pre-review clarification of information-target evidence
eligibility, timer scope and resource wording; sample/master/data/methods did not
change. versions/bank-before.py and generator.diff document the narrowly adapted
reviewed generator. logs/ retains expected TDD failures and passing final checks.
