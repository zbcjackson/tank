"""Offline registration checks; no browser, model, or credentials."""
import json

import pytest

from bank import build, validate


def test_new_bank_has_calibration_identity_and_complete_targets(tmp_path):
    manifest = build(tmp_path / 'bank', 40, b'public-registration-test-seed')
    rows = [json.loads(line) for line in (tmp_path / 'bank/cases.jsonl').read_text().splitlines()]
    assert all(row['id'].startswith('supp-cal-v1-') for row in rows)
    assert manifest['revision'] == 'supplemental-calibration-bank-v1'
    assert manifest['formal_N'] is None and manifest['model_execution_eligible'] is False
    assert 'schedule' not in manifest
    assert validate(tmp_path / 'bank')['new_seed_clusters'] == 48


def test_registration_never_replaces_an_existing_directory(tmp_path):
    output = tmp_path / 'existing'
    output.mkdir()
    marker = output / 'manifest.json'
    marker.write_text('previous experiment')
    with pytest.raises(FileExistsError):
        build(output, 40, b'public-registration-test-seed')
    assert marker.read_text() == 'previous experiment'


def test_full_fixed_sample_is_reproducible_and_balanced(tmp_path):
    from collections import Counter
    from agent_computer_use.contracts import GoalContract

    first, second = tmp_path / 'first', tmp_path / 'second'
    master = b'public-full-size-registration-test'
    manifest = build(first, 760, master)
    assert build(second, 760, master) == manifest
    assert (first / 'cases.jsonl').read_bytes() == (second / 'cases.jsonl').read_bytes()
    assert validate(first)['new_seed_clusters'] == 912
    rows = [json.loads(line) for line in (first / 'cases.jsonl').read_text().splitlines()]
    assert len(rows) == 1824 and manifest['planned_trials'] == 3648
    cells = Counter()
    for row in rows:
        GoalContract.from_input(row['goal'])
        cells[row['reserved_stratum'], row['target'], row['condition'], row['reserved_arm_order'][0]] += 1
        if row['negative']:
            assert row['target'] == (99 if row['negative'] == 'missing' else 1)
    assert len(cells) == 96  # 10 positive strata×2 targets×2 starts×2 orders + 4 negative×1×2×2
    assert set(cells.values()) == {19}


def test_case_bytes_are_bound_and_invalid_sample_is_rejected(tmp_path):
    for count in (0, 736, 759):
        with pytest.raises(ValueError):
            build(tmp_path / str(count), count, b'public-test')
    path = tmp_path / 'valid'
    build(path, 40, b'public-test')
    with (path / 'cases.jsonl').open('a') as stream:
        stream.write('\n')
    with pytest.raises(AssertionError):
        validate(path)
