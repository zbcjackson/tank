"""Independent arithmetic, input isolation, GoalContract and freeze verification."""
import csv
import hashlib
import json
import runpy
import sys
import tarfile
import tempfile
from collections import Counter
from decimal import Decimal, localcontext
from importlib.metadata import version
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path('/Users/zbcjackson/src/tank')


def deny_network(event, args):
    if event == 'socket.connect':
        raise RuntimeError('offline registration validation attempted a connection')


sys.addaudithook(deny_network)
from agent_computer_use.contracts import GoalContract
from bank import build, validate


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


frozen = json.loads((ROOT/'freeze.json').read_text())
assert frozen['sha256'] == canonical_hash({k:v for k,v in frozen.items() if k!='sha256'})
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
           for name,sha in frozen['files'].items())
p = json.loads((ROOT/'protocol.json').read_text())
assert {name:version(name) for name in p['sdk_versions']}==p['sdk_versions']
manifest = json.loads((ROOT/'bank/manifest.json').read_text())
assert p['formal_N'] is None and p['model_execution_eligible'] is False
assert 'schedule' not in frozen and 'schedule' not in manifest
assert p['allocation']['trials'] == 3648
master = bytes.fromhex((ROOT/'bank-master-seed.hex').read_text().strip())
assert hashlib.sha256(master).hexdigest()==manifest['seed_commitment']
with tempfile.TemporaryDirectory() as scratch:
    rebuilt = build(Path(scratch)/'bank',760,master)
    assert rebuilt == manifest
    assert (Path(scratch)/'bank/cases.jsonl').read_bytes()==(ROOT/'bank/cases.jsonl').read_bytes()
assert validate(ROOT/'bank')['new_seed_clusters']==912

rows = [json.loads(line) for line in (ROOT/'bank/cases.jsonl').read_text().splitlines()]
clusters = {}
cells = Counter()
for row in rows:
    GoalContract.from_input(row['goal'])
    clusters.setdefault(row['cluster_id'],[]).append(row)
    cells[row['reserved_stratum'],row['target'],row['condition'],row['reserved_arm_order'][0]]+=1
assert len(rows)==1824 and len(clusters)==912 and len(cells)==96
assert set(cells.values())=={19}
seeds = {canonical_hash(pair[0]['seed']) for pair in clusters.values()}
assert len(seeds)==912
old = json.loads((ROOT/'inputs/calibration-freeze.json').read_text())
old_seeds = {canonical_hash(c['seed']) for c in old['cases']}
old_ids = {c['cluster_id'] for c in old['cases']}
reserve_ids, reserve_seeds = set(),set()
archive = REPO/'docs/research/artifacts/jev-confirmation-design-20261022.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='ba9d819100b21ee70d2460b163bece3fabcbed84780a5c402d91fcda4bb06600'
with tarfile.open(archive) as tf:
    for line in tf.extractfile('reserved-bank/cases.jsonl'):
        row = json.loads(line)
        reserve_ids.add(row['cluster_id'])
        reserve_seeds.add(canonical_hash(row['seed']))
assert len(reserve_ids)==len(reserve_seeds)==12288
assert not (seeds & (old_seeds | reserve_seeds))
assert not (set(clusters) & (old_ids | reserve_ids))

order = list(csv.DictReader((ROOT/'slot-order.csv').open()))
expected = []
for pair in sorted(clusters.values(),key=lambda pair:pair[0]['reserved_order_key']):
    for condition in ('cold','prewarmed'):
        row = next(r for r in pair if r['condition']==condition)
        for arm in row['reserved_arm_order']:
            expected.append((row['cluster_id'],condition,arm,row['id']))
assert len(order)==3648
assert [(r['cluster_id'],r['condition'],r['arm'],r['case_id']) for r in order]==expected
assert [int(r['position']) for r in order]==list(range(3648))

with localcontext() as ctx:
    ctx.prec = 60
    tail,target = Decimal('.025'),Decimal('.005')
    analytic = tail.ln()/(1-target).ln()
    upper735 = 1-(tail.ln()/735).exp()
    upper736 = 1-(tail.ln()/736).exp()
    upper760 = 1-(tail.ln()/760).exp()
    assert upper735>target and upper736<=target
    assert p['information_target']['analytic_minimum']==736
    assert abs(float(upper760)-p['information_target']['zero_event_upper_at760'])<1e-15
    assert p['information_target']['fixed_positive_N']==760
scoring = runpy.run_path(str(REPO/'backend/benchmarks/computer_use/jev_scoring.py'))
assert p['analysis']['gates']=={k:{'operator':o,'threshold':t} for k,(o,t) in scoring['GATES'].items()}
assert abs(scoring['kl_upper'](0,760)-float(upper760))<1e-15
runtime = json.loads((ROOT/'runtime-sources.json').read_text())
assert all(hashlib.sha256((REPO/'backend'/name).read_bytes()).hexdigest()==sha for name,sha in runtime.items())
report = {'registration_sha256':frozen['sha256'],'files_verified':len(frozen['files']),
          'seed_clusters':912,'positive_seeds':760,'negative_seeds':152,'condition_goals':1824,
          'planned_slots':3648,'balanced_cells':96,'each_cell':19,
          'old_calibration_seeds_checked':len(old_seeds),'confirmation_reserve_seeds_checked':len(reserve_seeds),
          'ID_overlap':0,'data_overlap':0,'actual_master_rebuild_identical':True,
          'GoalContracts_parsed':1824,'analytic_floor':736,'zero_upper735':float(upper735),
          'zero_upper736':float(upper736),'zero_upper760':float(upper760),
          'runtime_sources_verified':len(runtime),'scorer_gates_matched':12,
          'new_model_calls':0,'formal_N':None,'model_execution_eligible':False}
with (ROOT/'validation.json').open('x') as output:
    json.dump(report,output,indent=2);output.write('\n')
print(json.dumps(report,indent=2))
