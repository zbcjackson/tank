"""Frozen supplemental calibration data bank, not a runnable model schedule."""
import copy
import hashlib
import hmac
import json
from pathlib import Path

ROOT=Path(__file__).parent
NAMESPACE='supplemental-calibration-v1:20261022'
ID_PREFIX='supp-cal-v1-'
encoded=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
fingerprint=lambda x:hashlib.sha256(encoded(x).encode()).hexdigest()

def templates():
    f=json.loads((ROOT/'inputs/calibration-freeze.json').read_text())
    assert f['sha256']=='2e071288e1e781733df0ecaba20d6bc539e3dee03fd1303c60f49f4d27e3ce2c'
    return [c for c in f['cases']if c['condition']=='cold']

def replace(value,old_tag,tag,old_id,new_id):
    if isinstance(value,dict):return {replace(k,old_tag,tag,old_id,new_id):replace(v,old_tag,tag,old_id,new_id)for k,v in value.items()}
    if isinstance(value,list):return [replace(v,old_tag,tag,old_id,new_id)for v in value]
    if isinstance(value,str):return value.replace(old_tag,tag).replace(old_id,new_id)
    return value

def build(output,n_positive,master):
    if n_positive<40 or n_positive%40:raise ValueError('ten strata and targets1/4 require a multiple of40')
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    target=output/'cases.jsonl'
    original=templates();old={fingerprint(c['seed'])for c in original};tags={next(v['value']for v in c['goal']['inputs']if v['key']=='title').removeprefix('Approved ')for c in original}
    positive={};negative=[]
    for c in original:
        if c['negative']:negative.append(c);continue
        label=c['product']+'/'+(c['family']if c['group']=='normal'else'recovery-'+c['fault_stage'])
        positive.setdefault(label,[]).append(c)
    seen=set();ids=set();counts={};rows=0
    with target.open('x')as stream:
        groups=[(label,sorted(ts,key=lambda c:c['target']),n_positive//10)for label,ts in sorted(positive.items())]
        groups.extend((c['product']+'/'+c['negative'],[c],n_positive//20)for c in sorted(negative,key=lambda c:c['cluster_id']))
        for label,ts,count in groups:
            counts[label]=count
            for rank in range(count):
                template=ts[rank%len(ts)];identity=f'{NAMESPACE}:{label}:{rank}'
                index=0
                while True:
                    tag=hmac.new(master,f'{identity}:{index}'.encode(),'sha256').hexdigest()[:10]
                    if tag not in tags:tags.add(tag);break
                    index+=1
                cid=ID_PREFIX+hashlib.sha256(identity.encode()).hexdigest()[:20]
                assert cid not in ids;ids.add(cid)
                old_tag=next(v['value']for v in template['goal']['inputs']if v['key']=='title').removeprefix('Approved ')
                seed_hash=None
                for condition in ('cold','prewarmed'):
                    case=replace(template,old_tag,tag,template['cluster_id'],cid)
                    case.update(cluster_id=cid,id=cid+'-'+condition,condition=condition,reserved_stratum=label,reserved_rank=rank)
                    case['goal']['goal_id']=case['id']
                    case['reserved_arm_order']=['v','jt']if(rank//len(ts)+(condition=='prewarmed'))%2==0 else['jt','v']
                    case['reserved_order_key']=hmac.new(master,(identity+':order').encode(),'sha256').hexdigest()
                    actual_hash=fingerprint(case['seed'])
                    if seed_hash is None:
                        assert actual_hash not in old and actual_hash not in seen;seen.add(actual_hash);seed_hash=actual_hash
                    assert actual_hash==seed_hash
                    stream.write(encoded(case)+'\n');rows+=1
    manifest={'revision':'supplemental-calibration-bank-v1','namespace':NAMESPACE,
        'formal_N':None,'model_execution_eligible':False,
        'planned_positive_N':n_positive,'planned_negative_N':n_positive//5,
        'planned_trials':n_positive*24//5,'negative_ratio':.2,'admissible_positive_step':40,'seed_clusters':len(ids),'condition_goals':rows,
        'strata':counts,'seed_commitment':hashlib.sha256(master).hexdigest(),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'cases_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'input_freeze':'2e071288e1e781733df0ecaba20d6bc539e3dee03fd1303c60f49f4d27e3ce2c',
        'status':'Fixed supplemental calibration data. Native/runner qualification and executable freeze pending; no model execution permission.',
        'novelty':'Fresh synthetic data fingerprints and labels only; numeric IDs1/4 and original layouts/templates deliberately retained. Not unseen layouts or new applications.',
        'selection_rule':'Use every registered seed; no model-result selection or adaptive extension. Prefix ranks0-3 positive/ranks0-1 negative are for no-model qualification only.',
        'separation':'No calibration data fingerprint reused; all24 original cases checked. Earlier two-record fixtures have a different four-record schema/size.'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest

def validate(output):
    output=Path(output);m=json.loads((output/'manifest.json').read_text());assert m['formal_N']is None and not m['model_execution_eligible']and'schedule'not in m
    assert hashlib.sha256((output/'cases.jsonl').read_bytes()).hexdigest()==m['cases_sha256']
    old={fingerprint(c['seed'])for c in templates()};groups={};new=set();count=0
    for line in(output/'cases.jsonl').read_text().splitlines():
        c=json.loads(line);count+=1;g=c['goal'];assert g['goal_id']==c['id']
        assert {r['id']for r in c['seed']}=={1,2,3,4}
        groups.setdefault(c['cluster_id'],[]).append((c['condition'],c['reserved_arm_order'],fingerprint(c['seed'])))
        new.add(fingerprint(c['seed']));assert fingerprint(c['seed'])not in old
        title=next(v['value']for v in g['inputs']if v['key']=='title')
        wanted=json.loads(next(v['value']for v in g['completion']if v['key']=='status:Records'))
        expected=copy.deepcopy(sorted(c['seed'],key=lambda r:r['id']))
        for r in expected:
            if r['id']==c['target']:r['title']=title
        assert wanted==expected
        assert c['oracle']['rows']==expected
        visible=json.loads(g['completion'][1]['value'])
        assert visible==c['oracle']['visible_list']
        if c['product']=='sqlite-web':assert visible['rows']==[[str(r[k])for k in('id','title','notes')]for r in expected]
        else:assert visible['records']==[{'id':str(r['id']),'url':r['url'],'title':r['title'],'description':'keep | '+r['description']}for r in expected]
        assert g['outcomes'][0]['conditions'][0]['key'].startswith('status:Editor seen:')
        assert c['fault_path']==(c['start_path']if c['fault_stage']=='list'else c['oracle']['edit_path'])if c['recovery']else c['fault_path']is None
    assert count==m['condition_goals'] and len(groups)==len(new)==m['seed_clusters']
    for pair in groups.values():assert len(pair)==2 and {v[0]for v in pair}=={'cold','prewarmed'}and pair[0][1]==list(reversed(pair[1][1]))and pair[0][2]==pair[1][2]
    return {'new_seed_clusters':len(new),'condition_goals':count,'overlap_with_calibration':len(new&old)}
