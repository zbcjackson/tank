"""Review-only independent checks; no execution, network, or original artifact writes."""
import csv
import hashlib
import hmac
import json
import math
import subprocess
import sys
import tarfile
from collections import Counter, defaultdict
from copy import deepcopy
from decimal import Decimal, ROUND_CEILING, localcontext
from pathlib import Path

REPO = Path('/Users/zbcjackson/src/tank')
HERE = Path(__file__).parent
ROOT = HERE / 'extracted'
BASE = '3c2a980a'

def deny(event, args):
    if event == 'socket.connect':
        raise RuntimeError('review forbids network connections')

sys.addaudithook(deny)
from agent_computer_use.contracts import GoalContract

def sha(data):
    return hashlib.sha256(data).hexdigest()

def logical(value):
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())

def read(name):
    return json.loads((ROOT/name).read_text())

archive = REPO/'docs/research/artifacts/jev-supplemental-calibration-registration-20261022.tar.xz'
m = json.loads(archive.with_name(archive.name.replace('.tar.xz', '-manifest.json')).read_text())
assert sha(archive.read_bytes()) == m['sha256']
assert archive.stat().st_size == m['bytes']
with tarfile.open(archive) as tf:
    members = tf.getmembers()
    assert len({i.name for i in members}) == len(members) == 43
    assert {i.name for i in members} == {i['path'] for i in m['members']}
    for item in m['members']:
        data = tf.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
        # Ignore only the intentionally renamed/recreated validator output in this copy.
        if item['path'] != 'validation.json':
            assert (ROOT/item['path']).read_bytes() == data
f = read('freeze.json')
assert logical({k:v for k,v in f.items() if k!='sha256'}) == f['sha256'] == m['registration_sha256']
for name, value in f['files'].items():
    assert sha((ROOT/name).read_bytes()) == value
p = read('protocol.json')
assert f['model_execution_eligible'] is False and f['formal_N'] is None
assert p['model_execution_eligible'] is False and p['formal_N'] is None
old = read('old-artifacts.json')
assert len(old['files']) == 54 and old['baseline'] == BASE
for item in old['files']:
    baseline = subprocess.check_output(['git', 'show', f"{BASE}:{item['path']}"], cwd=REPO)
    blob = subprocess.check_output(['git', 'rev-parse', f"{BASE}:{item['path']}"], cwd=REPO, text=True).strip()
    assert blob == item['git_blob']
    assert sha(baseline) == item['sha256']
    assert (REPO/item['path']).read_bytes() == baseline
runtime = read('runtime-sources.json')
for name, value in runtime.items():
    current = (REPO/'backend'/name).read_bytes()
    baseline = subprocess.check_output(['git', 'show', f'{BASE}:backend/{name}'], cwd=REPO)
    assert sha(current) == value and current == baseline
provenance = read('source-provenance.json')
with tarfile.open(REPO/'docs/research/artifacts/jev-confirmation-design-20261022.tar.xz') as tf:
    base_generator = tf.extractfile('bank.py').read()
    assert sha(base_generator) == provenance['generator_base_sha256']
    reserve = [json.loads(line) for line in tf.extractfile('reserved-bank/cases.jsonl')]
old_cases = read('inputs/calibration-freeze.json')['cases']
assert logical({k:v for k,v in read('inputs/calibration-freeze.json').items() if k!='sha256'}) == provenance['input_freeze_logical_sha256']
master = bytes.fromhex((ROOT/'bank-master-seed.hex').read_text())
assert len(master) == 32 and sha(master) == read('seed-commitment.json')['sha256']
rows = [json.loads(line) for line in (ROOT/'bank/cases.jsonl').read_text().splitlines()]
by_cluster = defaultdict(list)
by_stratum = defaultdict(list)
cells = Counter()
new_tags = set()
for row in rows:
    GoalContract.from_input(row['goal'])
    by_cluster[row['cluster_id']].append(row)
    assert row['goal']['goal_id'] == row['id']
    assert row['id'] == row['cluster_id']+'-'+row['condition']
    assert row['negative'] in (None,'missing','revoked')
    assert (row['group']=='negative') == bool(row['negative'])
    assert row['recovery'] == (row['group']=='recovery')
    assert {r['id'] for r in row['seed']} == {1,2,3,4}
    title = next(x['value'] for x in row['goal']['inputs'] if x['key']=='title')
    tag = title.removeprefix('Approved ')
    assert len(tag)==10 and len(title)==19
    identity = f"supplemental-calibration-v1:20261022:{row['reserved_stratum']}:{row['reserved_rank']}"
    assert row['cluster_id'] == 'supp-cal-v1-'+sha(identity.encode())[:20]
    assert row['reserved_order_key'] == hmac.new(master,(identity+':order').encode(),'sha256').hexdigest()
    # For this frozen bank there was no collision retry: verify the first HMAC output.
    assert tag == hmac.new(master,(identity+':0').encode(),'sha256').hexdigest()[:10]
    if row['condition']=='cold':
        assert tag not in new_tags
        new_tags.add(tag)
        by_stratum[row['reserved_stratum']].append(row)
    before = sorted(deepcopy(row['seed']),key=lambda r:r['id'])
    after = deepcopy(before)
    for record in after:
        if record['id']==row['target']:
            record['title']=title
    completion = {x['key']:x['value'] for x in row['goal']['completion']}
    assert json.loads(completion['status:Records']) == after == row['oracle']['rows']
    acceptance = row['private_acceptance']
    assert acceptance['records'] == (before if row['negative'] else after)
    assert acceptance['positive'] == (row['negative'] is None)
    assert acceptance['one_successful_POST'] == (row['negative'] is None)
    assert acceptance['negative_condition'] == row['negative']
    assert acceptance['other_tables_schema_unchanged'] is True
    assert acceptance['allow_target_date_modified_increase'] == (row['product']=='linkding' and not row['negative'])
    visible = row['oracle']['visible_list']
    if row['product']=='sqlite-web':
        assert json.loads(completion['status:List rows']) == visible
        assert visible=={'columns':['id','title','notes'],'path':'/work_items/content/','rows':[[str(r[k]) for k in ('id','title','notes')] for r in after]}
    else:
        assert json.loads(completion['status:List records']) == visible
        assert visible=={'path':'/bookmarks','records':[{'id':str(r['id']),'url':r['url'],'title':r['title'],'description':'keep | '+r['description']} for r in after]}
    cells[row['reserved_stratum'],row['target'],row['condition'],row['reserved_arm_order'][0]] += 1
assert len(rows)==1824 and len(by_cluster)==912 and len(new_tags)==912
assert len({r['id'] for r in rows})==1824
assert len(cells)==96 and set(cells.values())=={19}
for cid,pair in by_cluster.items():
    assert len(pair)==2 and {r['condition'] for r in pair}=={'cold','prewarmed'}
    cold=next(r for r in pair if r['condition']=='cold')
    warm=next(r for r in pair if r['condition']=='prewarmed')
    left=deepcopy(cold);right=deepcopy(warm)
    for item in (left,right):
        item.pop('id');item.pop('condition');item.pop('reserved_arm_order');item['goal'].pop('goal_id')
    assert left==right
    assert cold['reserved_arm_order']==warm['reserved_arm_order'][::-1]
positive = [pair[0] for pair in by_cluster.values() if not pair[0]['negative']]
negative = [pair[0] for pair in by_cluster.values() if pair[0]['negative']]
assert len(positive)==760 and len(negative)==152
assert sum(r['recovery'] for r in positive)==304
assert len(by_stratum)==14
assert sorted(len(v) for v in by_stratum.values())==[38]*4+[76]*10
qualification = []
for stratum, items in by_stratum.items():
    limit=2 if items[0]['negative'] else 4
    assert sorted(r['reserved_rank'] for r in items)==list(range(len(items)))
    prefix = [r for r in items if r['reserved_rank']<limit]
    assert len(prefix)==limit
    if not prefix[0]['negative']:
        assert Counter((r['target'],r['reserved_arm_order'][0]) for r in prefix)==Counter({(1,'v'):1,(1,'jt'):1,(4,'v'):1,(4,'jt'):1})
    else:
        assert {r['target'] for r in items}==({99} if items[0]['negative']=='missing' else {1})
        assert Counter(r['reserved_arm_order'][0] for r in prefix)==Counter({'v':1,'jt':1})
    qualification.extend(prefix)
assert len(qualification)==48
new_ids=set(by_cluster)
new_data={logical(pair[0]['seed']) for pair in by_cluster.values()}
old_ids={r['cluster_id'] for r in old_cases};old_data={logical(r['seed']) for r in old_cases}
reserved_ids={r['cluster_id'] for r in reserve};reserved_data={logical(r['seed']) for r in reserve}
assert len(old_ids)==len(old_data)==24
assert len(reserved_ids)==len(reserved_data)==12288
assert len(new_data)==912 and not new_ids&(old_ids|reserved_ids) and not new_data&(old_data|reserved_data)
order = list(csv.DictReader((ROOT/'slot-order.csv').open()))
expected=[]
for pair in sorted(by_cluster.values(),key=lambda pair:pair[0]['reserved_order_key']):
    for condition in ('cold','prewarmed'):
        row=next(r for r in pair if r['condition']==condition)
        expected.extend((row['cluster_id'],condition,arm,row['id']) for arm in row['reserved_arm_order'])
assert [(r['cluster_id'],r['condition'],r['arm'],r['case_id']) for r in order]==expected
assert [int(r['position']) for r in order]==list(range(3648))
assert len({(r['case_id'],r['arm']) for r in order})==3648
with localcontext() as context:
    context.prec=80
    tail=Decimal('.025');target=Decimal('.005')
    minimum=int((tail.ln()/(1-target).ln()).to_integral_value(rounding=ROUND_CEILING))
    uppers={str(n):1-(tail.ln()/n).exp() for n in (735,736,760)}
    assert minimum==736 and uppers['735']>target>=uppers['736']>uppers['760']
    assert math.ceil(minimum/40)*40==760
    assert abs(Decimal(str(p['information_target']['zero_event_upper_at760']))-uppers['760'])<Decimal('1e-16')
historical=read('inputs/calibration-independent.json')
resource=read('resource-preview.json')
assert len(historical['rows'])==96
assert resource['historical_summed_trial_elapsed_hours']==sum(r['elapsed_ms'] for r in historical['rows'])*38/3600000
assert resource['historical_known_tokens']==historical['known_tokens']*38==167681878
assert resource['task_deadline_sum_hours']==3648*120/3600==121.6
out={'status':'passed','archive_members':43,'frozen_files':len(f['files']),'old_artifacts_git_blob_and_sha256':54,'runtime_source_baseline_and_sha256':len(runtime),'GoalContracts_and_private_acceptance':1824,'independent_HMAC_cluster_identity_and_order':912,'balanced_cells':96,'qualification_seeds':48,'qualification_condition_goals':96,'qualification_slots':192,'old_calibration_seeds':24,'confirmation_reserved_seeds':12288,'data_and_ID_intersections':0,'planned_unique_slots':3648,'analytic_minimum':minimum,'Decimal80_upper':{k:str(v) for k,v in uppers.items()},'registration_sha256':f['sha256'],'resource_reference_checked':True,'new_model_calls':0,'formal_N':None,'model_execution_eligible':False}
(HERE/'independent-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
