"""Rebuild documentation outputs in a new isolated directory."""
import hashlib
import json
import runpy
import shutil
import sys
from pathlib import Path

def deny(event,args):
    if event=='socket.connect':
        raise RuntimeError('registration reproduction forbids network')

sys.addaudithook(deny)
here=Path(__file__).parent
source=here/'extracted'
target=here/'registration-rebuild'
target.mkdir(exist_ok=False)
freeze=json.loads((source/'freeze.json').read_text())
generated={'protocol.json','audit-contract.json','slot-order.csv','runtime-sources.json','resource-preview.json','freeze.json'}
for name in freeze['files']:
    if name not in generated:
        destination=target/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source/name,destination)
runpy.run_path(str(target/'register.py'),run_name='__main__')
checks={}
for name in sorted(generated):
    actual=(target/name).read_bytes()
    assert actual==(source/name).read_bytes(),name
    checks[name]=hashlib.sha256(actual).hexdigest()
report={'status':'passed','generated_outputs_byte_identical':checks,'fresh_directory':str(target),'new_model_calls':0}
(here/'registration-reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
