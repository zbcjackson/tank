import asyncio,importlib,json,os,plistlib,tempfile
from pydantic import BaseModel
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
from benchmarks.computer_use.s4_ax import OwnedApplication
from tank_backend.agents.subagent import SubAgentContext,SubAgentAuthorization,SubAgentBudget
from tank_backend.tools import computer_ax
from agent_computer_use.channels.native import NativeAXChannel

async def main():
 out=Path('/private/tmp/tank-jev-textedit-inspect-20261019-v3');out.mkdir(exist_ok=False)
 quartz=importlib.import_module('Quartz')
 if (quartz.CGSessionCopyCurrentDictionary() or {}).get('CGSSessionScreenIsLocked',False):raise RuntimeError('desktop locked')
 owner=OwnedApplication({'id':'textedit-inspect','application':'textedit','dispatch':'ax_press','repeat':0,'max_decisions':0,'move_window':False})
 context=SubAgentContext(SubAgentAuthorization(frozenset({'desktop'})),SubAgentBudget(),asyncio.Event())
 channel=None;result={'mode':'no-model inspection','model_requests':0}
 original=tempfile.mkstemp
 def rich(*args,**kwargs):
  kwargs['suffix']='.rtf'
  fd,name=original(*args,**kwargs)
  os.write(fd,b'{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Helvetica;}}\\f0\\fs28 Jev image pilot\\par Second line\\par}')
  os.lseek(fd,0,0)
  return fd,name
 try:
  with patch('tempfile.mkstemp',rich):config=owner.start()
  context.runtime.bind('textedit-inspect')
  channel=NativeAXChannel(config=config.model_copy(update={'labels':'accessible_name'}))
  snap=await channel.observe('textedit-inspect',context)
  frame=await channel.capture(snap,context)
  (out/'window.png').write_bytes(frame.png)
  candidates,incomplete=computer_ax.ax_window_candidates(config.window_id,frame.frame.display_geometry)
  items=[{k:getattr(c,k) for k in ('index','role','title','value','description','identifier','actions','enabled','frame','ancestors','focused','value_settable')} for c in candidates]
  app=plistlib.loads(Path('/System/Applications/TextEdit.app/Contents/Info.plist').read_bytes())
  result.update(config=config.model_dump(mode='json'),application={'version':app.get('CFBundleShortVersionString'),'build':app.get('CFBundleVersion')},snapshot=asdict(snap),frame=asdict(frame.frame),candidates=items,incomplete=incomplete)
  print(json.dumps({'snapshot_complete':snap.complete,'incomplete':incomplete,'candidates':items},ensure_ascii=False))
 finally:
  if channel is not None:await channel.aclose()
  await context.runtime.aclose()
  result['cleanup']=owner.close()
  (out/'inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda o:o.model_dump(mode='json') if isinstance(o,BaseModel) else str(type(o)))+'\n')
  print('cleanup',result['cleanup'])
asyncio.run(main())
