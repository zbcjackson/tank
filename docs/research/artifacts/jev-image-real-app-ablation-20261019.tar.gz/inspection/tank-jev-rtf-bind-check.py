import asyncio,importlib,json
from pathlib import Path
from benchmarks.computer_use import jev_image_ablation as p,s4_ax
from agent_computer_use.channels.native import NativeAXChannel
from agent_computer_use import create_subagent
from agent_computer_use.contracts import Target
from PIL import Image,ImageChops
import io
from tank_backend.agents.subagent import SubAgentContext,SubAgentAuthorization,SubAgentBudget
async def main():
 p.preflight()
 out=Path('/private/tmp/tank-jev-rtf-selection-check-20261019-bind');out.mkdir(exist_ok=False)
 owner=s4_ax.OwnedApplication({'id':'selection-check','application':'textedit','dispatch':'ax_press','repeat':0,'max_decisions':0,'move_window':False},rtf=p.documents()['scene-01'])
 ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop'})),SubAgentBudget(),asyncio.Event())
 ctx.runtime.bind('selection-check');channel=None
 try:
  cfg=owner.start();api=s4_ax.computer_ax._load_ax()
  nodes,incomplete=s4_ax.computer_ax.ax_window_candidates(cfg.window_id,s4_ax.computer_use_macos._main_geometry(s4_ax.computer_use_macos._active_displays()),include_descriptions=False)
  body=[n for n in nodes if n.role=='AXTextArea' and n.identifier=='First Text View'];assert len(body)==1 and not incomplete
  foundation=importlib.import_module('Foundation');objc=importlib.import_module('objc');functions={}
  bundle=foundation.NSBundle.bundleWithPath_('/System/Library/Frameworks/ApplicationServices.framework/Frameworks/HIServices.framework')
  objc.loadBundleFunctions(bundle,functions,[('AXValueCreate',b'@in^{_CFRange=qq}')])
  selected=functions['AXValueCreate'](4,(0,len('Jev visual probe')))
  error=api['AXUIElementSetAttributeValue'](body[0].element.native,'AXSelectedTextRange',selected)
  s4_ax.pump(.2)
  actual=api['AXUIElementCopyAttributeValue'](body[0].element.native,'AXSelectedText',None)
  print('selection',error,actual,'body',owner.read_values())
  assert error==0 and actual==(0,'Jev visual probe')
  plugin=create_subagent({'macos':{'profiles':{'com.apple.TextEdit':s4_ax.macos_policy()['profiles']['com.apple.TextEdit']}}})
  channel=plugin.controller.source
  await channel.bind(Target(application='com.apple.TextEdit'),'selection-check',ctx)
  snap=await channel.observe('selection-check',ctx)
  hashes=[]
  previous=None
  for i in range(8):
   frame=await channel.capture(snap,ctx);hashes.append(frame.frame.image_sha256)
   (out/f'frame-{i}.png').write_bytes(frame.png)
   im=Image.open(io.BytesIO(frame.png)).convert('RGB')
   print('frame',i,'selected',api['AXUIElementCopyAttributeValue'](body[0].element.native,'AXSelectedText',None),'diff_bbox',ImageChops.difference(previous,im).getbbox() if previous else None)
   previous=im
   s4_ax.pump(.15)
  print('unique_capture_hashes',len(set(hashes)),hashes)
 finally:
  if channel is not None:await channel.aclose()
  await ctx.runtime.aclose();print('cleanup',owner.close())
asyncio.run(main())
