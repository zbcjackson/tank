import json,hashlib,statistics
from pathlib import Path
from PIL import Image,ImageChops
p=Path('/private/tmp/tank-jev-ablation-live-20261019-reviewed')
r=json.loads((p/'result.json').read_text()); labels=json.loads((p/'private/labels.json').read_text())
raw=[json.loads(l) for l in (p/'calls.jsonl').read_text().splitlines()]
req={x['call_id']:x for x in raw if 'request' in x};res={x['call_id']:x for x in raw if 'response' in x}
assert len(req)==len(res)==12 and req.keys()==res.keys()
assert r['completed'] and r['spend']['stop_reason'] is None
assert json.loads((p/'spend.jsonl').read_text().splitlines()[-1])==r['spend']
summary={'freeze':r['sha256'],'completed':True,'requests':len(req),'task_rows':[],'boxes':[],'pairs':[]}
inp=out=0
for cid,q in req.items():
 a=res[cid]['response']; inp+=a['input_tokens'];out+=a['output_tokens'];trial=q['trial'];text=trial.endswith('-text')
 assert len(q['images'])==int(not text)
 assert q['headers']==({} if text else {'TypeSafe-Danger-Zone-Images':'true'})
 if not text:
  for asset in q['images']:
   data=(p/asset['path']).read_bytes();assert len(data)==asset['bytes'];assert hashlib.sha256(data).hexdigest()==asset['sha256']
 if 'ablation' in q['purpose']:
  assert 'completion' not in q['request']['state']['goal']
  s=json.dumps(q['request']);assert 'expected_body' not in s and 'expected_variant' not in s and '\\colortbl' not in s
  assert all(z['image_size'][0]<=1920 and z['image_size'][1]<=1920 for z in next(x for x in r['rows'] if x['id']==trial)['capture_frames'])
assert inp+out==r['spend']['batch']['known_tokens']
assert inp*42==r['spend']['batch']['known_nano_usd']
assert r['spend']['batch']['reserved_tokens']==r['spend']['batch']['reserved_nano_usd']==0
for x in r['rows']:
 assert x['status']=='finished' and x['cleanup_confirmed'] and x['cleanup_errors']==[]
 if x['kind']=='task':
  expected=labels[x['scene']]['expected_body'];a=x.get('model_answer');correct=bool(a and isinstance(x['criteria'].get(a['choice']),dict) and x['criteria'][a['choice']]['value']==expected)
  assert x['model_correct']==correct
  proposals={(e['candidate_set_id'],e['action_id']) for e in x['events'] if e['kind']=='computer_use_proposal' and e['source']=='ablation_'+x['arm']}
  sent={(e['candidate_set_id'],e['action_id']) for e in x['result']['details']['receipts'] if e['status']=='sent'}
  assert x['selection_executed']==len(proposals&sent)==len(x['native_actions'])
  assert len(x['native_actions'])<=1
  if x['passed']:assert correct and x['independent_values']=={'document':expected} and x['native_actions']==[{'pid':x['binding']['pid'],'value':expected,'status':'returned'}]
  else:assert x['native_actions']==[]
  diffs=[]
  if x['result']['reason']=='unstable_visual_frame':
   imgs=[Image.open(p/'images'/f"{x['id']}-capture-{i}.png").convert('RGB') for i in range(len(x['capture_frames']))]
   diffs=[ImageChops.difference(imgs[0],im).getbbox() for im in imgs[1:]]
  summary['task_rows'].append({'id':x['id'],'arm':x['arm'],'called':bool(a),'choice':a['choice'] if a else None,'correct':correct,'abstained':x['model_abstained'],'completed':x['passed'],'reason':x['result']['reason'],'native_actions':len(x['native_actions']),'elapsed_ms':x['elapsed_ms'],'known_tokens':x['known_tokens'],'changed_pixel_bboxes':diffs})
 else:
  assert x['native_actions']==[] and x['independent_values']=={'document':'Jev visual probe\nNorth\nSouth\n'}
  for b in x['boxes']:
   if b['status']=='returned': assert b['correct'] and b['answer']['cardinality']['choice']==b['cardinality'] and b['native_actions_added']==0
   summary['boxes'].append({'id':x['id']+'-'+b['id'],'status':b['status'],'expected':b['cardinality'],'correct':b.get('correct',False),'reason':b.get('reason'),'choice':b.get('answer',{}).get('cardinality',{}).get('choice')})
for scene in ('scene-01','scene-02'):
 for position in range(2):
  pair=scene+f'-p{position}';rows=[x for x in summary['task_rows'] if x['id'].startswith(pair)]
  summary['pairs'].append({'id':pair,'both_called':all(x['called'] for x in rows),'image_correct':next(x['correct'] for x in rows if x['arm']=='image'),'text_correct':next(x['correct'] for x in rows if x['arm']=='text')})
summary.update(input_tokens=inp,output_tokens=out,total_tokens=inp+out,nano_usd=inp*42,cleanup_confirmed=10,source_files=len(json.loads((p/'freeze.json').read_text())['source_sha256']))
latencies={}
for arm in ('text','image'):
 xs=[e['elapsed_ms'] for x in r['rows'] if x['kind']=='task' and x['arm']==arm for e in x['events'] if e['kind']=='model_call' and e['phase']=='finished']
 latencies[arm]={'n':len(xs),'median_ms':statistics.median(xs),'values_ms':xs}
summary['model_latency']=latencies
Path('/private/tmp/tank-jev-ablation-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
