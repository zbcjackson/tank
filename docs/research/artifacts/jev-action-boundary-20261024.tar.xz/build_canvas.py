from pathlib import Path
import json
root=Path('/private/tmp/tank-jev-action-boundary-20261024')
rows=json.loads((root/'derived-v1/trials.json').read_text());decision=json.loads((root/'derived-v1/decision.json').read_text());scope=json.loads((root/'derived-v1/scope.json').read_text())
fields='id policy product pair_id family negative positive_success negative_success elapsed_s sdk_boundary_s remainder_s capped_completion_s text_calls visual_calls logical_fallbacks sdk_calls tokens host_reason'.split()
data={'trials':[{k:r[k] for k in fields} for r in rows],'decision':{'supported':decision['supported_for_next_explicit_experimental_wiring'],'critical_events':decision['critical_events']},'freeze':scope['freeze_sha256'],'audit':scope['audit_sha256']}
code=r'''import {Stack, Row, Grid, H1, H2, Text, Stat, Table, Select, Callout, BarChart, useState, useHostTheme} from "cursor/canvas";
type Trial={id:string;policy:string;product:string;pair_id:string;family:string;negative:boolean;positive_success:boolean;negative_success:boolean;elapsed_s:number;sdk_boundary_s:number;remainder_s:number;capped_completion_s:number|null;text_calls:number;visual_calls:number;logical_fallbacks:number;sdk_calls:number;tokens:number;host_reason:string};
const DATA:{trials:Trial[];decision:{supported:boolean;critical_events:number};freeze:string;audit:string}=__DATA__;
const families:Record<string,string>={"schema-title":"表结构页 → 改标题","detail-notes":"记录详情 → 改备注","multi-field":"同时修改两个字段","semantic-title":"按标题定位","details-title":"书签详情面板 → 改标题","editor-description":"编辑页起步 → 改描述","semantic-url":"按URL定位",missing:"目标缺失",ambiguous:"同名且不可唯一确定"};
const labels:Record<string,string>={v:"V 纯视觉",ja:"JA 动作级Jev"};
const total=(rs:Trial[],f:(r:Trial)=>number)=>rs.reduce((n,r)=>n+f(r),0);
const mean=(rs:Trial[],f:(r:Trial)=>number)=>total(rs,f)/rs.length;
const f=(x:number)=>x.toFixed(2);
const success=(r:Trial)=>r.negative?r.negative_success:r.positive_success;
export default function BoundaryResults(){
 const theme=useHostTheme();
 const [product,setProduct]=useState("all"),[cohort,setCohort]=useState("positive"),[family,setFamily]=useState("all"),[detail,setDetail]=useState("");
 const base=DATA.trials.filter(r=>(product==="all"||r.product===product)&&r.negative===(cohort==="negative"));
 const options=Array.from(new Set(base.map(r=>r.family)));
 const activeFamily=options.includes(family)?family:"all";
 const rows=base.filter(r=>activeFamily==="all"||r.family===activeFamily);
 const pairs=Array.from(new Set(rows.map(r=>r.pair_id))).map(id=>({id,v:rows.find(r=>r.pair_id===id&&r.policy==="v")!,ja:rows.find(r=>r.pair_id===id&&r.policy==="ja")!}));
 const groups=["v","ja"].map(policy=>({policy,rows:rows.filter(r=>r.policy===policy)}));
 const selected=pairs.find(p=>p.id===detail)??pairs[0];
 const positive=cohort==="positive";
 const timing=(r:Trial)=>positive?r.capped_completion_s!:r.elapsed_s;
 const common=pairs.filter(p=>p.v.positive_success&&p.ja.positive_success);
 const source="来源：2026-10-24新实测 · 12任务实例、两臂共24次 · 统一冷启动；当前每臂"+pairs.length+"次。";
 const timingName=positive?"正例完成均时：失败计120秒":"负例安全退出实际均时";
 return <Stack gap={24} style={{maxWidth:1240,margin:"0 auto",padding:24,background:theme.bg.editor,color:theme.text.primary}}>
  <Stack gap={8}>
   <Text size="small" tone="secondary">动作级准入边界验证 · sqlite-web / linkding · 所有24槽均已执行与清理</Text>
   <H1>新页面、字段和语义目标上的真实结果</H1>
   <Text>动作级正例8/8、负例4/4；纯视觉正例7/8、负例4/4。关键错误事件0、unknown用量0。Jev仅接收文字；视觉使用同一Gemini，未测试Jev图片或Box。</Text>
   <Text>工程筛查条件{DATA.decision.supported?"满足：支持下一片显式实验配置接线验证":"未满足：需要按失败限制范围"}。当前生产默认未改；这不是正式总体采用或模型能力排名结论。</Text>
  </Stack>
  <Callout tone="info">纯视觉在表结构页因完整候选超出截图而于SDK调用前拒绝。这1次仍留在8个正例分母、完成时间计120秒；它是宿主覆盖限制，不能说成Gemini识别错误。模型均未收到私有目标ID、标准动作或评分标签。</Callout>
  <Row gap={12} wrap>
   <Select value={product} onChange={setProduct} options={[{value:"all",label:"两个真实产品"},{value:"sqlite-web",label:"sqlite-web"},{value:"linkding",label:"linkding"}]}/>
   <Select value={cohort} onChange={setCohort} options={[{value:"positive",label:"正例任务"},{value:"negative",label:"安全退出负例"}]}/>
   <Select value={activeFamily} onChange={setFamily} options={[{value:"all",label:"全部当前流程"},...options.map(x=>({value:x,label:families[x]??x}))]}/>
  </Row>
  <Row gap={32} wrap>
   {groups.map(g=><Stat key={g.policy} label={labels[g.policy]+" 通过/完整分母"} value={g.rows.filter(success).length+" / "+g.rows.length}/>)}
   <Stat label="当前任务实例配对数" value={pairs.length}/>
   <Stat label="全批关键错误事件" value={DATA.decision.critical_events}/>
  </Row>
  <Grid columns="repeat(auto-fit,minmax(350px,1fr))" gap={24}>
   <Stack gap={8}>
    <H2>{timingName}</H2>
    <Text size="small" tone="secondary">横轴：策略；纵轴：每任务平均秒数。正例计失败惩罚，负例使用实际退出时间。</Text>
    <BarChart categories={groups.map(g=>labels[g.policy])} series={[{name:timingName,tone:"info",data:groups.map(g=>mean(g.rows,timing))}]} valueSuffix=" s" height={250} showValues/>
    <Text size="small" tone="tertiary">{source} 任务计时包含设置、认证、执行、回读与清理。</Text>
   </Stack>
   <Stack gap={8}>
    <H2>真实SDK调用构成</H2>
    <Text size="small" tone="secondary">横轴：策略；纵轴：当前任务的总SDK调用次数。图例为Jev文字与Gemini图片。</Text>
    <BarChart categories={groups.map(g=>labels[g.policy])} series={[{name:"Jev文字",tone:"info",data:groups.map(g=>total(g.rows,r=>r.text_calls))},{name:"Gemini图片",tone:"neutral",data:groups.map(g=>total(g.rows,r=>r.visual_calls))}]} height={250} showValues/>
    <Text size="small" tone="tertiary">{source} 图像恢复可能另加图片调用；逻辑接管数在下表单列。</Text>
   </Stack>
  </Grid>
  {positive&&common.length>0&&<Stack gap={8}>
   <H2>双方成功的配对：仅作时间诊断</H2>
   <Text>当前{common.length}对，实际均时：V {f(common.reduce((n,p)=>n+p.v.elapsed_s,0)/common.length)}秒；JA {f(common.reduce((n,p)=>n+p.ja.elapsed_s,0)/common.length)}秒。全批对应7对，V37.32秒、JA5.97秒。</Text>
   <Text size="small" tone="secondary">该子集不替代上方完整正例分母和失败惩罚；不能通过只选成功任务获得主要速度结论。</Text>
  </Stack>}
  <Stack gap={8}>
   <H2>实际时间、接管与报告用量</H2>
   <Table headers={["策略","实际均时(s)","SDK边界均时(s)","其余未细分(s)","文字/图片/接管","提供方报告tokens"]} rows={groups.map(g=>[labels[g.policy],f(mean(g.rows,r=>r.elapsed_s)),f(mean(g.rows,r=>r.sdk_boundary_s)),f(mean(g.rows,r=>r.remainder_s)),total(g.rows,r=>r.text_calls)+" / "+total(g.rows,r=>r.visual_calls)+" / "+total(g.rows,r=>r.logical_fallbacks),total(g.rows,r=>r.tokens).toLocaleString()])} columnAlign={["left","right","right","right","right","right"]}/>
   <Text size="small" tone="secondary">SDK边界含局部capture/accounting、网络及提供商处理；其余时间不等于纯宿主CPU。不同模型token定义不同；账本record-only/unpriced，不把少图或报告token数当成美元节省。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>全部当前配对与失败原因</H2>
   <Table headers={["产品 / 流程","V核验","JA核验",positive?"V完成(s，失败120)":"V退出(s)",positive?"JA完成(s，失败120)":"JA退出(s)","JA−V(s)","V / JA退出原因"]} rows={pairs.map(p=>[p.v.product+" / "+families[p.v.family],success(p.v)?"通过":"失败",success(p.ja)?"通过":"失败",f(timing(p.v)),f(timing(p.ja)),f(timing(p.ja)-timing(p.v)),p.v.host_reason+" / "+p.ja.host_reason])} striped/>
   <Text size="small" tone="secondary">负例通过指缺失/不唯一目标的零派发、数据库不变及安全退出；未测自然语言澄清质量。产品/页面/流程相关，任务实例数不是独立应用数；未作置信区间或正式采用检验。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>单个配对的原始证据定位</H2>
   <Select value={selected.id} onChange={setDetail} options={pairs.map(p=>({value:p.id,label:p.v.product+" / "+families[p.v.family]+" / "+p.id}))}/>
   <Table headers={["策略 / 试次ID","实际时间(s)","SDK调用","文字 / 图片 / 接管","核验"]} rows={[selected.v,selected.ja].map(r=>[labels[r.policy]+" / "+r.id,f(r.elapsed_s),r.sdk_calls,r.text_calls+" / "+r.visual_calls+" / "+r.logical_fallbacks,success(r)?"通过":"失败"])} striped/>
   <Text size="small" tone="tertiary">每次保存实际DB前后副本、HTML/PNG、HTTP、派发见证、原始SDK请求/响应、用量与诊断；完整源码与脚本随证据包保存。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>结论的适用范围</H2>
   <Text>支持把动作级selector接入显式实验配置作为下一片工作，保持默认不变。本批提供相同的完整业务记录与公开目标读回补强；不能直接推断生产原始DOM/AX观测已具有相同能力。未见流程迁移是开发证据，非自然语言规划或广泛生产覆盖认证。</Text>
   <Text size="small" tone="secondary">负例公开标题含Absent/Shared提示词，未验证中性命名拒绝泛化；实验配置仅供受控开发。仅两个已见产品、12新任务实例、一个启动条件。提供商缓存、路由和服务负载未受控。保留视觉确认；图片/Box另作独立问题，不扩回旧3648槽。</Text>
   <Text size="small" tone="tertiary">冻结SHA256：{DATA.freeze}；真实业务审计：{DATA.audit}。</Text>
  </Stack>
 </Stack>;
}
'''
path=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-action-boundary-results.canvas.tsx')
assert not path.exists();code=code.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')));path.write_text(code);(root/path.name).write_text(code)
(root/'canvas-tsconfig.json').write_text(json.dumps({'extends':'/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/tsconfig.json','include':[str(path)]},indent=2)+'\n')
print(json.dumps({'path':str(path),'bytes':len(code.encode())},ensure_ascii=False))
