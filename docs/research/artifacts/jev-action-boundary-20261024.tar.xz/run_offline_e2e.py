"""Owned local E2E lifecycle; restore the existing dev backend in finally."""
from pathlib import Path
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
import urllib.request

ROOT=Path(__file__).parent/'e2e'
REPO=Path('/Users/zbcjackson/src/tank')
PANE='%0'
def command(args):return subprocess.check_output(args,text=True).strip()
def listening():
    with socket.socket() as s:
        s.settimeout(.3)
        return s.connect_ex(('127.0.0.1',8000))==0
def health():
    try:
        with urllib.request.urlopen('http://127.0.0.1:8000/api/health',timeout=2) as response:
            return response.status
    except Exception:return None
def wait_for(predicate,seconds,message):
    start=time.monotonic()
    while time.monotonic()-start<seconds:
        if predicate():return
        time.sleep(.25)
    raise RuntimeError(message)

def main():
    original=command(['tmux','display-message','-p','-t',PANE,'#{pane_current_command}\t#{pane_current_path}'])
    assert original=='uv\t'+str(REPO/'backend/core'),original
    assert health()==200
    (ROOT/'original-pane.json').write_text(json.dumps({'pane':PANE,'original':original},indent=2)+'\n')
    owned=None;stopped=False;test_exit=None;restored=False;errors=[]
    try:
        subprocess.run(['tmux','send-keys','-t',PANE,'C-c'],check=True);stopped=True
        wait_for(lambda:not listening(),30,'original dev backend did not close')
        print('Original dev backend stopped; starting owned local-only E2E service.',flush=True)
        env=dict(os.environ);env['PYTHONPATH']=str(REPO/'backend')
        with (ROOT/'server.log').open('w') as log:
            owned=subprocess.Popen([str(REPO/'backend/.venv/bin/python'),str(ROOT/'offline_e2e_server_v2.py')],
                cwd=REPO/'backend',env=env,stdout=log,stderr=subprocess.STDOUT)
            wait_for(lambda:owned.poll() is not None or health()==200,60,'offline E2E backend readiness timeout')
            assert owned.poll() is None and health()==200
            config=json.loads((ROOT/'offline-e2e-effective-config.json').read_text())
            assert config['asr']=='asr-sherpa:asr' and config['llm_url'].startswith('http://127.0.0.1:')
            assert config['local_credential_asserted'] and str(ROOT/'offline-e2e.db') in config['database']
            assert not config['tts_enabled'] and not config['jobs_enabled']
            (ROOT/'verified-ready.json').write_text(json.dumps({'health':200,'effective':config},indent=2)+'\n')
            print('Actual local Sherpa / loopback model / isolated DB verified; running pnpm test.',flush=True)
            with (ROOT/'pnpm-test.log').open('w') as output:
                test_exit=subprocess.run(['pnpm','test'],cwd=REPO/'test',env=env,stdout=output,stderr=subprocess.STDOUT).returncode
            (ROOT/'test-exit.json').write_text(json.dumps({'exit_code':test_exit})+'\n')
    finally:
        if owned is not None:
            if owned.poll() is None:
                owned.send_signal(signal.SIGINT)
                try:owned.wait(timeout=25)
                except subprocess.TimeoutExpired:
                    owned.kill();owned.wait(timeout=10)
            (ROOT/'owned-stop.json').write_text(json.dumps({'owned_pid':owned.pid,'exit':owned.returncode})+'\n')
        if stopped:
            wait_for(lambda:not listening(),20,'owned E2E backend port remained open')
            current=command(['tmux','display-message','-p','-t',PANE,'#{pane_current_path}'])
            assert current==str(REPO/'backend/core'),current
            subprocess.run(['tmux','send-keys','-t',PANE,'uv run tank-backend --reload','Enter'],check=True)
            wait_for(lambda:health()==200,60,'original dev backend restore timeout')
            restored=True
            pane=command(['tmux','capture-pane','-t',PANE,'-p','-S','-50'])
            errors=[line for line in pane.splitlines() if re.search('error|traceback|exception',line,re.I)]
            (ROOT/'restore.json').write_text(json.dumps({'health':health(),'restored':restored,'reload_errors':errors},indent=2)+'\n')
            print('Owned E2E service closed; original dev backend restored.',flush=True)
    assert restored and not errors,errors
    assert test_exit==0,test_exit
    egress=json.loads((ROOT/'offline-e2e-egress.json').read_text())
    assert not egress['external_python_socket_attempts'] and not egress['real_provider_credentials']
    print('E2E passed; zero external sockets, real model credentials and remote ASR requests.',flush=True)

if __name__=='__main__':main()
