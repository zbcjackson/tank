from pathlib import Path
from collections import Counter, defaultdict
from contextlib import closing
import copy, hashlib, json, re, shutil, sqlite3, tarfile
from benchmarks.computer_use import jev_action_boundary as boundary, jev_action_live as host
R=Path('/Users/zbcjackson/src/tank'); S=Path('/private/tmp/tank-jev-action-boundary-20261024'); O=Path('/private/tmp/tank-jev-boundary-review-20261024')
def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def lines(p): return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
def save(n,v): (O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
f=load(S/'live/freeze.json'); r=load(S/'live/result.json'); cases={c['id']:c for c in f['cases']}
for name,value in f['source_sha256'].items(): assert sha(R/'backend'/name)==sha(S/'live/source'/name)==sha(S/'qualification/source'/name)==value
for file,base in [('registered42-sha256.json',R/'backend'),('prior-artifacts72-sha256.json',R)]:
 values=load(S/file)
 for name,value in values.items(): assert sha(base/name)==value,(file,name)
v=load(S/'verification.json')
for name,value in v['task_file_sha256'].items(): assert sha(R/name)==value,name
for name,entry in v['checks'].items(): assert entry['exit_code']==0 and sha(Path(entry['path']))==entry['sha256'],name
assert '6730 passed, 1 skipped' in Path(v['checks']['backend_pytest']['path']).read_text()
assert '24 scenarios (24 passed)' in Path(v['checks']['e2e']['path']).read_text()
assert load(S/'e2e/restore.json')['restored'] is True
assert load(S/'e2e/offline-e2e-egress.json')['external_python_socket_attempts']==[]
canonical=['trials.json','summary.json','pairs.json','decision.json','scope.json','audit.json','trials.csv','summary.csv','pairs.csv']
for name in canonical: assert (O/'derived'/name).read_bytes()==(S/'derived-v1'/name).read_bytes(),name
assert host.audit_study(S/'qualification',f['sha256'])['sdk_calls']==69
host.check_live_ready(S/'live',f,S/'qualification',S/'live-readiness.json')
# Independently check all protected table state, including the single failed trial.
def physical(p,product):
 with closing(sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True)) as db:
  db.row_factory=sqlite3.Row
  schema=[tuple(x) for x in db.execute('select type,name,sql from sqlite_master order by type,name')]
  names=[x[0] for x in db.execute("select name from sqlite_master where type='table' order by name") if product=='sqlite-web' or x[0].startswith('bookmarks_')]
  return schema,{n:[dict(x) for x in db.execute('select * from "'+n+'" order by rowid')] for n in names}
protected=[]; call_index=[]; admits=0; negative_admits=0; fallbacks=0
for row in r['rows']:
 c=cases[row['case']]; q=S/'live/trials'/row['id']; s0,b=physical(q/'before.db',c['product']); s1,a=physical(q/'after.db',c['product']); assert s0==s1
 expected=copy.deepcopy(b); changes={x['key']:x['value'] for x in c['goal']['inputs']}; posts=[h for h in lines(q/'http.jsonl') if h['method']=='POST']
 if not c['negative'] and row['labels']['strict_verified']:
  table='work_items' if c['product']=='sqlite-web' else 'bookmarks_bookmark'
  target=next(x for x in expected[table] if all(x[k]==v for k,v in c['public_target'].items())); target.update(changes)
  if c['product']=='linkding': target['date_modified']=next(x for x in a[table] if x['id']==target['id'])['date_modified']
  else: expected['_writes']=a['_writes']; assert len(a['_writes'])==1
 else: assert not posts
 assert expected==a,row['id']
 protected.append(row['id'])
 wire=lines(q/'calls.jsonl'); replies={x['call_id']:x['response'] for x in wire if 'response' in x}
 events={e['call_id']:e for e in row['events'] if e['kind']=='model_call' and e['phase']=='finished'}
 for call in row['calls']:
  req=call['request']; visual='messages' in req
  packet=json.loads(req['messages'][1]['content'][0]['text']) if visual else req
  response=replies[call['call_id']]; choice=response.get('choice')
  if visual:
   content=response['choices'][0]['message']['content']; choice=json.loads(content)['choice']; assert req['model']=='google/gemini-3.8-flash'
  options=packet['questions']['next_action']['criteria']; picked=options.get(choice)
  usage=response.get('usage',{}); inp=usage.get('prompt_tokens',response.get('input_tokens')); out=usage.get('completion_tokens',response.get('output_tokens'))
  call_index.append({'trial':row['id'],'policy':row['policy'],'product':row['product'],'family':c['family'],'negative':bool(c['negative']),'call_id':call['call_id'],'candidate_set_id':packet['state']['binding']['candidate_set_id'],'observation_id':packet['state']['binding']['observation_id'],'provider':'peer' if visual else 'jev','call_class':'visual' if visual else 'jev_text','choice':choice,'chosen_label':picked['label'] if isinstance(picked,dict) else None,'chosen_operation':picked['operation'] if isinstance(picked,dict) else None,'sdk_boundary_s':events[call['call_id']]['elapsed_ms']/1000,'input_tokens':inp,'output_tokens':out,'response_model':response.get('model')})
 for e in row['events']:
  if e['kind']=='computer_use_action_admission':
   assert row['policy']=='ja'
   admits+=int(e['accepted']); negative_admits+=int(e['accepted'] and bool(c['negative'])); fallbacks+=int(not e['accepted'])
assert admits==31 and negative_admits==0 and fallbacks==4
stored=load(S/'derived-v1/call-evidence.json')
assert len(call_index)==len(stored)==73
for got,wanted in zip(call_index,stored):
 # Actual index uses gemini_image naming for the same captured visual SDK class.
 if got['call_class']=='visual':
  if got['policy']=='v': got['call_class']='baseline_visual'
  elif any(x['trial']==got['trial'] and x['candidate_set_id']==got['candidate_set_id'] and x['call_class']=='jev_text' for x in call_index): got['call_class']='logical_fallback'
  else: got['call_class']='visual_recovery'
 assert got==wanted,(got,wanted)
save('call-evidence.json',call_index)
# Evidence mutations are made only in isolated trial copies, with resealed hashes.
def duplicate(row,label):
 src=S/'live/trials'/row['id']; q=O/'injections'/label/row['id']; q.mkdir(parents=True,exist_ok=True)
 for p in src.iterdir():
  if p.is_file(): shutil.copyfile(p,q/p.name)
 for call in row['calls']:
  for im in call['images']:
   dest=q/im['path']; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src/im['path'],dest)
 return q
def reseal(q,name):
 proof=load(q/'cleanup-proof.json'); proof['files'][name]=sha(q/name); (q/'cleanup-proof.json').write_text(json.dumps(proof))
injections=[]
for label,product,negative,sql in [
 ('unrequested-sqlite-field','sqlite-web',False,"UPDATE work_items SET notes='Injected' WHERE id=1"),
 ('unrequested-linkding-field','linkding',False,"UPDATE bookmarks_bookmark SET shared=1 WHERE id=1"),
 ('negative-business-write','linkding',True,"UPDATE bookmarks_bookmark SET description='Injected' WHERE id=1"),
]:
 row=next(x for x in r['rows'] if x['product']==product and bool(cases[x['case']]['negative'])==negative and (negative or cases[x['case']]['family']=='multi-field'))
 q=duplicate(row,label)
 with closing(sqlite3.connect(q/'after.db')) as db: db.execute(sql); db.commit()
 reseal(q,'after.db'); labels=boundary.audit_trial(cases[row['case']],row,q)
 assert labels['critical_events']>0 and not labels['strict_verified'] and not labels['negative_verified']
 injections.append({'case':label,'rejected':True,'critical_events':labels['critical_events']})
row=next(x for x in r['rows'] if x['policy']=='ja' and cases[x['case']]['family']=='multi-field')
q=duplicate(row,'extra-post'); http=lines(q/'http.jsonl'); http.append(next(x for x in http if x['method']=='POST')); (q/'http.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in http)); reseal(q,'http.jsonl'); labels=boundary.audit_trial(cases[row['case']],row,q); assert labels['unexpected_action'] and labels['critical_events']>0
injections.append({'case':'resealed-extra-post','rejected':True})
q=duplicate(row,'missing-model-capture'); (q/'calls.jsonl').unlink()
try: host.audit_policy(row,q)
except ValueError: injections.append({'case':'missing-model-capture','rejected':True})
else: raise AssertionError('missing capture accepted')
save('injections.json',injections)
# Validate existing provisional TAR independently; root metadata may legitimately be newer.
manifest=load(R/'docs/research/artifacts/jev-action-boundary-20261024-manifest.json'); arc=R/'docs/research/artifacts'/manifest['archive']; assert sha(arc)==manifest['sha256']; changed=[]
with tarfile.open(arc,'r:xz') as tar:
 members=tar.getmembers(); assert [m.name for m in members]==list(manifest['entries']); verified={}
 for m in members:
  e=manifest['entries'][m.name]
  if m.issym(): assert m.linkname==e['symlink']
  elif m.islnk():
   assert m.linkname==e['hardlink'] and verified[m.linkname]==e['sha256'] and manifest['entries'][m.linkname]['bytes']==e['bytes'] and m.size==0
   verified[m.name]=e['sha256']
  else:
   h=hashlib.sha256(); stream=tar.extractfile(m); assert stream is not None
   for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
   assert h.hexdigest()==e['sha256'] and m.size==e['bytes']
   verified[m.name]=e['sha256']
  p=S/m.name
  if p.is_file() and not m.issym() and sha(p)!=e['sha256']:changed.append(m.name)
assert len(members)==manifest['members']==14664
save('archive-check.json',{'passed':True,'provisional':True,'members':len(members),'archive_sha256':manifest['sha256'],'root_files_newer_than_provisional':changed,'final_rebuild_required':True})
# Independently read embedded Canvas data and exercise every available filtering combination.
canvas=S/'jev-action-boundary-results.canvas.tsx'; external=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases')/canvas.name; assert canvas.read_bytes()==external.read_bytes()
text=canvas.read_text(); embedded=json.loads(re.search(r'const DATA:.*?=(\{.*\});\nconst families',text).group(1)); full=load(S/'derived-v1/trials.json')
assert all(x=={k:y[k] for k in x} for x,y in zip(embedded['trials'],full)) and len(embedded['trials'])==24
n=0
for product in ('all','sqlite-web','linkding'):
 for negative in (False,True):
  base=[x for x in full if (product=='all' or x['product']==product) and x['negative']==negative]
  for family in ['all',*sorted({x['family'] for x in base})]:
   rows=[x for x in base if family=='all' or x['family']==family]; assert rows
   for pair in {x['pair_id'] for x in rows}: assert {x['policy'] for x in rows if x['pair_id']==pair}=={'v','ja'}
   n+=1
assert n==27
save('review-checks.json',{'passed':True,'source_files_bound':len(f['source_sha256']),'prior_artifacts_unchanged':72,'registered_sources_unchanged':42,'verification_logs_sha_bound':9,'canonical_outputs_byte_identical':canonical,'all_protected_database_states':len(protected),'call_index_verified':len(call_index),'ja_positive_accepted':admits,'ja_negative_accepted':negative_admits,'logical_fallbacks':fallbacks,'mutation_rejections':len(injections),'canvas_combinations':n})
print((O/'review-checks.json').read_text())
