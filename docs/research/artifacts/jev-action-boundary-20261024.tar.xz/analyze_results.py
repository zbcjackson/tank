"""Descriptive complete-denominator boundary analysis; no provider calls."""
from pathlib import Path
import argparse,collections,csv,hashlib,json,statistics
from benchmarks.computer_use import jev_action_live as host,jev_action_boundary as boundary
p=argparse.ArgumentParser();p.add_argument('--study',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
f=json.loads((a.study/'freeze.json').read_text());host.load_freeze(a.study,f['sha256']);r=json.loads((a.study/'result.json').read_text());cases={c['id']:c for c in f['cases']};assert len(r['rows'])==24
complete=r['completed'] is True
audit=host.audit_study(a.study,f['sha256']) if complete else {'complete':False,'stop_reason':r['spend']['stop_reason'],'scope':'Incomplete batch: unrun slots are not measured outcomes.'}
rows=[]
for row in r['rows']:
 c=cases[row['case']];out={k:row[k] for k in ('id','case','policy','product','pair_id','cluster_id','position','condition','status','attempted','cleanup_confirmed')}
 out.update(family=c['family'],negative=bool(c['negative']),positive_success=False,negative_success=False,critical_events=0,host_reason=row.get('result',{}).get('reason'),elapsed_s=row.get('elapsed_ms',0)/1000,sdk_boundary_s=0,remainder_s=0,capped_completion_s=None,text_calls=0,visual_calls=0,logical_fallbacks=0,sdk_calls=len(row.get('calls',[])),tokens=row.get('usage',{}).get('total_tokens',0),audited=False)
 if 'labels' in row:
  q=a.study/'trials'/row['id'];labels=boundary.audit_trial(c,row,q);metrics=host.audit_policy(row,q);assert labels==row['labels'] and metrics==row['policy_metrics']
  out.update(positive_success=labels['strict_verified'],negative_success=labels['negative_verified'],critical_events=labels['critical_events'],audited=True,**metrics)
  sdk=sum(e['elapsed_ms'] for e in row['events'] if e['kind']=='model_call' and e['phase']=='finished')/1000
  assert sdk<=out['elapsed_s']+.001;out.update(sdk_boundary_s=sdk,remainder_s=out['elapsed_s']-sdk)
  if not c['negative']:out['capped_completion_s']=out['elapsed_s'] if labels['strict_verified'] else 120
 rows.append(out)
def average(rs,key):return statistics.mean(x[key] for x in rs) if rs else None
summary=[]
for product in ('all','sqlite-web','linkding'):
 for policy in ('v','ja'):
  subset=[x for x in rows if x['policy']==policy and (product=='all' or x['product']==product)];pos=[x for x in subset if not x['negative']];neg=[x for x in subset if x['negative']]
  summary.append({'product':product,'policy':policy,'positive_planned':len(pos),'positive_attempted':sum(x['attempted'] for x in pos),'positive_passed':sum(x['positive_success'] for x in pos),'negative_planned':len(neg),'negative_attempted':sum(x['attempted'] for x in neg),'negative_passed':sum(x['negative_success'] for x in neg),'positive_mean_capped_s':average(pos,'capped_completion_s') if complete else None,'positive_mean_actual_s':average(pos,'elapsed_s') if complete else None,'positive_mean_sdk_s':average(pos,'sdk_boundary_s') if complete else None,'negative_mean_exit_s':average(neg,'elapsed_s') if complete else None,**{k:sum(x[k] for x in subset) for k in ('text_calls','visual_calls','logical_fallbacks','sdk_calls','tokens','critical_events')}})
pairs=[]
for pair in dict.fromkeys(x['pair_id'] for x in rows):
 group={x['policy']:x for x in rows if x['pair_id']==pair};assert set(group)=={'v','ja'}
 v,j=group['v'],group['ja'];pairs.append({'pair_id':pair,'product':v['product'],'family':v['family'],'negative':v['negative'],'v_status':v['status'],'ja_status':j['status'],'v_success':v['negative_success'] if v['negative'] else v['positive_success'],'ja_success':j['negative_success'] if j['negative'] else j['positive_success'],'v_elapsed_s':v['elapsed_s'],'ja_elapsed_s':j['elapsed_s'],'ja_minus_v_capped_s':j['capped_completion_s']-v['capped_completion_s'] if complete and not v['negative'] else None,'both_positive_success':not v['negative'] and v['positive_success'] and j['positive_success']})
regressions=[x['pair_id'] for x in pairs if not x['negative'] and x['v_success'] and not x['ja_success']];shared=[x['pair_id'] for x in pairs if not x['negative'] and not x['v_success'] and not x['ja_success']];neg_fail=[x['pair_id'] for x in pairs if x['negative'] and not x['ja_success']]
all_s={x['policy']:x for x in summary if x['product']=='all'};critical=sum(x['critical_events'] for x in rows);faster=complete and all_s['ja']['positive_mean_capped_s']<all_s['v']['positive_mean_capped_s'];support=bool(complete and not critical and not regressions and not shared and not neg_fail and faster)
common_ids={x['pair_id'] for x in pairs if x['both_positive_success']};common={p:average([x for x in rows if x['policy']==p and x['pair_id'] in common_ids],'elapsed_s') for p in ('v','ja')}
decision={'complete':complete,'supported_for_next_explicit_experimental_wiring':support,'default_configuration_changed':False,'critical_events':critical,'quality_regression_pairs':regressions,'shared_failed_positive_pairs':shared,'ja_negative_failure_pairs':neg_fail,'positive_capped_mean_faster':faster,'common_successful_positive_pairs':len(common_ids),'common_successful_positive_actual_mean_s':common,'scope':'Engineering screening only; not formal adoption or population accuracy certification. A V pre-SDK host refusal remains a failed planned task, not Gemini recognition failure.'}
scope={'freeze_sha256':f['sha256'],'audit_sha256':audit.get('sha256'),'planned_trials':24,'task_instances':12,'conditions':['cold'],'models':f['models'],'price':'record-only/unpriced; provider token definitions differ, not an invoice','timing':'Full task includes setup/authentication/observations/capture/dispatch/readback/cleanup. SDK boundary includes local accounting/capture/network/provider; remainder is unseparated.','limitations':['Two known products; new pages/fields/semantic task boundaries are development instances, correlated by product/workflow.','Qualification discovered V schema-title visual_target_unavailable before SDK; retained in full denominators and 120s failure penalty.','Shared completion/progress facts derive from actual records and public criteria/inputs plus full visible readback; no private target selection supplied.','Provider cache/routing/load uncontrolled; no general model capability or intrinsic latency ranking.','No new Jev image/Box or production default; no real requests beyond the one declared batch.','Negative public titles include Absent/Shared semantic hints; raw absence/nonuniqueness and safe exits verified, neutral-title refusal generalization unproven. Engineering support is limited to controlled development configuration.']}
a.output.mkdir(exist_ok=False)
for name,data in [('trials',rows),('summary',summary),('pairs',pairs),('decision',decision),('scope',scope),('audit',audit)]:
 (a.output/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
for name,data in [('trials',rows),('summary',summary),('pairs',pairs)]:
 with (a.output/(name+'.csv')).open('w',newline='') as stream:
  w=csv.DictWriter(stream,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps({'all_policies':list(all_s.values()),'decision':decision},ensure_ascii=False,indent=2))
