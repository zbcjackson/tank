"""Raw evidence verification independent of the study and analysis implementations."""
from pathlib import Path
from contextlib import closing
from urllib.parse import urlsplit
import argparse,base64,collections,csv,hashlib,json,sqlite3,statistics
from bs4 import BeautifulSoup
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('--study',type=Path,required=True);p.add_argument('--derived',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def lines(p):return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
def physical(p,product):
 with closing(sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True)) as db:
  db.row_factory=sqlite3.Row;schema=[list(x) for x in db.execute('select type,name,sql from sqlite_master order by type,name')];names=[x[0] for x in db.execute("select name from sqlite_master where type='table' order by name")]
  if product=='linkding':names=[n for n in names if n.startswith('bookmarks_')]
  tables={n:[dict(x) for x in db.execute('select * from "'+n.replace('"','""')+'" order by rowid')] for n in names}
  if product=='sqlite-web':records=tables['work_items']
  else:
   tags={x['id']:x['name'] for x in tables['bookmarks_tag']};members=tables['bookmarks_bookmark_tags'];records=[]
   for r in tables['bookmarks_bookmark']:
    x={k:r[k] for k in ('id','url','title','description','notes','owner_id')};x.update({k:bool(r[k]) for k in ('unread','shared','is_archived')});x['tag_names']=sorted(tags[z['tag_id']] for z in members if z['bookmark_id']==r['id']);records.append(x)
  return schema,tables,records
f=load(a.study/'freeze.json');r=load(a.study/'result.json');d=load(a.derived/'trials.json');summary=load(a.derived/'summary.json');pairs=load(a.derived/'pairs.json');assert r['mode']=='live'
assert len(f['schedule'])==len(r['rows'])==len(d)==24 and [x['id'] for x in r['rows']]==[x['id'] for x in f['schedule']]
cases={c['id']:c for c in f['cases']};derived={x['id']:x for x in d};diags=collections.defaultdict(list)
for e in lines(a.study/'sdk-diagnostics.jsonl'):diags[e['call_id']].append(e)
callids=set();tokens=0;checks=[];app_files=0
for row in r['rows']:
 c=cases[row['case']];v=derived[row['id']];assert all(row[k]==x for k,x in next(s for s in f['schedule'] if s['id']==row['id']).items())
 if not row['attempted']:assert row['status']=='not_run' and not v['audited'];continue
 q=a.study/'trials'/row['id']
 if 'labels' not in row:continue
 proof=load(q/'cleanup-proof.json');assert row['status']=='finished' and row['cleanup_confirmed'] and not row['cleanup_errors']
 assert proof['channel_closed'] and proof['browser_closed'] and proof['process_returncode'] is not None and proof['audit_failed'] is False
 for name,value in proof['files'].items():
  if value is None:assert name in ('calls.jsonl','dispatch-witness.jsonl') and not (q/name).exists()
  else:assert sha(q/name)==value
 assert proof['files']==row['labels']['evidence']['files']
 if c['product']=='linkding':
  expected=f['apps']['linkding']['source_files'];actual={str(z.relative_to(q/'app')):sha(z) for z in (q/'app').rglob('*') if z.is_file() and not set(z.relative_to(q/'app').parts)&{'data','__pycache__','.venv','node_modules'} and z.suffix!='.pyc'};assert actual==expected;app_files+=len(actual)
 schema0,tables0,before=physical(q/'before.db',c['product']);schema1,tables1,after=physical(q/'after.db',c['product']);assert schema0==schema1 and before==c['seed']
 criterion=json.loads(next(x.split('Target predicate: ',1)[1] for x in c['goal']['constraints'] if x.startswith('Target predicate: ')));assert criterion==c['public_target'];matches=[x for x in before if all(x.get(k)==value for k,value in criterion.items())]
 changes={x['key']:x['value'] for x in c['goal']['inputs']};expected=json.loads(json.dumps(before))
 if len(matches)==1:next(x for x in expected if x['id']==matches[0]['id']).update(changes)
 soup=BeautifulSoup((q/'final.html').read_text(),'html.parser');posts=[x for x in lines(q/'http.jsonl') if x['method']=='POST'];witness=lines(q/'dispatch-witness.jsonl');native=[x for x in witness if x['phase']=='authorized' or x.get('native_called') is True]
 for x in witness:
  if x['phase']=='authorized':assert x['binding']['goal_id']==c['id'] and x['binding']['scope']==c['goal']['scope'] and x['authorization_active'] is True
 if c['product']=='sqlite-web':
  cols=[x.get('data-col') for x in soup.select('table.cell-content thead th')];visible=[{k:td.get_text(' ',strip=True) for k,td in zip(cols,tr.find_all('td',recursive=False)) if k} for tr in soup.select('table.cell-content tbody tr')];wanted=[{k:str(x[k]) for k in ('id','title','notes')} for x in after];listpath='/work_items/content/'
 else:
  visible=[{'id':li.get('data-bookmark-id'),'title':li.select_one('.title a[href]').get_text(' ',strip=True),'url':li.select_one('.title a[href]').get('href'),'description':li.select_one('.description').get_text(' ',strip=True) if li.select_one('.description') else ''} for li in soup.select('li[data-bookmark-id]')];wanted=[{'id':str(x['id']),'title':x['title'],'url':x['url'],'description':' | '.join(filter(None,[', '.join(x['tag_names']),x['description']]))} for x in after];listpath='/bookmarks'
 list_ok=sorted(visible,key=lambda x:x['id'])==sorted(wanted,key=lambda x:x['id']) and urlsplit(row['final_url']).path==listpath
 if c['negative']:
  success=bool(len(matches)!=1 and tables0==tables1 and not posts and not native and list_ok and row['elapsed_ms']<=120000 and row['result']['reason'] in ('none','escalate','ambiguous','need_more_context','no_progress'));assert success==row['labels']['negative_verified']==v['negative_success']
 else:
  identity=matches[0]['id'] if len(matches)==1 else None;edit=(f'/work_items/update/{base64.urlsafe_b64encode(json.dumps([identity],separators=(",",":")).encode()).decode().rstrip("=")}/' if c['product']=='sqlite-web' else f'/bookmarks/{identity}/edit')
  post_ok=len(posts)==1 and posts[0]['path']==edit and posts[0]['status'].startswith('302 ')
  success=bool(len(matches)==1 and after==expected and list_ok and post_ok and row['elapsed_ms']<=120000)
  assert success==row['labels']['strict_verified']==v['positive_success']
  if success:
   for name,values in tables0.items():
    if name in ('work_items','_writes','bookmarks_bookmark'):continue
    assert values==tables1[name]
   if c['product']=='linkding':
    expected_table=json.loads(json.dumps(tables0['bookmarks_bookmark']));target=next(x for x in expected_table if x['id']==identity);actual=next(x for x in tables1['bookmarks_bookmark'] if x['id']==identity);assert actual['date_modified']>target['date_modified'];target.update(changes);target['date_modified']=actual['date_modified'];assert expected_table==tables1['bookmarks_bookmark']
   else:assert len(tables1['_writes'])==1 and tables1['_writes'][0]['id']==identity and tables1['_writes'][0]['operation']=='update'
 assert row['labels']['critical_events']==v['critical_events']
 wire=lines(q/'calls.jsonl');raw=[x for x in wire if 'request' in x];responses={x['call_id']:x['response'] for x in wire if 'response' in x};assert raw==row['calls'];finished={x['call_id']:x for x in row['events'] if x['kind']=='model_call' and x['phase']=='finished'};assert set(responses)==set(finished)=={x['call_id'] for x in raw}
 rowtokens=0;text=0;images=0
 for call in raw:
  cid=call['call_id'];assert cid not in callids;callids.add(cid);rec=r['spend']['requests'][cid];events=diags[cid];event=finished[cid];response=responses[cid]
  assert [x['phase'] for x in events]==['invoke_started','invoke_returned','call_returned'];assert events[-1]['usage_status']==events[-1]['reservation_status']==rec['status']=='known';assert events[-1]['completion_status']==event['status']=='returned';assert rec['trial']==row['id']
  usage=(response['usage']['prompt_tokens'],response['usage']['completion_tokens']) if 'usage' in response else (response['input_tokens'],response['output_tokens']);assert usage==(rec['input_tokens'],rec['output_tokens'])==(event['prompt_tokens'],event['completion_tokens'])==(events[-1]['input_tokens'],events[-1]['output_tokens']);rowtokens+=sum(usage)
  for im in call['images']:
   assert sha(q/im['path'])==im['sha256']
   with Image.open(q/im['path']) as png:assert png.format=='PNG' and png.size==(1280,720);png.verify()
  if call['images']:images+=1
  else:text+=1
 assert (text,images,len(raw),rowtokens)==(v['text_calls'],v['visual_calls'],v['sdk_calls'],v['tokens']);assert rowtokens==row['usage']['total_tokens'];tokens+=rowtokens
 sdk=sum(x['elapsed_ms'] for x in finished.values())/1000;assert abs(v['sdk_boundary_s']-sdk)<1e-9 and abs(v['elapsed_s']-row['elapsed_ms']/1000)<1e-9
 if not c['negative']:assert v['capped_completion_s']==(v['elapsed_s'] if success else 120)
 checks.append({'id':row['id'],'policy':row['policy'],'negative':bool(c['negative']),'success':success,'sdk_calls':len(raw),'tokens':rowtokens})
if r['completed']:
 assert len(checks)==24 and callids==set(r['spend']['requests'])==set(diags);assert tokens==r['spend']['batch']['known_tokens'];assert r['spend']['batch']['reserved_tokens']==r['spend']['batch']['reserved_nano_usd']==0
 for s in summary:
  rs=[x for x in d if x['policy']==s['policy'] and (s['product']=='all' or x['product']==s['product'])];pos=[x for x in rs if not x['negative']];neg=[x for x in rs if x['negative']]
  assert (s['positive_planned'],s['positive_passed'],s['negative_planned'],s['negative_passed'])==(len(pos),sum(x['positive_success'] for x in pos),len(neg),sum(x['negative_success'] for x in neg))
  for key,col,group in [('positive_mean_capped_s','capped_completion_s',pos),('positive_mean_actual_s','elapsed_s',pos),('positive_mean_sdk_s','sdk_boundary_s',pos),('negative_mean_exit_s','elapsed_s',neg)]:assert abs(s[key]-statistics.mean(x[col] for x in group))<1e-9
  for key in ('text_calls','visual_calls','logical_fallbacks','sdk_calls','tokens','critical_events'):assert s[key]==sum(x[key] for x in rs)
 for pair in pairs:
  group={x['policy']:x for x in d if x['pair_id']==pair['pair_id']};assert set(group)=={'v','ja'}
  if not pair['negative']:assert abs(pair['ja_minus_v_capped_s']-(group['ja']['capped_completion_s']-group['v']['capped_completion_s']))<1e-9
for name in ('trials','summary','pairs'):
 with (a.derived/(name+'.csv')).open() as stream:csvrows=list(csv.DictReader(stream))
 assert csvrows==[{k:('' if value is None else str(value)) for k,value in x.items()} for x in load(a.derived/(name+'.json'))]
report={'passed':True,'complete':r['completed'],'planned':24,'raw_trials_verified':len(checks),'sdk_calls_verified':len(callids),'known_tokens_verified':tokens,'actual_linkding_source_files_verified':app_files,'trials':checks,'input_sha256':{str(z):sha(z) for root in (a.study,a.derived) for z in root.rglob('*') if z.is_file()},'scope':'No imports from study/analyzer. Independent raw SQL/HTML, public predicate cardinality, protected fields/tables, dispatch/seal, original responses/ledger/diagnostics/PNG, derived means/pairs/CSV. No statistical adoption or invoice claim.'}
a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('passed','complete','raw_trials_verified','sdk_calls_verified','known_tokens_verified','actual_linkding_source_files_verified')}))
