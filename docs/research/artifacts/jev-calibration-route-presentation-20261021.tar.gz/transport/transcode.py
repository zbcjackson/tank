"""Losslessly transcode the already verified TAR stream from gzip to XZ."""
import gzip
import hashlib
import json
import lzma
from pathlib import Path
import shutil

repo=Path('/Users/zbcjackson/src/tank/docs/research/artifacts')
source=repo/'jev-calibration-route-20261021.tar.gz'
original_manifest=repo/'jev-calibration-route-20261021-manifest.json'
target=repo/'jev-calibration-route-20261021.tar.xz'
target_manifest=repo/'jev-calibration-route-20261021-xz-manifest.json'
manifest=json.loads(original_manifest.read_text())
assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['sha256']
assert not target.exists() and not target_manifest.exists()
digest=hashlib.sha256();total=0
with gzip.open(source,'rb') as raw,lzma.open(target,'xb',preset=6) as compressed:
    while chunk:=raw.read(1024*1024):
        digest.update(chunk);total+=len(chunk);compressed.write(chunk)
check=hashlib.sha256();readback=0
with lzma.open(target,'rb') as raw:
    while chunk:=raw.read(1024*1024):
        check.update(chunk);readback+=len(chunk)
assert readback==total and check.hexdigest()==digest.hexdigest()
new={**manifest,'archive':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
     'original_gzip':{k:manifest[k]for k in ('archive','bytes','sha256')},
     'tar_stream_bytes':total,'tar_stream_sha256':digest.hexdigest(),'tar_stream_identical':True,
     'transport':'Lossless gzip-to-XZ conversion; identical TAR headers, regular members and hardlinks. Original gzip and its manifest retained as packaging intermediates; original manifest is in presentation supplement.'}
target_manifest.write_text(json.dumps(new,indent=2)+'\n')
receipt={k:v for k,v in new.items()if k!='members'}
Path('/private/tmp/tank-calibration-transcode.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert target.stat().st_size<100_000_000,'Retain both originals and choose reviewed transport before committing'
for path in (source,original_manifest):
    destination=Path('/private/tmp')/('tank-calibration-original-'+path.name)
    assert not destination.exists();shutil.move(path,destination)
print(json.dumps(receipt))
