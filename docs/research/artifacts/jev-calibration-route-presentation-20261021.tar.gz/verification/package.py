"""Immutable presentation/type-fix supplement; preserve the original data archive."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile
from dotenv import dotenv_values

repo=Path('/Users/zbcjackson/src/tank');tmp=Path('/private/tmp')
sha=lambda data:hashlib.sha256(data).hexdigest()
items={
 'presentation/jev-calibration-route.canvas.tsx':Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-calibration-route.canvas.tsx'),
 'presentation/generate.py':tmp/'tank-calibration-canvas.py',
 'presentation/type-fix.json':tmp/'tank-calibration-presentation-fix.json',
 'presentation/tsc-before.log':tmp/'tank-calibration-canvas-tsc.log',
 'presentation/tsc-after.log':tmp/'tank-calibration-canvas-tsc-v2.log',
 'transport/transcode.py':tmp/'tank-calibration-transcode.py',
 'transport/transcode.json':tmp/'tank-calibration-transcode.json',
 'transport/transcode.log':tmp/'tank-calibration-transcode.log',
 'transport/original-gzip-member-manifest.json':tmp/'tank-calibration-original-jev-calibration-route-20261021-manifest.json',
 'verification/package.py':Path(__file__),
}
fix=json.loads(items['presentation/type-fix.json'].read_text())
assert sha(items['presentation/jev-calibration-route.canvas.tsx'].read_bytes())==fix['new_canvas_sha256']
assert items['presentation/tsc-after.log'].read_bytes()==b''
old=json.loads((tmp/'tank-calibration-old-artifacts.json').read_text())
assert len(old)==38 and all(sha((repo/name).read_bytes())==value['sha256']for name,value in old.items())
values={**dotenv_values(repo/'backend/core/.env'),**os.environ}
credentials={v.encode()for k,v in values.items()if v and len(v)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)}
assert len(credentials)==21
core=repo/'docs/research/artifacts/jev-calibration-route-20261021.tar.xz'
assert sha(core.read_bytes())=='11d5c73c56b1637349fa5984d5e1243e0d08e9442654d9b0e3c3c80a2bb1a972'
extra={'verification/checks.json':(json.dumps({'Canvas_tsc_exit':0,'Canvas_data_unchanged':True,'old_files_unchanged':38,'actual_credentials_scanned':21,'credential_matches':0,'data_archive_sha256':sha(core.read_bytes()),'model_calls_added':0},indent=2)+'\n').encode()}
members=[]
for name in sorted(set(items)|set(extra)):
 data=extra[name]if name in extra else items[name].read_bytes();assert not any(secret in data for secret in credentials),name
 members.append({'name':name,'bytes':len(data),'sha256':sha(data)})
target=repo/'docs/research/artifacts/jev-calibration-route-presentation-20261021.tar.gz'
manifest_path=target.with_name('jev-calibration-route-presentation-20261021-manifest.json')
assert not target.exists()and not manifest_path.exists()
with target.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w')as archive:
 for member in members:
  name=member['name'];data=extra[name]if name in extra else items[name].read_bytes();assert sha(data)==member['sha256'];info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
with tarfile.open(target)as archive:
 assert len(archive.getmembers())==len(members)
 for member in members:
  stream=archive.extractfile(member['name']);assert stream is not None;data=stream.read();assert sha(data)==member['sha256']and len(data)==member['bytes'];assert not any(secret in data for secret in credentials)
manifest={'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'data_archive_sha256':sha(core.read_bytes()),'actual_credentials_scanned':21,'credential_matches':0,'members':members}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items()if k!='members'}));print('members',len(members))
