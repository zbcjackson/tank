"""Independent raw-call, database, HTTP, source and denominator audit. No host imports."""
import base64,hashlib,json,re,sqlite3,statistics,sys
from pathlib import Path
p=Path(sys.argv[1]);out=Path(sys.argv[2]);root=Path('/Users/zbcjackson/src/tank/backend')
h=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda o:json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'))
f=json.loads((p/'freeze.json').read_text());r=json.loads((p/'result.json').read_text());fc=dict(f);fc.pop('sha256');assert h(enc(fc).encode())==f['sha256']==r['sha256']
assert all(h((root/n).read_bytes())==sha for n,sha in f['source_sha256'].items())
appenv=Path(f['app']['python']).parent.parent
assert all(h((appenv/n).read_bytes())==sha for n,sha in f['app']['files'].items())
first={x['case']:x['arm']for x in reversed(f['schedule'])}
assert list(first.values()).count('v')==list(first.values()).count('jt')==3
for kind in('insert','update'):assert sorted(first[c['id']]for c in f['cases']if c['kind']==kind and not c['recovery'])==['jt','v']
assert len(r['rows'])==len(f['schedule'])==12
assert [(x['id'],x['case'],x['arm'])for x in r['rows']]==[(x['id'],x['case'],x['arm'])for x in f['schedule']]
assert r['spend']==json.loads((p/'spend.jsonl').read_text().splitlines()[-1]);cases={c['id']:c for c in f['cases']};ids=set();calls=[];rows=[];pngs=0
for row in r['rows']:
 c=cases[row['case']];d={'id':row['id'],'case':row['case'],'arm':row['arm'],'kind':c['kind'],'recovery':c['recovery'],'status':row['status'],'strict_completed':False,'recovery_completed':False,'cleanup_confirmed':row.get('cleanup_confirmed',False),'capped_completion_ms':120000}
 if row['status']=='not_run':rows.append(d);continue
 rp=p/row['id'];saved=rp/'row.json'
 if saved.exists():assert json.loads(saved.read_text())==row
 raw=[json.loads(l)for l in (rp/'calls.jsonl').read_text().splitlines()]if(rp/'calls.jsonl').exists()else[]
 requests=[q for q in raw if'request'in q];replies={q['call_id']:q['response']for q in raw if'response'in q};sequence=[];it=ot=0;reported=0.0;invalid=0
 if 'calls'in row:assert requests==row['calls']
 for q in requests:
  cid=q['call_id'];assert cid not in ids;ids.add(cid);req=q['request'];peer='messages'in req;model='peer'if peer else'jev';sequence.append(model);ledger=r['spend']['requests'][cid];assert ledger['trial']==row['id']
  packet=json.loads(req['messages'][1]['content'][0]['text'])if peer else req
  assert not any(k in packet['state']for k in('oracle','seed','http','recovery','kind'))
  assert not any(tag in packet['state']['goal']['goal_id']for tag in('normal','recovery','insert','update'))
  if peer:
   assert req['model']==f['models']['peer']['model']and req['response_format']=={'type':'json_object'}
   for info in q['images']:
    parts=req['messages'][1]['content'];png=base64.b64decode(parts[1]['image_url']['url'].split(',',1)[1]);assert png== (rp/info['path']).read_bytes()and h(png)==info['sha256']and png.startswith(b'\x89PNG\r\n\x1a\n');pngs+=1
  else:assert not q['images']
  a=replies.get(cid);known=ledger['status']=='known';prompt=completion=None
  if a is not None:
   if peer:
    usage=a.get('usage')or{};prompt,completion=usage.get('prompt_tokens'),usage.get('completion_tokens');reported+=usage.get('cost')or 0
    try:choice=json.loads(a['choices'][0]['message']['content'])['choice']
    except (ValueError,KeyError,IndexError,TypeError):choice=None
   else:prompt,completion=a.get('input_tokens'),a.get('output_tokens');choice=a.get('choice')
   invalid+=choice not in packet['questions']['next_action']['criteria']
  if known:
   assert isinstance(prompt,int)and isinstance(completion,int)and prompt==ledger['input_tokens']and completion==ledger['output_tokens'];it+=prompt;ot+=completion
  calls.append({'row':row['id'],'call_id':cid,'model':model,'status':ledger['status'],'input_tokens':prompt if known else None,'output_tokens':completion if known else None,'estimate_nano_usd':prompt*f['price_nano_usd'][model][0]+completion*f['price_nano_usd'][model][1]if known else None})
 purposes={e['call_id']:e['purpose']for e in row.get('events',[])if e['kind']=='model_call'and'call_id'in e and'purpose'in e}
 response_positions={q['call_id']:i for i,q in enumerate(raw)if'response'in q};text_controls=[];proofs=[];bypasses=0;recovery_images=0
 routes={e['observation_id']:e.get('reason')for e in row.get('events',[])if e['kind']=='computer_use_route'}
 for index,q in enumerate(raw):
  if'request'not in q:continue
  req=q['request'];peer='messages'in req;packet=json.loads(req['messages'][1]['content'][0]['text'])if peer else req;binding=packet['state']['binding'];cid=q['call_id']
  if not peer and replies.get(cid,{}).get('choice')in('none','ambiguous','need_more_context','escalate')and r['spend']['requests'][cid]['status']=='known':text_controls.append((cid,binding))
  if peer:
   reason=routes.get(binding['observation_id']);bypasses+=row['arm']=='jt'and reason=='visual_required';recovery_images+=reason=='repeated_state'
   if purposes.get(cid)=='computer_use.visual_fallback':
    prior=[text for text,b in text_controls if b==binding and response_positions[text]<index];assert prior
    proofs.append({'text_call_id':prior[-1],'visual_call_id':cid,'binding':binding})
 http=[json.loads(l)for l in(rp/'http.jsonl').read_text().splitlines()]if(rp/'http.jsonl').exists()else[]
 if 'http'in row:assert row['http']==http
 dbpath=rp/'fixture.db';actual=None;business=False;schema_ok=False;write_ok=False
 if dbpath.exists():
  db=sqlite3.connect(dbpath.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
  try:
   actual={'records':[dict(x)for x in db.execute('SELECT * FROM work_items ORDER BY id')],'writes':[dict(x)for x in db.execute('SELECT * FROM _writes ORDER BY rowid')],'schema':[list(x)for x in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]}
  except sqlite3.Error:actual=None
  finally:db.close()
 if actual is not None:
  if 'database'in row:assert row['database']==actual
  seed=json.loads(json.dumps(c['seed']));values={v['key']:v['value']for v in c['goal']['inputs']};expected=json.loads(json.dumps(seed))
  if c['kind']=='insert':
   expected.append({'id':max(x['id']for x in seed)+1,'title':values['title'],'notes':values['notes']});old=None;target=expected[-1]
  else:
   target_id=int(re.search(r'record id (\d+)',c['goal']['intent']).group(1));old=next(x for x in seed if x['id']==target_id);target=next(x for x in expected if x['id']==target_id);target['title']=values['title']
  assert expected==c['oracle']['rows']and c['goal']['completion']==[{'key':'status:Records','value':enc(expected)}]
  business=actual['records']==expected
  expected_write={'operation':c['kind'],'id':target['id'],'old_title':old['title']if old else None,'new_title':target['title'],'old_notes':old['notes']if old else None,'new_notes':target['notes']}
  write_ok=actual['writes']==[expected_write]
  expected_schema=[['table','_writes','CREATE TABLE _writes(operation TEXT, id INTEGER, old_title TEXT, new_title TEXT, old_notes TEXT, new_notes TEXT)'],['table','work_items','CREATE TABLE work_items(id INTEGER PRIMARY KEY, title TEXT NOT NULL, notes TEXT NOT NULL)']]
  for op in('delete','insert','update'):
   old_t,old_n=('NULL','NULL')if op=='insert'else('old.title','old.notes');new_t,new_n=('NULL','NULL')if op=='delete'else('new.title','new.notes');identity='old.id'if op=='delete'else'new.id'
   expected_schema.append(['trigger','log_'+op,f"CREATE TRIGGER log_{op} AFTER {op} ON work_items BEGIN INSERT INTO _writes VALUES ('{op}',{identity},{old_t},{new_t},{old_n},{new_n}); END"])
  schema_ok=actual['schema']==expected_schema
 posts=sum(x['method']=='POST'for x in http);res=row.get('result',{});strict=bool(row['status']=='finished'and row.get('cleanup_confirmed')and row.get('app_unchanged')and row.get('elapsed_ms',float('inf'))<=120000 and res.get('status')=='completed'and business and schema_ok and write_ok and posts==1)
 assert strict==row['strict_completed']
 injection=[i for i,x in enumerate(http)if x.get('injected')];recovered=bool(c['recovery']and strict and len(injection)==1 and http[injection[0]]['method']=='GET'and http[injection[0]]['path']==c['start_path']and http[injection[0]]['status']=='503 Service Unavailable'and any(x['method']=='GET'and x['path']==c['start_path']and x['query']=='retry=1'and x['status']=='200 OK'for x in http[injection[0]+1:]))
 assert recovered==row.get('recovery_completed',False)
 if recovered:assert res['details']['progress']['recent_steps'][0]['label']=='Retry'
 if 'usage'in row:assert row['usage']['prompt_tokens']==it and row['usage']['completion_tokens']==ot
 if 'app_sha256'in row:assert row['app_sha256']==h(enc(f['app']).encode())
 cap=row.get('elapsed_ms')if strict else 120000;assert row['capped_completion_ms']==cap
 events=row.get('events',[]);finished=[e for e in events if e['kind']=='model_call'and e.get('phase')=='finished'];assert all(e['task_id']==row['task_id']for e in finished)
 if all(r['spend']['requests'][q['call_id']]['status']=='known'for q in requests):assert [e['call_id']for e in finished]==[q['call_id']for q in requests]
 audit=[json.loads(l)for l in(rp/'audit.jsonl').read_text().splitlines()]if(rp/'audit.jsonl').exists()else[]
 if 'task_id'in row:assert all(a['task_id']==row['task_id']and a['category']=='execution'for a in audit)
 if(rp/'final.png').exists():assert(rp/'final.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n');pngs+=1
 d.update(fallback_proofs=proofs,direct_bypasses=bypasses,recovery_images=recovery_images,strict_completed=strict,recovery_completed=recovered,elapsed_ms=row.get('elapsed_ms'),capped_completion_ms=cap,reason=res.get('reason',row.get('error_type','unknown')),business_records_match=business,schema_match=schema_ok,one_correct_write=write_ok,post_requests=posts,injected_gets=len(injection),sequence=sequence,input_tokens=it,output_tokens=ot,reported_peer_cost_usd=reported,invalid_choices=invalid,visual_fallbacks=len(proofs),captures=sum(e['kind']=='task_execution'and e.get('operation')=='computer_use.capture'and e.get('phase')=='finished'for e in events),returned_to_jev=any(sequence[i]=='peer'and'jev'in sequence[i+1:]for i in range(len(sequence))))
 rows.append(d)
assert ids==set(r['spend']['requests']);assert sum((x['input_tokens']or 0)+(x['output_tokens']or 0)for x in calls)==r['spend']['batch']['known_tokens']
def aggregate(ds):
 ran=[x for x in ds if x['status']!='not_run'];return{'planned':len(ds),'run':len(ran),'strict_completed':sum(x['strict_completed']for x in ds),'recovery_planned':sum(x['recovery']for x in ds),'recovery_completed':sum(x['recovery_completed']for x in ds),'cleanup_confirmed':sum(x['cleanup_confirmed']for x in ds),'mean_capped_completion_ms':statistics.mean(x['capped_completion_ms']for x in ds),'calls':sum(len(x.get('sequence',[]))for x in ds),'image_calls':sum(x.get('sequence',[]).count('peer')for x in ds),'jev_calls':sum(x.get('sequence',[]).count('jev')for x in ds),'input_tokens':sum(x.get('input_tokens',0)for x in ds),'output_tokens':sum(x.get('output_tokens',0)for x in ds),'fallbacks':sum(x.get('visual_fallbacks',0)for x in ds),'direct_bypasses':sum(x.get('direct_bypasses',0)for x in ds),'recovery_images':sum(x.get('recovery_images',0)for x in ds),'returns_to_jev':sum(x.get('returned_to_jev',False)for x in ds),'captures':sum(x.get('captures',0)for x in ds),'estimate_nano_usd':sum(x['estimate_nano_usd']or 0 for x in calls if x['row']in{d['id']for d in ds})}
s={'sha256':f['sha256'],'completed':r['completed'],'stop_reason':r['spend']['stop_reason'],'source_files':len(f['source_sha256']),'app_files':len(f['app']['files']),'pngs':pngs,'rows':rows,'calls':calls,'arms':[{'arm':a,**aggregate([d for d in rows if d['arm']==a])}for a in('v','jt')],'groups':[{'arm':a,'kind':k,'recovery':fault,**aggregate([d for d in rows if d['arm']==a and d['kind']==k and d['recovery']==fault])}for a in('v','jt')for k in('insert','update')for fault in(False,True)],'model_usage':[{'model':m,'calls':sum(c['model']==m for c in calls),'input_tokens':sum(c['input_tokens']or 0 for c in calls if c['model']==m),'output_tokens':sum(c['output_tokens']or 0 for c in calls if c['model']==m),'estimate_nano_usd':sum(c['estimate_nano_usd']or 0 for c in calls if c['model']==m)}for m in('jev','peer')],'unknown_requests':[cid for cid,q in r['spend']['requests'].items()if q['status']!='known'],'total_tokens':r['spend']['batch']['known_tokens'],'reported_peer_cost_usd':sum(x.get('reported_peer_cost_usd',0)for x in rows),'cost_status':r['spend']['cost_status']}
out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items()if k not in('rows','calls')},indent=2))
