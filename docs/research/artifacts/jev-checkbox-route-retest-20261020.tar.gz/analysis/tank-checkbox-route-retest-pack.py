"""Archive the single frozen real-model retest; preserve all prior artifacts."""
import hashlib,io,json,os,re,sys,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank');artifacts=root/'docs/research/artifacts';live=Path('/private/tmp/tank-checkbox-route-ready-20261020');h=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads(Path('/private/tmp/tank-checkbox-route-retest-old-artifacts.json').read_text());assert len(old)==13
for name,hashes in old.items():
 assert h((artifacts/name).read_bytes())==hashes['archive_sha256']
 assert h((artifacts/name.replace('.tar.gz','-manifest.json')).read_bytes())==hashes['manifest_sha256']
f=json.loads((live/'freeze.json').read_text());r=json.loads((live/'result.json').read_text());assert f['sha256']==r['sha256'];files={'live/'+str(p.relative_to(live)):p for p in live.rglob('*')if p.is_file()}
for name,sha in f['source_sha256'].items():
 p=live/'source'/name;assert h(p.read_bytes())==sha==h((root/'backend'/name).read_bytes())
appenv=Path(f['app']['python']).parent.parent
for name,sha in f['app']['files'].items():
 p=appenv/name;assert h(p.read_bytes())==sha;files['app/'+name]=p
for suffix in ('analyze.py','summary.json','choices.py','choices.json','pack.py','old-artifacts.json'):
 p=Path('/private/tmp/tank-checkbox-route-retest-'+suffix);files['analysis/'+p.name]=p
for p in Path('/private/tmp').glob('tank-checkbox-route-retest-*.log'):
 if p.name!='tank-checkbox-route-retest-pack-result.log':files['verification/'+p.name]=p
values={**dotenv_values(root/'backend/core/.env'),**os.environ};secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)];assert secrets
for name,p in files.items():assert not any(s in p.read_bytes()for s in secrets),f'credential found: {name}'
archive=artifacts/'jev-checkbox-route-retest-20261020.tar.gz';assert not archive.exists();manifest={'date':'2026-10-20','baseline_commit':'70a0c39a','plan_commit':sys.argv[1],'implementation_commit':'c76af867','freeze_sha256':f['sha256'],'old_archives_unchanged':old,'credential_values_scanned':len(secrets),'files':{}}
with tarfile.open(archive,'w:gz')as tf:
 for name,p in sorted(files.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data));manifest['files'][name]={'bytes':len(data),'sha256':h(data)}
manifest['archive_sha256']=h(archive.read_bytes())
with tarfile.open(archive)as tf:
 assert set(tf.getnames())==set(files)
 for member in tf.getmembers():
  data=tf.extractfile(member).read();assert len(data)==manifest['files'][member.name]['bytes']and h(data)==manifest['files'][member.name]['sha256']
archive.with_name('jev-checkbox-route-retest-20261020-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'members':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'old_archives':len(old),'credential_values':len(secrets)}))
