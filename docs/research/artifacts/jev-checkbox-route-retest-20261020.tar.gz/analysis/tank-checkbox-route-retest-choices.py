"""Audit selected checkbox proposals and final host steps. No host imports or model calls."""
import json,sys,tarfile,hashlib
from pathlib import Path
p=Path(sys.argv[1]); out=Path(sys.argv[2]);result=json.loads((p/'result.json').read_text());rows=[]
for row in result['rows']:
 d=p/row['id']; path=d/'calls.jsonl';raw=[json.loads(line)for line in path.read_text().splitlines()]if path.exists()else[];replies={q['call_id']:q['response']for q in raw if'response'in q};proposals=[];initial=None
 for q in raw:
  if'request'not in q:continue
  req=q['request']; peer='messages'in req; packet=json.loads(req['messages'][1]['content'][0]['text'])if peer else req
  offered=packet['questions']['next_action']['criteria'];a=replies.get(q['call_id']);choice=None
  if a is not None:
   choice=json.loads(a['choices'][0]['message']['content'])['choice']if peer else a.get('choice')
  detail=offered.get(choice)if isinstance(choice,str)else None
  if initial is None:initial={'column_candidates':sum(isinstance(v,dict)and v.get('role')=='checkbox'and v.get('label','').startswith('Allow updating this column.')for v in offered.values()),'offered_checkboxes':[v['label']for v in offered.values()if isinstance(v,dict)and v.get('role')=='checkbox']}
  proposals.append({'call_id':q['call_id'],'model':'peer'if peer else'jev','choice':choice,'label':detail.get('label')if isinstance(detail,dict)else None,'role':detail.get('role')if isinstance(detail,dict)else None})
 steps=row.get('result',{}).get('details',{}).get('progress',{}).get('recent_steps',[])
 rows.append({'id':row['id'],'initial':initial,'proposals':proposals,'checkbox_choices':[q for q in proposals if q['role']=='checkbox'],'host_steps':steps})
old=Path('/Users/zbcjackson/src/tank/docs/research/artifacts/jev-real-product-route-20261020.tar.gz');pairs=[]
with tarfile.open(old)as tf:
 for row in result['rows']:
  d=p/row['id'];path=d/'calls.jsonl'
  if not path.exists():continue
  newreq=[json.loads(line)for line in path.read_text().splitlines()if line.strip()];newfirst=next((q for q in newreq if'request'in q and'messages'in q['request']),None)
  oldraw=[json.loads(line)for line in tf.extractfile('live/'+row['id']+'/calls.jsonl').read().decode().splitlines()];oldfirst=next((q for q in oldraw if'request'in q and'messages'in q['request']),None)
  if row['arm']=='v'and newfirst and oldfirst:
   newpng=newfirst['images'][0]['sha256'];oldpng=oldfirst['images'][0]['sha256'];pairs.append({'id':row['id'],'new_sha256':newpng,'old_sha256':oldpng,'same_initial_image':newpng==oldpng})
summary={'rows':rows,'v_initial_image_pairs':pairs,'scope':'Actual model proposals and saved host steps; no SQL column-only scoring or causal old/new inference.'}
out.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checkbox_choices':{r['id']:[q['label']for q in r['checkbox_choices']]for r in rows if r['checkbox_choices']},'v_initial_image_pairs':pairs},ensure_ascii=False,indent=2))
