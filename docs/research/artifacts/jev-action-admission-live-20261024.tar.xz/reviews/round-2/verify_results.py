"""Pre-close review: byte-bound receipts, independent rerender, Canvas, and TAR."""
import hashlib
import itertools
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import tarfile
from unittest.mock import patch

REPO = Path('/Users/zbcjackson/src/tank')
ROOT = Path('/private/tmp/tank-jev-action-live-20261024')
OUT = Path(__file__).parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

def forbidden(*args, **kwargs):
    raise AssertionError('review must not construct model clients or connect sockets')

verification = load(ROOT / 'verification.json')
post = load(ROOT / 'post-results-verification.json')
assert sha(ROOT / 'verification.json') == post['pre_live_verification']['sha256']
for mapping, prefix in ((verification['source_sha256'], REPO / 'backend'),):
    for name, expected in mapping.items():
        assert sha(prefix / name) == expected, name
for name, expected in verification['task_file_sha256'].items():
    if name.endswith('.py'):
        assert sha(REPO / name) == expected, name
for group in (verification['checks'], post['current_checks']):
    for name, check in group.items():
        assert type(check['exit_code']) is int and check['exit_code'] == 0, name
        assert sha(Path(check['path'])) == check['sha256'], name
for name, expected in load(ROOT / 'prior-artifacts70-sha256.json').items():
    assert sha(REPO / name) == expected, name
for item in post['new_untracked_artifacts']:
    path = REPO / item['path']
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
readiness = load(ROOT / 'live-readiness.json')
for key in ('review', 'verification'):
    assert sha(Path(readiness[key]['path'])) == readiness[key]['sha256']
assert readiness['review']['sha256'] == 'df416a124e89f2e74e84d675648712742af042d2356395d326ae42865bc8a3b5'

sys.argv = ['analyze_live.py', '--study', str(ROOT / 'live'), '--output', str(OUT / 'regenerated-derived')]
with patch('httpx.AsyncClient.__init__', forbidden), patch('httpx2.AsyncClient.__init__', forbidden), patch('socket.getaddrinfo', forbidden), patch('socket.socket.connect', forbidden):
    runpy.run_path(str(ROOT / 'analyze_live.py'), run_name='__main__')
new = OUT / 'regenerated-derived'
assert len(list(new.iterdir())) == 8
derived_matches = {}
for path in new.iterdir():
    assert path.read_bytes() == (ROOT / 'derived-v1' / path.name).read_bytes(), path.name
    derived_matches[path.name] = sha(path)

result = load(ROOT / 'live/result.json')
audit = load(new / 'audit.json')
assert sha(ROOT / 'live/result.json') == post['result_sha256']
assert audit == load(ROOT / 'live/audit.json')
assert audit['sha256'] == '4e6a807889cacf6b7ca3a1482cfa2a56cd21f83b5b62e51ca7b9950b248014f0'
assert result['completed'] and len(result['rows']) == 36 and audit['sdk_calls'] == 100
index = []
negative_witnesses = []
for row in result['rows']:
    path = ROOT / 'live/trials' / row['id']
    responses = {c['call_id']: c['response'] for c in lines(path / 'calls.jsonl') if 'response' in c}
    finished = [e for e in row['events'] if e['kind'] == 'model_call' and e['phase'] == 'finished']
    for event in finished:
        response = responses[event['call_id']]
        index.append({
            'trial': row['id'], 'policy': row['policy'], 'product': row['product'],
            'negative': bool(row['negative']), 'condition': row['condition'],
            'call_id': event['call_id'], 'purpose': event['purpose'],
            'sdk_boundary_ms': event['elapsed_ms'], 'response_model': response.get('model'),
            'response_provider': response.get('provider'), 'choice': response.get('choice'),
            'input_tokens': event['prompt_tokens'], 'output_tokens': event['completion_tokens'],
        })
    if row['negative']:
        witness = lines(path / 'dispatch-witness.jsonl')
        assert not any(w['phase'] == 'authorized' or w.get('native_called') is True for w in witness)
        negative_witnesses.append({'id': row['id'], 'witness_exists': (path / 'dispatch-witness.jsonl').exists(), 'records': len(witness), 'sealed_witness_hash': row['labels']['evidence']['files']['dispatch-witness.jsonl']})
assert index == load(ROOT / 'derived-v1/call-evidence.json')
(OUT / 'negative-witnesses.json').write_text(json.dumps(negative_witnesses, indent=2) + '\n')

canvas = Path(post['canvas_path'])
assert sha(canvas) == post['canvas_sha256'] == sha(ROOT / canvas.name)
text = canvas.read_text()
start = text.index('=') if text.startswith('const DATA') else text.index('=', text.index('const DATA'))
data = json.JSONDecoder().raw_decode(text[start + 1:].lstrip())[0]
trials = load(new / 'trials.json')
assert data['trials'] == [{k: row[k] for k in data['trials'][0]} for row in trials]
assert data['pairs'] == load(new / 'pairs.json')
assert data['scope'] == {'freeze_sha256': audit['freeze_sha256'], 'audit_sha256': audit['sha256']}
assert 'fetch(' not in text and 'XMLHttpRequest' not in text
assert all(line.startswith('import ') and 'from "cursor/canvas"' in line for line in text.splitlines() if line.startswith('import '))
combinations = 0
for product, condition, negative in itertools.product(('all', 'sqlite-web', 'linkding'), ('all', 'cold', 'prewarmed'), (False, True)):
    selected = [r for r in data['trials'] if (product == 'all' or r['product'] == product) and (condition == 'all' or r['condition'] == condition) and r['negative'] == negative]
    assert selected and {r['policy'] for r in selected} == {'v', 'jt', 'ja'}
    pair_ids = {r['pair_id'] for r in selected}
    assert all({r['policy'] for r in selected if r['pair_id'] == pair} == {'v', 'jt', 'ja'} for pair in pair_ids)
    combinations += 1
assert combinations == 18

manifest = load(REPO / 'docs/research/artifacts/jev-action-admission-live-20261024-manifest.json')
archive = REPO / 'docs/research/artifacts' / manifest['archive']
assert sha(archive) == manifest['sha256'] and archive.stat().st_size == manifest['bytes']
from dotenv import dotenv_values
values = {**dotenv_values(REPO / 'backend/core/.env'), **os.environ}
secrets = [str(values[k]).encode() for k in ('TYPESAFE_API_KEY', 'OPENROUTER_API_KEY') if values.get(k)]
assert len(secrets) == 2
checked = {}
with tarfile.open(archive, 'r:xz') as bundle:
    members = bundle.getmembers()
    assert len(members) == manifest['members'] == 22071
    assert [m.name for m in members] == list(manifest['entries'])
    for member in members:
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert '.env' not in Path(member.name).parts
        entry = manifest['entries'][member.name]
        if member.issym():
            assert member.linkname == entry['symlink']
        elif member.islnk():
            assert member.linkname == entry['hardlink'] and checked[member.linkname] == entry['sha256']
            checked[member.name] = checked[member.linkname]
        else:
            value = bundle.extractfile(member).read()
            assert member.isfile() and len(value) == entry['bytes'] and hashlib.sha256(value).hexdigest() == entry['sha256']
            assert not any(secret in value for secret in secrets), member.name
            checked[member.name] = entry['sha256']
        if member.name.startswith(('live/', 'qualification/')) and 'sha256' in entry:
            assert sha(ROOT / member.name) == entry['sha256'], member.name
summary = {
    '45_sources_and_4_python_task_files_unchanged': True,
    'old_9_and_new_7_check_logs_byte_bound': True,
    '70_original_artifacts_unchanged': True,
    'round_1_review_and_readiness_bindings_unchanged': True,
    'official_live_audit_sha256': audit['sha256'],
    'regenerated_8_derived_outputs_match_byte_for_byte': derived_matches,
    'call_evidence_index_recomputed': len(index),
    'negative_no_native_dispatch': len(negative_witnesses),
    'canvas_exact_embedded_data_and_complete_filter_combinations': combinations,
    'provisional_archive_members_verified': len(members),
    'provisional_archive_sha256': manifest['sha256'],
    'provisional_archive_actual_credential_values_scanned': len(secrets),
    'provisional_archive_credential_matches': 0,
    'model_calls_made_by_reviewer': 0,
}
(OUT / 'independent-review-checks.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
