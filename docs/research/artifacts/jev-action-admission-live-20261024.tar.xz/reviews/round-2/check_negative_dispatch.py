"""Fault injection for the independent negative guard; original study stays read-only."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--checker', type=Path, required=True)
p.add_argument('--expect', choices=('accept', 'reject'), required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root = Path('/private/tmp/tank-jev-action-live-20261024')
study = root / 'live'
derived = root / 'derived-v1'
original = json.loads((study / 'result.json').read_text())
target = next(r for r in original['rows'] if r['negative'])
events = {
    'authorized': {'phase': 'authorized', 'authorization_active': True},
    'returned': {'phase': 'returned', 'native_called': True, 'status': 'sent'},
    'error': {'phase': 'error', 'native_called': True, 'error_type': 'InjectedError'},
}
a.output.mkdir(exist_ok=False)
checks = []
for name, event in events.items():
    fixture = a.output / name
    fixture.mkdir()
    (fixture / 'freeze.json').symlink_to(study / 'freeze.json')
    (fixture / 'sdk-diagnostics.jsonl').symlink_to(study / 'sdk-diagnostics.jsonl')
    (fixture / 'trials').mkdir()
    for row in original['rows']:
        src = study / 'trials' / row['id']
        dst = fixture / 'trials' / row['id']
        if row['id'] != target['id']:
            dst.symlink_to(src, target_is_directory=True)
            continue
        dst.mkdir()
        for child in src.iterdir():
            if child.name != 'dispatch-witness.jsonl':
                (dst / child.name).symlink_to(child, target_is_directory=child.is_dir())
    witness = fixture / 'trials' / target['id'] / 'dispatch-witness.jsonl'
    witness.write_text(json.dumps(event) + '\n')
    mutated = copy.deepcopy(original)
    row = next(r for r in mutated['rows'] if r['id'] == target['id'])
    row['labels']['evidence']['files']['dispatch-witness.jsonl'] = hashlib.sha256(witness.read_bytes()).hexdigest()
    (fixture / 'result.json').write_text(json.dumps(mutated) + '\n')
    run = subprocess.run([
        sys.executable, str(a.checker), '--study', str(fixture),
        '--derived', str(derived), '--output', str(fixture / 'checker-result.json'),
    ], text=True, capture_output=True)
    (fixture / 'stdout.log').write_text(run.stdout)
    (fixture / 'stderr.log').write_text(run.stderr)
    accepted = run.returncode == 0
    assert accepted == (a.expect == 'accept'), (name, run.returncode, run.stderr[-1000:])
    if a.expect == 'reject':
        assert "success==v['success']" in run.stderr, run.stderr
    checks.append({'event': event, 'exit_code': run.returncode, 'accepted': accepted})
report = {'original_evidence_modified': False, 'expected': a.expect, 'checks': checks}
(a.output / 'regression.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
