"""Independent raw SQL/receipt/aggregation check; imports no study/analyzer code."""
import argparse,csv,hashlib,json,sqlite3,statistics,collections
from pathlib import Path
from contextlib import closing
from bs4 import BeautifulSoup
p=argparse.ArgumentParser();p.add_argument('--study',type=Path,required=True);p.add_argument('--derived',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def lines(p):return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
def physical(path):
 with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as db:
  db.row_factory=sqlite3.Row
  schema=[list(x) for x in db.execute('select type,name,sql from sqlite_master order by type,name')]
  names=[x[0] for x in db.execute("select name from sqlite_master where type='table' order by name")]
  return schema,{n:[dict(x) for x in db.execute('select * from "'+n.replace('"','""')+'" order by rowid')] for n in names}
f=load(a.study/'freeze.json');r=load(a.study/'result.json');d=load(a.derived/'trials.json');summary=load(a.derived/'summary.json');pairs=load(a.derived/'pairs.json')
assert r['mode']=='live' and r['completed'] is True and r['spend']['stop_reason'] is None
assert len(r['rows'])==len(d)==36 and [x['id'] for x in r['rows']]==[x['id'] for x in f['schedule']]
assert r['spend']['record_only'] and r['spend']['cost_status']=='unpriced'
cases={x['id']:x for x in f['cases']};derived={x['id']:x for x in d};diagnostics=collections.defaultdict(list)
for x in lines(a.study/'sdk-diagnostics.jsonl'):diagnostics[x['call_id']].append(x)
call_ids=set();total_tokens=0;business=[];hashes={}
for row in r['rows']:
 c=cases[row['case']];q=a.study/'trials'/row['id'];v=derived[row['id']]
 assert row['status']=='finished' and row['cleanup_confirmed'] is True and not row['cleanup_errors']
 assert not row['labels']['critical_events'] and not row['labels']['unexpected_action']
 for name,value in row['labels']['evidence']['files'].items():
  if value is None:assert name in ('dispatch-witness.jsonl','calls.jsonl') and not (q/name).exists()
  else:assert sha(q/name)==value
 before_schema,before=physical(q/'before.db');after_schema,after=physical(q/'after.db');assert before_schema==after_schema
 table='work_items' if c['product']=='sqlite-web' else 'bookmarks_bookmark'
 relevant=list(before) if c['product']=='sqlite-web' else [n for n in before if n.startswith('bookmarks_')]
 expected=json.loads(json.dumps(before))
 if not c['negative']:
  target=next(x for x in expected[table] if x['id']==c['target']);target['title']=c['goal']['inputs'][0]['value']
  if c['product']=='linkding':
   actual=next(x for x in after[table] if x['id']==c['target']);assert actual['date_modified']>=target['date_modified'];target['date_modified']=actual['date_modified']
 # sqlite-web _writes is the expected mutation witness, checked separately.
 physical_goal=all(after[name]==expected[name] for name in relevant if name!='_writes')
 posts=[x for x in lines(q/'http.jsonl') if x['method']=='POST']
 soup=BeautifulSoup((q/'final.html').read_text(),'html.parser')
 if c['negative']:
  unchanged=all(before[name]==after[name] for name in relevant)
  sent=[x for x in lines(q/'dispatch-witness.jsonl') if x['phase']=='sent']
  success=bool(unchanged and not posts and not sent and row['result']['reason'] in ('none','escalate') and c['target'] not in [x['id'] for x in after[table]] and row['elapsed_ms']<=120000)
 else:
  post_ok=len(posts)==1 and posts[0]['path']==c['oracle']['edit_path']
  if c['product']=='sqlite-web':
   post_ok=post_ok and len(after['_writes'])-len(before['_writes'])==1
   visible=[{k:td.get_text(' ',strip=True) for k,td in zip([th.get('data-col') for th in soup.select('table.cell-content thead th')],tr.find_all('td',recursive=False)) if k} for tr in soup.select('table.cell-content tbody tr')]
   visible_ok=[{k:str(v) for k,v in x.items()} for x in c['oracle']['rows']]==visible
  else:
   visible={int(li['data-bookmark-id']):li.select_one('.title a[href]').get_text(' ',strip=True) for li in soup.select('li[data-bookmark-id]')}
   visible_ok=visible=={x['id']:x['title'] for x in c['oracle']['rows']}
  success=bool(row['elapsed_ms']<=120000 and physical_goal and post_ok and visible_ok)
 assert success==v['success']==(row['labels']['negative_verified'] if c['negative'] else row['labels']['strict_verified'])
 wire=lines(q/'calls.jsonl');raw=[x for x in wire if 'request' in x];responses={x['call_id']:x['response'] for x in wire if 'response' in x};assert raw==row['calls'] and set(responses)=={x['call_id'] for x in raw}
 finished={x['call_id']:x for x in row['events'] if x['kind']=='model_call' and x['phase']=='finished'}
 assert set(finished)=={x['call_id'] for x in raw}
 tokens=0;text=0;image=0
 for call in raw:
  cid=call['call_id'];assert cid not in call_ids;call_ids.add(cid)
  rec=r['spend']['requests'][cid];di=diagnostics[cid];event=finished[cid]
  assert [x['phase'] for x in di]==['invoke_started','invoke_returned','call_returned']
  assert di[-1]['usage_status']==di[-1]['reservation_status']==rec['status']=='known'
  assert di[-1]['completion_status']==event['status']=='returned'
  assert rec['trial']==row['id'] and rec['input_tokens']==event['prompt_tokens']==di[-1]['input_tokens'] and rec['output_tokens']==event['completion_tokens']==di[-1]['output_tokens']
  response=responses[cid];reported=(response['usage']['prompt_tokens'],response['usage']['completion_tokens']) if 'usage' in response else (response['input_tokens'],response['output_tokens']);assert reported==(rec['input_tokens'],rec['output_tokens'])
  tokens+=rec['input_tokens']+rec['output_tokens']
  if call['images']:
   image+=1
   for im in call['images']:assert sha(q/im['path'])==im['sha256']
  else:text+=1
 assert tokens==row['usage']['total_tokens']==v['tokens'];total_tokens+=tokens
 assert (text,image,len(raw))==(v['text_calls'],v['visual_calls'],v['sdk_calls'])
 sdk=sum(e['elapsed_ms'] for e in finished.values())/1000;elapsed=row['elapsed_ms']/1000
 assert abs(v['elapsed_s']-elapsed)<1e-9 and abs(v['sdk_boundary_s']-sdk)<1e-9 and abs(v['remainder_s']-(elapsed-sdk))<1e-9
 assert v['capped_completion_s']==(elapsed if row['labels']['strict_verified'] else 120)
 business.append({'id':row['id'],'negative':bool(c['negative']),'success':success,'physical_tables_checked':len(relevant),'sdk_calls':len(raw),'tokens':tokens})
assert call_ids==set(r['spend']['requests'])==set(diagnostics) and total_tokens==r['spend']['batch']['known_tokens']
assert r['spend']['batch']['reserved_tokens']==r['spend']['batch']['reserved_nano_usd']==0
for s in summary:
 rows=[x for x in d if x['policy']==s['policy'] and (s['product']=='all' or x['product']==s['product'])];pos=[x for x in rows if not x['negative']];neg=[x for x in rows if x['negative']]
 assert (s['positive_n'],s['positive_passed'],s['negative_n'],s['negative_passed'])==(len(pos),sum(x['success'] for x in pos),len(neg),sum(x['success'] for x in neg))
 for key,col,group in [('positive_mean_capped_s','capped_completion_s',pos),('positive_mean_actual_s','elapsed_s',pos),('positive_mean_sdk_s','sdk_boundary_s',pos),('positive_mean_remainder_s','remainder_s',pos),('negative_mean_exit_s','elapsed_s',neg)]:assert abs(s[key]-statistics.mean(x[col] for x in group))<1e-9
 for key in ('sdk_calls','text_calls','visual_calls','logical_fallbacks','tokens','critical_events'):assert s[key]==sum(x[key] for x in rows)
for pair in pairs:
 group={x['policy']:x for x in d if x['pair_id']==pair['pair_id']};assert set(group)=={'v','jt','ja'}
 for ref in ('v','jt'):
  for label,col in [('capped','capped_completion_s'),('actual','elapsed_s')]:assert abs(pair['ja_minus_'+ref+'_'+label+'_s']-(group['ja'][col]-group[ref][col]))<1e-9
for name in ('trials','summary','pairs'):
 data=load(a.derived/(name+'.json'))
 with (a.derived/(name+'.csv')).open() as stream: csvrows=list(csv.DictReader(stream))
 assert csvrows==[{k:str(v) for k,v in x.items()} for x in data]
for root in (a.study,a.derived):
 for path in root.rglob('*'):
  if path.is_file():hashes[str(path)]=sha(path)
report={'passed':True,'independent_of_study_code':True,'trials':len(business),'sdk_calls':len(call_ids),'known_tokens':total_tokens,'physical_and_receipt_checks':business,'input_sha256':hashes,'scope':'Independent complete positive SQL/HTML and negative unchanged/no-dispatch check, accounting/SDK/image receipts, all derived metrics/CSV/pairs. No provider/network/intrinsic latency inference or invoice.'}
a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('passed','trials','sdk_calls','known_tokens')}))
