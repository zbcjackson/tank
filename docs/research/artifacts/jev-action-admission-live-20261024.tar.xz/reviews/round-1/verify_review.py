"""Independent pre-live review checks. No clients, credentials, or model calls."""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import subprocess
import tarfile

REPO = Path('/Users/zbcjackson/src/tank')
TASK = Path('/private/tmp/tank-jev-action-live-20261024')
OUT = Path(__file__).parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

v = json.loads((TASK / 'verification.json').read_text())
handoff = json.loads((TASK / 'review-handoff.json').read_text())
assert sha(TASK / 'verification.json') == handoff['verification_sha256']
assert len(v['source_sha256']) == 45
for name, expected in v['source_sha256'].items():
    assert sha(REPO / 'backend' / name) == expected, name
for name, expected in v['task_file_sha256'].items():
    assert sha(REPO / name) == expected, name
for name, item in v['checks'].items():
    assert type(item['exit_code']) is int and item['exit_code'] == 0, name
    assert sha(Path(item['path'])) == item['sha256'], name
prior = json.loads((TASK / 'prior-artifacts70-sha256.json').read_text())
assert len(prior) == 70
for name, expected in prior.items():
    assert sha(REPO / name) == expected, name
archive = REPO / 'docs/research/artifacts/jev-action-admission-20261023.tar.xz'
with tarfile.open(archive) as bundle:
    original = json.load(bundle.extractfile('verification-before-review.json'))['original_registered_source_sha256']
assert len(original) == 42
assert all(v['source_sha256'][name] == expected for name, expected in original.items())
signer = '/private/tmp/tank-jev-execution-20261023/git-allowed-signers'
signatures = subprocess.check_output([
    'git', '-c', 'gpg.ssh.allowedSignersFile=' + signer, 'log', '--format=%H:%G?',
    handoff['baseline'] + '..16fbd95d',
], cwd=REPO, text=True).splitlines()
assert len(signatures) == 4 and all(s.endswith(':G') for s in signatures), signatures
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True)
assert not (TASK / 'live/started.json').exists()

def forbidden(*args, **kwargs):
    raise AssertionError('review must not construct model HTTP clients or connect sockets')

with patch('httpx.AsyncClient.__init__', forbidden), patch('httpx2.AsyncClient.__init__', forbidden), patch('socket.getaddrinfo', forbidden), patch('socket.socket.connect', forbidden):
    from benchmarks.computer_use import jev_action_live as pilot
    frozen = pilot.load_freeze(TASK / 'live', handoff['freeze_sha256'])
    qualified = pilot.audit_study(TASK / 'qualification', frozen['sha256'])
assert qualified['sha256'] == v['qualification_sha256']
assert qualified['mode'] == 'fake' and qualified['complete'] is True
assert qualified['planned'] == 36 and qualified['sdk_calls'] == 100
assert qualified['known_tokens'] == 1000
assert all(p['positive_passed'] == 8 and p['negative_passed'] == 4 and p['critical_events'] == 0 for p in qualified['policies'].values())
(OUT / 'independent-qualification-audit.json').write_text(json.dumps(qualified, ensure_ascii=False, indent=2) + '\n')
result = {
    '45_sources_match': True,
    '8_task_files_match': True,
    '9_verification_logs_hash_bound_and_exit_zero': True,
    '42_registered_sources_unchanged': True,
    '70_original_artifacts_unchanged': True,
    'signatures': signatures,
    'live_not_started': True,
    'independent_fake_audit_sha256': qualified['sha256'],
    'no_model_clients_or_external_connections': True,
}
(OUT / 'independent-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
