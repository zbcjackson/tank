from pathlib import Path
import json
root=Path('/private/tmp/tank-jev-action-live-20261024')
data={'trials':json.loads((root/'derived-v1/trials.json').read_text()),'pairs':json.loads((root/'derived-v1/pairs.json').read_text()),'scope':json.loads((root/'derived-v1/scope.json').read_text())}
code=r'''import {Stack, Row, Grid, H1, H2, Text, Stat, Table, Select, Callout, BarChart, useState, useHostTheme} from "cursor/canvas";
type Trial={id:string;policy:string;product:string;cluster_id:string;pair_id:string;condition:string;family:string;negative:boolean;success:boolean;elapsed_s:number;capped_completion_s:number;sdk_boundary_s:number;remainder_s:number;text_calls:number;visual_calls:number;logical_fallbacks:number;sdk_calls:number;tokens:number;host_reason:string;critical_events:number};
type Pair={product:string;cluster_id:string;condition:string;negative:boolean;pair_id:string;ja_minus_v_capped_s:number;ja_minus_jt_capped_s:number;ja_minus_v_actual_s:number;ja_minus_jt_actual_s:number};
const DATA: {trials:Trial[];pairs:Pair[];scope:{freeze_sha256:string;audit_sha256:string}}=__DATA__;
const policies=["v","jt","ja"];
const names:Record<string,string>={v:"V 纯视觉",jt:"JT 原分流",ja:"JA 动作级分流"};
const families:Record<string,string>={unique:"唯一标题","same-title":"重名标题",missing:"目标缺失"};
const n=(v:number)=>v.toFixed(2);
const total=(rows:Trial[],f:(r:Trial)=>number)=>rows.reduce((a,r)=>a+f(r),0);
const mean=(rows:Trial[],f:(r:Trial)=>number)=>total(rows,f)/rows.length;
export default function ActionLiveResults(){
 const theme=useHostTheme();
 const [product,setProduct]=useState("all"),[condition,setCondition]=useState("all"),[cohort,setCohort]=useState("positive"),[selected,setSelected]=useState("");
 const rows=DATA.trials.filter(r=>(product==="all"||r.product===product)&&(condition==="all"||r.condition===condition)&&r.negative===(cohort==="negative"));
 const pairs=DATA.pairs.filter(p=>rows.some(r=>r.pair_id===p.pair_id));
 const active=pairs.find(p=>p.pair_id===selected)??pairs[0];
 const details=rows.filter(r=>r.pair_id===active.pair_id);
 const groups=policies.map(p=>({policy:p,rows:rows.filter(r=>r.policy===p)}));
 const positives=DATA.trials.filter(r=>!r.negative),negatives=DATA.trials.filter(r=>r.negative);
 const timing=(r:Trial)=>cohort==="positive"?r.capped_completion_s:r.elapsed_s;
 const timeTitle=cohort==="positive"?"正例完成均时（失败计120秒）":"负例退出实际均时";
 const source="来源：2026-10-24新实测 · sqlite-web/linkding实际产品、公开合成数据 · 当前每策略"+groups[0].rows.length+"次，"+new Set(rows.map(r=>r.cluster_id)).size+"个相关seed。";
 return <Stack gap={24} style={{maxWidth:1240,margin:"0 auto",padding:24,background:theme.bg.editor,color:theme.text.primary}}>
  <Stack gap={8}>
   <Text size="small" tone="secondary">36次真实试验 · 6个新内容seed · 冷/本地预热 · 三种策略</Text>
   <H1>动作级准入的真实开发实测</H1>
   <Text>V始终使用Gemini视觉；JT沿用原文字准入规则；JA先询问Jev，再核对被选动作是否可区分，必要时交回同一Gemini。保留完整候选及相同控制器与权限规则。</Text>
   <Text>全批正例通过 {positives.filter(r=>r.success).length}/{positives.length}；目标缺失负例通过 {negatives.filter(r=>r.success).length}/{negatives.length}；关键错误事件 {total(DATA.trials,r=>r.critical_events)}。实际模型为 jev-1.14.0 / google/gemini-3.8-flash；本批没有Jev图片或Box调用。</Text>
  </Stack>
  <Callout tone="info">这是开发比较：仅两个已见产品与模板族，6个seed；冷/预热条件相关，提供商缓存、路由和服务负载未受控。不能据此宣称通用视觉能力排名、正式采用或美元费用收益。</Callout>
  <Row gap={12} wrap>
   <Select value={product} onChange={setProduct} options={[{value:"all",label:"两个产品"},{value:"sqlite-web",label:"sqlite-web"},{value:"linkding",label:"linkding"}]}/>
   <Select value={condition} onChange={setCondition} options={[{value:"all",label:"冷/预热均保留"},{value:"cold",label:"冷启动"},{value:"prewarmed",label:"本地预热"}]}/>
   <Select value={cohort} onChange={setCohort} options={[{value:"positive",label:"正例：完成任务"},{value:"negative",label:"负例：目标缺失"}]}/>
  </Row>
  <Row gap={32} wrap>
   {groups.map(g=><Stat key={g.policy} label={names[g.policy]+" 通过 / 分母"} value={g.rows.filter(r=>r.success).length+" / "+g.rows.length}/>)}
   <Stat label="当前完整配对 / seed" value={pairs.length+" / "+new Set(rows.map(r=>r.cluster_id)).size}/>
  </Row>
  <Grid columns="repeat(auto-fit,minmax(350px,1fr))" gap={24}>
   <Stack gap={8}>
    <H2>{timeTitle}</H2>
    <Text size="small" tone="secondary">横轴：策略；纵轴：每任务均值（秒）。包含设置、执行、回读与清理。</Text>
    <BarChart categories={policies.map(p=>names[p])} series={[{name:timeTitle,tone:"info",data:groups.map(g=>mean(g.rows,timing))}]} valueSuffix=" s" height={250} showValues/>
    <Text size="small" tone="tertiary">{source}</Text>
   </Stack>
   <Stack gap={8}>
    <H2>真实调用次数与接管</H2>
    <Text size="small" tone="secondary">横轴：策略；纵轴：当前所选任务的总次数；每次SDK调用对应文字或图片请求。</Text>
    <BarChart categories={policies.map(p=>names[p])} series={[{name:"Jev文字SDK调用",tone:"info",data:groups.map(g=>total(g.rows,r=>r.text_calls))},{name:"Gemini图片SDK调用",tone:"neutral",data:groups.map(g=>total(g.rows,r=>r.visual_calls))}]} height={250} showValues/>
    <Text size="small" tone="tertiary">{source} SDK次数不等于提供商内部请求数或美元费用。</Text>
   </Stack>
  </Grid>
  <Stack gap={8}>
   <H2>耗时与用量的完整口径</H2>
   <Table headers={["策略","实际均时(s)","SDK边界(s)","其余时间(s)","文字 / 图片 / 接管","报告token数"]} rows={groups.map(g=>[names[g.policy],n(mean(g.rows,r=>r.elapsed_s)),n(mean(g.rows,r=>r.sdk_boundary_s)),n(mean(g.rows,r=>r.remainder_s)),total(g.rows,r=>r.text_calls)+" / "+total(g.rows,r=>r.visual_calls)+" / "+total(g.rows,r=>r.logical_fallbacks),total(g.rows,r=>r.tokens).toLocaleString()])} columnAlign={["left","right","right","right","right","right"]}/>
   <Text size="small" tone="secondary">SDK边界含局部capture/accounting、网络和提供商处理；“任务−SDK”只是未细分余量。不能据此拆出纯网络、模型推理或宿主CPU时间。Token来自两种模型的不同定义，record-only仍为unpriced，不作账单或节省金额。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>全部当前配对</H2>
   <Table headers={["产品 / 场景","条件","V(s)","JT(s)","JA(s)","JA−V(s)","JA−JT(s)"]} rows={pairs.map(p=>{
    const rs=policies.map(s=>rows.find(r=>r.pair_id===p.pair_id&&r.policy===s)!);
    return [p.product+" / "+families[rs[0].family],p.condition==="cold"?"冷":"预热",...rs.map(r=>n(timing(r))),n(timing(rs[2])-timing(rs[0])),n(timing(rs[2])-timing(rs[1]))];
   })} striped/>
   <Text size="small" tone="secondary">正例使用失败120秒惩罚后的完成时间；负例使用实际退出时间。负差仅表示本次配对更短；未作置信区间、显著性或采用检验。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>单组证据索引</H2>
   <Select value={active.pair_id} onChange={setSelected} options={pairs.map(p=>({value:p.pair_id,label:p.product+" / "+p.condition+" / "+p.cluster_id}))}/>
   <Table headers={["策略 / 试次ID","核验","实际(s)","文字 / 图片 / 接管","宿主退出原因"]} rows={details.map(r=>[names[r.policy]+" / "+r.id,r.success?"通过":"失败",n(r.elapsed_s),r.text_calls+" / "+r.visual_calls+" / "+r.logical_fallbacks,r.host_reason])} striped/>
   <Text size="small" tone="tertiary">每次试验均保存DB前后副本、最终HTML/图片、原始调用、派发见证、用量与SDK诊断。由独立物理审计核验，不以宿主自报完成作为成功。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>可支持的后续决策范围</H2>
   <Text>本批用于判断动作级准入是否值得继续验证。下一步应据全部成功/失败及安全证据，决定小范围扩大到未见布局和更多任务；先固定反例与评估口径，再考虑生产接线。保持当前生产默认不变。</Text>
   <Text size="small" tone="tertiary">冻结 SHA256：{DATA.scope.freeze_sha256}；独立审计：{DATA.scope.audit_sha256}。完整原始证据和精确数值见仓库research记录与归档manifest。</Text>
  </Stack>
 </Stack>;
}
'''
fields='id policy product cluster_id pair_id condition family negative success elapsed_s capped_completion_s sdk_boundary_s remainder_s text_calls visual_calls logical_fallbacks sdk_calls tokens host_reason critical_events'.split()
data['trials']=[{k:r[k] for k in fields} for r in data['trials']]
data['scope']={k:data['scope'][k] for k in ('freeze_sha256','audit_sha256')}
code=code.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')))
path=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-action-live-results.canvas.tsx')
path.write_text(code)
(root/'jev-action-live-results.canvas.tsx').write_text(code)
print(json.dumps({'canvas':str(path),'bytes':len(code.encode())},ensure_ascii=False))
