"""Descriptive paired development analysis; no model calls or billing claims."""
from pathlib import Path
import argparse,csv,hashlib,json,statistics
from collections import defaultdict

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--study',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
from benchmarks.computer_use import jev_action_live as pilot
f=json.loads((args.study/'freeze.json').read_text())
audit=pilot.audit_study(args.study,f['sha256'])
r=json.loads((args.study/'result.json').read_text())
assert audit['mode']=='live' and audit['complete'] and len(r['rows'])==36
cases={c['id']:c for c in f['cases']}
rows=[]
for row in r['rows']:
 case=cases[row['case']]
 success=row['labels']['negative_verified'] if case['negative'] else row['labels']['strict_verified']
 sdk=sum(e['elapsed_ms'] for e in row['events'] if e['kind']=='model_call' and e['phase']=='finished')/1000
 elapsed=row['elapsed_ms']/1000
 assert sdk<=elapsed+.001
 out={k:row[k] for k in ('id','case','policy','product','cluster_id','pair_id','condition','position')}
 out.update(family=case['family'],negative=bool(case['negative']),success=success,
    elapsed_s=elapsed,capped_completion_s=elapsed if row['labels']['strict_verified'] else 120,
    sdk_boundary_s=sdk,remainder_s=elapsed-sdk,**row['policy_metrics'],
    sdk_calls=len(row['calls']),tokens=row['usage']['total_tokens'],
    host_status=row['result']['status'],host_reason=row['result']['reason'],
    critical_events=row['labels']['critical_events'],unexpected_action=row['labels']['unexpected_action'])
 rows.append(out)

def summarize(items):
 pos=[row for row in items if not row['negative']]
 neg=[row for row in items if row['negative']]
 return {'positive_n':len(pos),'positive_passed':sum(row['success'] for row in pos),
    'positive_mean_capped_s':statistics.mean(row['capped_completion_s'] for row in pos),
    'positive_mean_actual_s':statistics.mean(row['elapsed_s'] for row in pos),
    'positive_mean_sdk_s':statistics.mean(row['sdk_boundary_s'] for row in pos),
    'positive_mean_remainder_s':statistics.mean(row['remainder_s'] for row in pos),
    'negative_n':len(neg),'negative_passed':sum(row['success'] for row in neg),
    'negative_mean_exit_s':statistics.mean(row['elapsed_s'] for row in neg),
    **{key:sum(row[key] for row in items) for key in ('sdk_calls','text_calls','visual_calls','logical_fallbacks','tokens','critical_events')},
    'unexpected_actions':sum(row['unexpected_action'] for row in items)}
summary=[]
for product in ['all','sqlite-web','linkding']:
 for policy in pilot.POLICIES:
  subset=[row for row in rows if row['policy']==policy and (product=='all' or row['product']==product)]
  summary.append({'product':product,'policy':policy,**summarize(subset)})
pairs=[]
by_pair=defaultdict(dict)
for row in rows:by_pair[row['pair_id']][row['policy']]=row
assert len(by_pair)==12 and all(set(group)==set(pilot.POLICIES) for group in by_pair.values())
for pair_id,group in by_pair.items():
 a=group['ja'];data={k:a[k] for k in ('product','cluster_id','condition','negative')}
 data.update(pair_id=pair_id)
 for reference in ('v','jt'):
  data['ja_minus_'+reference+'_capped_s']=a['capped_completion_s']-group[reference]['capped_completion_s']
  data['ja_minus_'+reference+'_actual_s']=a['elapsed_s']-group[reference]['elapsed_s']
 pairs.append(data)
positive_pairs=[p for p in pairs if not p['negative']]
seed_means={}
for reference in ('v','jt'):
 grouped=defaultdict(list)
 for p in positive_pairs:grouped[p['cluster_id']].append(p['ja_minus_'+reference+'_capped_s'])
 assert len(grouped)==4 and all(len(v)==2 for v in grouped.values())
 seed_means[reference]={key:statistics.mean(value) for key,value in grouped.items()}
checks={'trials':36,'seeds':6,'paired_conditions':12,'positive_seed_clusters':4,
    'condition_pairs_are_correlated':True,'new_real_study':True,'formal_confirmation':False,
    'quality_labels':'independent DB/HTML/dispatch audit; ordinary failure kept, successful-goal timer includes setup/cleanup; failures penalized at120s',
    'time_measurement':'SDK boundary includes local capture/accounting/network/provider; task minus SDK is unseparated remainder, not host CPU or intrinsic inference',
    'price':'unpriced; token/call counts are not invoices or dollar savings',
    'limitations':['Known two products/template families, six new-content seeds, not unseen-layout confirmation.','Balanced arm positions by product/start condition; provider cache/routing/service load not controlled.','No Jev image/Box comparison or general vision model ranking.','No confidence intervals or statistical adoption claims.'],
    'seed_mean_ja_minus_reference_capped_s':seed_means,
    'audit_sha256':audit['sha256'],'freeze_sha256':f['sha256']}
args.output.mkdir(exist_ok=False)
for name,data in [('trials',rows),('summary',summary),('pairs',pairs),('scope',checks),('audit',audit)]:
 (args.output/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
for name,data in [('trials',rows),('summary',summary),('pairs',pairs)]:
 with (args.output/(name+'.csv')).open('w',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
print(json.dumps({'all_policies':[s for s in summary if s['product']=='all'],'scope':checks},ensure_ascii=False,indent=2))
