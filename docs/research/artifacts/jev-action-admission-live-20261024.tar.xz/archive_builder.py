from pathlib import Path
import tarfile,hashlib,json
repo=Path('/Users/zbcjackson/src/tank')
root=Path('/private/tmp/tank-jev-action-live-20261024')
archive=repo/'docs/research/artifacts/jev-action-admission-live-20261024.tar.xz'
manifest=archive.with_name(archive.name.removesuffix('.tar.xz')+'-manifest.json')
assert not archive.exists() and not manifest.exists()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()
old=json.loads((root/'prior-artifacts70-sha256.json').read_text())
assert all(sha(repo/name)==value for name,value in old.items())
final=json.loads((root/'final-metadata.json').read_text())
files=sorted(p for p in root.rglob('*') if p.is_file() or p.is_symlink())
entries={};seen={};hardlinks=0
with tarfile.open(archive,'w:xz',preset=6) as bundle:
    for path in files:
        name=path.relative_to(root).as_posix()
        if path.is_symlink():entries[name]={'symlink':str(path.readlink())}
        else:
            stat=path.stat();value=sha(path)
            entries[name]={'bytes':stat.st_size,'sha256':value,'mode':stat.st_mode,'mtime_ns':stat.st_mtime_ns}
            if value in seen:
                info=bundle.gettarinfo(str(path),arcname=name)
                info.type=tarfile.LNKTYPE;info.linkname=seen[value];info.size=0
                bundle.addfile(info);entries[name]['hardlink']=seen[value];hardlinks+=1
                continue
            seen[value]=name
        bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:xz') as bundle:
    members=bundle.getmembers()
    assert [m.name for m in members]==list(entries)
    verified={}
    for member in members:
        expected=entries[member.name]
        if member.issym():assert member.linkname==expected['symlink']
        elif member.islnk():
            assert member.linkname==expected['hardlink']
            assert verified[member.linkname]==expected['sha256']
            assert entries[member.linkname]['bytes']==expected['bytes']
            verified[member.name]=expected['sha256']
        else:
            stream=bundle.extractfile(member);assert stream is not None
            h=hashlib.sha256()
            for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
            assert h.hexdigest()==expected['sha256'],member.name
            assert member.size==expected['bytes']
            verified[member.name]=expected['sha256']
body={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,
      'members':len(entries),'content_hardlinks':hardlinks,
      'purpose':'Source-bound 36-trial real three-policy action-admission development study with fresh synthetic public content on two known real products. Contains preserved diagnostics, complete/partial model receipts, DB/HTML/dispatch audit, simulated qualification, regression verification, bounded independent reviews, descriptive paired analysis and Canvas copy. Not a Jev image/Box study, formal confirmation, generic vision ranking or provider billing invoice. All 42 registered runtime sources and 70 old artifacts retained byte-identical. Standard TAR content hardlinks preserve every path, hash and original stat.',
      'final_metadata':final,
      'prior_artifacts_sha256':old,'entries':entries}
manifest.write_text(json.dumps(body,ensure_ascii=False,indent=2).replace('/',r'\/')+'\n')
print(json.dumps({k:body[k] for k in ('archive','sha256','bytes','members')}))
