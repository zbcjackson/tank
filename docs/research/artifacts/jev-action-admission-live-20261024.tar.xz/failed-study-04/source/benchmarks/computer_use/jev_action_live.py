"""One small source-frozen V/current-JT/action-JT development study on owned products."""
from __future__ import annotations

import copy
import hashlib
import json
import re
import tarfile
from importlib.metadata import version
from pathlib import Path

from agent_computer_use.contracts import GoalContract
from benchmarks.computer_use import jev_calibration_route as calibration
from benchmarks.computer_use import jev_action_admission, jev_sdk_diagnostics
from benchmarks.computer_use.jev_image_dev import digest

ROOT = Path(__file__).resolve().parents[2]
BASELINE = ROOT.parent / 'docs/research/artifacts/jev-action-admission-20261023.tar.xz'
BASELINE_SHA = 'a887d05a025bb547f7de027848fa27bbca1c8d06c04448c40d6572b1b820929a'
PACKAGES = ('playwright', 'openai', 'typesafe-sdk', 'pillow', 'httpx', 'httpx2')
POLICIES = ('v', 'jt', 'ja')


def sources() -> dict[str, str]:
    if hashlib.sha256(BASELINE.read_bytes()).hexdigest() != BASELINE_SHA:
        raise ValueError('reviewed prototype baseline changed')
    with tarfile.open(BASELINE) as bundle:
        stream = bundle.extractfile('verification-before-review.json')
        if stream is None:
            raise ValueError('baseline source bindings missing')
        names = list(json.load(stream)['original_registered_source_sha256'])
    names += [str(Path(module.__file__).relative_to(ROOT))
              for module in (jev_action_admission, jev_sdk_diagnostics)]
    names += [str(Path(__file__).relative_to(ROOT))]
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}


def study_cases(namespace: str) -> tuple[list[dict], list[dict]]:
    if not namespace.strip() or len(namespace) > 128:
        raise ValueError('bounded new study namespace required')
    templates = calibration.calibration_cases()
    result, schedule = [], []
    for product in ('sqlite-web', 'linkding'):
        for index, family in enumerate(('unique', 'same-title', 'missing')):
            candidates = [c for c in templates if c['product'] == product and c['family'] == family
                          and c['group'] == ('negative' if family == 'missing' else 'normal')
                          and c['condition'] == 'cold']
            template = candidates[(index + 1) % len(candidates)]
            old_nonce = template['goal']['inputs'][0]['value'].rsplit(' ', 1)[-1]
            if not re.fullmatch('[a-f0-9]{10}', old_nonce):
                raise ValueError('unexpected reviewed seed format')
            nonce = digest([namespace, product, family])[:16]
            def fresh(value):
                if isinstance(value, str):
                    return (value.replace(old_nonce, nonce).replace('/calibration/', '/action-admission-dev/')
                            .replace('Review ', 'Action study ').replace('Approved ', 'Action approved '))
                if isinstance(value, list):return [fresh(v) for v in value]
                if isinstance(value, dict):return {k:fresh(v) for k,v in value.items()}
                return value
            seed = 'aa-' + digest([namespace, product, family])[:20]
            cold_order = POLICIES[index:] + POLICIES[:index]
            for condition in ('cold', 'prewarmed'):
                order = cold_order if condition == 'cold' else cold_order[::-1]
                for position, policy in enumerate(order):
                    case = fresh(copy.deepcopy(template))
                    case.update(id='case-' + digest([namespace, seed, condition, policy])[:20],
                                cluster_id=seed, condition=condition, pair_id=seed+'-'+condition,
                                policy=policy)
                    case['goal']['goal_id'] = case['id']
                    GoalContract.from_input(case['goal'])
                    arm = 'v' if policy == 'v' else 'jt'
                    result.append(case)
                    schedule.append({'id':case['id']+'-'+arm,'case':case['id'],'arm':arm,
                                     'policy':policy,'position':position, **{k:case[k] for k in
                                     ('product','cluster_id','pair_id','condition')}})
    return result, schedule


def freeze_inputs(sql_python: Path, link_root: Path, namespace: str) -> dict:
    original = calibration.freeze_inputs(sql_python, link_root)
    cases, schedule = study_cases(namespace)
    result = {'revision':'action-admission-live-1','namespace':namespace,'formal_confirmation':False,
              'cases':cases,'schedule':schedule,'apps':original['apps'],'source_sha256':sources(),
              'versions':{name:version(name) for name in PACKAGES},'models':original['models'],
              'provenance':{**original['provenance'],BASELINE.name:BASELINE_SHA},
              'record_only':True,'price_evidence':'unpriced; inherited historical model metadata is not a current quote',
              'max_candidates':64,'seconds_per_task':120,'max_actions':6,'max_observations':24,'retries':0,
              'data_policy':{'jev':'public goal/state/candidates/history text only',
                             'peer':'same public state and bound synthetic 1280x720 PNG'},
              'policy_injection':'serial standalone process; restore VisualSelector binding in finally',
              'authorization_origin':'user: 开始直到完成实测; digest binds integrity, not a user-quoted new hash',
              'sample_scope':'6 new-content seeds in known product/template families; 36 development trials, not holdout confirmation'}
    result['sha256'] = digest(result)
    return result


def prepare(output: Path, *, sql_python: Path, link_root: Path, namespace: str) -> dict:
    if not output.is_absolute():raise ValueError('absolute new output directory required')
    frozen = freeze_inputs(sql_python, link_root, namespace)
    output.mkdir(exist_ok=False)
    for name, expected in frozen['source_sha256'].items():
        data=(ROOT/name).read_bytes()
        if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('source drift during preparation')
        path=output/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    (output/'freeze.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n')
    return frozen


def load_freeze(output: Path, approved: str) -> dict:
    frozen=json.loads((output/'freeze.json').read_text())
    if frozen['sha256']!=approved or digest({k:v for k,v in frozen.items() if k!='sha256'})!=approved:
        raise ValueError('study freeze changed')
    if (frozen['source_sha256']!=sources() or frozen['versions']!={n:version(n) for n in PACKAGES}
            or frozen['models']!={'jev':calibration.base.JEV,'peer':calibration.base.PEER}):
        raise ValueError('study runtime/model drift')
    for name, expected in frozen['source_sha256'].items():
        if hashlib.sha256((output/'source'/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('saved source changed')
    apps=frozen['apps']
    if (calibration.shared.app_manifest(Path(apps['sqlite-web']['python']))!=apps['sqlite-web']
            or calibration.link.app_manifest(Path(apps['linkding']['python']))!=apps['linkding']):
        raise ValueError('qualified product drift')
    return frozen


def eligible_aliases(packet: dict) -> set[str]:
    """Independent packet representation of the frozen mechanical text predicate."""
    from collections import Counter
    criteria = {k:v for k,v in packet['questions']['next_action']['criteria'].items()
                if isinstance(v, dict)}
    identities = {}
    for alias, value in criteria.items():
        effects = [('checkbox:checked' if value['role']=='checkbox' and
                    (f['key'].startswith('dom:checked:') or f['key']=='checkbox:'+value['label'])
                    else f['key'], f['value']) for f in value['effect']]
        changes = [packet['state']['value_change_checks'][ref]
                   for ref in value.get('change_refs', [])]
        identities[alias] = digest([value['role'], value['label'], value['ancestors'],
                                   value['current_value'],value['input_key'],effects,changes])
    counts = Counter(identities.values())
    return {alias for alias,value in criteria.items() if counts[identities[alias]]==1
            and value['label'].strip() and value['label']!=value['role']}


def audit_policy(row: dict, path: Path) -> dict:
    from collections import defaultdict
    responses = {r['call_id']:r['response'] for r in
                 map(json.loads,(path/'calls.jsonl').read_text().splitlines()) if 'response' in r}
    groups = defaultdict(list)
    for call in row['calls']:
        request=call['request']
        peer='messages' in request
        packet=json.loads(request['messages'][1]['content'][0]['text']) if peer else request
        groups[packet['state']['binding']['candidate_set_id']].append((call,packet,peer))
    routes={e['observation_id']:e['reason'] for e in row['events'] if e['kind']=='computer_use_route'}
    admissions={e['candidate_set_id']:e for e in row['events']
                if e['kind']=='computer_use_action_admission'}
    text_count=visual_count=fallbacks=0
    for identity, group in groups.items():
        first=group[0][1]
        reason=routes[first['state']['binding']['observation_id']]
        allowed=eligible_aliases(first)
        attempt=(row['policy']=='jt' and reason=='jev_eligible' or
                 row['policy']=='ja' and bool(allowed) and reason in {'jev_eligible','visual_required'})
        text=[entry for entry in group if not entry[2]]
        visual=[entry for entry in group if entry[2]]
        if len(text)!=int(attempt):raise ValueError('declared text policy differs from captured calls')
        fallback=False
        if text:
            choice=responses[text[0][0]['call_id']]['choice']
            offered=text[0][1]['questions']['next_action']['criteria']
            accepted=isinstance(offered.get(choice),dict) and (row['policy']=='jt' or choice in allowed)
            fallback=not accepted
            if row['policy']=='ja':
                event=admissions[identity]
                if (type(event['accepted']) is not bool or event['accepted']!=accepted
                        or event['next_route']!=('text_candidate' if accepted else 'visual_fallback')):
                    raise ValueError('action admission verdict differs from captured answer')
        if len(visual)!=int(not attempt or fallback):raise ValueError('visual/fallback count differs')
        for _,packet,_ in group:
            if packet['state']!=first['state'] or packet['questions']!=first['questions']:
                raise ValueError('fallback changed the full observation or candidates')
        text_count+=len(text);visual_count+=len(visual);fallbacks+=fallback
    if row['policy']!='ja' and admissions:raise ValueError('unexpected action-level policy event')
    if row['policy']=='ja' and len(admissions)!=text_count:raise ValueError('missing action admission event')
    return {'text_calls':text_count,'visual_calls':visual_count,'logical_fallbacks':fallbacks}


async def run_trial(case: dict, slot: dict, output: Path, frozen: dict, ledger,
                    jev_credential: str, peer_credential: str) -> dict:
    from contextlib import nullcontext
    from unittest.mock import patch
    from agent_computer_use import visual_selector
    original=jev_action_admission.VisualSelector
    if visual_selector.VisualSelector is not original:raise ValueError('selector namespace drift')
    context=(patch.object(visual_selector,'VisualSelector',jev_action_admission.ActionAdmissionSelector)
             if slot['policy']=='ja' else nullcontext())
    with context:
        row=await calibration.run_task(case,slot['arm'],output,frozen=frozen,ledger=ledger,
                                      jev_credential=jev_credential,peer_credential=peer_credential)
    if visual_selector.VisualSelector is not original:raise ValueError('selector restoration failed')
    row.update(policy=slot['policy'],pair_id=case['pair_id'],negative=case['negative'])
    return row


def check_diagnostics(output: Path, rows: list[dict]) -> None:
    from collections import defaultdict
    records=[json.loads(line) for line in (output/'sdk-diagnostics.jsonl').read_text().splitlines()]
    groups=defaultdict(list)
    for record in records:groups[record['call_id']].append(record)
    expected={call['call_id'] for row in rows if row['attempted'] for call in row.get('calls',[])}
    if set(groups)!=expected:raise ValueError('diagnostic call IDs differ')
    for identity, events in groups.items():
        if ([e['phase'] for e in events]!=['invoke_started','invoke_returned','call_returned']
                or events[-1]['usage_status']!='known' or events[-1]['reservation_status']!='known'):
            raise ValueError('incomplete SDK diagnostic outcome: '+identity)


async def run_batch(output: Path, approved: str, *, mode: str,
                    jev_credential: str='', peer_credential: str='') -> dict:
    import asyncio
    from contextlib import nullcontext
    from benchmarks.computer_use import jev_audit as audit, jev_execution as execution, jev_fake_http
    from tank_backend.benchmarks.spend_ledger import SpendLedger, SpendLimit
    frozen=load_freeze(output,approved)
    if mode!='fake':raise ValueError('live requires reviewed readiness')
    if any((output/name).exists() for name in ('started.json','result.json','spend.jsonl')):
        raise FileExistsError('started study cannot resume')
    with (output/'started.json').open('x') as stream:json.dump({'sha256':approved,'mode':mode},stream)
    (output/'trials').mkdir()
    rows=[{**slot,'status':'not_run','attempted':False,'cleanup_confirmed':False}
          for slot in frozen['schedule']]
    cases={c['id']:c for c in frozen['cases']}
    ledger=SpendLedger(SpendLimit(0,0),record_only=True,journal=output/'spend.jsonl')
    result={'sha256':approved,'mode':mode,'completed':False,'rows':rows,'formal_confirmation':False}
    def persist():
        result['spend']=ledger.snapshot()
        (output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    persist()
    transport_context=(jev_fake_http.offline_http(jev_fake_http.reply,output/'fake-http.jsonl')
                       if mode=='fake' else nullcontext(None))
    try:
        with transport_context as transport, jev_sdk_diagnostics.sdk_diagnostics(output/'sdk-diagnostics.jsonl'):
            for row in rows:
                try:
                    load_freeze(output,approved)
                    row.update(attempted=True,status='started');persist()
                    if transport is not None:transport['active_trial']=row['id']
                    row.update(await run_trial(cases[row['case']],row,output/'trials',frozen,ledger,
                               jev_credential or 'fixture-only',peer_credential or 'fixture-only'))
                    path=output/'trials'/row['id']
                    execution.audit_usage(row,ledger.snapshot(),path)
                    if transport is not None:
                        audit.audit_usage(row,ledger.snapshot(),[t for t in transport['requests']
                                          if t['trial_id']==row['id']])
                    row['labels']=audit.audit_trial(cases[row['case']],row,path)
                    row['policy_metrics']=audit_policy(row,path)
                    if row['labels']['critical_events'] or row['labels']['unexpected_action']:
                        ledger.stop('critical_action')
                except asyncio.CancelledError:
                    ledger.stop('cancelled');row['status']='cancelled';raise
                except Exception as error:
                    path=output/'trials'/row['id']/'row.json'
                    if path.exists():row.update(json.loads(path.read_text()))
                    row.update(status='error',error_type=type(error).__name__)
                    ledger.stop('operational_error')
                persist()
                if ledger.snapshot()['stop_reason']:break
            result['completed']=not ledger.snapshot()['stop_reason'] and all(
                row['status']=='finished' and row['cleanup_confirmed'] and 'labels' in row for row in rows)
            if result['completed']:check_diagnostics(output,rows)
            result['fake_external_requests']=(len(transport['blocked_external']) if transport is not None else None)
    except BaseException:
        ledger.stop('batch_error');result['completed']=False;raise
    finally:
        ledger.close();persist()
    return result
