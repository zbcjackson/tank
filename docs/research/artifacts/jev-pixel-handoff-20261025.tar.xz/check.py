"""Offline reconciliation and deliberately invalid evidence checks; no SDK imports."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/zbcjackson/src/tank')
def digest(p):return sha256(p.read_bytes()).hexdigest()
f=json.loads((ROOT/'freeze.json').read_text())
for name,expected in f['files'].items():assert digest(ROOT/name)==expected
for name,expected in f['sources'].items():assert digest(ROOT/'sources'/name)==expected and digest(REPO/name)==expected
q=ROOT/'qualification'
a=json.loads((q/'variant-0/normalized-packet.json').read_text());b=json.loads((q/'variant-1/normalized-packet.json').read_text());assert a==b
assert digest(q/'variant-0/frame.png')!=digest(q/'variant-1/frame.png')
assert json.loads((q/'comparison.json').read_text())['model_state_equal']
prior=ROOT/'prior-checks/verification.json'
v=json.loads(prior.read_text())
for name,expected in v['source_sha256'].items():assert digest(ROOT/'sources'/name)==expected and digest(REPO/name)==expected
for name,expected in v['checked_python_and_ts_sha256'].items():assert digest(prior.parent/'checked-sources'/name)==expected and digest(REPO/name)==expected
assert len(v['checks'])==9
for c in v['checks'].values():assert c['exit_code']==0 and digest(prior.parent/c['log'])==c['sha256']
output=ROOT/'fake';assert json.loads((output/'result.json').read_text())['completed']
subprocess.run([sys.executable,str(ROOT/'audit.py'),'fake'],check=True,stdout=subprocess.DEVNULL)
negative=[]
for kind in ('wrong-source','wrong-image-choice','wrong-frame-id','wrong-image-hash','missing-return','changed-database'):
    test=Path(tempfile.mkdtemp(prefix='tank-pixel-negative-',dir='/private/tmp'))
    shutil.copyfile(ROOT/'freeze.json',test/'freeze.json');shutil.copytree(output,test/'fake')
    case=test/'fake/pixel-task'
    if kind=='wrong-source':
        p=case/'task-result.json';data=json.loads(p.read_text());data['details']['progress']['recent_steps'][0]['changes'][0]['after']=data['details']['progress']['recent_steps'][0]['changes'][0]['after'].replace('/2/edit','/1/edit');p.write_text(json.dumps(data))
        p=test/'fake/result.json';d=json.loads(p.read_text());d['rows'][0]['result']=data;p.write_text(json.dumps(d))
    elif kind=='wrong-image-choice':
        p=case/'captures.json';d=json.loads(p.read_text());response=next(x for x in d if 'response' in x and 'choices' in x['response']);response['response']['choices'][0]['message']['content']='{"choice":"c8"}';p.write_text(json.dumps(d))
    elif kind=='wrong-frame-id':
        p=case/'captures.json';d=json.loads(p.read_text());request=next(x['request'] for x in d if x.get('purpose')=='computer_use.visual' and 'request' in x)
        packet=json.loads(request['messages'][1]['content'][0]['text']);packet['frame_id']='unbound-review-frame';request['messages'][1]['content'][0]['text']=json.dumps(packet);p.write_text(json.dumps(d))
    elif kind=='wrong-image-hash':
        p=case/'events.json';d=json.loads(p.read_text());proposal=next(x['metadata'] for x in d if x['kind']=='computer_use_proposal' and x['metadata']['source']=='visual');proposal['image_sha256']='0'*64;p.write_text(json.dumps(d))
    elif kind=='missing-return':
        p=case/'task-result.json';d=json.loads(p.read_text());d['details']['progress']['recent_steps'].pop();p.write_text(json.dumps(d))
    else:
        import sqlite3
        with sqlite3.connect(case/'app/data/db.sqlite3') as db:db.execute("UPDATE bookmarks_bookmark SET title='wrong' WHERE id=1")
    result=subprocess.run([sys.executable,str(ROOT/'audit.py'),'fake',str(test)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert result.returncode!=0,kind
    negative.append(dict(case=kind,rejected=True,log=result.stderr.decode().splitlines()[-1]))
report=dict(all_passed=True,freeze_sha256=digest(ROOT/'freeze.json'),runtime_files=len(f['sources']),prior_full_checks_reused=9,prior_backend='6836 passed, 1 skipped',prior_e2e='24 scenarios, 95 steps',negative_audits=negative,new_real_calls=0)
(ROOT/'offline-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
