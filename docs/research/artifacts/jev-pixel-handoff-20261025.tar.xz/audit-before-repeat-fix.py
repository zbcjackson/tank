"""Independent offline task audit. No driver imports, credentials, SDK or execution."""
import base64
from collections import Counter
from hashlib import sha256
import io
import json
from pathlib import Path
import sqlite3
import sys
from urllib.parse import urlsplit
from PIL import Image
ROOT=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path(__file__).resolve().parent
mode=sys.argv[1];output=ROOT/mode;p=output/'pixel-task'
def read(name):return json.loads((p/name).read_text())
f=json.loads((ROOT/'freeze.json').read_text());batch=json.loads((output/'result.json').read_text())
assert batch['freeze_sha256']==sha256((ROOT/'freeze.json').read_bytes()).hexdigest()
assert len(batch['rows'])==1;row=batch['rows'][0];assert row['attempted'] and not row['error_type']
before=read('database-before.json');after=read('database-after.json');assert before==after,'bookmark database changed'
with sqlite3.connect((p/'app/data/db.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    db.row_factory=sqlite3.Row
    tables={name:[dict(r) for r in db.execute('SELECT * FROM '+name+' ORDER BY rowid')] for name in before['tables']}
    schema=[list(r) for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
assert tables==before['tables'] and schema==before['schema']
assert before['records']==f['seed']
initial=read('initial-public-dom.json');goal=read('goal.json');origin=urlsplit(goal['completion'][0]['value']);origin=origin.scheme+'://'+origin.netloc
assert goal=={**f['goal_recipe'],'completion':[dict(key='status:Page URL',value=origin+'/bookmarks?q=Entry+%23keep')]}
assert initial['ready'] and initial['complete'] and initial['viewport']==[1280,720]
assert next(x['value'] for x in initial['facts'] if x['key']=='status:Page URL')==origin+'/bookmarks?q=Entry'
assert goal['completion'][0] not in initial['facts']
result=read('task-result.json');assert row['result']==result
assert result['cleanup']=='confirmed' and result['details']['pending_effect'] is False
cleanup=read('cleanup.json');assert cleanup['server_exit'] is not None and cleanup['runner_cleanup']=='confirmed'
http=[json.loads(x) for x in (p/'http.jsonl').read_text().splitlines()];assert all(x['method']=='GET' for x in http)
captures=read('captures.json');events=read('events.json');execution=read('audit.json')
requests=[x for x in captures if 'request' in x];responses=[x for x in captures if 'response' in x]
reqs={x['call_id']:x for x in requests};resps={x['call_id']:x['response'] for x in responses}
starts=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='started']
ends=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='finished'];spent=batch['spend']['requests']
assert 0<len(reqs)==len(requests)==len(responses)==len(starts)==len(ends)
assert set(reqs)==set(resps)==set(spent)=={e['call_id'] for e in starts}=={e['call_id'] for e in ends}
choices=[];images=[];selected=[];tokens=0;previous=None
for end in ends:
    call=end['call_id'];request=reqs[call];response=resps[call];charge=spent[call]
    a,b=end['prompt_tokens'],end['completion_tokens'];assert type(a) is int and type(b) is int and a>=0 and b>=0
    assert end['status']=='returned' and charge['status']=='known' and charge['trial']=='pixel-task'
    assert (a,b)==(charge['input_tokens'],charge['output_tokens']);tokens+=a+b
    if request['model']==f['jev']['model']:
        assert request['url']==f['jev']['url'] and request['purpose']=='computer_use.jev'
        packet=request['request'];assert set(packet)=={'model','state','questions'};previous=packet
        assert (response['input_tokens'],response['output_tokens'])==(a,b);choice=response['choice'];source='jev'
    else:
        assert request['model']==f['vision']['model'] and request['url'].startswith(f['vision']['url'])
        assert request['purpose']=='computer_use.visual';params=request['request'];parts=params['messages'][1]['content']
        assert len(parts)==2 and parts[0]['type']=='text' and parts[1]['type']=='image_url'
        packet=json.loads(parts[0]['text']);assert previous is not None and packet['state']==previous['state'] and packet['questions']==previous['questions']
        png=base64.b64decode(parts[1]['image_url']['url'].split(',')[1],validate=True);im=Image.open(io.BytesIO(png)).convert('RGB');assert im.size==(1280,720)
        image_record=dict(call_id=call,sha256=sha256(png).hexdigest(),frame_id=packet['frame_id']);images.append(image_record)
        assert (response['usage']['prompt_tokens'],response['usage']['completion_tokens'])==(a,b)
        choice=json.loads(response['choices'][0]['message']['content'])['choice'];source='visual'
        edits={k:c for k,c in packet['questions']['next_action']['criteria'].items() if isinstance(c,dict) and c.get('label')=='Edit'}
        assert len(edits)==2
        red=[(x,y) for y in range(im.height) for x in range(im.width) if (lambda c:c[0]>160 and c[1]<80 and c[2]<80)(im.getpixel((x,y)))]
        assert len(red)>100
        center=sum(y for x,y in red)/len(red)
        expected=min(edits,key=lambda k:abs(packet['image_candidates'][k][1]+packet['image_candidates'][k][3]/2-center))
        assert choice==expected,'image choice does not match red preview'
        assert edits[choice]['effect'][0]['value'].startswith(origin+'/bookmarks/2/edit?')
        (p/'sent-frame.png').write_bytes(png)
    assert packet['state']['goal']==goal and packet['state']['binding']['observation_id']==packet['state']['snapshot']['observation_id']
    assert packet['state']['evidence_contract']['sources']['goal.completion']=='desired_outcomes'
    assert not any(x['key'].startswith(('status:Records','status:List rows','status:Editor seen')) for x in packet['state']['snapshot']['facts'])
    criteria=packet['questions']['next_action']['criteria'];choices.append(dict(model=request['model'],choice=choice,source=source))
    if choice in criteria and isinstance(criteria[choice],dict):selected.append(dict(source=source,choice=choice,detail=criteria[choice]))
proposals=[e['metadata'] for e in events if e['kind']=='computer_use_proposal'];receipts=result['details']['receipts'];steps=result['details']['progress']['recent_steps']
assert len(selected)==len(proposals)==len(receipts)==len(steps)
for chosen,proposal,receipt,step in zip(selected,proposals,receipts,steps):
    assert proposal['source']==chosen['source'] and proposal['model_choice']==chosen['choice']
    assert proposal['action_id']==receipt['action_id']==step['action_id']
    assert receipt['status']=='sent' and step['dispatch_status']=='sent' and step['effect_status']=='verified'
    assert chosen['detail']['role']==step['role'] and chosen['detail']['label']==step['label']
    changes=[c for c in step['changes'] if c['key']=='status:Page URL'];assert len(changes)==1
    assert chosen['detail']['effect']==[dict(key='status:Page URL',value=changes[0]['after'])]
paths=[urlsplit(next(c['after'] for c in step['changes'] if c['key']=='status:Page URL')).path for step in steps]
labels=[s['label'] for s in steps]
correct_source=(result['status']=='completed' and result['reason']=='goal_verified' and paths==['/bookmarks/2/edit','/bookmarks','/bookmarks'] and labels==['Edit','Cancel','Keep'])
if correct_source:
    assert steps[0]['changes'][0]['after'].startswith(origin+'/bookmarks/2/edit?return_url=')
    assert steps[1]['changes'][0]['after']==origin+'/bookmarks?q=Entry'
    assert steps[2]['changes'][0]['after']==goal['completion'][0]['value']
    assert any(x['path']=='/bookmarks/2/edit' and x['status'].startswith('200') for x in http)
    assert not any(x['path']=='/bookmarks/1/edit' for x in http)
    assert result['details']['progress']['recent_action']['target_ref']==selected[-1]['detail']['target_ref']
for call in {x['call_id'] for x in execution}:
    seq=[x for x in execution if x['call_id']==call];assert [x['phase'] for x in seq]==['prepared','dispatch','finished'] and seq[-1]['status']=='returned'
assert Counter(x['operation'] for x in execution if x['phase']=='finished')['computer_use.dispatch']==len(receipts)
assert batch['spend']['stop_reason'] is None and batch['spend']['batch']['reserved_tokens']==0
assert batch['spend']['batch']['known_tokens']==tokens and len(spent)==batch['spend']['batch']['admitted_requests']<=8
assert not row['blocked_network']
handoff=(correct_source and len(images)==1 and [s['source'] for s in selected]==['visual','jev','jev'] and choices[0]['choice'] in {'need_more_context','ambiguous','none','escalate'})
report=dict(evidence_complete=True,correct_source=correct_source,handoff_observed=handoff,task_status=result['status'],reason=result['reason'],sdk_calls=len(reqs),models=dict(Counter(r['model'] for r in requests)),tokens=tokens,choices=choices,images=images,selected=selected,post_count=0,writes=0,actions=len(receipts),cleanup_confirmed=True)
write=lambda path,value:path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
write(p/'independent-audit.json',report)
write(output/'independent-audit.json',dict(all_passed=report['evidence_complete'] and report['correct_source'] and (handoff or mode!='fake'),reports=[report]))
print(json.dumps({k:v for k,v in report.items() if k not in {'selected','images'}},ensure_ascii=False))
if mode=='fake':assert handoff
