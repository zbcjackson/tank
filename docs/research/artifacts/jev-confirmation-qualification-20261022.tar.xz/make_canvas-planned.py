import json
from pathlib import Path
ROOT=Path(__file__).parent
run=ROOT/'run-v4'
cases=json.loads((run/'cases.json').read_text())
native=json.loads((ROOT/'native-independent.json').read_text())
fake=json.loads((ROOT/'fake-independent.json').read_text())
actual=json.loads((run/'fake/result.json').read_text())
nby={r['id']:r for r in native['rows']};fby={r['id']:r for r in fake['rows']}
rows=[]
for c in cases:
 n=nby[c['id']];a=[fby[c['id']+'-'+arm] for arm in c['reserved_arm_order']]
 rows.append({'id':c['id'],'product':c['product'],'condition':c['condition'],'stratum':c['reserved_stratum'],'target':c['target'],'negative':c['negative'],'native':bool(n['business'] and n['script_finished'] and n['cleanup'] and n['list_model_eligible']),'captures':len(n['states']),'fakePassed':sum(x['physical_and_http_match'] and x['cleanup'] for x in a),'fakePng':sum(x['png'] for x in a),'sdk':sum(x['sdk_calls'] for x in a),'order':' → '.join(c['reserved_arm_order'])})
data={'staticGoals':24576,'seeds':48,'rows':rows,'fakeSDK':fake['fake_SDK_calls'],'fakeImages':fake['fake_image_calls'],'nativeImages':native['capture_accepted'],'oldArtifacts':44,'freeze':json.loads((run/'freeze.json').read_text())['sha256']}
source='''import {Stack,Row,H1,H2,Text,Stat,Table,Select,Callout,useState,useHostTheme} from "cursor/canvas";
type RecordRow={id:string;product:string;condition:string;stratum:string;target:number;negative:string|null;native:boolean;captures:number;fakePassed:number;fakePng:number;sdk:number;order:string};
const DATA: {staticGoals:number;seeds:number;rows:RecordRow[];fakeSDK:number;fakeImages:number;nativeImages:number;oldArtifacts:number;freeze:string}=__DATA__;
export default function Qualification(){
 const theme=useHostTheme();const[product,setProduct]=useState("all");const[condition,setCondition]=useState("all");
 const rows=DATA.rows.filter(x=>(product==="all"||x.product===product)&&(condition==="all"||x.condition===condition));
 const cells=Array.from(new Set(rows.map(x=>x.stratum))).map(name=>{const rs=rows.filter(x=>x.stratum===name);return[name,`${rs.filter(x=>x.native).length}/${rs.length}`,`${rs.reduce((n,x)=>n+x.fakePassed,0)}/${rs.length*2}`,rs.reduce((n,x)=>n+x.captures,0),rs.reduce((n,x)=>n+x.fakePng,0)]});
 return <Stack gap={22} style={{padding:24,maxWidth:1120,margin:"0 auto",color:theme.text.primary}}>
 <Stack gap={8}><H1>新任务库：原生与执行器资格</H1><Text tone="secondary">2026-10-22 · 原版 sqlite-web 0.8.1 / linkding 1.47.0 · 只测试接线与验收机制</Text><Callout tone="info">固定48组seed、96份目标的原生资格及192次模拟模型任务已核验。正式N仍未准入；此处的通过率不是模型能力或正式确认结果。</Callout></Stack>
 <Row gap={24} wrap><Stat label="全库目标结构解析" value={DATA.staticGoals.toLocaleString()}/><Stat label="原生业务 / 清理" value="96 / 96"/><Stat label="模拟任务验收 / 清理" value="192 / 192"/><Stat label="真实模型调用" value="0"/></Row>
 <Stack gap={10}><H2>查看覆盖与图片证据</H2><Row gap={12} wrap><Select value={product} onChange={setProduct} options={[{value:"all",label:"两个产品"},{value:"sqlite-web",label:"sqlite-web"},{value:"linkding",label:"linkding"}]}/><Select value={condition} onChange={setCondition} options={[{value:"all",label:"冷 / 预热"},{value:"cold",label:"冷启动"},{value:"prewarmed",label:"预热服务、新浏览器上下文"}]}/></Row><Table headers={["固定场景层","原生通过 / 目标数","模拟通过 / 次数","原生PNG(张)","模拟图片调用(次)"]} rows={cells}/><Text size="small" tone="secondary">来源：native-independent.json / fake-independent.json · 2026-10-22。正例每层rank0–3，负例每层rank0–1；两条件保留，同组按原顺序运行V/JT。原生96目标只覆盖固定前缀，全库24576份仅完成结构验证。</Text></Stack>
 <Stack gap={8}><H2>通过的是什么</H2><Text>正例：正确身份、实际DB与全部业务表变化、一次业务POST、返回列表、GET故障恢复、候选及PNG。负例：缺目标退出、编辑器内撤权、无业务POST且DB不变。原生脚本与真实Controller/官方SDK的模拟运行分开记录。</Text><Text>共{DATA.fakeSDK}次模拟SDK调用、{DATA.fakeImages}次模拟图片调用，以及{DATA.nativeImages}张原生资格PNG。假答案从公开目标和候选生成，不能解释为Jev或视觉模型的判断准确率；10tokens/次是模拟记账值。</Text></Stack>
 <Stack gap={8}><H2>固定任务明细</H2><Table headers={["任务身份","场景","目标ID","先后策略","原生","模拟通过"]} rows={rows.map(x=>[x.id,x.stratum,x.target,x.order,x.native?"通过":"失败",`${x.fakePassed}/2`])}/></Stack>
 <Stack gap={8}><H2>失败记录与下一步</H2><Text>新驱动草案的清单字段、错误记录及登录重定向失败均保留；经新冻结修正后完整重验。未改运行时代码或原版应用页面，也未挑换失败任务。旧{DATA.oldArtifacts}份归档/manifest保持。</Text><Text>下一步将统计区间候选接入经测试的离线评分器，并预注册独立补充校准。760＋152仅是可选信息目标提案；本轮没有生成真实模型执行许可，也没有消耗确认库的模型测量。</Text><Text size="small" tone="tertiary">资格冻结：{DATA.freeze}。本面板内联数据，无外部请求；来源为本轮逐项回执及独立审计。</Text></Stack>
 </Stack>}
'''.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')))
(ROOT/'jev-confirmation-qualification.canvas.tsx').write_text(source)
print('canvas source',len(source.encode()))
