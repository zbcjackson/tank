import json
from pathlib import Path
ROOT=Path(__file__).parent
native=json.loads((ROOT/'native-independent.json').read_text())
cases=json.loads((ROOT/'run-v4/cases.json').read_text())
fake=json.loads((ROOT/'fake-independent.json').read_text())
trace=json.loads((ROOT/'failure-evidence.json').read_text())
rows=[{'product':c['product'],'condition':c['condition'],'stratum':c['reserved_stratum'],'images':len(r['states']),'native':r['business'] and r['script_finished'] and r['cleanup'] and r['list_model_eligible']} for c,r in zip(cases,native['rows'])]
data={'rows':rows,'fakeRows':fake['rows'],'trace':trace['fixed_trace_repeats'],'beforeGeneration':trace['failure_trace']['before_retry']['generation'],'afterGeneration':trace['failure_trace']['after_retry']['generation'],'sameNode':trace['failure_trace']['same_Retry_node_ref']}
source='''import {Stack,Row,H1,H2,Text,Stat,Table,Select,Callout,useState,useHostTheme} from "cursor/canvas";
type Native={product:string;condition:string;stratum:string;images:number;native:boolean};
type Fake={id:string;positive:boolean;qualified:boolean;database_unchanged:boolean;cleanup:boolean;sdk_calls:number;png:number};
type Trace={repeat:number;success:boolean;reason:string;cleanup:boolean;last_builder:{reason:string;elements:number}};
const DATA:{rows:Native[];fakeRows:Fake[];trace:Trace[];beforeGeneration:number;afterGeneration:number;sameNode:boolean}=__DATA__;
export default function Qualification(){const theme=useHostTheme();const[product,setProduct]=useState("all");const[condition,setCondition]=useState("all");
 const rows=DATA.rows.filter(x=>(product==="all"||x.product===product)&&(condition==="all"||x.condition===condition));
 const cells=Array.from(new Set(rows.map(x=>x.stratum))).map(name=>{const rs=rows.filter(x=>x.stratum===name);return[name,`${rs.filter(x=>x.native).length}/${rs.length}`,rs.reduce((n,x)=>n+x.images,0)]});
 return <Stack gap={22} style={{padding:24,maxWidth:1120,margin:"0 auto",color:theme.text.primary}}>
 <Stack gap={8}><H1>任务可执行，Controller资格未通过</H1><Text tone="secondary">2026-10-22 · 原版sqlite-web0.8.1 / linkding1.47.0 · 新数据、原布局</Text><Callout tone="warning">96份目标的原生业务/图片/清理全部通过。显式模拟HTTP批次在第2项因no_viable_actions停批：1通过、1失败、190未运行。正式N仍未准入。</Callout></Stack>
 <Row gap={24} wrap><Stat label="全库目标结构解析(份)" value="24,576"/><Stat label="原生通过 / 计划目标" value="96 / 96"/><Stat label="模拟已尝试 / 计划次数" value="2 / 192"/><Stat label="未运行(次，保留分母)" value="190"/></Row>
 <Stack gap={8}><H2>关键证据：旧Retry节点仍被当成完整观察</H2><Text>失败观察ready=true、complete=true，唯一元素仍是之前的Retry，节点ref相同：{String(DATA.sameNode)}。URL已变为/bookmarks/1/edit?retry=1，编辑器投影已读到目标1；该Retry没有可验证的click_effect，候选数变为0。</Text><Text>导航generation从{DATA.beforeGeneration}到{DATA.afterGeneration}，仅检查generation变化还不足以保证文档、候选与投影来自同一状态。两次固定诊断一次成功、一次复现；不把诊断成功补进主批次。</Text><Table headers={["固定诊断重复","结果","最终候选原因","最终元素数","清理"]} rows={DATA.trace.map(t=>[t.repeat+1,t.success?"通过":"失败",t.reason,t.last_builder.elements,t.cleanup?"确认":"未确认"])}/><Text size="small" tone="secondary">来源：diagnostic-v2/*/builder-trace.json、calibration-receipt.json与failure-evidence.json。2026-10-22；假模型结果，不估计真实成功率。</Text></Stack>
 <Stack gap={8}><H2>模拟批次的实际两项</H2><Table headers={["冻结任务身份","资格","业务DB不变","SDK调用(次)","图片调用(次)","清理"]} rows={DATA.fakeRows.map(r=>[r.id,r.qualified?"通过":"失败",r.database_unchanged?"是":"否",r.sdk_calls,r.png,r.cleanup?"确认":"未确认"])}/><Text>本批6次模拟SDK调用、5次图片调用、60个模拟tokens。V正确保存一次；JT失败前无业务POST、DB不变。负例32次均未运行，不报告负例通过率。</Text></Stack>
 <Stack gap={10}><H2>原生资格覆盖与PNG</H2><Row gap={12} wrap><Select value={product} onChange={setProduct} options={[{value:"all",label:"两个产品"},{value:"sqlite-web",label:"sqlite-web"},{value:"linkding",label:"linkding"}]}/><Select value={condition} onChange={setCondition} options={[{value:"all",label:"冷 / 预热"},{value:"cold",label:"冷启动"},{value:"prewarmed",label:"预热服务、新上下文"}]}/></Row><Table headers={["固定场景层","原生通过 / 目标数","PNG(张)"]} rows={cells}/><Text size="small" tone="secondary">来源：native-independent.json · 2026-10-22。固定48组seed、96目标、416张1280×720 PNG。含80正例、8缺目标、8撤权；全部物理DB/HTTP/返回列表独立核验。只覆盖预定前缀，全库24576目标仅静态解析。</Text></Stack>
 <Stack gap={8}><H2>网络替换缺口与保留记录</H2><Text>早期run-v4/fake只有5个模拟响应，另1次Jev SDK调用绕过Mock，用假凭据被401拒绝。原账本unknown_usage保持；原外部请求硬编码0已用单独勘误纠正。没有取得真实模型输出，不把本轮称为零外部请求。</Text><Text>已修复研究驱动：为真实httpx2.AsyncClient显式注入MockTransport，独立进程SDK测试及Python外联拒绝回归通过。确认库首簇有认证失败的外发记录；后续协议必须保留该事实，不能换掉后声称整库从未外发。</Text></Stack>
 <Stack gap={8}><H2>下一步</H2><Text>先对Retry导航后的观察一致性写确定性红测试，确保DOM元素、URL、编辑器投影、候选和图片属于同一就绪文档；修复后新freeze重跑完整原生/fake资格。当前不启动补充校准或正式模型实验。</Text><Text size="small" tone="tertiary">8项研究回归通过；原生96及失败矩阵均有独立物理审计。生产源码未改、旧44工件保持。模拟输出只验证执行机制，不能比较Jev与视觉模型能力。</Text></Stack>
 </Stack>}
'''.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')))
(ROOT/'jev-confirmation-qualification.canvas.tsx').write_text(source)
print('canvas bytes',len(source.encode()))
