from collections import Counter
import pytest
import qualify

def test_fixed_prefix_keeps_conditions_arms_and_target_balance():
    cases = qualify.select_cases()
    assert len(cases) == 96
    assert len({c['cluster_id'] for c in cases}) == 48
    assert Counter(c['condition'] for c in cases) == {'cold':48,'prewarmed':48}
    assert Counter(bool(c['negative']) for c in cases) == {False:80,True:16}
    for product in ('sqlite-web','linkding'):
        for condition in ('cold','prewarmed'):
            for target in (1,4):
                rows = [c for c in cases if c['product']==product and c['condition']==condition and c['target']==target and not c['negative']]
                assert len(rows)==10
                assert Counter(c['reserved_arm_order'][0] for c in rows)=={'v':5,'jt':5}
    assert all(c['reserved_rank'] < (2 if c['negative'] else 4) for c in cases)
    assert all(c['id'].startswith('hold-v2-') for c in cases)

def test_fake_policy_uses_public_identity_for_new_goal_ids():
    packet = {'state':{'goal':{'goal_id':'hold-v2-new-cold','outcomes':[{'conditions':[{'key':'status:Editor seen:4'}]}]}},
              'questions':{'next_action':{'criteria':{
                  'wrong':{'operation':'click','label':'Edit','role':'link','ancestors':[['row','1 same title']],'effect':[]},
                  'right':{'operation':'click','label':'Edit','role':'link','ancestors':[['row','4 same title']],'effect':[]},
                  'none':'none'}}}}
    assert qualify.choose(packet) == 'right'
    packet['state']['goal']['outcomes'][0]['conditions'][0]['key']='status:Editor seen:99'
    assert qualify.choose(packet) == 'none'

def test_frozen_task_tamper_is_rejected(tmp_path):
    import pytest
    frozen = qualify.prepare(tmp_path/'run')
    assert frozen['formal_N'] is None and frozen['mode']=='offline-only'
    assert len(frozen['schedule'])==192
    qualify.verify(tmp_path/'run',frozen['sha256'])
    tasks=tmp_path/'run'/'cases.json'
    tasks.write_text(tasks.read_text().replace('Approved ','Tampered ',1))
    with pytest.raises(ValueError,match='file drift'):
        qualify.verify(tmp_path/'run',frozen['sha256'])

@pytest.mark.asyncio
async def test_unknown_usage_stops_with_all_192_rows_retained(tmp_path):
    frozen = qualify.prepare(tmp_path/'run')
    result = await qualify.run_fake(tmp_path/'run',frozen['sha256'],failure='unknown')
    assert len(result['rows'])==192
    assert sum(r['attempted'] for r in result['rows'])==1
    assert result['spend']['stop_reason']=='unknown_usage'
    assert sum(r['status']=='not_run' for r in result['rows'])==191
    assert result['external_model_requests']==0

@pytest.mark.asyncio
async def test_invalid_choice_has_no_post_and_stops_qualification(tmp_path):
    import asyncio
    frozen = qualify.prepare(tmp_path/'run')
    result = await asyncio.wait_for(qualify.run_fake(tmp_path/'run',frozen['sha256'],failure='invalid'),20)
    assert len(result['rows'])==192
    assert sum(r['attempted'] for r in result['rows'])==1
    row=result['rows'][0]
    assert not row['calibration_success'] and row['cleanup_confirmed']
    assert not any(h['method']=='POST' for h in row['http'])
    assert result['spend']['stop_reason']

@pytest.mark.asyncio
async def test_transport_exception_keeps_denominator_and_cleans_up(tmp_path):
    frozen=qualify.prepare(tmp_path/'run')
    result=await qualify.run_fake(tmp_path/'run',frozen['sha256'],failure='exception')
    assert len(result['rows'])==192 and sum(r['attempted'] for r in result['rows'])==1
    row=result['rows'][0]
    assert row['cleanup_confirmed'] and not row['calibration_success']
    assert not any(h['method']=='POST' for h in row['http'])
    assert result['spend']['stop_reason']

def test_source_tamper_and_live_entry_are_rejected(tmp_path):
    import subprocess,sys
    frozen=qualify.prepare(tmp_path/'run')
    source=tmp_path/'run'/'source'/'native.py'
    source.write_text(source.read_text()+'\n# drift\n')
    with pytest.raises(ValueError,match='file drift'):
        qualify.verify(tmp_path/'run',frozen['sha256'])
    completed=subprocess.run([sys.executable,str(qualify.ROOT/'qualify.py'),'live',str(tmp_path/'run')],capture_output=True,text=True)
    assert completed.returncode==2 and 'invalid choice' in completed.stderr
