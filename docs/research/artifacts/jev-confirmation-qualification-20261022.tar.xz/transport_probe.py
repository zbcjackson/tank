import asyncio,json,socket
import httpx2
from typesafe_sdk import AsyncTypeSafeClient,Choice
import qualify

def refuse(*args,**kwargs):
    raise AssertionError('standalone probe attempted network')
socket.getaddrinfo=refuse
async def main():
    seen=[]
    def answer(payload):
        seen.append(payload)
        return {'model':'typesafe-1.14','answers':{'pick':{'type':'choice','choice':'a','confidence':1,'probabilities':{'a':1}}},'usage':{'input_tokens':7,'output_tokens':3}}
    with qualify.offline_http(answer):
        for _ in range(2):
            async with AsyncTypeSafeClient(api_key='qualification-fake',base_url='https://network-forbidden.invalid',compression=False) as client:
                await client.system_one(state={'synthetic':True},questions={'pick':Choice(criteria={'a':'first'})})
    assert len(seen)==2
    print(json.dumps({'two_mock_responses':len(seen)}))
asyncio.run(main())
