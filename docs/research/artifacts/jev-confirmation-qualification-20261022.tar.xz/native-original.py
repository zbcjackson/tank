"""Scripted fixture qualification. No model clients, credentials or Controller loop."""
import argparse,asyncio,base64,copy,dataclasses,hashlib,json,os,shutil,sys,time
from pathlib import Path
from urllib.parse import urlsplit
from benchmarks.computer_use import jev_real_product_route as sql,jev_linkding_route as link,jev_calibration_route as calibration
from agent_computer_use.channels.dom import BrowserConfig,ManagedChromiumChannel
from agent_computer_use.contracts import GoalContract
from agent_computer_use.action_builder import ActionBuilder
from agent_computer_use.visual_selector import VisualSelector
from tank_backend.agents.subagent import SubAgentAuthorization,SubAgentBudget,SubAgentContext,SubAgentStopped
from tank_backend.llm.model_data import ModelDataScope
REPO=Path('/Users/zbcjackson/src/tank');APP=Path('/private/tmp/linkding-1.47.0');SQLPY=Path('/private/tmp/tank-sqlite-web-20261020-env/bin/python');LINKPY=APP/'.venv/bin/python'
def serial(x):
 if dataclasses.is_dataclass(x):return dataclasses.asdict(x)
 if hasattr(x,'model_dump'):return x.model_dump(mode='json')
 raise TypeError(type(x).__name__)
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=serial)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def prepare(root):
 source=root/'qualification-source';source.mkdir(exist_ok=False)
 for path in (Path(__file__),Path('/private/tmp/tank-jev-confirmation-proxy.py')):shutil.copyfile(path,source/path.name)
 executable=json.loads((root/'executable-freeze.json').read_text());sources=executable['source_sha256']
 for name,digest in sources.items():
  p=REPO/'backend'/name;assert sha(p)==digest;dest=source/'runtime'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 f={'kind':'four-record-after-fix-script-only-qualification','model_execution_eligible':False,'model_calls':0,'tasks_sha256':sha(root/'calibration-tasks.json'),'protocol_sha256':sha(root/'protocol.json'),'source_sha256':sources,'scripts':{p.name:sha(p)for p in source.glob('*.py')},'apps':{'sqlite-web':sql.app_manifest(SQLPY),'linkding':link.app_manifest(LINKPY)},'task_ids':[x['id']for x in json.loads((root/'calibration-tasks.json').read_text())]}
 f['sha256']=hashlib.sha256(encoded(f)).hexdigest();save(root/'qualification-freeze.json',f);return f

def verify(root,digest):
 f=json.loads((root/'qualification-freeze.json').read_text());assert f['sha256']==digest==hashlib.sha256(encoded({k:v for k,v in f.items()if k!='sha256'})).hexdigest()
 assert sha(root/'calibration-tasks.json')==f['tasks_sha256']and sha(root/'protocol.json')==f['protocol_sha256']
 for n,s in f['source_sha256'].items():assert sha(REPO/'backend'/n)==s==sha(root/'qualification-source/runtime'/n)
 for n,s in f['scripts'].items():assert sha(root/'qualification-source'/n)==s
 assert f['apps']['sqlite-web']==sql.app_manifest(SQLPY)and f['apps']['linkding']==link.app_manifest(LINKPY)
 return f

async def run(root,digest):
 frozen=verify(root,digest);out=root/'qualification';out.mkdir(exist_ok=False);rows=[];save(out/'started.json',{'sha256':digest,'task_ids':frozen['task_ids']})
 for case in json.loads((root/'calibration-tasks.json').read_text()):
  d=out/case['id'];d.mkdir();up=d/'upstream';up.mkdir();proxy=d/'proxy';proxy.mkdir();row={'id':case['id'],'product':case['product'],'group':case['group'],'qualified':False,'cleanup':False,'observations':[],'events':[],'model_calls':0};rows.append(row);processes=[];handles=[];ch=ctx=None;database=None;before=None;start=time.monotonic();product=case['product']
  async def spawn(command,cwd,log):
   h=log.open('wb');handles.append(h);p=await asyncio.create_subprocess_exec(*map(str,command),cwd=cwd,env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1'},stdout=h,stderr=asyncio.subprocess.STDOUT);processes.append(p);return p
  async def ready(p,path):
   async with asyncio.timeout(15):
    while not path.exists():assert p.returncode is None;await asyncio.sleep(.02)
   return json.loads(path.read_text())['port']
  try:
   async with asyncio.timeout(45):
    if product=='linkding':
     adapter=link.LinkdingAdapter(LINKPY);database=await adapter.initialize(d,LINKPY,case);read=link.database_state;command=adapter.server_command(LINKPY,database,up);cwd=adapter.server_directory(database,up)
    else:
     database=d/'fixture.db';sql.create_database(database,case['seed']);read=sql.database_state;command=(SQLPY,REPO/'backend/benchmarks/computer_use/jev_real_product_route.py','--serve','--database',database,'--output',up);cwd=REPO/'backend'
    before=read(database);sql.backup_database(database,d/'before.db');save(d/'before.json',before)
    token=base64.urlsafe_b64encode(f'[{case["target"]}]'.encode()).decode().rstrip('=');edit=f'/bookmarks/{case["target"]}/edit'if product=='linkding'else f'/work_items/update/{token}/';list_path='/bookmarks'if product=='linkding'else'/work_items/content/'
    service=await spawn(command,cwd,up/'app.log');port=await ready(service,up/'ready.json');command=[sys.executable,root/'qualification-source/tank-jev-confirmation-proxy.py','--upstream',port,'--output',proxy]
    if case['fault_stage']:command+=['--fault',list_path if case['fault_stage']=='list'else edit]
    bridge=await spawn(command,root,proxy/'proxy.log');port=await ready(bridge,proxy/'ready.json');origin=f'http://127.0.0.1:{port}'
    class Observer:
     def on_event(self,kind,metadata):row['events'].append({'kind':kind,**metadata})
    ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event(),observer=Observer(),model_data_scope=ModelDataScope(frozenset({'text','image'}),33554432));ctx.runtime.bind(case['id']);ch=ManagedChromiumChannel(BrowserConfig(scope=case['public_goal']['scope'],url=origin+('/login/'if product=='linkding'else list_path)));visual=VisualSelector(ch);visual.register(ctx);goal=GoalContract.from_input(case['public_goal'])
    await ch.start(ctx);assert ch.page is not None
    if product=='linkding':
     auth=json.loads((d/'auth.json').read_text());await ch.page.context.add_cookies([{**auth,'url':origin}]);await ch.page.goto(origin+list_path,timeout=5000)
    page=ch.page
    async def observe(phase):
     await page.wait_for_load_state('load',timeout=5000);await page.wait_for_function("document.readyState === 'complete'",timeout=5000);snap=await ch.observe(goal.scope,ctx);actions=ActionBuilder(64,visual=True).build(case['id'],1,goal,snap);entry={'phase':phase,'snapshot':snap,'actions':actions,'capture':'refused'};row['observations'].append(entry)
     try:
      frame=await visual.capture_frame(snap,actions,ctx);entry.update(capture='accepted',frame=frame.frame,bounds=frame.bounds);name=f'{len(row["observations"]):02}-{phase}.png';(d/name).write_bytes(frame.png);entry['png']=name
     except Exception as exc:entry.update(error_type=type(exc).__name__,reason=str(exc))
     entry['page_url']=page.url;entry['list']=await page.evaluate(link._PAGE_READ if product=='linkding'else sql._LIST_READ);save(d/'row.json',row);return actions
    if case['fault_stage']=='list':
     await page.get_by_role('link',name='Retry',exact=True).wait_for(timeout=5000);await observe('list-fault');await page.get_by_role('link',name='Retry',exact=True).click(timeout=5000)
    actions=await observe('list')
    if case['group']=='negative':
     if case['family']=='missing':
      assert all(x['id']!=case['target']for x in before['records']);row['negative_evidence']='target absent from actual physical records; scripted abstention, not a model refusal'
     else:
      await page.goto(origin+edit,timeout=5000);actions=await observe('revocation-editor-setup');action=next(x for x in actions.actions if x.operation=='click');ctx.authorization.revoke()
      try:await ch.dispatch(actions.binding,action,ctx)
      except SubAgentStopped as exc:row['negative_evidence']={'type':type(exc).__name__,'detail':str(exc)}
      else:raise AssertionError('revoked dispatch did not raise')
    else:
     if product=='linkding':await page.locator(f'li[data-bookmark-id="{case["target"]}"]').get_by_role('link',name='Edit',exact=True).click(timeout=5000)
     else:await page.locator(f'a[href="{edit}"]').click(timeout=5000)
     if case['fault_stage']=='editor':
      await page.get_by_role('link',name='Retry',exact=True).wait_for(timeout=5000);await observe('editor-fault');await page.get_by_role('link',name='Retry',exact=True).click(timeout=5000)
     await page.get_by_label('Title'if product=='linkding'else'title',exact=True).wait_for(state='visible',timeout=5000);await observe('editor')
     if product=='sqlite-web':await page.locator('input[name="chk_title"]').check(timeout=5000);await observe('title-enabled')
     await page.get_by_label('Title'if product=='linkding'else'title',exact=True).fill(case['public_goal']['inputs'][0]['value'],timeout=5000);await observe('filled')
     await page.get_by_role('button',name='Save'if product=='linkding'else'Update',exact=True).click(timeout=5000);await page.wait_for_url(lambda url: urlsplit(url).path==list_path,timeout=5000);await observe('returned')
     row['returned_list']=await page.evaluate(link._PAGE_READ if product=='linkding'else sql._LIST_READ)
    row['script_finished']=True
  except BaseException as exc:
   if isinstance(exc,(KeyboardInterrupt,asyncio.CancelledError)):raise
   row['error']={'type':type(exc).__name__,'reason':str(exc)}
  finally:
   if ch:await ch.aclose()
   if ctx:await ctx.runtime.aclose()
   for p in reversed(processes):
    if p.returncode is None:p.terminate()
    try:await asyncio.wait_for(p.wait(),5)
    except asyncio.TimeoutError:p.kill();await p.wait();row['forced_kill']=True
   for h in handles:h.close()
   row['cleanup']=bool(ch and ch.closed and all(p.returncode is not None for p in processes)and not row.get('forced_kill'))
   if database and database.exists():
    after=read(database);row['after']=after;sql.backup_database(database,d/'after.db');save(d/'after.json',after)
    if before:
     expected=copy.deepcopy(before)
     if case['group']!='negative':
      next(x for x in expected['records']if x['id']==case['target'])['title']=case['public_goal']['inputs'][0]['value']
      if product=='linkding':
       b=next(x for x in expected['tables']['bookmarks_bookmark']if x['id']==case['target']);a=next(x for x in after['tables']['bookmarks_bookmark']if x['id']==case['target']);b['title']=a['title'];assert a['date_modified']>b['date_modified'];b['date_modified']=a['date_modified']
      else:expected['writes']=after['writes'];row['one_SQL_update']=len(after['writes'])==1 and after['writes'][0]['operation']=='update'and after['writes'][0]['id']==case['target']
     row['business_match']=expected==after
   http=proxy/'http.jsonl';row['http']=[json.loads(s)for s in http.read_text().splitlines()]if http.exists()else[];posts=[h for h in row['http']if h['method']=='POST'];row['post_match']=(not posts)if case['group']=='negative'else(len(posts)==1 and posts[0]['path']==edit and posts[0]['status']==302);row['fault_match']=sum(h['injected']for h in row['http'])==(1 if case['group']=='recovery'else 0)
   if row.get('returned_list'):
    value=row['returned_list'];visible=value['list']['records']if product=='linkding'else value['rows'];expectedrows=case['private_acceptance']['records'];row['list_match']=sorted((r['id'],r['title'],r['url'])for r in visible)==sorted((str(r['id']),r['title'],r['url'])for r in expectedrows)if product=='linkding'else sorted(visible)==sorted([[str(r[k])for k in('id','title','notes')]for r in expectedrows])
   else:row['list_match']=case['group']=='negative'
   row['model_calls']=sum(e['kind']=='model_call'for e in row['events']);row['qualified']=bool(row.get('script_finished')and row.get('business_match')and row['post_match']and row['fault_match']and row['list_match']and row['cleanup']and all(o['capture']=='accepted'and o['snapshot'].complete and (o['phase']=='returned' or len(o['actions'].actions)>0) for o in row['observations'])and not row['model_calls']);row['elapsed_seconds']=time.monotonic()-start;save(d/'row.json',row);save(out/'result.json',{'sha256':digest,'rows':rows,'planned':24,'model_calls':0,'not_a_controller_model_success_rate':True});print(json.dumps({k:row.get(k)for k in('id','qualified','cleanup','error','business_match','post_match','fault_match','list_match')}),flush=True)
 verify(root,digest);return {'planned':24,'executed':len(rows),'qualified':sum(r['qualified']for r in rows),'cleanup':sum(r['cleanup']for r in rows),'model_calls':sum(r['model_calls']for r in rows)}
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--run');a=p.parse_args()
print(json.dumps(asyncio.run(run(a.root,a.run))if a.run else {'sha256':prepare(a.root)['sha256']}))
