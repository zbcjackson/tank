"""Independent physical/HTTP/SDK-capture audit, not a model scorer."""
import base64,copy,hashlib,io,json,sqlite3,sys
from collections import Counter
from contextlib import closing
from pathlib import Path
from PIL import Image
ROOT=Path(sys.argv[1]);OUT=Path(__file__).parent/'fake-independent.json'
read=lambda p:json.loads(p.read_text())

def physical(path,product):
    with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)) as db:
        db.row_factory=sqlite3.Row;db.execute('BEGIN')
        schema=[list(r) for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
        if product=='sqlite-web':return {'schema':schema,'records':[dict(r) for r in db.execute('SELECT * FROM work_items ORDER BY id')],'writes':[dict(r) for r in db.execute('SELECT * FROM _writes ORDER BY rowid')]}
        names=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'bookmarks_%' ORDER BY name")]
        assert len(names)==10
        return {'schema':schema,'tables':{n:[dict(r) for r in db.execute('SELECT * FROM '+n+' ORDER BY rowid')] for n in names}}

f=read(ROOT/'freeze.json');cases={c['id']:c for c in read(ROOT/'cases.json')};result=read(ROOT/'fake/result.json')
assert not result['completed'] and len(result['rows'])==len(f['schedule'])==192
assert [x['status'] for x in result['rows'][2:]]==['not_run']*190
positive=negative=posts_total=images=requests=revoked=missing=0;arms=Counter();report=[]
for scheduled,row in zip(f['schedule'],result['rows']):
    assert all(row[k]==v for k,v in scheduled.items())
    if not row['attempted']:continue
    c=cases[row['case']];d=ROOT/'fake'/row['id'];product=c['product']
    assert row['attempted'] and row['status']=='finished' and row['cleanup_confirmed'] and row['elapsed_ms']<=120000
    assert row['app_unchanged'] and row.get('trial_source_unchanged',product!='linkding')
    assert bool(row['prewarm'])==(c['condition']=='prewarmed')
    before=physical(d/'before.db',product);after=physical(d/'after.db',product);want=copy.deepcopy(before)
    http=[json.loads(s) for s in (d/'http.jsonl').read_text().splitlines()];assert http==row['http']
    posts=[h for h in http if h['method']=='POST'];posts_total+=len(posts)
    if not row['calibration_success']:
        assert before==after and not posts and row['result']['reason']=='no_viable_actions' and row['arm']=='jt'
    elif c['negative']:
        negative+=1;assert before==after and not posts and row['negative_passed'] and not row['strict_completed']
        if c['negative']=='missing':
            missing+=1;records=before['records'] if product=='sqlite-web' else before['tables']['bookmarks_bookmark'];assert all(r['id']!=c['target'] for r in records)
            assert row['result']['reason'] in ('none','escalate')
        else:
            revoked+=1;assert row['revocation']['before_native_dispatch'] and row['result']['reason']=='error'
            assert row['revocation']['path']==c['oracle']['edit_path']
    else:
        positive+=1;assert row['strict_completed'] and not row['negative_passed']
        records=want['records'] if product=='sqlite-web' else want['tables']['bookmarks_bookmark']
        record=next(r for r in records if r['id']==c['target']);record['title']=c['goal']['inputs'][0]['value']
        if product=='sqlite-web':
            assert len(after['writes'])==1 and after['writes'][0]['operation']=='update' and after['writes'][0]['id']==c['target'];want['writes']=after['writes']
        else:
            actual=next(r for r in after['tables']['bookmarks_bookmark'] if r['id']==c['target']);assert actual['date_modified']>record['date_modified'];record['date_modified']=actual['date_modified']
        assert want==after and len(posts)==1 and posts[0]['path']==c['oracle']['edit_path'] and posts[0]['status'].startswith('302 ')
        if c['fault_stage']:assert sum(h.get('injected',False) for h in http)==1
    arms[row['arm']+'/'+('negative' if c['negative'] else 'positive')]+=1
    calls=row['calls'];requests+=len(calls)
    for call in calls:
        request=call['request'];visual='messages' in request
        packet=json.loads(request['messages'][1]['content'][0]['text']) if visual else request
        goal=packet['state']['goal'];assert goal['goal_id']==c['id'] and goal['intent']==c['goal']['intent']
        assert [(x['key'],x['value'],x['field_label'])for x in goal['inputs']]==[(x['key'],x['value'],x['field_label'])for x in c['goal']['inputs']]
        assert not any(key in packet or key in packet['state'] for key in ('oracle','private_acceptance','seed'))
        assert len(call['images'])==(1 if visual else 0)
        for image in call['images']:
            png=(d/image['path']).read_bytes();assert hashlib.sha256(png).hexdigest()==image['sha256']
            with Image.open(io.BytesIO(png)) as im:assert im.format=='PNG' and im.size==(1280,720);im.verify()
            images+=1
    report.append({'id':row['id'],'positive':not bool(c['negative']),'qualified':row['calibration_success'],'database_unchanged':before==after,'cleanup':True,'sdk_calls':len(calls),'png':sum(len(x['images']) for x in calls)})
transport=[json.loads(s) for s in (ROOT/'fake/transport.jsonl').read_text().splitlines()]
assert requests==6 and images==5
assert len(transport)==result['fake_sdk_calls']==6 and result['fake_image_calls']==5
failed=result['rows'][1];assert len(failed['calls'])==2 and len(failed['calls'][0]['images'])==1 and not failed['calls'][1]['images']
assert sum(e.get('prompt_tokens',0)+e.get('completion_tokens',0) for row in result['rows'] for e in row.get('events',[]) if e.get('kind')=='model_call' and e.get('phase')=='finished')==60
assert positive==1 and negative==0 and posts_total==1 and revoked==missing==0
summary={'scheduled_trials':192,'attempted':2,'not_run':190,'positive_passed':positive,'positive_failed':1,'negative_passed':negative,'cleanup':2,'business_POSTs':posts_total,'revocation_guards':revoked,'missing_exits':missing,'fake_SDK_calls':6,'fake_image_calls':5,'known_fake_tokens':60,'arms':dict(arms),'external_model_requests':0,'formal_N':None,'rows':report}
OUT.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='rows'}))
