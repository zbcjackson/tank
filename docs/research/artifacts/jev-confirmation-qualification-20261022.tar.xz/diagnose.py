"""Two predeclared same-case JT traces; no real SDK network."""
import asyncio,dataclasses,json
from pathlib import Path
import pytest
import qualify
from benchmarks.computer_use import jev_calibration_route as cal
from agent_computer_use.action_builder import ActionBuilder
ROOT=Path(__file__).parent;RUN=ROOT/'run-v5'
# Record the exact public builder input/output; forward unchanged.
original=ActionBuilder.build
async def main():
    output=ROOT/'diagnostic';output.mkdir(exist_ok=False)
    cases=json.loads((RUN/'cases.json').read_text());frozen=json.loads((RUN/'executable-freeze.json').read_text());summary=[]
    for index in range(2):
        dest=output/str(index);dest.mkdir();traces=[]
        def build(self,*args,**kwargs):
            result=original(self,*args,**kwargs)
            traces.append({'visual':self.visual,'snapshot':dataclasses.asdict(args[3]),'actions':dataclasses.asdict(result)})
            return result
        with pytest.MonkeyPatch.context() as patch:
            patch.setattr(ActionBuilder,'build',build)
            with qualify.offline_http(lambda payload:answer(payload)):
                row=await cal.run_task(cases[0],'jt',dest,frozen=frozen,jev_credential='qualification-fake',peer_credential='qualification-fake')
        (dest/'builder-trace.json').write_text(json.dumps(traces,ensure_ascii=False,indent=2)+'\n')
        summary.append({'repeat':index,'success':row['calibration_success'],'reason':row['result']['reason'],'cleanup':row['cleanup_confirmed'],'last_builder':{'reason':traces[-1]['actions']['reason'],'elements':len(traces[-1]['snapshot']['elements'])}})
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
def answer(payload):
    visual='messages' in payload;packet=json.loads(payload['messages'][1]['content'][0]['text']) if visual else payload
    choice=qualify.choose(packet)
    if visual:return {'id':'fixture','object':'chat.completion','created':1,'model':cal.base.PEER['model'],'choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':json.dumps({'choice':choice})}}],'usage':{'prompt_tokens':7,'completion_tokens':3,'total_tokens':10}}
    return {'model':cal.base.JEV['model'],'answers':{'next_action':{'type':'choice','choice':choice,'confidence':1,'probabilities':{k:float(k==choice) for k in packet['questions']['next_action']['criteria']}}},'usage':{'input_tokens':7,'output_tokens':3}}
asyncio.run(main())
