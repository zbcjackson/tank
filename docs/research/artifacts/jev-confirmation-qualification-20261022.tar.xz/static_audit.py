"""Independent archive/current runtime/full-bank static audit, no execution."""
import hashlib,json,tarfile
from collections import Counter
from pathlib import Path
from agent_computer_use.contracts import GoalContract
ROOT=Path(__file__).parent
REPO=Path('/Users/zbcjackson/src/tank')
ART=REPO/'docs/research/artifacts'
DESIGN=Path('/private/tmp/tank-jev-confirmation-design-20261022')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((ART/'jev-confirmation-design-20261022-manifest.json').read_text())
archive=ART/manifest['archive'];assert sha(archive.read_bytes())==manifest['sha256']
with tarfile.open(archive) as tar:
    for item in manifest['members']:
        raw=tar.extractfile(item['name']).read();assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
    archived_cases=tar.extractfile('reserved-bank/cases.jsonl').read()
    assert archived_cases==(DESIGN/'reserved-bank/cases.jsonl').read_bytes()
    frozen=json.load(tar.extractfile('inputs/calibration-freeze.json'))
for name,value in frozen['source_sha256'].items():assert sha((REPO/'backend'/name).read_bytes())==value
counts=Counter();seeds={};goals=0
for line in archived_cases.splitlines():
    c=json.loads(line);goal=GoalContract.from_input(c['goal']);assert goal.goal_id==c['id'];goals+=1
    assert not any(key in c['goal'] for key in ('oracle','private_acceptance','seed'))
    counts[c['reserved_stratum']]+=1
    seeds.setdefault(c['cluster_id'],[]).append(c['condition'])
assert goals==24576 and len(seeds)==12288 and all(sorted(v)==['cold','prewarmed'] for v in seeds.values())
old={str(p.relative_to(REPO)):sha(p.read_bytes()) for p in sorted(ART.iterdir()) if p.is_file() and p.suffix in ('.gz','.xz','.json')}
assert len(old)==44
(ROOT/'old-artifacts.json').write_text(json.dumps(old,indent=2)+'\n')
summary={'archive_members_verified':len(manifest['members']),'runtime_sources_verified':len(frozen['source_sha256']),'all_goal_contracts_parsed':goals,'seed_clusters':len(seeds),'stratum_condition_goal_counts':dict(counts),'old_artifacts_snapshotted':len(old),'model_calls':0,'formal_N':None}
(ROOT/'static-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
