"""Run without pytest's inherited SDK HTTP fixture."""
import subprocess,sys
from pathlib import Path

def test_standalone_typesafe_transport_cannot_use_network():
    root=Path(__file__).parent
    result=subprocess.run([sys.executable,str(root/'transport_probe.py')],capture_output=True,text=True,timeout=20)
    assert result.returncode==0,result.stdout+result.stderr
    assert 'two_mock_responses' in result.stdout
