"""Archive positive and negative evidence, never rewrite prior receipts."""
import hashlib,io,json,lzma,os,re,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path(__file__).parent;repo=Path('/Users/zbcjackson/src/tank');sha=lambda b:hashlib.sha256(b).hexdigest()
assert '8 passed' in (root/'tests-guarded.log').read_text()
assert (root/'canvas-tsc.log').read_bytes()==b''
assert json.loads((root/'native-independent.json').read_text())['native_fixture_business_pass']==96
assert json.loads((root/'fake-independent.json').read_text())['not_run']==190
old=json.loads((root/'old-artifacts.json').read_text());assert len(old)==44
assert all(sha((repo/n).read_bytes())==v for n,v in old.items())
f=json.loads((root/'run-v5/freeze.json').read_text());sources=f['apps']['linkding']['source_files'];original=Path(f['apps']['linkding']['root'])
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file() and not any(x in p.parts for x in ('__pycache__','.pytest_cache','app')) and p.suffix!='.pyc'}
# Working DBs are represented by physical before/after backups, not live working files.
files={n:p for n,p in files.items() if p.name!='fixture.db'}
for name,value in sources.items():
 p=original/name;assert sha(p.read_bytes())==value;files['unique-app-source/linkding/'+name]=p
# Verify every omitted per-trial application source rather than assume it matched.
trial_hashes={}
for app in root.glob('**/app'):
 if not app.is_dir():continue
 hashes={name:sha((app/name).read_bytes()) for name in sources}
 assert hashes==sources;trial_hashes[str(app.relative_to(root))]=sha(json.dumps(hashes,sort_keys=True).encode())
(root/'deduplicated-app-sources.json').write_text(json.dumps({'source_count':len(sources),'trial_sources':trial_hashes,'working_databases':'Omitted; physical before.db/after.db and full business readbacks retained.','sqlite_source_provenance':'Unmodified installed environment hashed in each freeze; earlier product archives contain application sources.'},indent=2)+'\n')
files['deduplicated-app-sources.json']=root/'deduplicated-app-sources.json'
values={**dotenv_values(repo/'backend/core/.env'),**os.environ}
credentials={v.encode() for k,v in values.items() if v and len(v)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)}
assert len(credentials)>=1
members=[]
for name,p in sorted(files.items()):
 data=p.read_bytes();assert not any(v in data for v in credentials),name
 members.append({'name':name,'bytes':len(data),'sha256':sha(data)})
target=repo/'docs/research/artifacts/jev-confirmation-qualification-20261022.tar.xz';mp=target.with_name('jev-confirmation-qualification-20261022-manifest.json')
assert not target.exists() and not mp.exists()
with target.open('xb') as out,lzma.LZMAFile(out,'w',preset=6) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for m in members:
  data=files[m['name']].read_bytes();assert sha(data)==m['sha256'];info=tarfile.TarInfo(m['name']);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(target,'r|xz') as tar:
 for actual,expected in zip(tar,members,strict=True):
  assert actual.name==expected['name'];data=tar.extractfile(actual).read();assert len(data)==expected['bytes'] and sha(data)==expected['sha256'];assert not any(v in data for v in credentials)
manifest={'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'members':members,'old_files_unchanged':44,'actual_credentials_scanned':len(credentials),'matches':0,'native_qualified':96,'fake_scheduled':192,'fake_attempted':2,'fake_passed':1,'fake_failed':1,'fake_not_run':190,'earlier_unmocked_authentication_denied_Jev_invocations':1,'earlier_unknown_usage_preserved':True,'real_model_outputs_received':0,'formal_N':None,'model_execution_eligible':False,'deduplicated_trial_app_sources':len(trial_hashes)}
mp.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='members'}));print('members',len(members))
