"""Package existing evidence; never executes trials."""
from hashlib import sha256
import json
from pathlib import Path
import tarfile
ROOT=Path(__file__).resolve().parent
DEST=Path('/Users/zbcjackson/src/tank/docs/research/artifacts/jev-spatial-evidence-20261025.tar.xz')
files={str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*'))
       if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts}
(ROOT/'manifest.json').write_text(json.dumps({'files':files},ensure_ascii=False,indent=2)+'\n')
with tarfile.open(DEST,'w:xz') as archive:
    for p in [ROOT/'manifest.json',*[ROOT/n for n in files]]:
        archive.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
with tarfile.open(DEST) as archive:
    names=archive.getnames()
    assert set(names)==set(files)|{'manifest.json'} and len(names)==len(files)+1
    assert all(member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts for member in archive.getmembers())
    for name,expected in files.items():assert sha256(archive.extractfile(name).read()).hexdigest()==expected
print(json.dumps({'artifact':str(DEST),'sha256':sha256(DEST.read_bytes()).hexdigest(),'members':len(names),'bytes':DEST.stat().st_size}))
