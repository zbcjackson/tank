# 有界空间证据/位置提示：完成审查

- 日期：2026-10-25。
- 模式：review-and-refactor；本独立任务第1轮；无旧问题，不递归委派。评审者未参与本片实现。
- 基线：2f88ad5edafeb93bb25bb56dfce2769d20eb8143；审查HEAD：a986cfd1（含afd65f95/5032b146/82eeb54c/dab2fe2e/a986cfd1）。审查完整baseline..HEAD的24文件差异，包含已提交实现/测试/文档/证据。
- 范围：4运行文件、插件依赖声明/uv.lock、2插件测试、显式旧冻结夹具及旧测试、E2E既有step、相关开发/测试/设计/计划/研究文档和归档。无用户未提交修改，工作区开始/结束均干净。
- 已显式重新读取agents/code-reviewer.md，遵守已读项目架构、后端编码/开发/测试、Git及完成审查约定。检查正确性、固定Code Smell清单、DRY/KISS/YAGNI、契约与生命周期边界，未以风格偏好制造问题。

## 结论与处置

未发现确认的可操作问题或待解决旧问题；第1轮结束，不追加无变更复审。
没有实施修改、重构或新提交，也没有评审者自修但未经独立复核的最终修改。
现有完整检查与当前源字节匹配，独立定向验证和离线证据复核通过；不需无故重复33分钟完整后端套件，不新增收费实测。

## 实现与边界核查

1. observe_bounds默认false，只有拥有的主frame且存在固定viewport_size才补充Playwright实际renderer bounding_box及视口。没有读取页面自报坐标或模型Box，也没有新增坐标执行。子frame不继承主frame坐标契约，AX行为保持。
2. 几何加入DOMView/Snapshot，受原双读一致性、is_snapshot_current及派发前原DOM/导航/场景检查覆盖；CSSOM位移、滚动引起框变化、视口尺寸变化会失效旧动作。逐元素读取后仍经过相同完整视图重读；读取失败不给候选。参考动作仍由原locator及绑定target_ref执行。
3. spatial_hint为有界、冻结的公开任务声明，role限button/link/checkbox，四方向限枚举。没有任意坐标、自然语言猜测或额外授权；缺提示保持原准入。Pydantic exclude_if在未使用时省略可选字段，snapshot几何未用时省略，旧请求形状保持。
4. spatial_candidate_ids只处理至少两个同role/label、同完整文字身份的DOM点击候选；所有匹配候选框须有限/正尺寸/视口内，viewport必须为正整数对。只有沿所需轴整个框在每个同组框一侧的候选才额外准入；重叠/缺失/越界/混合来源不借坐标放行。
5. 原text_candidate_ids先验证动作/细节身份完整性，抽取_text_identity避免重复规则；原唯一文字候选与新增最多一个空间候选取并集，全部原候选仍供选择。未通过选择沿原视觉分支，硬停止、权限、输入缺失、引用/效果/清理边界未改。非有限模型元数据在SDK/图片之前停止。
6. 依赖明确声明Pydantic最低2.12以使用可选字段省略；uv.lock只新增直接依赖及requires-dist两行，现有2.12.5版本图未变。不存在为单次任务引入通用框架或重复执行器。

## 旧回归夹具核查

- legacy_qualification_data从原可信归档及原始receipt验证冻结SHA，只在临时shadow树提供记录源；没有导入归档源码执行。当前已声明的两项amendment与execution入口仍复制当前文件，生产amendment/registration模块未改。
- _host只在显式请求fixture的测试作用域patch BACKEND/freeze_inputs，结束恢复；没有autouse扩大旧准入。行为测试仍运行正常安装的实现和真实产品。旧协议单测不冒称当前宿主资格。
- legacy_product_fingerprints验证当前固定依赖版本与全部应用/依赖代码字节，只排除生成RECORD、pyvenv.cfg及两项virtualenv bootstrap，并将安装路径作为测试指纹兼容信息；不作为重建环境新资格。
- 新当前宿主测试在真实源码根上仍被unregistered runtime change拒绝且不创建输出目录。独立复跑该测试及旧execution冻结单测，2 passed；真实本片驱动不运行pytest/conftest，不使用这些测试夹具，实际652产品文件单独冻结。

## 原始实测与证据核查

独立安全解包至/private/tmp/tank-jev-spatial-evidence-review-20261025-extracted：

- 归档SHA256为2c64f8090d77b4be4a3f1aeeecd8a1986faefaf6d3fd529ab411bdeb3df32a92；499普通成员，无越界路径/链接；manifest498项与实际集合及逐文件SHA完全一致。
- freeze SHA256为884d7d66072c2877cb23b66b6ec695ec10a8067bc68bb82140f3697703b995ce。驱动/审计原字节、353运行源/依赖、12改动Python/TS检查源与当前工作区一致；实际产品652项、旧79工件及默认config SHA匹配。verify_evidence运行后派生输出仍匹配manifest。
- 阅读run.py/audit.py/verify_evidence.py及原始请求/事件/账本/执行/页面证据：先无模型与假HTTP资格才live一次，实际Runner/原版产品，公开leftmost声明，无隐藏正确alias/ref/坐标答案、无DB完成补强或旧指纹fixture。初始URL未完成，正确来源由预冻独立审计而非共享URL单独认定。
- 真实27候选，两个work_items链接原文字身份相同；实际renderer框分别顶部约(239.75,18.296875,75.515625,17)、左侧约(15,132.796875,183.328125,30.5)，主frame1280×720元数据。Jev选择c6，accepted=true、spatial_candidates=1，与唯一Jev proposal、sent回执、近期动作id/ref对应左侧目标。
- 仅1次TypeSafe jev-1.14.0调用、1次正确引用点击；执行observe×2/dispatch×1，无computer_use.capture或视觉模型事件。completed/goal_verified、pending_effect=false、零POST/DB写入、schema与其余数据不变，清理confirmed。
- 原始SDK用量16270+287=16557，调用/捕获/响应/事件/账本完整结算，无unknown/未结预留。金额未定价、host token限额非provider预留硬上界及不同计时口径均正确限定。
- 研究/现行设计明确此次新增提示/几何、前后单样本输入不同；没有宣称视觉更弱、任意自然语言位置理解、拒绝泛化、统计效果或默认采用。

## 实际验证

独立新增检查：

1. TANK_REQUIRE_CHROMIUM=1 TANK_REAL_PRODUCT_PYTHON=/private/tmp/tank-sqlite-web-smoke-20261025-env/bin/python caffeinate -is uv run --no-sync pytest -q -rs plugins/agent-computer-use/tests/test_vision.py plugins/agent-computer-use/tests/test_dom.py -k spatial：34 passed、571 deselected，7.79秒。日志/private/tmp/tank-jev-spatial-evidence-review-targeted-20261025.log。
2. .venv/bin/python -m pytest -q -rs core/tests/test_jev_qualification.py::test_current_host_cannot_reuse_legacy_registration core/tests/test_jev_execution.py::test_prepare_freezes_full_execution_and_distinct_offline_prefix：2 passed，58.86秒。日志/private/tmp/tank-jev-spatial-evidence-review-legacy-direct-20261025.log。首次uv命令因sandbox禁止读取用户uv缓存而未启动pytest，随后直接使用同一项目venv完成，无全局配置更改。
3. 系统Python独立解包目录执行python3 verify_evidence.py：PASS；包含9项已闭合检查日志SHA、运行/测试源字节及fake/live独立业务审计。另独立比对当前源/产品/历史/config与manifest：PASS。
4. python3 scripts/check_docs.py：OK，124 files under docs/。
5. git diff --check baseline..HEAD：PASS。
6. 既有allowed-signers只读验签：本片5提交均G；没有修改签名配置。

复用并核实原完整验证（实现/检查源字节未再改变）：verification.json的9项exit_code均0、所有日志SHA匹配；6836 passed/1 skipped/21 warnings、2003.13秒，唯一跳过为ToolManager requires full config；E2E24场景95步骤通过、4m01.315s；Web lint/tsc-b、backend/CLI ruff、11改动Python pyright通过；finally原后端恢复health200、前后端reload_errors空。首轮旧产品指纹失败日志保留，不将其当作通过。tank_protocol及生成物未变，protocol_sync不适用。
没有重放run.py inspect/live、没有读取凭据或新增模型请求。没有重复完整后端/E2E或把旧轮次检查算作本片验证。

## 限制与交接

几何只支持可信主frame中的显式相对极值声明与保守分离，不覆盖区域名称解析、复杂相对关系、任意自然语言位置理解、像素语义或坐标执行。模型仍可能选择其他原唯一文字候选，机械可区分性并不等于任务正确性；本轮独立来源验收仅覆盖这个受控任务。
当前默认关闭；不能据单次直通扩大用户写入或模型优劣结论。旧实测始终绑定其原冻结源，不自动认证后续修改。
无未解决问题或验证阻塞；不宣称证明实现无缺陷。协调者核对报告/diff后可闭合计划，交回条件扩展并归档原始报告；重新封包须同步SHA/成员数，不改写原始冻结或实测结果。
