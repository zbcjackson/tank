"""Independent offline evidence audit; no driver import or model clients."""
import base64
from collections import Counter
from hashlib import sha256
from html.parser import HTMLParser
import json
from pathlib import Path
import sqlite3
import struct
import sys

ROOT=Path(__file__).resolve().parent
mode=sys.argv[1];output=ROOT/mode
f=json.loads((ROOT/'freeze.json').read_text())
batch=json.loads((output/'result.json').read_text())
assert batch['freeze_sha256']==sha256((ROOT/'freeze.json').read_bytes()).hexdigest()
assert len(f['cases'])==len(batch['rows'])==1

class Tables(HTMLParser):
    def __init__(self):super().__init__();self.tables=[];self.rows=None;self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='table':self.rows=[]
        elif tag=='tr' and self.rows is not None:self.row=[]
        elif tag in ('th','td') and self.row is not None:self.cell=[]
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag in ('th','td') and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        elif tag=='tr' and self.row is not None:self.rows.append(self.row);self.row=None
        elif tag=='table' and self.rows is not None:self.tables.append(self.rows);self.rows=None

reports=[]
for case,row in zip(f['cases'],batch['rows']):
    assert row['id']==case['id'] and row['attempted'] is True
    p=output/case['id']
    def read(name):return json.loads((p/name).read_text())
    before=read('database-before.json')
    with sqlite3.connect((p/'fixture.db').as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row
        records=[dict(r) for r in db.execute('SELECT * FROM work_items ORDER BY id')]
        writes=[dict(r) for r in db.execute('SELECT * FROM _writes ORDER BY rowid')]
        schema=[list(r) for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
    assert before['records']==f['seed'] and before['writes']==[]
    assert records==before['records'] and writes==[] and schema==before['schema'],'business mutation'
    assert read('database-after.json')==dict(records=records,writes=writes,schema=schema)
    initial=read('initial-public-dom.json');facts=[x for x in initial['facts'] if x['key'].startswith('status:DOM table:')]
    assert initial['ready'] is True and initial['complete'] is True and len(facts)==1
    public=json.loads(facts[0]['value']);columns=json.loads(facts[0]['key'].split('status:DOM table:',1)[1])
    assert columns==['id','title','notes']
    assert public['rows']==[[str(r[c]) for c in columns] for r in records]
    goal=read('goal.json');completion=goal['completion']
    assert len(completion)==1 and completion[0]==dict(key='status:Page URL',value=public['url'].removesuffix('content/'))
    initial_url=next(x['value'] for x in initial['facts'] if x['key']=='status:Page URL')
    assert initial_url!=completion[0]['value']
    assert goal['goal_id']=='case-01' and goal['scope']=='spatial-check' and goal['inputs']==[]
    assert 'left sidebar' in goal['intent'] and 'do not use the top' in goal['intent']
    assert goal['allowed_operations']==['click']
    assert goal['spatial_hint']==dict(role='link',label='work_items',relation='leftmost')
    assert initial['viewport']==[1280,720]
    final=read('final-table.json');assert final==facts[0]
    parser=Tables();parser.feed((p/'final-list.html').read_text())
    matching=[]
    for table in parser.tables:
        if not table:continue
        indexes=[i for i,c in enumerate(table[0]) if c in columns]
        if [table[0][i] for i in indexes]==columns:
            matching.append([[r[i] for i in indexes] for r in table[1:] if len(r)==len(table[0])])
    assert matching==[public['rows']]
    http=[json.loads(s) for s in (p/'http.jsonl').read_text().splitlines()]
    assert all(x['method']=='GET' for x in http),'non-GET product request'
    target_html=(p/'final-target.html').read_text()
    target_parser=Tables();target_parser.feed(target_html)
    assert any(all(name in str(t) for name in ('id','title','notes')) for t in target_parser.tables)
    assert any(x['path']=='/work_items/' and x['status'].startswith('200') for x in http)
    result=read('task-result.json');assert row['result']==result
    assert result['cleanup']=='confirmed' and result['details']['pending_effect'] is False
    cleanup=read('cleanup.json');assert cleanup['server_exit'] is not None and cleanup['runner_cleanup']=='confirmed'
    captures=read('captures.json');events=read('events.json');execution=read('audit.json')
    requests=[x for x in captures if 'request' in x];responses=[x for x in captures if 'response' in x]
    reqs={x['call_id']:x for x in requests};resps={x['call_id']:x['response'] for x in responses}
    starts=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='started']
    ends=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='finished']
    spent=batch['spend']['requests']
    assert len(requests)==len(responses)==len(starts)==len(ends)==len(reqs)>0
    assert set(reqs)==set(resps)==set(spent)=={x['call_id'] for x in starts}=={x['call_id'] for x in ends}
    models={};tokens=0;choices=[];images=[];previous_jev=None;visual_packet=None
    for end in ends:
        call=end['call_id'];request=reqs[call];response=resps[call];charge=spent[call]
        a,b=end['prompt_tokens'],end['completion_tokens']
        assert type(a) is int and type(b) is int and a>=0 and b>=0
        assert end['status']=='returned' and charge['status']=='known' and charge['trial']==case['id']
        assert (a,b)==(charge['input_tokens'],charge['output_tokens'])
        if request['model']==f['jev']['model']:
            assert request['url']==f['jev']['url'] and request['purpose']=='computer_use.jev'
            assert set(request['request'])=={'model','state','questions'}
            packet=request['request'];previous_jev=packet
            assert (response['input_tokens'],response['output_tokens'])==(a,b)
            choice=response['choice']
        else:
            assert request['model']==f['vision']['model'] and request['url'].startswith(f['vision']['url'])
            assert request['purpose']=='computer_use.visual'
            params=request['request'];parts=params['messages'][1]['content']
            assert len(parts)==2 and parts[0]['type']=='text' and parts[1]['type']=='image_url'
            packet=json.loads(parts[0]['text']);visual_packet=packet
            assert previous_jev is not None and packet['state']==previous_jev['state'] and packet['questions']==previous_jev['questions']
            assert isinstance(packet['frame_id'],str) and packet['frame_id']
            image_url=parts[1]['image_url']['url'];prefix='data:image/png;base64,'
            assert image_url.startswith(prefix)
            png=base64.b64decode(image_url[len(prefix):],validate=True)
            assert png[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',png[16:24])==(1280,720)
            assert packet['image_candidates'] and all(len(box)==4 and box[0]>=0 and box[1]>=0 and box[2]>0 and box[3]>0 and box[0]+box[2]<=1280 and box[1]+box[3]<=720 for box in packet['image_candidates'].values())
            images.append(dict(call_id=call,frame_id=packet['frame_id'],sha256=sha256(png).hexdigest(),width=1280,height=720))
            assert (response['usage']['prompt_tokens'],response['usage']['completion_tokens'])==(a,b)
            choice=json.loads(response['choices'][0]['message']['content'])['choice']
        assert packet['state']['goal']['goal_id']==case['id']
        assert packet['state']['binding']['observation_id']==packet['state']['snapshot']['observation_id']
        assert packet['state']['evidence_contract']['sources']['goal.completion']=='desired_outcomes'
        assert all(not x['key'].startswith(('status:Records','status:List rows','status:Editor seen')) for x in packet['state']['snapshot']['facts'])
        models[request['model']]=models.get(request['model'],0)+1;tokens+=a+b
        choices.append(dict(model=request['model'],choice=choice))
    assert models.get(f['jev']['model'],0)>=1,'no Jev SDK selection'
    for call in {x['call_id'] for x in execution}:
        seq=[x for x in execution if x['call_id']==call]
        assert [x['phase'] for x in seq]==['prepared','dispatch','finished'] and seq[-1]['status']=='returned'
    assert batch['spend']['stop_reason'] is None and batch['spend']['batch']['reserved_tokens']==0
    assert batch['spend']['batch']['known_tokens']==tokens
    assert len(spent)==batch['spend']['batch']['admitted_requests']<=8
    assert not row['blocked_network'] and row['error_type'] is None
    dispatches=[e for e in events if e['kind']=='computer_use_dispatch']
    receipts=result['details']['receipts']
    # Geometry is public observation data, not an image or an action coordinate.
    assert previous_jev is not None
    native_snapshot=previous_jev['state']['snapshot']
    assert native_snapshot['geometry']==dict(coordinate_space='main_frame_viewport_css_pixels',viewport_size=[1280,720])
    assert previous_jev['state']['goal']['spatial_hint']==goal['spatial_hint']
    criteria=previous_jev['questions']['next_action']['criteria']
    duplicates=[(key,c) for key,c in criteria.items() if isinstance(c,dict) and c.get('label')=='work_items']
    assert len(duplicates)==2
    assert {k:v for k,v in duplicates[0][1].items() if k!='target_ref'}=={k:v for k,v in duplicates[1][1].items() if k!='target_ref'}
    elements={e['ref']:e for e in native_snapshot['elements']}
    boxes={key:elements[c['target_ref']]['bounds'] for key,c in duplicates}
    assert all(elements[c['target_ref']]['source']=='dom' for key,c in duplicates)
    assert all(c['effect']==completion for key,c in duplicates)
    left=[key for key,c in duplicates if boxes[key][0]<200 and boxes[key][1]>=55 and boxes[key][0]+boxes[key][2]<=200]
    assert len(left)==1
    left_alias=left[0];selected_ref=criteria[left_alias]['target_ref']
    assert all(boxes[left_alias][0]+boxes[left_alias][2]<=box[0] for key,box in boxes.items() if key!=left_alias)
    assert sorted(boxes.values())==sorted(e['bounds'] for e in initial['elements'] if e['role']=='link' and e['label']=='work_items')
    proposals=[e['metadata'] for e in events if e['kind']=='computer_use_proposal']
    admissions=[e['metadata'] for e in events if e['kind']=='computer_use_action_admission']
    dispatched=[e['metadata'] for e in dispatches]
    correct_source=(result['status']=='completed' and result['reason']=='goal_verified'
        and len(dispatched)==len(receipts)==1 and receipts[0]['status']=='sent'
        and result['details']['progress']['recent_action']['target_ref']==selected_ref
        and result['details']['progress']['recent_action']['id']==receipts[0]['action_id'])
    direct_jev=(correct_source and not images and len(reqs)==1 and choices==[dict(model=f['jev']['model'],choice=left_alias)]
        and len(proposals)==len(admissions)==1 and proposals[0]['source']=='jev'
        and proposals[0]['model_choice']==left_alias and proposals[0]['action_id']==receipts[0]['action_id']
        and admissions[0]['accepted'] is True and admissions[0]['next_route']=='text_candidate'
        and admissions[0]['spatial_candidates']==1 and admissions[0]['selected_id']==receipts[0]['action_id'])
    if direct_jev:
        assert all(e['operation']!='computer_use.capture' for e in execution)
    if mode=='fake':assert direct_jev
    report=dict(id=case['id'],evidence_complete=True,correct_source=correct_source,direct_jev=direct_jev,
                task_status=result['status'],reason=result['reason'],sdk_calls=len(reqs),models=models,tokens=tokens,
                choices=choices,images=images,post_count=0,writes=0,duplicate_aliases=[k for k,c in duplicates],
                left_alias=left_alias,selected_ref=selected_ref,boxes=boxes,
                dispatched_actions=len(dispatches),cleanup_confirmed=True)
    (p/'independent-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');reports.append(report)
print(json.dumps(reports,ensure_ascii=False))
if len(sys.argv)==2:
    assert batch['completed'] is True and len(reports)==1
    (output/'independent-audit.json').write_text(json.dumps(dict(all_passed=all(r['evidence_complete'] and r['correct_source'] and r['direct_jev'] for r in reports),reports=reports),ensure_ascii=False,indent=2)+'\n')
