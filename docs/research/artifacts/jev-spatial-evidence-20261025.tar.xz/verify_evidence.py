"""Offline evidence/source/log reconciliation. No SDK clients or trial replay."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
f=json.loads((ROOT/'freeze.json').read_text())
assert sha256((ROOT/'run.py').read_bytes()).hexdigest()==f['driver_sha256']
assert sha256((ROOT/'audit.py').read_bytes()).hexdigest()==f['auditor_sha256']
for path,expected in f['sources'].items():
    assert sha256((ROOT/'sources'/path).read_bytes()).hexdigest()==expected
v=json.loads((ROOT/'verification.json').read_text())
assert v['source_sha256']==f['sources'] and len(v['checks'])==9
for check in v['checks'].values():
    assert type(check['exit_code']) is int and check['exit_code']==0
    assert sha256((ROOT/check['log']).read_bytes()).hexdigest()==check['sha256']
for path,expected in v['checked_python_and_ts_sha256'].items():
    assert sha256((ROOT/'checked-sources'/path).read_bytes()).hexdigest()==expected
interface=json.loads((ROOT/'interface/qualification.json').read_text())
assert interface['all_passed'] and interface['positions_in_text'] and interface['spatial_candidates']==1
assert interface['freeze_sha256']==sha256((ROOT/'freeze.json').read_bytes()).hexdigest()
assert json.loads((ROOT/'interface/cleanup.json').read_text())['server_exit'] is not None
reports=[]
for mode in ('fake','live'):
    subprocess.run([sys.executable,str(ROOT/'audit.py'),mode],check=True,stdout=subprocess.DEVNULL)
    p=ROOT/mode;batch=json.loads((p/'result.json').read_text())
    diagnostics=[json.loads(line) for line in (p/'sdk-diagnostics.jsonl').read_text().splitlines()]
    starts=[x['call_id'] for x in diagnostics if x['phase']=='invoke_started']
    ends=[x for x in diagnostics if x['phase']=='call_returned']
    assert Counter(starts)==Counter(x['call_id'] for x in ends)==Counter(batch['spend']['requests'].keys())
    assert len(starts)==1 and not any(x['phase'].endswith('error') for x in diagnostics)
    assert all(x['completion_status']=='returned' and x['reservation_status']=='known' for x in ends)
    trial=p/'case-01';report=json.loads((trial/'independent-audit.json').read_text())
    assert report['correct_source'] is True and report['direct_jev'] is True and report['images']==[]
    assert report['models']=={f['jev']['model']:1} and report['dispatched_actions']==1
    events=json.loads((trial/'events.json').read_text())
    admission=[x['metadata'] for x in events if x['kind']=='computer_use_action_admission']
    assert len(admission)==1 and admission[0]['accepted'] is True
    assert admission[0]['spatial_candidates']==1 and admission[0]['candidates']==27
    assert admission[0]['next_route']=='text_candidate'
    capture=json.loads((trial/'captures.json').read_text())
    requests=[x for x in capture if 'request' in x]
    assert len(requests)==1 and set(requests[0]['request'])=={'model','state','questions'}
    assert not any(x['kind']=='model_call' and 'visual' in x['metadata'].get('purpose','') for x in events)
    execution=json.loads((trial/'audit.json').read_text())
    assert Counter(x['operation'] for x in execution if x['phase']=='finished')==Counter({'computer_use.observe':2,'computer_use.dispatch':1})
    reports.append(dict(mode=mode,correct_source=True,direct_jev=True,sdk_calls=1,image_calls=0,candidates=27,zero_writes=True))
(ROOT/'evidence-verification.json').write_text(json.dumps(dict(all_passed=True,reports=reports),indent=2)+'\n')
print('Offline reconciliation: PASS; nine current-source checks, fake/live each Jev once, correct sidebar reference, no image API or capture, zero writes.')
