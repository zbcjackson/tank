from pathlib import Path
from hashlib import sha256
import json,tarfile,subprocess
repo=Path('/Users/zbcjackson/src/tank');root=Path('/private/tmp/tank-linkding-spatial-20261025')
root.mkdir(exist_ok=True)
with tarfile.open(repo/'docs/research/artifacts/jev-second-product-qualification-20261020.tar.gz') as archive:
    product=json.loads(archive.extractfile('qualification/task-freeze.json').read())['product']
expected=product['app_file_sha256'];remaining={k:v for k,v in expected.items() if not (root/k).is_file() or sha256((root/k).read_bytes()).hexdigest()!=v}
source=repo/'docs/research/artifacts/jev-confirmation-preparation-20261021.tar.gz'
with tarfile.open(source,mode='r|gz') as archive:
    for member in archive:
        if not member.isfile():continue
        key=next((key for key in remaining if member.name.endswith('/'+key)),None)
        if key is None:continue
        data=archive.extractfile(member).read()
        if sha256(data).hexdigest()!=remaining[key]:continue
        target=root/key;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        del remaining[key]
        if not remaining:break
assert not remaining, list(remaining)
(root/'requirements-frozen.txt').write_text(''.join(f'{name}=={version}\n' for name,version in product['environment']['versions'].items()))
subprocess.run(['uv','venv','--python','/opt/homebrew/Caskroom/miniconda/base/bin/python',str(root/'.venv')],check=True)
subprocess.run(['uv','pip','install','--python',str(root/'.venv/bin/python'),'-r',str(root/'requirements-frozen.txt')],check=True)
(root/'requirements-frozen.txt').unlink()
print('Restored original 446 product files and fixed 26 dependencies from reviewed provenance.',flush=True)
