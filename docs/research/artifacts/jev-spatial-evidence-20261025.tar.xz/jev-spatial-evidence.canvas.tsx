import { H1, H2, Text, Stack, Row, Pill, Table, Callout, Divider, useHostTheme } from "cursor/canvas";
export default function SpatialEvidence() {
  const theme = useHostTheme();
  return <Stack gap={20} style={{ padding: 28, maxWidth: 1100, background: theme.bg.editor, color: theme.text.primary }}>
    <Row justify="space-between" align="center"><H1>位置依据让Jev直接选中左侧链接</H1><Pill tone="success">2026-10-25 · 一次真实任务</Pill></Row>
    <Text>原版sqlite-web有两个同名、同语义work_items链接。任务要求点击左侧导航进入结构页；完成URL相同不能证明点击来源正确。</Text>
    <Row gap={12} wrap><Pill>27候选全部保留</Pill><Text as="span">→</Text><Pill>1次Jev选择</Pill><Text as="span">→</Text><Pill tone="success">正确左侧引用 / 0图片调用</Pill></Row>
    <Callout tone="info" title="本轮改动">显式observe_bounds从浏览器renderer读取当前主frame框与视口；spatial_hint声明link / work_items / leftmost。宿主检查框有效、可分离及新鲜后额外准入，仍执行原引用，不执行模型坐标。</Callout>
    <H2>同名目标的实际DOM几何</H2>
    <Table headers={["候选 / 位置", "框 [x,y,宽,高]（CSS像素）", "结果"]} rows={[
      ["c3 / 顶部面包屑", "[239.75, 18.30, 75.52, 17]", "保留，未选择"],
      ["c6 / 左侧导航", "[15, 132.80, 183.33, 30.5]", "Jev选中 / 守卫接受 / 实际派发"],
    ]} />
    <Text size="small" tone="secondary">来源：本轮live公开DOM、原始模型响应、proposal及sent回执。坐标原点为主frame视口左上，x向右、y向下；不是截图像素或模型预测Box。</Text>
    <Divider />
    <H2>实测与回归证据</H2>
    <Table headers={["检查", "实际结果"]} rows={[
      ["真实任务", "completed / goal_verified；1动作；0 POST / 0数据写入；清理确认"],
      ["真实模型", "jev-1.14.0：输入16,270 / 输出287，共16,557已知token；图片模型0次"],
      ["时延口径", "SDK跨度1.253秒；驱动墙钟4.447秒，含服务、采集、核验和清理"],
      ["完整后端", "6,836通过 / 1跳过（ToolManager需完整配置）"],
      ["完整E2E", "24场景 / 95步骤通过，原服务已恢复"],
      ["静态检查", "Web lint及tsc -b、后端/CLI ruff、11改动Python的pyright通过"],
    ]} />
    <Text>前轮同一产品目标需要1次Jev加1次Gemini；本轮增加了显式位置提示和几何。前后各一次、输入条件不同，只支持此受控路径可行，不作模型准确率或速度排名。金额未定价。</Text>
    <Callout tone="warning" title="当前适用边界">默认仍关闭；不自动解析任意自然语言。重叠、缺失、越界、混合来源或陈旧几何不额外放行；原生AX/子frame未新增此能力。视觉兜底继续保留，Jev图片/Box未使用。</Callout>
    <Text size="small" tone="secondary">冻结884d7d66072c2877cb23b66b6ec695ec10a8067bc68bb82140f3697703b995ce；353运行源文件。来源：jev-spatial-evidence研究记录及独立verify_evidence.py核对结果。正式N未冻结、默认采用未变。</Text>
  </Stack>;
}
