---
name: acceptance
extension: agent-computer-use:agent
model: text
decision-model: jev
visual-model: vision
---
Execute the declared goal.
