"""Independently verify the saved diagnostic evidence; never import the driver."""
import hashlib
import json
import socket
from pathlib import Path

ROOT=Path(__file__).parent
REPO=Path('/Users/zbcjackson/src/tank')

def read(path):return json.loads((ROOT/path).read_text())
checks={}
raw=read('raw-probe/report.json')
before=read('raw-probe/database-before.json')
after=read('raw-probe/database-after.json')
snapshot=read('raw-probe/list-snapshot.json')
assert raw['before_complete'] and raw['after_complete']
assert len(after['writes'])==1 and after['records']==[
    {'id':1,'title':'Miro','notes':'Keep A'},{'id':2,'title':'Tavi','notes':'Keep B'}]
assert before['schema']==after['schema']
assert {f['key'] for f in raw['supported_completion_facts']}=={'status:Page URL'}
assert not raw['saved_value_facts']
assert any('Miro' in label for element in snapshot['elements'] for role,label in element['ancestors'] if role=='row')
assert 'Successfully updated 1 record.' in (ROOT/'raw-probe/list.html').read_text()
assert read('raw-probe/cleanup.json')['browser_closed']
checks['raw_dom_saved_row_context_without_supported_business_fact']=True
reports=read('runner-summary.json')
assert [r['mode'] for r in reports]==['textbox','business-status','url-only']
for r in reports:
    mode=r['mode'];base='runner/'+mode+'/'
    assert r['result']['cleanup']=='confirmed'
    assert r['schema_unchanged'] and not r['blocked_network']
    assert not r['real_credentials_loaded'] and r['external_model_calls']==0
    calls=read(base+'calls.json');captures=read(base+'captures.json');events=read(base+'events.json')
    requests={c['call_id'] for c in captures if 'request' in c}
    responses={c['call_id'] for c in captures if 'response' in c}
    started={e['metadata']['call_id'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='started'}
    finished=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='finished']
    assert requests==responses==started=={e['call_id'] for e in finished}
    assert len(calls)==len(requests)==r['fake_sdk_calls']
    assert all(e['status']=='returned' and e['prompt_tokens']==12 and e['completion_tokens']==0 for e in finished)
    assert read(base+'cleanup.json')['server_exit'] is not None
    if mode=='textbox':
        assert r['result']['reason']=='unsupported_completion_evidence' and not calls and not r['writes']
    elif mode=='business-status':
        assert r['result']['reason']=='effect_unknown' and r['result']['details']['pending_effect']
        assert r['business_saved'] and len(r['writes'])==1 and len(r['result']['details']['receipts'])==3
        steps=r['result']['details']['progress']['recent_steps']
        assert [s['operation'] for s in steps]==['click','fill','click']
        assert [s['label'] for s in steps]==['Allow updating this column. [name=chk_title]','title','Update']
        assert r['fake_sdk_calls']==3
    else:
        assert r['result']['status']=='completed' and r['result']['reason']=='goal_verified'
        assert not r['business_saved'] and not r['writes'] and r['fake_sdk_calls']==1
        assert r['result']['details']['progress']['recent_steps'][0]['label']=='Content'
    port=read(base+'ready.json')['port']
    with socket.socket() as stream:
        stream.settimeout(.5)
        assert stream.connect_ex(('127.0.0.1',port))!=0
checks['real_runner_three_contract_counterexamples']=True
checks['four_final_fake_sdk_calls_complete_known_usage']=True
checks['final_diagnostic_servers_closed']=True
baseline=read('baseline.json')
assert hashlib.sha256((REPO/'backend/core/config.yaml').read_bytes()).hexdigest()==baseline['default_config_sha256']
old=read('prior-artifacts-sha256.json')
for name,expected in old.items():
    with (REPO/name).open('rb') as stream:
        assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
checks['default_config_and_74_historical_artifacts_unchanged']=True
result={'checks':checks,'real_acceptance_executed':0,'real_acceptance_planned':6,
        'real_model_api_calls':0,'final_fake_sdk_calls':4,
        'business_effect_unknown_retained':True,'historical_artifacts':len(old)}
(ROOT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
