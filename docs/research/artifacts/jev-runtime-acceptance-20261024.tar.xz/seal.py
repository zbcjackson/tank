"""Seal closed owned diagnostic evidence and verify every archived member."""
from pathlib import Path
import hashlib
import json
import tarfile

ROOT=Path(__file__).parent
DEST=Path('/Users/zbcjackson/src/tank/docs/research/artifacts')
archive=DEST/'jev-runtime-acceptance-20261024.tar.xz'
manifest=DEST/'jev-runtime-acceptance-20261024-manifest.json'
assert not archive.exists() and not manifest.exists()
files=sorted(p for p in ROOT.rglob('*') if p.is_file())
assert all(not p.is_symlink() and p.name!='.env' for p in files)
bound={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
with tarfile.open(archive,'w:xz') as bundle:
    for p in files:bundle.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
with tarfile.open(archive) as bundle:
    names=bundle.getnames()
    assert len(names)==len(set(names))==len(bound)
    for member in bundle.getmembers():
        stream=bundle.extractfile(member)
        assert stream is not None and member.isfile()
        data=stream.read()
        assert len(data)==bound[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest()==bound[member.name]['sha256']
result={'schema_version':1,'date':'2026-10-24','archive':archive.name,
        'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'member_count':len(bound),'members':bound,
        'baseline':json.loads((ROOT/'baseline.json').read_text()),
        'verification':json.loads((ROOT/'verification.json').read_text()),
        'scope':'Three independent host-contract diagnostics and a reference UI probe; not live model quality trials',
        'limitations':['Six planned real-model tasks not admitted or run; visual task not qualified',
            'Business effect_unknown remains in original Runner result; DB oracle not injected to resolve it',
            'Early setup/config/reference-script failures retained; initial missing HTTP adapter attempted offline.invalid and failed',
            'Final fake SDK calls=4; earlier incomplete reference diagnostic had four additional fake calls; two earlier SDK attempts failed before fake HTTP capture'],
        'review':{'status':'pending','mode':'review-and-refactor','round':1}}
manifest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sha256':result['archive_sha256'],'members':len(bound),'bytes':archive.stat().st_size}))
