"""Three host-contract diagnostics, not the six-task live model acceptance."""
from __future__ import annotations
import asyncio
from dataclasses import asdict
import json
import os
from pathlib import Path
import time
from unittest.mock import MagicMock, patch

import httpx
from tank_backend.agents.approval import PendingToolCallStore, ToolApprovalPolicy
from tank_backend.agents.definition import parse_agent_file
from tank_backend.agents.resources import DesktopResource
from tank_backend.agents.runner import AgentRunner
from tank_backend.agents.subagent import SubAgentAuthorization
from tank_backend.config.app_config import AppConfig
from tank_backend.pipeline.bus import Bus
from tank_backend.plugin.manifest import read_manifest_from_yaml
from tank_backend.plugin.registry import ExtensionRegistry
from benchmarks.computer_use import jev_real_product_route as product

ROOT = Path(__file__).parent
REPO = Path('/Users/zbcjackson/src/tank')
APP = Path('/private/tmp/tank-sqlite-web-20261020-env/bin/python')
SEED = [{'id':1,'title':'Nora','notes':'Keep A'}, {'id':2,'title':'Tavi','notes':'Keep B'}]

def write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

async def run(mode: str) -> dict:
    output=ROOT / 'runner' / mode
    output.mkdir(parents=True,exist_ok=False)
    database=output/'fixture.db'
    product.create_database(database, SEED)
    before=product.database_state(database)
    write(output/'database-before.json',before)
    process=None
    calls=[]; captures=[]; events=[]; audits=[]
    result=None
    class Observer:
        def on_event(self,kind,metadata):
            events.append({'kind':kind,'metadata':metadata})
    class Capture:
        async def request(self,call_id,request):
            captures.append({'call_id':call_id,'request':request.parameters})
        async def response(self,call_id,response):
            captures.append({'call_id':call_id,'response':response})
    class HTTP(httpx.AsyncBaseTransport):
        async def handle_async_request(self,request):
            data=json.loads(request.content)
            calls.append(data)
            native='questions' in data
            packet=data if native else json.loads(data['messages'][1]['content'][0]['text'])
            criteria=packet['questions']['next_action']['criteria']
            facts={f['key']:f['value'] for f in packet['state']['snapshot']['facts']}
            chosen='none'
            for key, candidate in criteria.items():
                if not isinstance(candidate,dict):continue
                label=candidate.get('label','')
                if mode=='url-only' and label=='Content':chosen=key;break
                if mode!='url-only':
                    if 'chk_title' in label and candidate.get('current_value')=='false':
                        chosen=key;break
                    if label=='Update' and facts.get('textbox:title')=='Miro':
                        chosen=key;break
            if native:
                return httpx.Response(200,json={'model':'jev-1.14.0','answers':{'next_action':{
                    'type':'choice','choice':chosen,'confidence':1,
                    'probabilities':{k:int(k==chosen) for k in criteria}}},
                    'usage':{'input_tokens':12,'output_tokens':0}})
            return httpx.Response(200,json={'id':'fixture','object':'chat.completion','created':1,
                'model':'fixture-vision','choices':[{'index':0,'finish_reason':'stop',
                'message':{'role':'assistant','content':json.dumps({'choice':chosen})}}],
                'usage':{'prompt_tokens':10,'completion_tokens':2,'total_tokens':12}})
    async def audit(record):
        audits.append(asdict(record))
    try:
        with (output/'server.log').open('w') as log:
            process=await asyncio.create_subprocess_exec(str(APP),
                str(REPO/'backend/benchmarks/computer_use/jev_real_product_route.py'),
                '--serve','--output',str(output),'--database',str(database),
                env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1'},
                stdout=log,stderr=asyncio.subprocess.STDOUT)
            async with asyncio.timeout(10):
                while not (output/'ready.json').is_file():
                    if process.returncode is not None:raise RuntimeError('product server exited')
                    await asyncio.sleep(.05)
            port=json.loads((output/'ready.json').read_text())['port']
            origin=f'http://127.0.0.1:{port}'
            goal={'schema_version':2,'goal_id':mode,'scope':'raw-runtime',
                'authorization_ref':'current_task','intent':'Change only work_items record 1 title from Nora to Miro and save; preserve notes and other records.',
                'objective':'Save the requested title and verify the persisted record.',
                'allowed_operations':['click','fill'],
                'constraints':['No SQL, deletion, schema change or unrelated field changes.'],
                'inputs':[{'key':'title','purpose':'Requested new title','field_label':'title','value':'Miro'}],
                'completion':[{'key':'status:Saved title','value':'Miro'}]}
            if mode=='textbox':goal['completion']=[{'key':'textbox:title','value':'Miro'}]
            if mode=='url-only':goal['completion']=[{'key':'status:Page URL','value':origin+'/work_items/content/'}]
            write(output/'goal.json',goal)
            definition_path=output/'agent.md'
            definition_path.write_text('---\nname: acceptance\nextension: agent-computer-use:agent\nmodel: default\ndecision-model: jev\nvisual-model: vision\n---\nExecute the declared goal.\n')
            definition=parse_agent_file(definition_path)
            registry=ExtensionRegistry()
            manifest=read_manifest_from_yaml(REPO/'backend/plugins/agent-computer-use/plugin.yaml')
            for extension in manifest.extensions:registry.register(manifest.plugin_name,extension)
            config=AppConfig.from_raw_dict({
                'llm':{'default':{'api_key':'fixture-only','model':'fixture-text','base_url':'https://offline.invalid/v1'},
                       'vision':{'api_key':'fixture-only','model':'fixture-vision','base_url':'https://offline.invalid/v1','max_tokens':128}},
                'decision_models':{'jev':{'url':'https://offline.invalid/v1/systemone','model':'jev-1.14.0','credential_env':'RAW_PROBE_KEY'}},
                'subagents':{'agent-computer-use:agent':{'config':{
                    'browser':{'scope':'raw-runtime','url':origin+'/work_items/update/WzFd/'},'selector':'jev-action-vision'}}}})
            runner=AgentRunner(MagicMock(),MagicMock(),Bus(),ToolApprovalPolicy(computer_mode='allow'),
                PendingToolCallStore(),{definition.name:definition},registry=registry,
                app_config=config,desktop_resource=DesktopResource())
            with patch.dict(os.environ,{'RAW_PROBE_KEY':'fixture-only'}),patch.object(httpx,'AsyncHTTPTransport',HTTP):
                async for event in runner.run_agent(definition,[],task_id='raw-'+mode,
                    task_input=goal,authorization=SubAgentAuthorization(frozenset({'desktop','network'})),
                    deadline=time.monotonic()+120,max_actions=6,max_observations=24,
                    observer=Observer(),audit=audit,model_capture=Capture()):
                    if 'task_result' in event.metadata:result=event.metadata['task_result']
            after=product.database_state(database)
            report={'mode':mode,'result':result,'fake_sdk_calls':len(calls),'external_model_calls':0,
                'real_credentials_loaded':False,'records':after['records'],'writes':after['writes'],
                'schema_unchanged':after['schema']==before['schema'],
                'business_saved':after['records']==[{**r,'title':'Miro'} if r['id']==1 else r for r in SEED]}
            write(output/'database-after.json',after)
            write(output/'report.json',report)
            return report
    finally:
        write(output/'calls.json',calls)
        write(output/'captures.json',captures)
        write(output/'events.json',events)
        write(output/'audit.json',audits)
        if process is not None and process.returncode is None:
            process.terminate()
            try:await asyncio.wait_for(process.wait(),5)
            except TimeoutError:
                process.kill();await process.wait()
        write(output/'cleanup.json',{'server_exit':None if process is None else process.returncode,
            'runner_cleanup':None if result is None else result.get('cleanup')})

async def main():
    reports=[]
    for mode in ('textbox','business-status','url-only'):
        report=await run(mode);reports.append(report)
        print(json.dumps({k:report[k] for k in ('mode','result','fake_sdk_calls','business_saved')},ensure_ascii=False),flush=True)
    write(ROOT/'runner-summary.json',reports)

if __name__=='__main__':asyncio.run(main())
