"""Read the unmodified product through the unmodified production DOM channel."""
from __future__ import annotations
import asyncio
import json
import os
import sys
from pathlib import Path

from agent_computer_use.channels.dom import BrowserConfig, ManagedChromiumChannel
from agent_computer_use.contracts import snapshot_json
from tank_backend.agents.subagent import SubAgentAuthorization, SubAgentBudget, SubAgentContext
from benchmarks.computer_use import jev_real_product_route as product

ROOT = Path(__file__).parent
APP_PYTHON = Path('/private/tmp/tank-sqlite-web-20261020-env/bin/python')
REPO = Path('/Users/zbcjackson/src/tank')

def write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

async def main() -> None:
    output = ROOT / 'raw-probe'
    output.mkdir(exist_ok=False)
    database = output / 'fixture.db'
    product.create_database(database, [
        {'id': 1, 'title': 'Nora', 'notes': 'Keep A'},
        {'id': 2, 'title': 'Tavi', 'notes': 'Keep B'}])
    write(output / 'database-before.json', product.database_state(database))
    ctx = SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),
                          SubAgentBudget(), asyncio.Event())
    ctx.runtime.bind('raw-probe')
    channel = None
    process = None
    try:
        with (output / 'server.log').open('w') as log:
            process = await asyncio.create_subprocess_exec(
                str(APP_PYTHON), str(REPO / 'backend/benchmarks/computer_use/jev_real_product_route.py'),
                '--serve', '--output', str(output), '--database', str(database),
                env={'PATH': os.environ.get('PATH',''), 'PYTHONUNBUFFERED':'1'},
                stdout=log, stderr=asyncio.subprocess.STDOUT)
            async with asyncio.timeout(10):
                while not (output / 'ready.json').is_file():
                    if process.returncode is not None:
                        raise RuntimeError('product server exited')
                    await asyncio.sleep(.05)
            port = json.loads((output / 'ready.json').read_text())['port']
            origin = f'http://127.0.0.1:{port}'
            channel = ManagedChromiumChannel(BrowserConfig(scope='raw-runtime',
                url=origin + '/work_items/update/WzFd/'))
            before = await channel.observe('raw-runtime', ctx)
            write(output / 'editor-snapshot.json', snapshot_json(before))
            assert channel.page is not None
            (output / 'editor.html').write_text(await channel.page.content())
            await channel.page.screenshot(path=str(output / 'editor.png'))
            # Reference actions only, outside the planned model measurement.
            await channel.page.locator('input[type=checkbox][name=chk_title]').check()
            await channel.page.get_by_role('textbox', name='title', exact=True).fill('Miro')
            await channel.page.get_by_role('button', name='Update', exact=True).click()
            await channel.page.wait_for_load_state('load')
            after = await channel.observe('raw-runtime', ctx)
            write(output / 'list-snapshot.json', snapshot_json(after))
            (output / 'list.html').write_text(await channel.page.content())
            await channel.page.screenshot(path=str(output / 'list.png'))
            write(output / 'database-after.json', product.database_state(database))
            report = {'before_complete': before.complete, 'after_complete': after.complete,
                'model_calls': 0, 'model_credentials_loaded': False,
                'supported_completion_facts': [f.model_dump() for f in after.facts if f.key.startswith('status:')],
                'saved_value_facts': [f.model_dump() for f in after.facts if 'Miro' in f.key or 'Miro' in f.value],
                'reference_ui_actions_only': True}
            write(output / 'report.json', report)
            assert any(f.key.startswith('status:') and 'Miro' in f.value for f in after.facts), (
                'raw production DOM has no supported business completion evidence for the saved record')
    finally:
        if channel is not None:
            await channel.aclose()
        await ctx.runtime.aclose()
        if process is not None and process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(),5)
            except TimeoutError:
                process.kill()
                await process.wait()
        write(output / 'cleanup.json', {'browser_closed': channel is None or channel.closed,
            'server_exit': None if process is None else process.returncode,
            'runtime_aclose_returned': True})

if __name__ == '__main__':
    asyncio.run(main())
