# Jev offline benchmark score

Evidence kind: **unverified**. All gates and evidence checks passed: **False**.

This report grants no model execution or adoption permission. Fake/calibration results are not formal confirmation.

Planned trials: 3648; positive seeds: 760; negative seeds: 152; unusable/missing rows: 0.

Cold/prewarmed are averaged within paired seeds. Ten positive strata have fixed equal weights. Failed/unrun positive trials cost 120 seconds. Bounds assume independent representative seeds. Speed is the sole primary endpoint; the alternative 1.05 time-NI gate does not apply.

## Fixed gates

- quality_point: FAIL; 0.0013157894736842105 >= 0.95
- quality_lower: FAIL; 1.2222120925553526e-05 >= 0.9
- quality_difference_lower: PASS; -0.004842028158283947 >= -0.02
- family_min_point: FAIL; 0.0 >= 0.9
- recovery_point: FAIL; 0.0 >= 0.9
- recovery_lower: FAIL; 0.0 >= 0.8
- recovery_difference_lower: PASS; -0.0120611460742075 >= -0.05
- unexpected_difference_upper: UNKNOWN; None <= 0.01
- speed_point: FAIL; 0.9998463404527702 <= 0.9
- speed_upper: FAIL; 1.0 < 1.0
- safety_events: UNKNOWN; None <= 0
- regressions: UNKNOWN; None == True

## Metrics

- Time ratio JT/V: {'point': 0.9998463404527702, 'interval': (0.9992290374848815, 1.0), 'reason': None}
- Capped time summaries (seconds): {'v': {'mean_capped_s': 119.89639658547105, 'median_capped_s': 120.0, 'p95_capped_s': 120.0, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}, 'jt': {'mean_capped_s': 119.87797335945724, 'median_capped_s': 120.0, 'p95_capped_s': 120.0, 'failed_actual_mean_s': None, 'failed_actual_clock_count': 0}}
- Negative exits (separate denominator): {'v': {'planned': 304, 'passed': 0, 'seed_error_rate': 1.0, 'error_upper95_one_sided': 1.0}, 'jt': {'planned': 304, 'passed': 1, 'seed_error_rate': 0.9967105263157895, 'error_upper95_one_sided': 0.9999969669039934}}
- Usage reconciliation: {'reconciled': False, 'known_tokens': 156643, 'unknown_requests': 1, 'reserved_tokens': 0, 'reserved_nano_usd': 0, 'cost_status': 'unpriced', 'stop_reason': 'unknown_usage'}

## Evidence

- Freeze: 6830e2d759bb9ee9db83b03d75f0afabb4886be0298e6994f13e802f95c2d494
- Result (canonical JSON): 5a057c2500ce2a48d8e718e1569b94840e3e9fe6c5976ace8f842b1e205203ce
- unknown or unbound usage requests
- unreconciled trial usage: supp-cal-v1-494f948d50376159bd5d-cold-v
- unreconciled batch usage or stopped batch
- independent audit not supplied
