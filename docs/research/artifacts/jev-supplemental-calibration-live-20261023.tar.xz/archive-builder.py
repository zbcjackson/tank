from pathlib import Path
import tarfile,hashlib,json
repo=Path('/Users/zbcjackson/src/tank')
root=Path('/private/tmp/tank-jev-live-20261023')
archive=repo/'docs/research/artifacts/jev-supplemental-calibration-live-20261023.tar.xz'
manifest=archive.with_name(archive.name.removesuffix('.tar.xz')+'-manifest.json')
assert not archive.exists() and not manifest.exists()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()
old=json.loads((root/'prior-artifacts64-sha256.json').read_text())
assert all(sha(repo/name)==value for name,value in old.items())
final=json.loads((root/'final-metadata.json').read_text())
files=sorted(p for p in root.rglob('*') if p.is_file() or p.is_symlink())
entries={};seen={};hardlinks=0
with tarfile.open(archive,'w:xz',preset=6) as bundle:
    for path in files:
        name=path.relative_to(root).as_posix()
        if path.is_symlink():entries[name]={'symlink':str(path.readlink())}
        else:
            stat=path.stat();value=sha(path)
            entries[name]={'bytes':stat.st_size,'sha256':value,'mode':stat.st_mode,'mtime_ns':stat.st_mtime_ns}
            if value in seen:
                info=bundle.gettarinfo(str(path),arcname=name)
                info.type=tarfile.LNKTYPE;info.linkname=seen[value];info.size=0
                bundle.addfile(info);entries[name]['hardlink']=seen[value];hardlinks+=1
                continue
            seen[value]=name
        bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:xz') as bundle:
    members=bundle.getmembers()
    assert [m.name for m in members]==list(entries)
    verified={}
    for member in members:
        expected=entries[member.name]
        if member.issym():assert member.linkname==expected['symlink']
        elif member.islnk():
            assert member.linkname==expected['hardlink']
            assert verified[member.linkname]==expected['sha256']
            assert entries[member.linkname]['bytes']==expected['bytes']
            verified[member.name]=expected['sha256']
        else:
            stream=bundle.extractfile(member);assert stream is not None
            h=hashlib.sha256()
            for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
            assert h.hexdigest()==expected['sha256'],member.name
            assert member.size==expected['bytes']
            verified[member.name]=expected['sha256']
body={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,
      'members':len(entries),'content_hardlinks':hardlinks,
      'purpose':'Single explicitly authorized real calibration attempt: six of 3648 slots, stopped on unknown usage, 14 SDK request captures and 13 completions, no replay or resume. Partial physical and known usage checks are not a complete audit certificate. No remote ASR. Duplicate bytes use standard tar hardlinks; every path/hash/original stat retained and all previous 64 artifacts unchanged. Prior preparation archive supplies immutable prerequisite context.',
      'qualification_sha256':final['qualification_sha256'],'execution_sha256':final['execution_sha256'],'final_metadata':final,
      'prior_artifacts_sha256':old,'entries':entries}
manifest.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:body[k] for k in ('archive','sha256','bytes','members')}))
