from pathlib import Path
import hashlib, json, os
repo=Path('/Users/zbcjackson/src/tank')
root=Path('/private/tmp/tank-jev-live-20261023')
evidence=Path('/private/tmp/tank-jev-live-review-20261023')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):
            h.update(block)
    return h.hexdigest()
def tree(path):
    result={}
    for current, dirs, files in os.walk(path, followlinks=False):
        for name in dirs+files:
            p=Path(current)/name
            rel=p.relative_to(path).as_posix()
            if p.is_symlink(): result[rel]=['symlink',os.readlink(p)]
            elif p.is_dir(): result[rel]=['directory']
            elif p.is_file(): result[rel]=['file',p.stat().st_size,sha(p)]
            else: raise AssertionError('unsupported snapshot member')
    return result
binding=root/'binding-inputs'
receipt=json.loads((binding/'verification-v3.json').read_text())
freeze=json.loads((binding/'freeze.json').read_text())
assert len(receipt['source_sha256'])==42
assert receipt['source_sha256']==freeze['source_sha256']
for name,wanted in receipt['source_sha256'].items():
    assert sha(repo/'backend'/name)==wanted==sha(binding/'source'/name)
assert len(receipt['checks'])==9
for check in receipt['checks'].values():
    assert check['exit_code']==0 and sha(binding/check['log'])==check['sha256']
prior=json.loads((root/'prior-artifacts64-sha256.json').read_text())
assert len(prior)==64 and all(sha(repo/name)==wanted for name,wanted in prior.items())
original=tree(Path('/private/tmp/tank-jev-execution-review-20261023/study-v3/live'))
snapshot=tree(root/'closed-live')
assert original==snapshot
assert not (root/'closed-live/audit.json').exists()
score=json.loads((root/'score-live-no-audit-v1/score.json').read_text())
assert all(score['evidence'][key] is False for key in ('independent_audit','complete_batch','usage_reconciled'))
assert score['counts']['planned_trials']==3648 and score['counts']['missing_rows']==0
assert score['usage']['known_tokens']==156643 and score['usage']['unknown_requests']==1
assert score['all_gates_passed'] is False and score['model_execution_eligible'] is False
before=json.loads((root/'task-files-before-review.json').read_text())
changed=[name for name,wanted in before.items() if sha(repo/name)!=wanted]
assert changed==['docs/plans/active/computer-use-jev-vision.md']
report={'source_files_bound':42,'closed_validation_logs':9,'old_artifacts_unchanged':64,'closed_live_equal_original':True,'closed_live_files':sum(item[0]=='file' for item in snapshot.values()),'closed_live_bytes':sum(item[1] for item in snapshot.values() if item[0]=='file'),'complete_audit_present':False,'planned_score_denominator':3648,'diagnostic_evidence_gates_false':True,'review_changed_files':changed,'unknown_usage_reconciled':False}
(evidence/'r1-bindings.json').write_text(json.dumps(report,indent=2)+'\n')
(evidence/'r1-closed-live-tree.json').write_text(json.dumps(snapshot,indent=2)+'\n')
print(json.dumps(report))
