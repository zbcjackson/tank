"""Independent read-only physical/known-usage audit; no complete-batch certificate."""
from pathlib import Path
import collections
import hashlib
import json
import socket
import dotenv

ROOT = Path('/private/tmp/tank-jev-live-20261023')
STUDY = Path('/private/tmp/tank-jev-execution-review-20261023/study-v3')
REPO = Path('/Users/zbcjackson/src/tank')
attempts = []
def forbidden(*args, **kwargs):
    attempts.append('network or credential access')
    raise AssertionError('closed evidence inspection forbids network/credentials')
socket.getaddrinfo = forbidden
socket.socket.connect = forbidden
socket.socket.connect_ex = forbidden
dotenv.dotenv_values = forbidden
dotenv.load_dotenv = forbidden
from benchmarks.computer_use import jev_execution as execution
from benchmarks.computer_use import jev_audit as audit
from benchmarks.computer_use import jev_qualification as qualification

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            h.update(data)
    return h.hexdigest()

frozen = execution.load_freeze(STUDY, '6830e2d759bb9ee9db83b03d75f0afabb4886be0298e6994f13e802f95c2d494')
output = STUDY / 'live'
result = json.loads((output / 'result.json').read_text())
started = json.loads((output / 'started.json').read_text())
closed = json.loads((output / 'closed.json').read_text())
spend = result['spend']
rows = result['rows']
assert len(rows) == 3648
assert [x['id'] for x in rows] == [x['id'] for x in frozen['schedule']] == started['planned_ids']
assert closed['result_sha256'] == qualification.digest(result)
assert closed['driver_context_ended'] is True and closed['fake_http_context_ended'] is False
assert result['completed'] is False and result['qualified'] is False
assert spend['stop_reason'] == 'unknown_usage'
cases = {case['id']: case for case in frozen['cases']}
requests = spend['requests']
physical = {}
captured = []
completions = {}
known_sum = 0
provider_counts = collections.Counter()
missing_completions = []
auth_fields = []
for slot, row in zip(frozen['schedule'], rows):
    assert all(row.get(key) == value for key, value in slot.items())
    path = output / row['id']
    if row.get('attempted') is not True:
        assert row['attempted'] is False and row['status'] == 'not_run'
        assert not path.exists()
        assert not any(req['trial'] == row['id'] for req in requests.values())
        continue
    assert row['status'] == 'finished' and row['cleanup_confirmed'] is True
    physical[row['id']] = audit.audit_trial(cases[row['case']], row, path)
    journal = [json.loads(line) for line in (path / 'calls.jsonl').read_text().splitlines()]
    raw_requests = [item for item in journal if 'request' in item]
    assert raw_requests == row['calls']
    for item in journal:
        if 'response' in item:
            assert item['call_id'] not in completions
            completions[item['call_id']] = item['response']
    for call in raw_requests:
        identity = call['call_id']
        captured.append(identity)
        ledger = requests[identity]
        assert ledger['trial'] == row['id']
        provider = 'peer' if 'messages' in call['request'] else 'jev'
        provider_counts[(provider, ledger['status'])] += 1
        if identity not in completions:
            assert ledger['status'] == 'unknown'
            assert ledger['input_tokens'] is None and ledger['output_tokens'] is None
            missing_completions.append(identity)
            continue
        payload = completions[identity]
        usage = payload['usage'] if provider == 'peer' else payload
        inputs = usage['prompt_tokens'] if provider == 'peer' else usage['input_tokens']
        outputs = usage['completion_tokens'] if provider == 'peer' else usage['output_tokens']
        assert type(inputs) is int and type(outputs) is int and inputs >= 0 and outputs >= 0
        assert ledger['status'] == 'known' and (inputs, outputs) == (ledger['input_tokens'], ledger['output_tokens'])
        finished = [event for event in row['events'] if event.get('kind') == 'model_call' and event.get('phase') == 'finished' and event.get('call_id') == identity]
        assert len(finished) == 1 and finished[0]['status'] == 'returned'
        assert (inputs, outputs) == (finished[0]['prompt_tokens'], finished[0]['completion_tokens'])
        known_sum += inputs + outputs
    def inspect_keys(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key.lower() in {'api_key', 'api-key', 'authorization', 'x-api-key', 'access_token'}:
                    auth_fields.append(key)
                inspect_keys(child)
        elif isinstance(value, list):
            for child in value:
                inspect_keys(child)
    inspect_keys(journal)
assert not auth_fields
assert len(physical) == 6 and len(captured) == len(set(captured)) == len(requests) == 14
assert len(completions) == 13 and len(missing_completions) == 1
assert set(captured) == set(requests)
assert known_sum == spend['batch']['known_tokens'] == 156643
assert spend['batch']['reserved_tokens'] == spend['batch']['reserved_nano_usd'] == 0
assert all(not label['critical_events'] and not label['unexpected_action'] for label in physical.values())
saved = json.loads((output / 'audit-evidence.json').read_text())
assert physical == saved['trials'] and saved['unresolved'] == {}
old = json.loads((ROOT / 'prior-artifacts64-sha256.json').read_text())
assert len(old) == 64 and all(sha(REPO / name) == value for name, value in old.items())
assert not attempts
report = {
    'execution_sha256': frozen['sha256'],
    'planned': len(rows), 'attempted': 6, 'unrun_proved': 3642,
    'closed_result_binding': True, 'fixed_prefix_order': True,
    'physical_raw_reaudited': 6, 'physical_labels_match_saved': True,
    'physical_labels': physical, 'cleanup_confirmed': 6,
    'critical_events': 0, 'unexpected_business_actions': 0,
    'runner_strict_completed': sum(row['strict_completed'] is True for row in rows),
    'runner_negative_passed': sum(row['negative_passed'] is True for row in rows),
    'sdk_request_captures': 14, 'sdk_completion_captures': 13,
    'provider_status_counts': {provider + '_' + status: count for (provider, status), count in provider_counts.items()},
    'known_tokens_reconciled_only': known_sum, 'unknown_call_ids': missing_completions,
    'global_usage_reconciled': False, 'complete_audit_certificate': False,
    'cost_status': 'unpriced', 'unknown_usage_is_free': False,
    'previous_artifacts64_unchanged': True, 'network_or_credential_attempts': attempts,
    'authentication_header_fields_in_sdk_captures': len(auth_fields),
    'all_runtime_sources_unchanged': True,
}
(ROOT / 'postrun-independent-raw.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'physical_labels'}))
