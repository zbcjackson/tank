"""Read-only batch monitor; writes only its own observation journal."""
import collections
import datetime
import json
from pathlib import Path

ROOT = Path('/private/tmp/tank-jev-live-20261023')
STUDY = Path('/private/tmp/tank-jev-execution-review-20261023/study-v3')
path = STUDY / 'live/result.json'
try:
    result = json.loads(path.read_text())
except (OSError, ValueError) as error:
    print(json.dumps({'result_readable': False, 'error_type': type(error).__name__}))
    raise SystemExit(0)
rows = result['rows']
spend = result.get('spend', {})
batch = spend.get('batch', {})
requests = spend.get('requests', {})
closed = STUDY / 'live/closed.json'
summary = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'planned': len(rows),
    'attempted': sum(row.get('attempted') is True for row in rows),
    'finished': sum(row.get('status') == 'finished' for row in rows),
    'strict_completed': sum(row.get('strict_completed') is True for row in rows),
    'negative_passed': sum(row.get('negative_passed') is True for row in rows),
    'recovery_completed': sum(row.get('recovery_completed') is True for row in rows),
    'cleanup_confirmed': sum(row.get('cleanup_confirmed') is True for row in rows),
    'completed': result.get('completed'),
    'qualified': result.get('qualified'),
    'stop_reason': spend.get('stop_reason'),
    'sdk_receipts_observed': len(requests),
    'result_sdk_total_before_close': result.get('logical_sdk_calls'),
    'known_tokens': batch.get('known_tokens'),
    'reserved_tokens': batch.get('reserved_tokens'),
    'reserved_nano_usd': batch.get('reserved_nano_usd'),
    'request_status_counts': dict(collections.Counter(x.get('status') for x in requests.values())),
    'cost_status': spend.get('cost_status'),
    'closed': closed.exists(),
}
line = json.dumps(summary, ensure_ascii=False)
with (ROOT / 'progress-observations.jsonl').open('a') as journal:
    journal.write(line + '\n')
print(line)
