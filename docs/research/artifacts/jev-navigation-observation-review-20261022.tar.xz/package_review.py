import hashlib,io,json,lzma,os,re,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path(__file__).parent;repo=Path('/Users/zbcjackson/src/tank');sha=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((root/'review.json').read_text())['unresolved_findings']==[]
values={**dotenv_values(repo/'backend/core/.env'),**os.environ}
credentials={v.encode()for k,v in values.items()if v and len(v)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)}
assert len(credentials)>=21
files=sorted(p for p in root.iterdir() if p.is_file())
members=[]
for p in files:
 data=p.read_bytes();assert not any(v in data for v in credentials),p.name
 members.append({'name':p.name,'bytes':len(data),'sha256':sha(data)})
archive=repo/'docs/research/artifacts/jev-navigation-observation-review-20261022.tar.xz'
manifest=archive.with_name('jev-navigation-observation-review-20261022-manifest.json')
assert not archive.exists() and not manifest.exists()
with archive.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for p,m in zip(files,members,strict=True):
  data=p.read_bytes();assert sha(data)==m['sha256'];info=tarfile.TarInfo(m['name']);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r|xz')as tar:
 for actual,m in zip(tar,members,strict=True):
  assert actual.name==m['name'];data=tar.extractfile(actual).read();assert sha(data)==m['sha256']and len(data)==m['bytes'];assert not any(v in data for v in credentials)
value={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':members,'review_mode':'review-and-refactor','round':1,'reviewed_head':'2d077cd3','task_baseline':'1ec85dae','source_changes_by_reviewer':False,'independent_targeted_tests':28,'independent_research_tests':8,'original_archive_unchanged':True,'actual_credential_values_scanned':len(credentials),'matches':0,'real_model_or_ASR_calls_by_reviewer':0,'historical_overscope_lint_failure_retained':True,'remote_ASR_profile_certified':False,'formal_N':None}
manifest.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items()if k!='members'}));print('members',len(members))
