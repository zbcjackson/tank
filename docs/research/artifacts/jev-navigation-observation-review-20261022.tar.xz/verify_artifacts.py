import hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
from dotenv import dotenv_values
from PIL import Image
repo=Path('/Users/zbcjackson/src/tank');root=Path('/private/tmp/tank-navigation-observation-20261022');out=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((repo/'docs/research/artifacts/jev-navigation-observation-20261022-manifest.json').read_text())
archive=repo/'docs/research/artifacts'/manifest['archive']
assert archive.stat().st_size==manifest['bytes']==52694856
assert sha(archive.read_bytes())==manifest['sha256']=='47cb50e9ae696951d1832bb44f5dc012df32ad7fc36cf67daa897165e0aa84cb'
values={**dotenv_values(repo/'backend/core/.env'),**os.environ}
credentials={v.encode() for k,v in values.items() if v and len(v)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)}
assert len(credentials)>=21
members=manifest['members'];pngs=0
with tarfile.open(archive,'r|xz') as tar:
 for member,want in zip(tar,members,strict=True):
  assert member.isreg() and member.name==want['name']
  data=tar.extractfile(member).read();assert len(data)==want['bytes'] and sha(data)==want['sha256']
  assert not any(value in data for value in credentials),member.name
  if member.name.endswith('.png'):
   import io
   with Image.open(io.BytesIO(data)) as image:
    assert image.format=='PNG',member.name
    if member.name.startswith(('run/qualification/','run/fake/','run-v2/qualification/','run-v2/fake/')):assert image.size==(1280,720),(member.name,image.size)
    image.verify()
   pngs+=1
assert len(members)==6836
old=json.loads((root/'old-artifacts.json').read_text());assert len(old)==46
for name,want in old.items():
 current=(repo/name).read_bytes();assert sha(current)==want
 baseline=subprocess.run(['git','show','1ec85dae:'+name],cwd=repo,check=True,capture_output=True).stdout;assert baseline==current
f=json.loads((root/'run-v2/freeze.json').read_text())
digest=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
assert digest({k:v for k,v in f.items() if k!='sha256'})==f['sha256']=='096472b203217a388dc5cec6f4fad001851156be0699d15b670a5fdd2ccd5026'
assert f['formal_N'] is None and not f['model_execution_eligible']
for name,want in f['files'].items(): assert sha((root/'run-v2'/name).read_bytes())==want
assert len(f['runtime_sources'])==36
executable=json.loads((root/'run-v2/executable-freeze.json').read_text())
assert digest({k:v for k,v in executable.items() if k!='sha256'})==executable['sha256']=='dde7db9a13a2e4f5f32cc1b9914b184fcbc76ecdad917d5d55f47430600bf901'
changed=[]
for name,want in f['runtime_sources'].items():
 assert sha((repo/'backend'/name).read_bytes())==want
 initial=subprocess.run(['git','show','1ec85dae:backend/'+name],cwd=repo,check=True,capture_output=True).stdout
 if sha(initial)!=want:changed.append(name)
assert sorted(changed)==sorted(['benchmarks/computer_use/jev_calibration_route.py','benchmarks/computer_use/jev_linkding_route.py','benchmarks/computer_use/jev_real_product_route.py','plugins/agent-computer-use/src/agent_computer_use/channels/dom.py'])
for name in ('cases.json','calibration-tasks.json'):
 assert (root/'run'/name).read_bytes()==(root/'run-v2'/name).read_bytes()
first=json.loads((root/'run/freeze.json').read_text());assert first['schedule']==f['schedule']
prior=Path('/private/tmp/tank-jev-confirmation-qualification-20261022')
assert prior.exists()
for name in ('cases.json','calibration-tasks.json'):
 assert (prior/'run'/name).read_bytes()==(root/'run-v2'/name).read_bytes()
assert json.loads((prior/'run/freeze.json').read_text())['schedule']==f['schedule']
for name in ('native-independent.json','fake-independent.json'):
 assert json.loads((out/name).read_text())==json.loads((root/name).read_text())
summary={'archive_members':len(members),'archive_sha256':manifest['sha256'],'actual_credential_values_scanned':len(credentials),'credential_matches':0,'decoded_all_archived_PNGs':pngs,'old_46_files_equal_SHA_and_baseline_Git_blob':True,'runtime_sources_match_current':36,'only_four_runtime_sources_changed':changed,'freeze_valid':f['sha256'],'same_96_goals_192_schedule_as_prior':True,'independent_physical_audits_identical':True}
(out/'artifact-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
