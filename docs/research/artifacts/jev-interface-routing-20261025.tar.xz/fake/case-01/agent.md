---
name: interface-check
extension: agent-computer-use:agent
model: default
decision-model: jev
visual-model: vision
---
Execute the declared goal.
