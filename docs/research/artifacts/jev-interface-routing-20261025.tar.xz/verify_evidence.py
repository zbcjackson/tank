"""Supplemental offline reconciliation; never imports driver or SDKs."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
f=json.loads((ROOT/'freeze.json').read_text())
assert sha256((ROOT/'run.py').read_bytes()).hexdigest()==f['driver_sha256']
assert sha256((ROOT/'audit.py').read_bytes()).hexdigest()==f['auditor_sha256']
for path,expected in f['sources'].items():
    assert sha256((ROOT/'sources'/path).read_bytes()).hexdigest()==expected
interface=json.loads((ROOT/'interface/qualification.json').read_text())
assert interface['all_passed'] and interface['freeze_sha256']==sha256((ROOT/'freeze.json').read_bytes()).hexdigest()
assert json.loads((ROOT/'interface/cleanup.json').read_text())['server_exit'] is not None
reports=[]
for mode in ('fake','live'):
    subprocess.run([sys.executable,str(ROOT/'audit.py'),mode],check=True,stdout=subprocess.DEVNULL)
    p=ROOT/mode
    batch=json.loads((p/'result.json').read_text())
    diagnostics=[json.loads(line) for line in (p/'sdk-diagnostics.jsonl').read_text().splitlines()]
    starts=[x['call_id'] for x in diagnostics if x['phase']=='invoke_started']
    ends=[x for x in diagnostics if x['phase']=='call_returned']
    assert Counter(starts)==Counter(x['call_id'] for x in ends)==Counter(batch['spend']['requests'].keys())
    assert not any(x['phase'].endswith('error') for x in diagnostics)
    assert all(x['task_id']==mode+'-case-01' and x['completion_status']=='returned' and x['reservation_status']=='known' for x in ends)
    trial=p/'case-01'
    report=json.loads((trial/'independent-audit.json').read_text())
    events=json.loads((trial/'events.json').read_text())
    capture=json.loads((trial/'captures.json').read_text())
    requests=[x for x in capture if 'request' in x]
    assert [x['model'] for x in requests]==[f['jev']['model'],f['vision']['model']]
    admission=[x['metadata'] for x in events if x['kind']=='computer_use_action_admission']
    assert len(admission)==1 and admission[0]['accepted'] is False and admission[0]['next_route']=='visual_fallback'
    assert admission[0]['choice']=='candidate'
    assert report['choices'][0]['choice'] in report['duplicate_aliases']
    assert report['correct_source'] is True and report['dispatched_actions']==1 and report['post_count']==report['writes']==0
    assert any(x['kind']=='computer_use_proposal' and x['metadata']['source']=='visual' for x in events)
    packet=json.loads(requests[1]['request']['messages'][1]['content'][0]['text'])
    criteria=packet['questions']['next_action']['criteria']
    offered={k for k,v in criteria.items() if isinstance(v,dict)}
    assert len(offered)==admission[0]['candidates']<=32 and set(packet['image_candidates'])==offered
    execution=json.loads((trial/'audit.json').read_text())
    finished=[x for x in execution if x['phase']=='finished']
    assert Counter(x['operation'] for x in finished)==Counter({'computer_use.observe':2,'computer_use.capture':1,'computer_use.dispatch':1})
    assert report['choices'][-1]['choice']==report['left_alias']
    if mode=='live':assert report['choices'][0]['choice']==report['left_alias']
    reports.append(dict(mode=mode,correct_source=True,sdk_calls=2,candidates=len(offered),zero_business_writes=True,all_sdk_execution_calls_closed=True))
(ROOT/'evidence-verification.json').write_text(json.dumps(dict(all_passed=True,reports=reports),indent=2)+'\n')
print('Offline evidence reconciliation: PASS; fake/live each duplicate admission→visual→correct sidebar navigation; zero writes, source bytes match.')
