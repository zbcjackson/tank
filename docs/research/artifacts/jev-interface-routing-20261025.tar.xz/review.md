# 界面证据路由：完成审查

- 日期：2026-10-25。
- 模式：review-and-refactor；本独立任务第1轮；无旧问题，不递归委派。
- 基线：363a3d4c36919895ea5f79046b1b86a4a3c69977；审查HEAD：2c61e495dac29e1db1d500296eecbc3fb737b7e3（含ec2ba1d8）。审查完整baseline..HEAD的7个文件，非仅末次提交。
- 范围：docs/README.md、docs/backlog.md、现行computer-use设计、主计划、新interface-routing计划/研究及证据归档。无生产/测试/依赖/默认配置变更；工作区开始和结束均干净，无用户未提交修改。
- 已显式重新加载agents/code-reviewer.md；沿用已读项目架构、backend编码/开发/测试及Git约定。采用项目docs-only检查及gitmoji签名提交规则。

## 结论与处置

未发现确认的可操作问题或待解决旧问题。第1轮结束，不增加无变更的复审。
未实施修复、重构或新提交；没有评审者自修但未经独立复核的最终修改。
设计更新与现行代码相符，清楚区分当前能力、已有有限证据与下一步资格计划。
一次自然图片接管及正确来源导航有原始证据支持；Jev原本选对、几何可区分而像素必要性未证的限制没有被掩盖。

## 独立复核

1. 从仓库归档独立安全解包至/private/tmp/tank-jev-interface-routing-review-20261025-extracted。SHA256为c6fb87b815a4757f390c8a5ed385d2ee4a0942ff5a3afeb40d3782b67dcf2aae；445普通成员，无越界路径/链接。manifest444项与实际成员集合及逐文件SHA完全一致。
2. freeze SHA256为cdd84c44c4cd7225fd01f37d55da697803888e875ee2c81656e50018cf5027c1。冻结run/audit原字节一致；352源码文件同时匹配归档保存字节、git基线与当前工作区。当前实际产品652项文件与冻结一致；旧78工件和默认config SHA不变。
3. 对照已审查上一任务驱动阅读完整改动：goal仅公开描述“内容页→左侧work_items链接→结构页”，禁止顶部同名链接、Structure页签和改数据；没有正确alias/ref/坐标。公开completion是多个入口共享的结构页URL，初始不成立，不泄漏左侧来源。导航用URL核验合理，未冒充业务保存验证。
4. 阅读inspect离线资格逻辑及已保存packet/frame/boxes，核对两次失败的类型转换与本地image scope修正只在临时检查器，不改变生产门或实际Runner。最终冻结下无模型检查、fake资格及其审计先于live门；live分支没有假HTTP或强制Jev输出，只有一个真实任务、一次批次。
5. 结构证据中c3/c6除了ref，role/label/value/祖先/effect相同；两者均指同一结构页URL，模型投影bounds为空。其他25候选仍可区分，所以实际Jev先调用。按原生产text_candidate_ids及ActionAdmissionSelector，重复身份的已选动作被拒绝，再沿原绑定转视觉，无App分类器或新增路由策略。
6. 实际真实Jev选择c6，原准入accepted=false、next_route=visual_fallback；Gemini同样选择c6。唯一visual proposal的action_id与Jev proposal、唯一sent回执和TaskResult.recent_action一致，target_ref为c6；实际唯一派发事件为sent click。生产DOM dispatch由绑定target_ref构建locator，并在点击前核对场景/DOM/引用，再返回相同action id回执。
7. 从真实visual请求解码并目视核对1280×720 PNG：顶部c3图框约(239.75,18.296875,75.515625,17)，左侧c6约(15,132.796875,183.328125,30.5)。27候选图框完整合法，视觉与Jev同goal/snapshot/questions；frame_id/image_sha与visual proposal一致。PNG SHA为e6140f5c1d48cefd77b9295a70bfbd36b71e6cecf3d431152501b6d7dddb59c2。未将reference-existing-product.png当本轮资格或模型证据。
8. 原始TaskResult completed/goal_verified、pending_effect=false；原生产读回确认导航，结构页GET/独立目标HTML与任务目的匹配。来源判定另由预冻审计器核对原PNG几何、选择ref、proposal与回执，故没有只用共享URL判正确入口。原始DB/触发器、返回列表DOM/HTML、schema均未变，_writes为空，所有产品HTTP为GET，清理confirmed。
9. 系统Python运行独立解包的verify_evidence.py：PASS，内部fake/live audit均通过。每次2SDK、1动作；执行闭合为observe×2/capture/dispatch。核验前后manifest逐项再次一致，派生结果可重复。真实Jev14964+287=15251、Gemini14816+526=15342，共30593整数token；捕获/事件/诊断/账本ID及用量一致，无unknown或未结预留。
10. 设计新增的逐步文字选择/所选动作准入/自然视觉接管/后续观察与硬停止边界与现行实现吻合。对旧S5“尚未实现/SDK未升级”的修正明确现行显式能力，不重写旧测量或采用结论。后续区域/几何补全是待资格评估，不是已交付功能；一次正确没有被用于放宽守卫或更改默认。

## 实际验证

- python3 verify_evidence.py（独立解包目录）：PASS，fake/live各2SDK、1动作、零写入。
- 临时只读哈希核对：manifest444项、352源码基线/当前、652产品文件、旧78工件及config：PASS。
- 手工核查无模型packet初始URL谓词为假、实际PNG/两个图框、proposal/receipt/recent-action身份和唯一sent click：PASS。
- python3 scripts/check_docs.py：OK，122 files under docs/。
- git diff --check 363a3d4c36919895ea5f79046b1b86a4a3c69977..HEAD：PASS。
- 既有allowed-signers只读验签：ec2ba1d8、2c61e495均G；未更改签名配置。
- 未执行run.py inspect/live、未启动产品/SDK、未读取凭据或发出模型请求。
- 生产源码未变化，按docs-only例外未重跑生产单元/E2E；不将前轮6801或E2E24/95计为本轮检查。

## 限制与交接

单个已知产品的单次布局导航不是模型排序或准确率确认。Jev已经选对，不能将守卫拒绝称作Jev失败；图片包包含几何，不能认定像素必要或视觉更强。候选顺序仍可能提供猜测线索，不能断言文字绝对无力识别。
当前可区分性守卫仍保守，区域/几何上下文补全及图形/颜色需求仍须后续独立资格；本任务没有追加位置接口、放宽守卫、扩大模型试次或改变默认。
没有未解决问题或验证阻塞；不宣称证明实现无缺陷。协调者可核对报告与diff后闭合本片并保留后续触发项，归档原始报告；如重新封包，须同步新SHA/成员数，不改写冻结原始记录。
