"""Fixed interface-evidence navigation task; unchanged product and production route."""
from __future__ import annotations
import asyncio
from contextlib import nullcontext
from dataclasses import asdict
from hashlib import sha256
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from unittest.mock import MagicMock
import urllib.request

os.environ['LANGFUSE_TRACING_ENABLED'] = 'false'
os.environ['OTEL_SDK_DISABLED'] = 'true'
import httpx
import pytest
from agent_computer_use.channels.dom import BrowserConfig, ManagedChromiumChannel, dom_table_fact
from tank_backend.agents.approval import PendingToolCallStore, ToolApprovalPolicy
from tank_backend.agents.definition import parse_agent_file
from tank_backend.agents.resources import DesktopResource
from tank_backend.agents.runner import AgentRunner
from tank_backend.agents.subagent import SubAgentAuthorization, SubAgentBudget, SubAgentContext
from tank_backend.benchmarks.model_policy import BenchmarkModelPolicy
from tank_backend.benchmarks.spend_ledger import SpendLedger, SpendLimit
from tank_backend.config.app_config import AppConfig
from tank_backend.pipeline.bus import Bus
from tank_backend.plugin.manifest import read_manifest_from_yaml
from tank_backend.plugin.registry import ExtensionRegistry
from benchmarks.computer_use import jev_real_product_route as product
from benchmarks.computer_use.jev_sdk_diagnostics import sdk_diagnostics

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/zbcjackson/src/tank')
APP = Path('/private/tmp/tank-sqlite-web-smoke-20261025-env/bin/python')
JEV = {'url':'https://api.typesafe.ai/v1/systemone','model':'jev-1.14.0'}
VISION = {'url':'https://openrouter.ai/api/v1','model':'google/gemini-3.8-flash','max_tokens':4096}
SEED = [{'id':1,'title':'Nora','notes':'Keep A'}, {'id':2,'title':'Tavi','notes':'Keep B'}]
CASES = [dict(id='case-01', start='/work_items/content/', destination='/work_items/')]

def write(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=lambda x: x.model_dump(mode="json") if hasattr(x,"model_dump") else sorted(x))+'\n')

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def sources():
    paths = subprocess.check_output(['git','ls-files','backend/core/src','backend/plugins/agent-computer-use/src',
        'backend/plugins/agent-computer-use/plugin.yaml','backend/uv.lock',
        'backend/benchmarks/computer_use/jev_real_product_route.py',
        'backend/benchmarks/computer_use/jev_sdk_diagnostics.py','backend/core/tests/sdk_http.py'],cwd=REPO,text=True).splitlines()
    return {p:digest(REPO/p) for p in paths}

def prepare():
    assert not (ROOT/'freeze.json').exists()
    f = dict(baseline='363a3d4c36919895ea5f79046b1b86a4a3c69977',cases=CASES,seed=SEED,jev=JEV,vision=VISION,
        selector='jev-action-vision',readback_tables=True,seconds=120,actions=6,observations=24,
        token_budget_per_task=100000,request_limit=8,request_bytes=4*1024*1024,
        cost_status='unpriced',token_limit='host accounted usage, not a provider reservation ceiling',
        sources=sources(),driver_sha256=digest(Path(__file__)),auditor_sha256=digest(ROOT/'audit.py'),app=product.app_manifest(APP),
        versions={n:metadata.version(n) for n in ('typesafe-sdk','openai','playwright','pillow')},
        completion_recipe='public navigation URL shared by both duplicate links; source region independently audited, no private alias or coordinates in goal',
        model_data='synthetic goal, public DOM state/candidates/history; bound PNG only on natural visual fallback')
    write(ROOT/'freeze.json',f)
    old={str(p.relative_to(REPO)):digest(p) for p in (REPO/'docs/research/artifacts').iterdir() if p.is_file()}
    write(ROOT/'preservation-before.json',dict(artifacts=old,config_sha256=digest(REPO/'backend/core/config.yaml')))
    print('freeze',digest(ROOT/'freeze.json'), 'sources',len(f['sources']),flush=True)

def check():
    f=json.loads((ROOT/'freeze.json').read_text())
    assert f['sources']==sources() and f['driver_sha256']==digest(Path(__file__))
    assert f['auditor_sha256']==digest(ROOT/'audit.py')
    assert f['app']==product.app_manifest(APP)
    assert f['cases']==CASES and f['seed']==SEED and f['jev']==JEV and f['vision']==VISION
    return f

async def public_table(origin, output, name):
    ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event())
    ctx.runtime.bind(name)
    browser=ManagedChromiumChannel(BrowserConfig(scope='interface-check',url=origin+'/work_items/content/',readback_tables=True))
    try:
        snapshot=await browser.observe('interface-check',ctx)
        write(output/(name+'.json'),asdict(snapshot))
        assert snapshot.ready and snapshot.complete
        found=[f for f in snapshot.facts if f.key.startswith('status:DOM table:')]
        assert len(found)==1
        return found[0]
    finally:
        await browser.aclose()
        await ctx.runtime.aclose()

def make_goal(origin):
    intent=('Starting from the work_items content page, click the work_items link in the left sidebar '
        'to open the table structure overview. Use that sidebar link only; do not use the top '
        'breadcrumb link or the Structure tab. Do not modify any data.')
    return dict(schema_version=2,goal_id='case-01',scope='interface-check',authorization_ref='current_task',
        intent=intent,objective=intent,allowed_operations=['click'],inputs=[],
        constraints=['Use only the work_items link in the left sidebar. No inserts, edits, deletes, SQL or schema changes.'],
        completion=[dict(key='status:Page URL',value=origin+'/work_items/')])

async def inspect_interface():
    from agent_computer_use.action_builder import ActionBuilder
    from agent_computer_use.contracts import GoalContract
    from agent_computer_use.action_admission import text_candidate_ids
    from agent_computer_use.model_view import decision_question, candidate_aliases
    from agent_computer_use.visual_selector import VisualSelector
    from tank_backend.llm.model_data import ModelDataScope
    f=check();output=ROOT/'interface';output.mkdir(exist_ok=False)
    database=output/'fixture.db';product.create_database(database,SEED)
    ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event(),
        model_data_scope=ModelDataScope(frozenset({'text','image'})))
    ctx.runtime.bind('interface-inspection');server=None;browser=None
    try:
        with (output/'server.log').open('w') as log:
            server=await asyncio.create_subprocess_exec(str(APP),str(Path(product.__file__)),
                '--serve','--database',str(database),'--output',str(output),
                env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1'},stdout=log,stderr=asyncio.subprocess.STDOUT)
            async with asyncio.timeout(10):
                while not (output/'ready.json').exists():
                    assert server.returncode is None;await asyncio.sleep(.05)
            origin='http://127.0.0.1:'+str(json.loads((output/'ready.json').read_text())['port'])
            browser=ManagedChromiumChannel(BrowserConfig(scope='interface-check',url=origin+CASES[0]['start'],readback_tables=True))
            snapshot=await browser.observe('interface-check',ctx);goal=GoalContract.from_input(make_goal(origin))
            actions=ActionBuilder(visual=True).build('case-01',1,goal,snapshot)
            packet=decision_question(goal,snapshot,actions)
            selector=VisualSelector(browser);selector.register(ctx)
            frame=await selector.capture_frame(snapshot,actions,ctx)
            (output/'frame.png').write_bytes(frame.png)
            criteria=packet['questions']['next_action']['criteria']
            duplicates=[(k,c) for k,c in criteria.items() if isinstance(c,dict) and c.get('label')=='work_items']
            assert len(duplicates)==2
            assert {k:v for k,v in duplicates[0][1].items() if k!='target_ref'}=={k:v for k,v in duplicates[1][1].items() if k!='target_ref'}
            assert all(e.get('bounds') is None for e in packet['state']['snapshot']['elements'])
            accepted=text_candidate_ids(actions);alias=candidate_aliases(actions)
            assert accepted and all(alias[k].id not in accepted for k,_ in duplicates)
            bounds=dict(frame.bounds)
            rectangles={k:bounds[c['target_ref']] for k,c in duplicates}
            assert sum(x<200 and y>=55 and x+w<=200 for x,y,w,h in rectangles.values())==1
            write(output/'packet.json',packet);write(output/'duplicate-boxes.json',rectangles)
            write(output/'qualification.json',dict(all_passed=True,freeze_sha256=digest(ROOT/'freeze.json'),
                initial_completion_false=True,candidates=len(actions.actions),duplicate_aliases=[k for k,c in duplicates],
                no_positions_in_text=True,unique_left_sidebar_target=True,models_called=0,credentials_loaded=False))
    finally:
        if browser is not None:await browser.aclose()
        await ctx.runtime.aclose()
        if server is not None and server.returncode is None:
            server.terminate();await asyncio.wait_for(server.wait(),5)
        write(output/'cleanup.json',dict(browser_closed=True,runtime_closed=True,server_exit=None if server is None else server.returncode))
    print('Original product interface qualification: PASS; two equivalent text links, one left-sidebar image target, zero model calls.',flush=True)

async def trial(case, output, mode, credential, ledger):
    output.mkdir(exist_ok=False)
    database=output/'fixture.db'
    product.create_database(database,SEED)
    # This snapshot is evidence only, never passed to goal construction or the Runner.
    write(output/'database-before.json',product.database_state(database))
    events=[]; captures=[]; audits=[]; calls=[]; blocked=[]
    result=None; server=None; error=None
    started=time.monotonic()
    class Observer:
        def on_event(self,kind,metadata):
            events.append(dict(kind=kind,metadata=metadata))
            write(output/'events.json',events)
    class Capture:
        async def request(self,call_id,request):
            captures.append(dict(call_id=call_id,url=request.url,model=request.model,purpose=request.purpose,request=request.parameters))
            write(output/'captures.json',captures)
        async def response(self,call_id,response):
            captures.append(dict(call_id=call_id,response=response))
            write(output/'captures.json',captures)
    async def audit(record):
        audits.append(asdict(record));write(output/'audit.json',audits)
    class HTTP(httpx.AsyncBaseTransport):
        async def handle_async_request(self,request):
            data=json.loads(request.content); calls.append(data)
            native='questions' in data
            packet=data if native else json.loads(data['messages'][1]['content'][0]['text'])
            criteria=packet['questions']['next_action']['criteria']
            facts={f['key']:f['value'] for f in packet['state']['snapshot']['facts']}
            chosen='none'
            for key,candidate in criteria.items():
                if not isinstance(candidate,dict) or candidate.get('label')!='work_items':continue
                if native:
                    chosen=key;break
                x,y,width,height=packet['image_candidates'][key]
                if x<200 and y>=55 and x+width<=200:
                    chosen=key;break
            write(output/'fake-http.json',calls)
            if native:
                return httpx.Response(200,json={'model':JEV['model'],'answers':{'next_action':{'type':'choice','choice':chosen,'confidence':1,
                    'probabilities':{k:int(k==chosen) for k in criteria}}},'usage':{'input_tokens':12,'output_tokens':0}})
            return httpx.Response(200,json={'id':'fixture','object':'chat.completion','created':1,'model':VISION['model'],
                'choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':json.dumps({'choice':chosen})}}],
                'usage':{'prompt_tokens':10,'completion_tokens':2,'total_tokens':12}})
    original_connect=socket.socket.connect
    def connect(sock,address):
        if isinstance(address,tuple) and address[0] not in {'127.0.0.1','::1','localhost'}:
            blocked.append(str(address[0]));raise OSError('non-loopback socket denied')
        return original_connect(sock,address)
    try:
        with (output/'server.log').open('w') as log:
            server=await asyncio.create_subprocess_exec(str(APP),str(Path(product.__file__)),
                '--serve','--database',str(database),'--output',str(output),
                env={'PATH':os.environ.get('PATH',''),'PYTHONUNBUFFERED':'1'},stdout=log,stderr=asyncio.subprocess.STDOUT)
            async with asyncio.timeout(10):
                while not (output/'ready.json').is_file():
                    assert server.returncode is None
                    await asyncio.sleep(.05)
            origin='http://127.0.0.1:'+str(json.loads((output/'ready.json').read_text())['port'])
            initial=await public_table(origin,output,'initial-public-dom')
            goal=make_goal(origin)
            assert all(f['key']!='status:Page URL' or f['value']!=goal['completion'][0]['value']
                       for f in json.loads((output/'initial-public-dom.json').read_text())['facts'])
            write(output/'goal.json',goal)
            definition_path=output/'agent.md'
            definition_path.write_text('---\nname: interface-check\nextension: agent-computer-use:agent\nmodel: default\ndecision-model: jev\nvisual-model: vision\n---\nExecute the declared goal.\n')
            definition=parse_agent_file(definition_path)
            registry=ExtensionRegistry()
            manifest=read_manifest_from_yaml(REPO/'backend/plugins/agent-computer-use/plugin.yaml')
            for extension in manifest.extensions:registry.register(manifest.plugin_name,extension)
            config=AppConfig.from_raw_dict({'llm':{
                'default':{'api_key':'unused','model':'unused','base_url':VISION['url']},
                'vision':{'api_key':credential['vision'],'model':VISION['model'],'base_url':VISION['url'],'max_tokens':4096}},
                'decision_models':{'jev':{**JEV,'credential_env':'SMOKE_JEV_KEY'}},
                'subagents':{'agent-computer-use:agent':{'config':{'selector':'jev-action-vision',
                    'browser':{'scope':'interface-check','url':origin+case['start'],'readback_tables':True}}}}})
            runner=AgentRunner(MagicMock(),MagicMock(),Bus(),ToolApprovalPolicy(computer_mode='allow'),PendingToolCallStore(),
                {definition.name:definition},registry=registry,app_config=config,desktop_resource=DesktopResource())
            with pytest.MonkeyPatch.context() as mp:
                mp.setenv('SMOKE_JEV_KEY',credential['jev'])
                if mode=='fake':
                    sys.path.insert(0,str(REPO/'backend/core/tests'))
                    from sdk_http import install_typesafe_fake_http
                    mp.setattr(httpx,'AsyncHTTPTransport',HTTP);install_typesafe_fake_http(mp)
                    mp.setattr(socket.socket,'connect',connect)
                async for event in runner.run_agent(definition,[],task_id=mode+'-'+case['id'],task_input=goal,
                    authorization=SubAgentAuthorization(frozenset({'desktop','network'})),deadline=time.monotonic()+120,
                    token_budget=100000,max_actions=6,max_observations=24,observer=Observer(),audit=audit,
                    model_capture=Capture(),model_policy=BenchmarkModelPolicy(ledger,())):
                    if 'task_result' in event.metadata:result=event.metadata['task_result'];write(output/'task-result.json',result)
            def structure_html():
                with urllib.request.urlopen(origin+case['destination'],timeout=10) as response:return response.read()
            (output/'final-target.html').write_bytes(await asyncio.to_thread(structure_html))
            final=await public_table(origin,output,'final-public-dom')
            write(output/'final-table.json',final.model_dump())
            def html():
                with urllib.request.urlopen(origin+'/work_items/content/',timeout=10) as response:
                    return response.read()
            (output/'final-list.html').write_bytes(await asyncio.to_thread(html))
    except BaseException as exc:
        error=type(exc).__name__
        import traceback
        write(output/'error.json',dict(type=error,frames=[dict(file=x.filename,line=x.lineno,function=x.name) for x in traceback.extract_tb(exc.__traceback__)]))
    finally:
        write(output/'database-after.json',product.database_state(database))
        write(output/'events.json',events);write(output/'captures.json',captures);write(output/'audit.json',audits)
        if server is not None and server.returncode is None:
            server.terminate()
            try:await asyncio.wait_for(server.wait(),5)
            except TimeoutError:server.kill();await server.wait()
        cleanup=dict(server_exit=None if server is None else server.returncode,
            runner_cleanup=None if result is None else result.get('cleanup'))
        write(output/'cleanup.json',cleanup)
    return dict(id=case['id'],attempted=True,status='returned' if result else 'error',error_type=error,
                elapsed_seconds=time.monotonic()-started,result=result,cleanup=cleanup,blocked_network=blocked)

async def batch(mode):
    f=check()
    interface=json.loads((ROOT/'interface/qualification.json').read_text())
    assert interface['all_passed'] and interface['freeze_sha256']==digest(ROOT/'freeze.json')
    if mode=='live':
        fake=json.loads((ROOT/'fake'/'result.json').read_text())
        audit=json.loads((ROOT/'fake'/'independent-audit.json').read_text())
        assert fake['freeze_sha256']==digest(ROOT/'freeze.json') and fake['completed'] and audit['all_passed']
    output=ROOT/mode;output.mkdir(exist_ok=False)
    credential={'jev':'fixture-only','vision':'fixture-only'}
    if mode=='live':
        from dotenv import dotenv_values
        values={**dotenv_values(REPO/'backend/core/.env'),**os.environ}
        credential={'jev':values.get('TYPESAFE_API_KEY') or '', 'vision':values.get('OPENROUTER_API_KEY') or ''}
        assert all(credential.values()),'required credentials missing'
    ledger=SpendLedger(SpendLimit(0,0),record_only=True,request_limit=8,journal=output/'spend.jsonl')
    result=dict(mode=mode,freeze_sha256=digest(ROOT/'freeze.json'),completed=False,
                rows=[dict(id=c['id'],attempted=False,status='not_run') for c in CASES],formal_N=None)
    def persist():
        result['spend']=ledger.snapshot();write(output/'result.json',result)
    persist()
    try:
        with sdk_diagnostics(output/'sdk-diagnostics.jsonl'):
            for row,case in zip(result['rows'],CASES):
                check();ledger.start_trial(case['id'],SpendLimit(0,0))
                row.update(await trial(case,output/case['id'],mode,credential,ledger))
                ledger.finish_trial();persist()
                # The separate auditor gates the next task; it does not import this driver.
                proc=await asyncio.create_subprocess_exec(sys.executable,str(ROOT/'audit.py'),mode,case['id'],stdout=asyncio.subprocess.PIPE)
                stdout,_=await proc.communicate();print(stdout.decode().strip(),flush=True)
                assert proc.returncode==0,'independent audit stopped batch'
                r=row.get('result') or {}
                assert not row['error_type'] and row['cleanup']['runner_cleanup']=='confirmed'
                assert r.get('status')!='unknown' and not r.get('details',{}).get('pending_effect')
                assert ledger.snapshot()['stop_reason'] is None
            result['completed']=True
    finally:
        ledger.close();persist()
    print(json.dumps(dict(mode=mode,completed=result['completed'],rows=[dict(id=r['id'],status=r['status'],result=r.get('result',{}).get('status')) for r in result['rows']],spend=result['spend']['batch'])),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='inspect':asyncio.run(inspect_interface())
    elif sys.argv[1] in {'fake','live'}:asyncio.run(batch(sys.argv[1]))
    else:raise SystemExit('prepare|inspect|fake|live')
