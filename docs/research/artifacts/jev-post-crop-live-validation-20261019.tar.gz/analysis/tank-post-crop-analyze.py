import hashlib,json,sys,statistics
from pathlib import Path
p=Path(sys.argv[1]);r=json.loads((p/'result.json').read_text());f=json.loads((p/'freeze.json').read_text());labels=json.loads((p/'private/labels.json').read_text());raw=[json.loads(l)for l in(p/'calls.jsonl').read_text().splitlines()]
requests={x['call_id']:x for x in raw if 'request'in x};responses={x['call_id']:x['response']for x in raw if 'response'in x};usage=r['spend']['requests']
assert json.loads((p/'spend.jsonl').read_text().splitlines()[-1])==r['spend'];assert r['spend']['record_only'];assert 'limit_requests'not in r['spend']['batch']
summary={'freeze':r['sha256'],'completed':r['completed'],'stop_reason':r['spend']['stop_reason'],'captured_requests':len(requests),'responses':len(responses),'task_rows':[],'boxes':[],'pairs':[],'record_only':True,'cost_status':r['spend']['cost_status']}
ins=outs=0;unknown=[]
for cid,u in usage.items():
 if u['status']not in {'known','not_sent'}:unknown.append(cid)
 ins+=u['input_tokens']or 0;outs+=u['output_tokens']or 0
for cid,q in requests.items():
 text=q['trial'].endswith('-text');assert len(q['images'])==int(not text)
 assert q['headers']==({}if text else {'TypeSafe-Danger-Zone-Images':'true'})
 for a in q['images']:
  b=(p/a['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==a['sha256'] and len(b)==a['bytes']
 if '.ablation.'in q['purpose']:
  assert 'completion'not in q['request']['state']['goal'];s=json.dumps(q['request']);assert 'expected_body'not in s and 'expected_variant'not in s and '\\colortbl'not in s
 for key in ('input_tokens','output_tokens'):
  if cid in responses and responses[cid].get(key)is not None:assert responses[cid][key]==usage[cid][key]
for x in r['rows']:
 for c in x['frames']:assert hashlib.sha256((p/c['path']).read_bytes()).hexdigest()==c['frame']['image_sha256']
 ids=[cid for cid,q in requests.items()if q['trial']==x['id']and usage[cid]['status']!='not_sent']
 if x['kind']=='task':
  target=x.get('named_target');expected=('Jev visual probe\nDONE\nSouth\n'if target=='north'else 'Jev visual probe\nNorth\nDONE\n')if target else labels[x['scene']]['expected_body']
  a=x.get('model_answer',{});choice=a.get('choice');selected=x.get('criteria',{}).get(choice);correct=isinstance(selected,dict)and selected.get('value')==expected
  assert correct==x.get('model_correct',False)
  if x['passed']:
   assert x['cleanup_confirmed']and x['independent_values']=={'document':expected}and len(x['native_actions'])==1
   assert x['native_actions'][0]['value']==expected and x['native_actions'][0]['status']=='returned'
   proposals={(e['candidate_set_id'],e['action_id'])for e in x['events']if e['kind']=='computer_use_proposal'and e['source']=='ablation_'+x['arm']}
   sent={(z['candidate_set_id'],z['action_id'])for z in x['result']['details']['receipts']if z['status']=='sent'}
   assert len(proposals&sent)==x['selection_executed']==1
  summary['task_rows'].append({'id':x['id'],'family':'named'if target else 'color','scene':x['scene'],'position':int(x['move_window']),'arm':x['arm'],'called':bool(ids),'choice':choice,'correct':correct,'abstained':x.get('model_abstained',False),'completed':x['passed'],'reason':x.get('result',{}).get('reason',x['status']),'stages':[e['stage']for e in x.get('events',[])if e['kind']=='computer_use_freshness'],'native_actions':len(x['native_actions']),'elapsed_ms':x.get('elapsed_ms')})
 else:
  assert not x['native_actions']
  for b in x['boxes']:
   correct=False
   if b['status']=='returned':
    ans=b['answer'];correct=ans['cardinality']['choice']==b['cardinality']
    if b['cardinality']=='one':
     assert len(b['independent_rectangles'])==1
     x0,y0,w,h=b['independent_rectangles'][0];inset=min(w,h)*f['box_interior_inset'];point=b['screen_point']
     correct=correct and point is not None and x0+inset<=point[0]<=x0+w-inset and y0+inset<=point[1]<=y0+h-inset
    assert correct==b['correct']and b['native_actions_added']==0
   summary['boxes'].append({'id':x['id']+'-'+b['id'],'expected':b['cardinality'],'status':b['status'],'correct':correct,'choice':b.get('answer',{}).get('cardinality',{}).get('choice'),'reason':b.get('reason'),'point':b.get('screen_point')})
for family in ('color','named'):
 for scene in('scene-01','scene-02'):
  for pos in range(2):
   rows=[x for x in summary['task_rows']if(x['family'],x['scene'],x['position'])==(family,scene,pos)]
   assert len(rows)==2
   summary['pairs'].append({'id':f'{family}-{scene}-p{pos}','both_called':all(x['called']for x in rows),'image_correct':next(x['correct']for x in rows if x['arm']=='image'),'text_correct':next(x['correct']for x in rows if x['arm']=='text')})
summary.update(input_tokens=ins,output_tokens=outs,total_tokens=ins+outs,unknown_requests=unknown,estimate_nano_usd=ins*f['model']['input_price']+outs*f['model']['output_price'],cleanup_confirmed=sum(x.get('cleanup_confirmed',False)for x in r['rows']),contexts=len(r['rows']),frames=sum(len(x['frames'])for x in r['rows']),source_files=len(f['source_sha256']))
if not unknown:assert ins+outs==r['spend']['batch']['known_tokens']
Path('/private/tmp/tank-post-crop-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
