"""Offline synthetic causal check of downscale-before-crop boundary mixing."""
import hashlib,io,json,subprocess
from pathlib import Path
from dataclasses import asdict
from PIL import Image,ImageChops
from tank_backend.tools.computer_observation import Observation
OUT=Path('/private/tmp/tank-frame-diagnostics-20261019-resample');OUT.mkdir(exist_ok=False)
logical=(213,77,840,954);physical=tuple(v*2 for v in logical)
a=Image.new('RGB',(3840,2160),'white');b=a.copy()
# The only changed pixels lie outside the bound window's right boundary.
b.paste((0,0,0),(physical[2],physical[1]+100,physical[2]+4,physical[3]-100))
assert a.crop(physical).tobytes()==b.crop(physical).tobytes()
rows=[];images={}
for label,img in [('a',a),('b',b)]:
 raw=OUT/(label+'-backing.png');img.save(raw)
 point=OUT/(label+'-point.png');subprocess.run(['sips','--resampleWidth','1920',str(raw),'--out',str(point)],check=True,capture_output=True)
 frame,png=Observation.capture(point.read_bytes(),session_id='offline-synthetic',display_id=4,window_id=1,window_bounds=logical,display_geometry=(4,0,0,1920,1080,3840,2160))
 (OUT/(label+'-observed.png')).write_bytes(png);images[label]=Image.open(io.BytesIO(png)).convert('RGB')
 # A diagnostic control, not a production replacement or coordinate contract.
 crop=OUT/(label+'-backing-crop.png');img.crop(physical).save(crop)
 crop_point=OUT/(label+'-crop-first.png');subprocess.run(['sips','--resampleWidth','627',str(crop),'--out',str(crop_point)],check=True,capture_output=True)
 rows.append({'id':label,'frame':asdict(frame),'crop_first_pixel_sha256':hashlib.sha256(Image.open(crop_point).convert('RGB').tobytes()).hexdigest()})
delta=ImageChops.difference(images['a'],images['b']);assert rows[0]['frame']['scene_sha256']!=rows[1]['frame']['scene_sha256'];assert rows[0]['crop_first_pixel_sha256']==rows[1]['crop_first_pixel_sha256']
result={'input_change_outside_window_only':True,'raw_window_equal':True,'downscale_then_crop_scene_equal':False,'observed_delta_bbox':delta.getbbox(),'observed_changed_pixels':sum(v!=(0,0,0)for v in delta.get_flattened_data()),'crop_first_control_equal':True,'rows':rows,'source_sha256':{str(Path(__file__)):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in {'rows','source_sha256'}}))
