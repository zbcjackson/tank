import base64
import hashlib
import json
import sqlite3
import subprocess
import tarfile
from pathlib import Path

from PIL import Image

root=Path('/Users/zbcjackson/src/tank');p=Path('/private/tmp/tank-product-workflow-fake-20261020')
f=json.loads((p/'freeze.json').read_text());r=json.loads((p/'result.json').read_text())
enc=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
digest=lambda x:hashlib.sha256(x).hexdigest()
unsigned=dict(f);unsigned.pop('sha256');assert digest(enc(unsigned).encode())==f['sha256']==r['sha256']
assert f['workflow']and len(f['cases'])==4 and len(f['schedule'])==len(r['rows'])==8
assert r['completed']and r['spend']['stop_reason']is None
assert r['spend']==json.loads((p/'spend.jsonl').read_text().splitlines()[-1])
assert [(x['id'],x['case'],x['arm'])for x in r['rows']]==[(x['id'],x['case'],x['arm'])for x in f['schedule']]
first={x['case']:x['arm']for x in reversed(f['schedule'])}
for recovery in(False,True):assert sorted(first[c['id']]for c in f['cases']if c['recovery']==recovery)==['jt','v']
cases={c['id']:c for c in f['cases']};call_ids=set();images=0;tokens=0;edit_observations=0
with tarfile.open(root/'docs/research/artifacts/jev-checkbox-route-retest-20261020.tar.gz')as prior:
    prior_result=json.load(prior.extractfile('live/result.json'))
    schema=prior_result['rows'][0]['database']['schema']
for row in r['rows']:
    c=cases[row['case']];d=p/row['id'];assert row==json.loads((d/'row.json').read_text())
    assert row['status']=='finished'and row['cleanup_confirmed']and row['app_unchanged']and not row['cleanup_errors']
    assert row['strict_completed']and row['workflow_completed']and row['recovery_completed']==c['recovery']
    assert row['capped_completion_ms']==row['elapsed_ms']and row['elapsed_ms']<120000
    expected=[dict(x)for x in c['seed']];target=c['order']+1;old=dict(next(x for x in expected if x['id']==target));new=next(x for x in expected if x['id']==target);new['title']=c['goal']['inputs'][0]['value']
    visible={'path':'/work_items/content/','columns':['id','title','notes'],'rows':[[str(x[k])for k in('id','title','notes')]for x in expected]}
    assert c['start_path']=='/work_items/content/'and c['oracle']['visible_list']==visible
    assert c['goal']['completion']==[{'key':'status:Records','value':enc(expected)},{'key':'status:List rows','value':enc(visible)}]
    assert c['goal']['outcomes']==[{'id':'correct-record-editor','conditions':[{'key':'status:Editor seen:'+str(target),'value':'true'}]}]
    db=sqlite3.connect((d/'fixture.db').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    records=[dict(x)for x in db.execute('SELECT * FROM work_items ORDER BY id')];writes=[dict(x)for x in db.execute('SELECT * FROM _writes ORDER BY rowid')];actual_schema=[list(x)for x in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')];db.close()
    assert records==expected==c['oracle']['rows']and actual_schema==schema
    assert writes==[{'operation':'update','id':target,'old_title':old['title'],'new_title':new['title'],'old_notes':old['notes'],'new_notes':new['notes']}]
    assert row['database']=={'records':records,'writes':writes,'schema':actual_schema}and row['list_readback']==visible
    http=[json.loads(line)for line in(d/'http.jsonl').read_text().splitlines()];assert row['http']==http
    posts=[i for i,x in enumerate(http)if x['method']=='POST'];assert len(posts)==1 and http[posts[0]]['path']==c['oracle']['edit_path']
    lists=[i for i,x in enumerate(http)if x['method']=='GET'and x['path']=='/work_items/content/'and x['status']=='200 OK'];edits=[i for i,x in enumerate(http)if x['method']=='GET'and x['path']==c['oracle']['edit_path']and x['status']=='200 OK']
    assert any(a<b<posts[0]for a in lists for b in edits)and any(a>posts[0]for a in lists)
    injected=[i for i,x in enumerate(http)if x['injected']]
    if c['recovery']:
        assert len(injected)==1 and http[injected[0]]['method']=='GET'and http[injected[0]]['path']==c['oracle']['edit_path']and http[injected[0]]['status']=='503 Service Unavailable'
        assert any(i>injected[0]and h['query']=='retry=1'for i,h in enumerate(http)if h['method']=='GET'and h['path']==c['oracle']['edit_path']and h['status']=='200 OK')
    else:assert not injected
    observed={};seen=set()
    for o in row['workflow_observations']:
        if o['editor_id']:seen.add(o['editor_id']);edit_observations+=1
        assert o['seen_editors']==sorted(seen);observed[o['observation_id']]=o
    assert any(o['editor_id']==str(target)and o['list']['path']==c['oracle']['edit_path']for o in observed.values())
    raw=[json.loads(line)for line in(d/'calls.jsonl').read_text().splitlines()];assert [q for q in raw if'request'in q]==row['calls']
    assert ['request'in q for q in raw]==[i%2==0 for i in range(len(raw))]
    events=[e for e in row['events']if e['kind']=='model_call'];assert len(events)==len(raw)
    proposed=[]
    for i in range(0,len(raw),2):
        q,reply=raw[i],raw[i+1];cid=q['call_id'];assert cid==reply['call_id']and cid not in call_ids;call_ids.add(cid)
        req=q['request'];a=reply['response'];peer='messages'in req;packet=json.loads(req['messages'][1]['content'][0]['text'])if peer else req
        assert all(k not in packet['state']for k in('oracle','seed','recovery','http'))
        facts={v['key']:v['value']for v in packet['state']['snapshot']['facts']};o=observed[packet['state']['binding']['observation_id']]
        assert facts['status:List rows']==enc(o['list'])
        assert sorted(k.removeprefix('status:Editor seen:')for k,v in facts.items()if k.startswith('status:Editor seen:')and v=='true')==o['seen_editors']
        if o['editor_id']:assert [e['value']for e in packet['state']['snapshot']['elements']if e['role']=='textbox'and e['label']=='id']==[o['editor_id']]
        choice=json.loads(a['choices'][0]['message']['content'])['choice']if peer else a['choice'];detail=packet['questions']['next_action']['criteria'][choice];assert isinstance(detail,dict);proposed.append((packet,detail))
        usage=(a['usage']['prompt_tokens'],a['usage']['completion_tokens'])if peer else(a['input_tokens'],a['output_tokens']);assert usage==(7,3)
        ledger=r['spend']['requests'][cid];assert ledger['status']=='known'and ledger['trial']==row['id']and(ledger['input_tokens'],ledger['output_tokens'])==usage;tokens+=sum(usage)
        e0,e1=events[i:i+2];assert e0['phase']=='started'and e1['phase']=='finished'and e0['call_id']==e1['call_id']==cid and e0['task_id']==e1['task_id']==row['task_id']
        if peer:
            data=base64.b64decode(req['messages'][1]['content'][1]['image_url']['url'].split(',',1)[1]);info=q['images'][0];assert data==(d/info['path']).read_bytes()and digest(data)==info['sha256'];images+=1
        else:assert not q['images']
    steps=row['result']['details']['progress']['recent_steps'];assert [s['label']for s in steps]==['Edit',*(['Retry']if c['recovery']else[]),'Allow updating this column. [name=chk_title]','title','Update']
    assert len(proposed)==len(steps)
    for (packet,detail),step in zip(proposed,steps,strict=True):assert detail['label']==step['label']and detail['operation']==step['operation']and step['dispatch_status']=='sent'and step['effect_status']=='verified'and packet['state']['binding']['observation_id']==step['observation_before']
    assert ('row',' '.join(str(c['seed'][target-1][k])for k in('id','title','notes')))in[tuple(x)for x in proposed[0][1]['ancestors']]
    images+=1
    with Image.open(d/'final.png')as image:assert image.format=='PNG';image.verify()
assert len(call_ids)==len(r['spend']['requests'])==36 and tokens==r['spend']['batch']['known_tokens']==360 and images==26
provenance=json.loads((p/'provenance.json').read_text());helper=p/'test-helper/test_dom.py';assert digest(helper.read_bytes())==provenance['helper_sha256']and 'fake only'in provenance['model_http']
old=json.loads(Path('/private/tmp/tank-product-workflow-old-artifacts.json').read_text());assert len(old)==14
for name,info in old.items():
    archive=root/'docs/research/artifacts'/name;manifest=archive.with_name(name.replace('.tar.gz','-manifest.json'));prior=subprocess.check_output(['git','show','e00698bc:'+str(manifest.relative_to(root))],cwd=root)
    assert prior==manifest.read_bytes()and digest(prior)==info['manifest_sha256']and digest(archive.read_bytes())==info['archive_sha256']
diag=json.loads(Path('/private/tmp/tank-product-workflow-candidate-diagnostic.json').read_text());assert diag['before_reason']=='visual_required'and diag['after_reason']=='jev_eligible'and all(not d['ancestors']for d in diag['before_edits'])
assert [x['ancestors']for x in diag['after_edits']]==[[['row','1 Draft 0 Keep 0/1']],[['row','2 Archive 0 Keep 0/2']]]
initial_row=next(row for row in r['rows']if row['id']=='workflow-update-0-normal-v');initial=initial_row['calls'][0]['images'][0]
png=(p/initial_row['id']/initial['path']).read_bytes();assert png==Path('/private/tmp/tank-product-workflow-probe2-20261020/list.png').read_bytes()
print(json.dumps({'planned':len(r['rows']),'fake_completed':8,'fake_GET_recovery':4,'cleanup':8,'fake_SDK_calls':len(call_ids),'fake_tokens':tokens,'task_PNG':images,'actual_editor_observations':edit_observations,'history_matches_observed_ids':True,'old_archives_unchanged':len(old),'initial_list_pixels_unchanged':True,'matrix_order_is_strict':True},indent=2))
