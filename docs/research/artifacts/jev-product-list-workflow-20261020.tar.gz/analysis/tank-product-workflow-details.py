"""Read-only proposal, dispatch and SDK timing details from the frozen live run."""
import json,statistics,sys
from pathlib import Path
p=Path(sys.argv[1]);out=Path(sys.argv[2]);result=json.loads((p/'result.json').read_text());rows=[]
for row in result['rows']:
 d=p/row['id'];raw=[json.loads(line)for line in(d/'calls.jsonl').read_text().splitlines()];replies={q['call_id']:q['response']for q in raw if'response'in q};finished={e['call_id']:e for e in row['events']if e['kind']=='model_call'and e.get('phase')=='finished'};proposals=[]
 for q in raw:
  if'request'not in q:continue
  req=q['request'];peer='messages'in req;packet=json.loads(req['messages'][1]['content'][0]['text'])if peer else req;a=replies[q['call_id']];choice=json.loads(a['choices'][0]['message']['content'])['choice']if peer else a['choice'];detail=packet['questions']['next_action']['criteria'][choice]
  proposals.append({'call_id':q['call_id'],'model':'peer'if peer else'jev','choice':choice,'label':detail.get('label')if isinstance(detail,dict)else None,'role':detail.get('role')if isinstance(detail,dict)else None,'ancestors':detail.get('ancestors')if isinstance(detail,dict)else None,'sdk_elapsed_ms':finished[q['call_id']]['elapsed_ms']})
 model_ms=sum(x['sdk_elapsed_ms']for x in proposals);assert len(finished)==len(proposals)and model_ms<=row['elapsed_ms']+1
 steps=row['result']['details']['progress']['recent_steps'];assert all(s['dispatch_status']=='sent'and s['effect_status']=='verified'for s in steps)
 rows.append({'id':row['id'],'case':row['case'],'arm':row['arm'],'elapsed_ms':row['elapsed_ms'],'model_elapsed_ms':model_ms,'other_elapsed_ms':row['elapsed_ms']-model_ms,'actual_inputs':len(steps),'proposals':proposals,'steps':steps,'actual_editor_observations':sum(bool(o['editor_id'])for o in row['workflow_observations'])})
summary={'rows':rows,'actual_inputs':sum(r['actual_inputs']for r in rows),'actual_editor_observations':sum(r['actual_editor_observations']for r in rows),'arms':[],'paired_jt_faster':sum(next(r['elapsed_ms']for r in rows if r['case']==c and r['arm']=='jt')<next(r['elapsed_ms']for r in rows if r['case']==c and r['arm']=='v')for c in {r['case']for r in rows})}
for arm in ('v','jt'):
 ds=[r for r in rows if r['arm']==arm];seconds=[r['elapsed_ms']/1000 for r in ds];summary['arms'].append({'arm':arm,'mean_s':statistics.mean(seconds),'median_s':statistics.median(seconds),'min_s':min(seconds),'max_s':max(seconds),'mean_model_call_s':statistics.mean(r['model_elapsed_ms']/1000 for r in ds),'mean_other_s':statistics.mean(r['other_elapsed_ms']/1000 for r in ds)})
out.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='rows'},ensure_ascii=False,indent=2))
