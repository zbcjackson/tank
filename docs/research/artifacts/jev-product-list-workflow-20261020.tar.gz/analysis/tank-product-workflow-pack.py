"""Package fixed fake/live workflow evidence without rewriting older artifacts."""
import hashlib,io,json,os,re,subprocess,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank');a=root/'docs/research/artifacts';h=lambda b:hashlib.sha256(b).hexdigest();old=json.loads(Path('/private/tmp/tank-product-workflow-old-artifacts.json').read_text());assert len(old)==14
for name,v in old.items():
 assert h((a/name).read_bytes())==v['archive_sha256'];assert h((a/name.replace('.tar.gz','-manifest.json')).read_bytes())==v['manifest_sha256']
files={};runs={'fake':Path('/private/tmp/tank-product-workflow-fake-20261020'),'live':Path('/private/tmp/tank-product-workflow-live-20261020-reviewed')}
for phase,p in runs.items():
 f=json.loads((p/'freeze.json').read_text())
 for name,sha in f['source_sha256'].items():assert h((p/'source'/name).read_bytes())==sha==h((root/'backend'/name).read_bytes())
 for file in p.rglob('*'):
  if file.is_file():files[phase+'/'+str(file.relative_to(p))]=file
f=json.loads((runs['live']/'freeze.json').read_text());env=Path(f['app']['python']).parent.parent
for name,sha in f['app']['files'].items():
 p=env/name;assert h(p.read_bytes())==sha;files['app/'+name]=p
for suffix in ('analyze.py','fake-summary.json','live-summary.json','details.py','details.json','candidate-diagnostic.json','old-artifacts.json','review1-check.py','pack.py'):
 p=Path('/private/tmp/tank-product-workflow-'+suffix);files['analysis/'+p.name]=p
probe=Path('/private/tmp/tank-product-workflow-probe2-20261020')
for p in probe.iterdir():
 if p.is_file():files['probe-before/'+p.name]=p
before=Path('/private/tmp/tank-product-workflow-before-dom.py');before.write_bytes(subprocess.check_output(['git','show','e00698bc:backend/plugins/agent-computer-use/src/agent_computer_use/channels/dom.py'],cwd=root));files['probe-before/dom-source-e00698bc.py']=before
for p in Path('/private/tmp').glob('tank-product-workflow-*.log'):
 if p.name!='tank-product-workflow-pack-result.log':files['verification/'+p.name]=p
values={**dotenv_values(root/'backend/core/.env'),**os.environ};secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)];assert secrets
for name,p in files.items():assert not any(secret in p.read_bytes()for secret in secrets),f'credential found: {name}'
archive=a/'jev-product-list-workflow-20261020.tar.gz';assert not archive.exists();m={'date':'2026-10-20','baseline_commit':'e00698bc','plan_commit':'5b7c13a7','implementation_commit':'9411bd9b','first_review_commit':'51fb5cf5','freeze_sha256':f['sha256'],'credential_values_scanned':len(secrets),'old_archives_unchanged':old,'files':{}}
with tarfile.open(archive,'w:gz')as t:
 for name,p in sorted(files.items()):
  b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b));m['files'][name]={'bytes':len(b),'sha256':h(b)}
m['archive_sha256']=h(archive.read_bytes())
with tarfile.open(archive)as t:
 assert set(t.getnames())==set(files)
 for member in t.getmembers():
  b=t.extractfile(member).read();assert len(b)==m['files'][member.name]['bytes']and h(b)==m['files'][member.name]['sha256']
archive.with_name('jev-product-list-workflow-20261020-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'members':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':m['archive_sha256'],'old_archives':len(old),'credential_values':len(secrets)}))
