"""Independent offline evidence audit; no driver import or model clients."""
import base64
from collections import Counter
from hashlib import sha256
from html.parser import HTMLParser
import json
from pathlib import Path
import sqlite3
import struct
import sys

ROOT=Path(__file__).resolve().parent
mode=sys.argv[1];output=ROOT/mode
f=json.loads((ROOT/'freeze.json').read_text())
batch=json.loads((output/'result.json').read_text())
assert batch['freeze_sha256']==sha256((ROOT/'freeze.json').read_bytes()).hexdigest()
assert len(f['cases'])==len(batch['rows'])==1

class Tables(HTMLParser):
    def __init__(self):super().__init__();self.tables=[];self.rows=None;self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='table':self.rows=[]
        elif tag=='tr' and self.rows is not None:self.row=[]
        elif tag in ('th','td') and self.row is not None:self.cell=[]
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag in ('th','td') and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        elif tag=='tr' and self.row is not None:self.rows.append(self.row);self.row=None
        elif tag=='table' and self.rows is not None:self.tables.append(self.rows);self.rows=None

reports=[]
for case,row in zip(f['cases'],batch['rows']):
    assert row['id']==case['id'] and row['attempted'] is True
    p=output/case['id']
    def read(name):return json.loads((p/name).read_text())
    before=read('database-before.json')
    with sqlite3.connect((p/'fixture.db').as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row
        records=[dict(r) for r in db.execute('SELECT * FROM work_items ORDER BY id')]
        writes=[dict(r) for r in db.execute('SELECT * FROM _writes ORDER BY rowid')]
        schema=[list(r) for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
    assert before['records']==f['seed'] and before['writes']==[]
    assert records==before['records'] and writes==[] and schema==before['schema'],'business mutation'
    assert read('database-after.json')==dict(records=records,writes=writes,schema=schema)
    initial=read('initial-public-dom.json');facts=[x for x in initial['facts'] if x['key'].startswith('status:DOM table:')]
    assert initial['ready'] is True and initial['complete'] is True and len(facts)==1
    public=json.loads(facts[0]['value']);columns=json.loads(facts[0]['key'].split('status:DOM table:',1)[1])
    assert columns==['id','title','notes']
    assert public['rows']==[[str(r[c]) for c in columns] for r in records]
    assert all(r[0]!=str(case['record']) and r[1]!=case['title'] for r in public['rows'])
    desired=[*public['rows'],[str(case['record']),case['title'],case['value']]]
    goal=read('goal.json');completion=goal['completion']
    assert len(completion)==1 and completion[0]['key']==facts[0]['key']
    assert json.loads(completion[0]['value'])=={**public,'rows':desired}
    assert completion[0]['value']!=facts[0]['value'],'initially satisfied completion'
    assert goal['goal_id']=='case-01' and goal['scope']=='runtime-check'
    assert str(case['record']) in goal['intent'] and case['title'] in goal['intent'] and case['old'] in goal['intent'] and case['value'] in goal['intent']
    assert goal['inputs']==[dict(key=case['field'],purpose='Requested new '+case['field'],field_label=case['field'],value=case['value'])]
    assert 'Do not create a record or substitute another record.' in goal['intent']
    final=read('final-table.json');assert final==facts[0]
    parser=Tables();parser.feed((p/'final-list.html').read_text())
    matching=[]
    for table in parser.tables:
        if not table:continue
        indexes=[i for i,c in enumerate(table[0]) if c in columns]
        if [table[0][i] for i in indexes]==columns:
            matching.append([[r[i] for i in indexes] for r in table[1:] if len(r)==len(table[0])])
    assert matching==[public['rows']]
    http=[json.loads(s) for s in (p/'http.jsonl').read_text().splitlines()]
    assert all(x['method']=='GET' for x in http),'non-GET product request'
    result=read('task-result.json');assert row['result']==result
    assert result['cleanup']=='confirmed' and result['details']['pending_effect'] is False
    cleanup=read('cleanup.json');assert cleanup['server_exit'] is not None and cleanup['runner_cleanup']=='confirmed'
    captures=read('captures.json');events=read('events.json');execution=read('audit.json')
    requests=[x for x in captures if 'request' in x];responses=[x for x in captures if 'response' in x]
    reqs={x['call_id']:x for x in requests};resps={x['call_id']:x['response'] for x in responses}
    starts=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='started']
    ends=[e['metadata'] for e in events if e['kind']=='model_call' and e['metadata']['phase']=='finished']
    spent=batch['spend']['requests']
    assert len(requests)==len(responses)==len(starts)==len(ends)==len(reqs)>0
    assert set(reqs)==set(resps)==set(spent)=={x['call_id'] for x in starts}=={x['call_id'] for x in ends}
    models={};tokens=0;choices=[];images=[];previous_jev=None
    for end in ends:
        call=end['call_id'];request=reqs[call];response=resps[call];charge=spent[call]
        a,b=end['prompt_tokens'],end['completion_tokens']
        assert type(a) is int and type(b) is int and a>=0 and b>=0
        assert end['status']=='returned' and charge['status']=='known' and charge['trial']==case['id']
        assert (a,b)==(charge['input_tokens'],charge['output_tokens'])
        if request['model']==f['jev']['model']:
            assert request['url']==f['jev']['url'] and request['purpose']=='computer_use.jev'
            assert set(request['request'])=={'model','state','questions'}
            packet=request['request'];previous_jev=packet
            assert (response['input_tokens'],response['output_tokens'])==(a,b)
            choice=response['choice']
        else:
            assert request['model']==f['vision']['model'] and request['url'].startswith(f['vision']['url'])
            assert request['purpose']=='computer_use.visual'
            params=request['request'];parts=params['messages'][1]['content']
            assert len(parts)==2 and parts[0]['type']=='text' and parts[1]['type']=='image_url'
            packet=json.loads(parts[0]['text'])
            assert previous_jev is not None and packet['state']==previous_jev['state'] and packet['questions']==previous_jev['questions']
            assert isinstance(packet['frame_id'],str) and packet['frame_id']
            image_url=parts[1]['image_url']['url'];prefix='data:image/png;base64,'
            assert image_url.startswith(prefix)
            png=base64.b64decode(image_url[len(prefix):],validate=True)
            assert png[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',png[16:24])==(1280,720)
            assert packet['image_candidates'] and all(len(box)==4 and box[0]>=0 and box[1]>=0 and box[2]>0 and box[3]>0 and box[0]+box[2]<=1280 and box[1]+box[3]<=720 for box in packet['image_candidates'].values())
            images.append(dict(call_id=call,frame_id=packet['frame_id'],sha256=sha256(png).hexdigest(),width=1280,height=720))
            assert (response['usage']['prompt_tokens'],response['usage']['completion_tokens'])==(a,b)
            choice=json.loads(response['choices'][0]['message']['content'])['choice']
        assert packet['state']['goal']['goal_id']==case['id']
        assert packet['state']['binding']['observation_id']==packet['state']['snapshot']['observation_id']
        assert packet['state']['evidence_contract']['sources']['goal.completion']=='desired_outcomes'
        assert all(not x['key'].startswith(('status:Records','status:List rows','status:Editor seen')) for x in packet['state']['snapshot']['facts'])
        models[request['model']]=models.get(request['model'],0)+1;tokens+=a+b
        choices.append(dict(model=request['model'],choice=choice))
    assert models.get(f['jev']['model'],0)>=1,'no Jev SDK selection'
    for call in {x['call_id'] for x in execution}:
        seq=[x for x in execution if x['call_id']==call]
        assert [x['phase'] for x in seq]==['prepared','dispatch','finished'] and seq[-1]['status']=='returned'
    assert batch['spend']['stop_reason'] is None and batch['spend']['batch']['reserved_tokens']==0
    assert batch['spend']['batch']['known_tokens']==tokens
    assert len(spent)==batch['spend']['batch']['admitted_requests']<=8
    assert not row['blocked_network'] and row['error_type'] is None
    dispatches=[e for e in events if e['kind']=='computer_use_dispatch']
    receipts=result['details']['receipts']
    # A correct control exit is distinct from exhaustion, observation refusal or zero-call completion.
    correct_exit=(not dispatches and not receipts and result['status'] in {'stopped','needs_input'}
        and result['reason'] in {'none','escalate','needs_user_input'}
        and choices[-1]['choice'] in {'none','escalate'})
    if mode=='fake':assert correct_exit and choices==[{'model':f['jev']['model'],'choice':'none'},{'model':f['vision']['model'],'choice':'none'}]
    report=dict(id=case['id'],evidence_complete=True,correct_exit=correct_exit,task_status=result['status'],reason=result['reason'],
                sdk_calls=len(reqs),models=models,tokens=tokens,choices=choices,images=images,post_count=0,writes=0,
                dispatched_actions=len(dispatches),cleanup_confirmed=True)
    (p/'independent-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');reports.append(report)
print(json.dumps(reports,ensure_ascii=False))
if len(sys.argv)==2:
    assert batch['completed'] is True and len(reports)==1
    (output/'independent-audit.json').write_text(json.dumps(dict(all_passed=all(r['evidence_complete'] and r['correct_exit'] for r in reports),reports=reports),ensure_ascii=False,indent=2)+'\n')
