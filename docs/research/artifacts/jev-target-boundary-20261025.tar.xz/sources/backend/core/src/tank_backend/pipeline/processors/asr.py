"""ASRProcessor — wraps streaming ASR as a pipeline Processor."""

from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import time
import uuid
from typing import TYPE_CHECKING, Any

import numpy as np

from ..bus import Bus, BusMessage
from ..event import PipelineEvent
from ..processor import FlowReturn, Processor
from ..text.transcript_stabilizer import PartialTranscriptStabilizer

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from tank_contracts import ASRStream


logger = logging.getLogger(__name__)

_STOP_TIMEOUT_S = 5.0


class ASRProcessor(Processor):
    """Wraps a per-utterance ``ASRStream`` as a pipeline Processor.

    Input:
      - VADResult(START_SPEECH) — start ASR session
      - AudioFrame — process audio, get partial transcripts
      - VADResult(END_SPEECH) — stop ASR session, get final transcript

    Output:
      - BrainInputEvent (on END_SPEECH with non-empty text)

    Bus messages posted:
      - speech_start — when speech starts (triggers assistant interrupt)
      - ui_message — stabilized partial and final transcripts for UI
      - asr_result — transcription metrics
      - recognition_failed — when ASR stop times out or fails unrecoverably

    For non-streaming streams (supports_streaming=False):
      - AudioFrame → ignored
      - VADResult END_SPEECH → batch transcribe full utterance PCM
    """

    def __init__(
        self,
        asr_stream: ASRStream,
        bus: Bus | None = None,
        user: str = "User",
        preferred_language: str = "zh",
        languages: tuple[str, ...] = ("zh", "en"),
        pipeline_sample_rate: int = 16000,
        asr_sample_rate: int = 16000,
    ) -> None:
        super().__init__(name="asr")
        self._asr = asr_stream
        self._bus = bus
        self._user = user
        self._preferred_language = preferred_language
        self._languages = languages
        # When the ASR engine needs a different rate than the pipeline wire
        # rate, resample each frame before feeding the recognizer.
        self._pipeline_sample_rate = pipeline_sample_rate
        self._asr_sample_rate = asr_sample_rate
        self._needs_resample = pipeline_sample_rate != asr_sample_rate

        # Streaming state
        self._partial_text: str = ""
        self._streaming_msg_id: str | None = None
        self._streaming_started_at: float | None = None
        self._speech_detected_sent: bool = False
        self._streaming_turn_id: str | None = None
        self._streaming_turn_revision: int = 0
        # Speculative turn chains: turn_id → last msg_id / final transcript,
        # so a reopened utterance can reuse the msg_id (UI updates in place)
        # and prepend the committed text to its partials. Bounded — reopens
        # only ever consult the most recent turn.
        self._turn_msg_ids: dict[str, str] = {}
        self._turn_final_texts: dict[str, str] = {}
        # Stabilizes raw hypotheses into an append-only display prefix so the
        # UI text does not flicker on every tail revision.
        self._stabilizer = PartialTranscriptStabilizer()

    def _reset_state(self) -> None:
        """Reset state for a new utterance."""
        self._partial_text = ""
        self._streaming_msg_id = None
        self._streaming_started_at = None
        self._speech_detected_sent = False
        self._streaming_turn_id = None
        self._streaming_turn_revision = 0
        self._stabilizer.reset()

    def _remember_turn(self, turn_id: str, msg_id: str, final_text: str) -> None:
        """Record a turn chain's identity for a possible future reopen."""
        self._turn_msg_ids[turn_id] = msg_id
        self._turn_final_texts[turn_id] = final_text
        if len(self._turn_msg_ids) > 4:
            for stale in list(self._turn_msg_ids)[:-2]:
                self._turn_msg_ids.pop(stale, None)
            for stale in list(self._turn_final_texts)[:-2]:
                self._turn_final_texts.pop(stale, None)

    def _to_asr_rate(self, pcm: np.ndarray) -> np.ndarray:
        """Resample float32 PCM from the pipeline rate to the ASR rate.

        No-op when the two rates match (the common case). Uses linear
        interpolation, matching the router's inbound resampler.
        """
        if not self._needs_resample or len(pcm) == 0:
            return pcm
        n_out = round(len(pcm) * self._asr_sample_rate / self._pipeline_sample_rate)
        if n_out <= 0:
            return pcm[:0]
        src_idx = np.linspace(0, len(pcm) - 1, n_out)
        return np.interp(src_idx, np.arange(len(pcm)), pcm).astype(np.float32)

    def _post_speech_start(self, timestamp_s: float | None = None) -> None:
        """Post speech_start to bus (triggers interrupt in assistant)."""
        if self._bus:
            self._bus.post(BusMessage(
                type="speech_start",
                source=self.name,
                payload={"timestamp_s": timestamp_s},
            ))

    def _post_partial(self, text: str) -> None:
        """Post a stabilized partial transcript to the UI.

        The raw hypothesis is run through the stabilizer first, so the UI
        sees an append-only confirmed prefix (newest edge word held back)
        instead of the flickering raw hypothesis. ``speech_detected`` still
        fires on the first raw hypothesis — it cues "user is speaking",
        which must not wait for stabilization.
        """
        if self._bus and self._streaming_msg_id:
            display = self._stabilizer.feed(text)
            if self._streaming_turn_id:
                # Reopened turn: the live partial only covers the resumed
                # tail — prepend the committed prefix so the UI shows the
                # growing merged utterance.
                display = (
                    self._turn_final_texts.get(self._streaming_turn_id, "")
                    + (display or "")
                )
            # First non-empty partial → tell frontend real speech was detected
            if not self._speech_detected_sent:
                self._speech_detected_sent = True
                from ...core.events import SignalMessage
                self._bus.post(BusMessage(
                    type="ui_message",
                    source=self.name,
                    payload=SignalMessage(signal_type="speech_detected"),
                ))
                self._bus.post(BusMessage(
                    type="speech_detected",
                    source=self.name,
                    payload={"text": text},
                ))
            if display:
                self._bus.post(BusMessage(
                    type="ui_message",
                    source=self.name,
                    payload=self._make_display_message(display, is_final=False),
                ))

    def _post_final(self, text: str) -> None:
        """Post final transcript to UI."""
        if self._bus and self._streaming_msg_id:
            # Batch mode: speech_detected may not have been sent via _post_partial
            if not self._speech_detected_sent:
                self._speech_detected_sent = True
                from ...core.events import SignalMessage
                self._bus.post(BusMessage(
                    type="ui_message",
                    source=self.name,
                    payload=SignalMessage(signal_type="speech_detected"),
                ))
                self._bus.post(BusMessage(
                    type="speech_detected",
                    source=self.name,
                    payload={"text": text},
                ))
            self._bus.post(BusMessage(
                type="ui_message",
                source=self.name,
                payload=self._make_display_message(text, is_final=True),
            ))

    def _make_display_message(self, text: str, is_final: bool) -> Any:
        """Create a DisplayMessage for UI."""
        from ...core.events import DisplayMessage
        return DisplayMessage(
            speaker=self._user,
            text=text,
            is_user=True,
            is_final=is_final,
            msg_id=self._streaming_msg_id,
        )

    def _post_metrics(
        self,
        text: str,
        elapsed: float,
        started_at_s: float | None,
        ended_at_s: float | None,
    ) -> None:
        """Post ASR metrics to bus."""
        if self._bus:
            self._bus.post(BusMessage(
                type="asr_result",
                source=self.name,
                payload={
                    "text": text,
                    "is_final": True,
                    "latency_s": elapsed,
                    "audio_duration_s": (
                        (ended_at_s - started_at_s)
                        if started_at_s and ended_at_s
                        else None
                    ),
                },
            ))

    def _post_recognition_failed(self) -> None:
        """Notify the frontend that ASR failed and the user should retry."""
        if not self._bus:
            return
        from ...core.events import SignalMessage
        self._bus.post(BusMessage(
            type="ui_message",
            source=self.name,
            payload=SignalMessage(signal_type="recognition_failed"),
        ))

    async def _stop_with_timeout(self) -> str:
        """Call ``self._asr.stop()`` with a timeout.

        The DashScope SDK can hang on stop() if its internal worker
        already self-killed. Returning empty string and posting
        ``recognition_failed`` lets the pipeline keep moving.
        """
        try:
            return await asyncio.wait_for(
                asyncio.to_thread(self._asr.stop),
                timeout=_STOP_TIMEOUT_S,
            )
        except asyncio.TimeoutError:
            logger.error(
                "ASR stop() timed out after %.1fs — dropping utterance",
                _STOP_TIMEOUT_S,
            )
            self._post_recognition_failed()
            return ""
        except Exception:
            logger.exception("ASR stop() raised — dropping utterance")
            self._post_recognition_failed()
            return ""

    async def _discard_session(self) -> None:
        """Stop the open ASR session quietly (reopened-utterance discard).

        Unlike :meth:`_stop_with_timeout`, failure here does not post
        ``recognition_failed`` — the full re-transcription that follows
        decides whether the utterance succeeded.
        """
        try:
            await asyncio.wait_for(
                asyncio.to_thread(self._asr.stop),
                timeout=_STOP_TIMEOUT_S,
            )
        except Exception:
            logger.warning("ASR stop() during reopen discard failed")

    async def _finalize_reopened(self, item: Any) -> tuple[str, float]:
        """Re-transcribe a reopened utterance over its full concatenated audio.

        The open streaming session only saw the resumed tail — the committed
        prefix lives in ``item.utterance_pcm``. Batch the whole merged
        utterance through a fresh session so the final transcript is
        coherent (works identically for streaming and batch engines).
        """
        if self._asr.supports_streaming:
            await self._discard_session()
        started_at = time.time()
        self._asr.start()
        self._asr.process_pcm(self._to_asr_rate(item.utterance_pcm))
        final_text = await self._stop_with_timeout()
        elapsed = time.time() - started_at
        return final_text, elapsed

    async def process(self, item: Any) -> AsyncIterator[tuple[FlowReturn, Any]]:
        from ...audio.input.types import AudioFrame
        from ...audio.input.vad import VADResult, VADStatus
        from ...core.events import BrainInputEvent, InputType

        # ── START_SPEECH: begin ASR session ──────────────────────────────
        if isinstance(item, VADResult) and item.status == VADStatus.START_SPEECH:
            self._asr.start()
            self._streaming_turn_id = item.turn_id
            self._streaming_turn_revision = item.turn_revision
            if item.turn_revision > 0 and item.turn_id:
                # Reopened turn — reuse the original msg_id so the UI
                # updates the existing user message in place. Fall back to
                # a fresh id when the chain is unknown (e.g. after restart).
                self._streaming_msg_id = self._turn_msg_ids.get(
                    item.turn_id, f"user_{uuid.uuid4().hex[:8]}",
                )
            else:
                self._streaming_msg_id = f"user_{uuid.uuid4().hex[:8]}"
            self._streaming_started_at = time.time()
            self._post_speech_start(item.started_at_s)
            yield FlowReturn.OK, None
            return

        # ── AudioFrame: streaming recognition ────────────────────────────
        if isinstance(item, AudioFrame):
            if not self._asr.supports_streaming:
                yield FlowReturn.OK, None
                return

            text = self._asr.process_pcm(self._to_asr_rate(item.pcm))

            if text and text != self._partial_text:
                self._partial_text = text
                self._post_partial(text)

            yield FlowReturn.OK, None
            return

        # ── END_SPEECH: finalize utterance ───────────────────────────────
        if isinstance(item, VADResult) and item.status == VADStatus.END_SPEECH:
            if item.utterance_pcm is None or len(item.utterance_pcm) == 0:
                self._reset_state()
                yield FlowReturn.OK, None
                return

            # Get final transcript
            if item.turn_revision > 0:
                final_text, elapsed = await self._finalize_reopened(item)
            elif self._asr.supports_streaming:
                final_text = await self._stop_with_timeout()
                if not final_text:
                    final_text = self._partial_text
                elapsed = (
                    time.time() - self._streaming_started_at
                    if self._streaming_started_at
                    else 0.0
                )
            else:
                # Batch mode: transcribe full utterance
                started_at = time.time()
                self._asr.start()
                self._asr.process_pcm(self._to_asr_rate(item.utterance_pcm))
                final_text = await self._stop_with_timeout()
                elapsed = time.time() - started_at
                # For batch mode, create msg_id and post speech_start now
                self._streaming_msg_id = f"user_{uuid.uuid4().hex[:8]}"
                if final_text:
                    self._post_speech_start()

            # Post metrics
            self._post_metrics(final_text, elapsed, item.started_at_s, item.ended_at_s)

            if final_text:
                self._post_final(final_text)

                msg_id = self._streaming_msg_id or f"user_{uuid.uuid4().hex[:8]}"
                if item.turn_id:
                    self._remember_turn(item.turn_id, msg_id, final_text)
                utterance_id = (
                    f"{item.started_at_s:.3f}_{item.ended_at_s:.3f}"
                    if item.started_at_s is not None and item.ended_at_s is not None
                    else msg_id
                )

                # Use engine-reported language if available, else detect from text
                from ...core.language import detect_language
                lang = self._asr.detected_language or detect_language(
                    final_text,
                    candidates=self._languages,
                    preferred=self._preferred_language,
                ).language

                event = BrainInputEvent(
                    type=InputType.AUDIO,
                    text=final_text,
                    user=self._user,
                    language=lang,
                    confidence=None,
                    metadata={"msg_id": msg_id, "utterance_id": utterance_id},
                    turn_id=item.turn_id,
                    turn_revision=item.turn_revision,
                )
                self._reset_state()
                yield FlowReturn.OK, event
            else:
                self._reset_state()
                yield FlowReturn.OK, None
            return

        # Unsupported input type
        yield FlowReturn.OK, None

    def handle_event(self, event: PipelineEvent) -> bool:
        if event.type == "flush":
            # Timeout-protected stop — don't let a hung SDK block interrupt flow
            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(self._asr.stop)
                    future.result(timeout=_STOP_TIMEOUT_S)
            except (concurrent.futures.TimeoutError, Exception):
                logger.warning("ASR stop() during flush timed out or failed")
            self._reset_state()
            return False  # propagate
        return False
