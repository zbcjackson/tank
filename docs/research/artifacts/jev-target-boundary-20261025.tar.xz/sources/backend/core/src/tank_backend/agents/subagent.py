"""Supplier-independent contract for task-oriented plugin agents."""

from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

from pydantic import JsonValue

from ..core.token_usage import TokenUsageLedger
from ..llm.model_data import ModelDataScope
from .base import AgentOutput

if TYPE_CHECKING:
    from ..llm.model_call import ModelCallPolicy, ModelCapture
    from ..policy.verdict import ApprovalResolver
    from .approval import ToolApprovalPolicy
    from .task_result import TaskResult
    from .task_runtime import ExecutionRecord, TaskRuntime


def validate_task_input(value: object) -> dict[str, JsonValue] | None:
    """Detach a bounded JSON object; domain validation belongs to the plugin."""
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError("task_input must be a JSON object")

    def copy_value(item: object, depth: int) -> JsonValue:
        if depth > 16:
            raise ValueError("task_input exceeds 16 levels of nesting")
        if item is None or isinstance(item, (str, bool, int)):
            return item
        if isinstance(item, float) and math.isfinite(item):
            return item
        if isinstance(item, list):
            return [copy_value(child, depth + 1) for child in item]
        if isinstance(item, dict) and all(isinstance(key, str) for key in item):
            return {key: copy_value(child, depth + 1) for key, child in item.items()}
        raise ValueError("task_input must contain only JSON values and string keys")

    result = copy_value(value, 0)
    assert isinstance(result, dict)
    encoded = json.dumps(result, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    try:
        size = len(encoded.encode("utf-8"))
    except UnicodeError as exc:
        raise ValueError("task_input must contain valid UTF-8 text") from exc
    if size > 64 * 1024:
        raise ValueError("task_input exceeds 65536 UTF-8 bytes")
    return result


class SubAgentStopped(RuntimeError):
    """A controlled, incomplete termination."""

    def __init__(
        self, reason: str, detail: str = "", metadata: dict[str, Any] | None = None,
        *, task_result: TaskResult | None = None,
    ) -> None:
        self.task_result = task_result
        self.reason = reason
        self.metadata = metadata or {}
        super().__init__(f"{reason}: {detail}" if detail else reason)


class SubAgentCleanupError(RuntimeError):
    """Cleanup could not be confirmed; a desktop must be quarantined."""

    def __init__(self, detail: str, task_result: TaskResult | None = None) -> None:
        self.task_result = task_result.with_cleanup("unknown") if task_result is not None else None
        super().__init__(detail)


class SubAgentCancelled(asyncio.CancelledError):
    """Cancellation after cleanup, retaining any already-received task evidence."""

    def __init__(self, task_result: TaskResult | None = None) -> None:
        self.task_result = task_result
        super().__init__("subagent cancellation requested")


@dataclass(frozen=True)
class SubAgentRequest:
    task: str
    context: str
    task_id: str
    task_input: dict[str, JsonValue] | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "task_input", validate_task_input(self.task_input))


@dataclass
class SubAgentAuthorization:
    """Task-level grant, issued by Tank, revocable at action boundaries."""

    permissions: frozenset[str] = frozenset()
    active: bool = True

    def revoke(self) -> None:
        self.active = False

    def check(self, permission: str | None = None) -> None:
        if not self.active or (permission and permission not in self.permissions):
            raise SubAgentStopped("error", f"authorization required: {permission or 'revoked'}")


@dataclass
class SubAgentBudget(TokenUsageLedger):
    """Usage accounting with an opt-in legacy task limit; zero means record only."""

    limit: int = 0

    def check(self) -> None:
        if self.limit > 0 and self.unknown_calls:
            raise SubAgentStopped("budget", "usage unknown")
        if self.limit > 0 and self.total_tokens >= self.limit:
            raise SubAgentStopped(
                "budget", f"token budget ({self.total_tokens}/{self.limit} tokens)",
            )


class SubAgentObserver(Protocol):
    def on_event(self, kind: str, metadata: dict[str, Any]) -> None: ...


@dataclass(frozen=True)
class SubAgentContext:
    authorization: SubAgentAuthorization
    budget: SubAgentBudget
    cancel: asyncio.Event
    deadline: float | None = None
    observer: SubAgentObserver | None = None
    max_steps: int | None = None
    audit: Callable[[ExecutionRecord], Awaitable[None]] | None = None
    model_policy: ModelCallPolicy | None = None
    model_capture: ModelCapture | None = None
    execution_policy: ToolApprovalPolicy | None = None
    approval_resolver: ApprovalResolver | None = None
    max_actions: int | None = None
    max_observations: int | None = None
    max_output_bytes: int = 4 * 1024 * 1024
    max_output_events: int = 4096
    user_input: Callable[[str], Awaitable[str]] | None = None
    model_data_scope: ModelDataScope = field(default_factory=ModelDataScope)
    runtime: TaskRuntime = field(init=False, compare=False, repr=False)

    def __post_init__(self) -> None:
        from .task_runtime import TaskRuntime

        if not isinstance(self.model_data_scope, ModelDataScope):
            raise ValueError("invalid model data scope")
        for value in (self.max_actions, self.max_observations,
                      self.max_output_bytes, self.max_output_events):
            if value is not None and (type(value) is not int or value < 0):
                raise ValueError("task limits must be nonnegative integers")

        object.__setattr__(self, "runtime", TaskRuntime(self, audit=self.audit))

    async def ask_user(self, question: str) -> str:
        """Wait in the original task, retaining its runtime and cumulative limits."""
        from ..tools.computer_native import join_on_cancel

        self.check()
        if self.user_input is None:
            raise SubAgentStopped("user_input_unavailable")
        pending = asyncio.ensure_future(self.user_input(question))
        try:
            while not pending.done():
                await asyncio.wait((pending,), timeout=0.1)
                self.check()
            self.check()
            return await pending
        finally:
            pending.cancel()
            await join_on_cancel(asyncio.gather(pending, return_exceptions=True))

    def check(self, permission: str | None = None) -> None:
        self.runtime.check_open()
        self.authorization.check(permission)
        if self.cancel.is_set():
            raise asyncio.CancelledError("subagent cancellation requested")
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise TimeoutError("subagent deadline exceeded")
        self.budget.check()
        if self.model_policy is not None:
            self.model_policy.check()

    def observe(self, kind: str, **metadata: Any) -> None:
        if self.observer is not None:
            try:
                self.observer.on_event(kind, metadata)
            except Exception:
                logging.getLogger(__name__).warning("Subagent observer failed for %s", kind)


class SubAgent(ABC):
    def __init__(self, *, cleanup_timeout: float = 5.0) -> None:
        from .task_resources import TaskResources

        self._resources = TaskResources(timeout=cleanup_timeout)
        self.closed = False

    def check_open(self) -> None:
        if self.closed:
            raise RuntimeError("A closed subagent cannot run or acquire resources")

    def own_resource(self, name: str, release: Callable[[], Awaitable[None]]) -> None:
        """Register owned resource release (detach only for borrowed resources)."""
        self.check_open()
        self._resources.own(name, release)

    @abstractmethod
    def run(self, request: SubAgentRequest, context: SubAgentContext) -> AsyncIterator[AgentOutput]:
        """Stream task outputs; call check_open at entry. The caller owns final aclose."""
        raise NotImplementedError

    async def aclose(self) -> None:
        """Release plugin-owned resources even if run never started.

        The host owns and closes the task runtime before invoking this hook.
        Subclasses register releases with own_resource instead of overriding this
        method. Never register the borrowed context/runtime or shared host clients.
        Repeated callers share the same cleanup outcome, including failures.
        """
        self.closed = True
        await self._resources.aclose()
