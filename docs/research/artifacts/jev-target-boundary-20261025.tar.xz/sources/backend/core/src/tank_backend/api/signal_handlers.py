"""WebSocket signal handlers — command pattern for incoming signals.

Each handler is registered via ``@register("signal_name")`` and dispatched
by :func:`dispatch` from the WebSocket router.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from tank_protocol import KNOWN_PROTOCOL_FEATURES, WebsocketMessage, capabilities_ack
from tank_protocol import signal as signal_frame

from ..audio.opus_codec import create_session_codecs, supported_protocol_features

if TYPE_CHECKING:
    from ..core.assistant import Assistant

logger = logging.getLogger(__name__)

# Handler signature: (assistant, msg, session_id, send_fn) → None
SendFn = Callable[[WebsocketMessage], Awaitable[None]]
SignalHandler = Callable[["Assistant", WebsocketMessage, str, SendFn], Awaitable[None]]

_handlers: dict[str, SignalHandler] = {}


class DisconnectSignal(Exception):
    """Raised by the disconnect handler to break the receive loop."""


def register(signal_name: str) -> Callable[[SignalHandler], SignalHandler]:
    """Decorator to register a signal handler."""

    def decorator(fn: SignalHandler) -> SignalHandler:
        _handlers[signal_name] = fn
        return fn

    return decorator


async def dispatch(
    signal: str,
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> bool:
    """Dispatch a signal to its handler. Returns True if handled."""
    handler = _handlers.get(signal)
    if handler is None:
        return False
    await handler(assistant, msg, session_id, send_fn)
    return True


# ---------------------------------------------------------------------------
# Signal handlers
# ---------------------------------------------------------------------------


@register("disconnect")
async def handle_disconnect(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    raise DisconnectSignal()


@register("wake")
async def handle_wake(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    try:
        assistant.compact_session()
        await send_fn(signal_frame("conversation_ready", session_id=session_id))
    except Exception as e:
        logger.error("Session compact failed: %s", e, exc_info=True)
        await send_fn(
            signal_frame(
                "session_reset_failed",
                session_id=session_id,
                metadata={"error": str(e)},
            )
        )


@register("idle")
async def handle_idle(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    logger.info("Client idle: %s", session_id)


@register("interrupt")
async def handle_interrupt(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    logger.info("Client interrupt: %s", session_id)
    assistant.interrupt()


@register("end_of_utterance")
async def handle_end_of_utterance(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    """Client signals push-to-talk send — force-finalize the current utterance.

    Bypasses VAD silence detection so streaming ASR sessions don't wait
    for trailing silence (and time out). The frontend pauses the mic
    after sending this signal.
    """
    logger.info("Client end_of_utterance: %s", session_id)
    assistant.end_utterance()


@register("audio_format")
async def handle_audio_format(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    """Client declares its actual capture sample rate + channel count.

    Browsers often ignore the requested 16 kHz AudioContext rate and capture
    at the hardware rate (e.g. 32/48 kHz). Without this, the backend would
    treat that audio as 16 kHz, pitching it down and wrecking recognition.
    The router resamples inbound PCM to 16 kHz mono using these values.
    """
    meta = msg.metadata or {}
    try:
        rate = int(meta.get("sample_rate", 16000))
        channels = int(meta.get("channels", 1))
    except (TypeError, ValueError):
        logger.warning("Invalid audio_format metadata: %r", meta)
        return
    logger.info(
        "Client audio_format: %s (sample_rate=%d, channels=%d)",
        session_id, rate, channels,
    )
    assistant.set_capture_format(sample_rate=rate, channels=channels)


@register("capabilities")
async def handle_capabilities(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    """Client declares the protocol features it wants to enable (P1-1/P1-2).

    Negotiable today: ``opus`` — binary audio switches to one Opus packet
    per WebSocket message, both directions (``audio/opus_codec.py``). The
    server acks every declaration with the features it actually enabled;
    unknown names are warn-and-ignored and unadvertised ones are declined,
    per the evolution rules. Non-opus connections keep raw PCM unchanged.
    """
    from . import deps

    requested_raw = (msg.metadata or {}).get("enable", [])
    requested = (
        [f for f in requested_raw if isinstance(f, str)]
        if isinstance(requested_raw, list)
        else []
    )
    supported = supported_protocol_features()
    enabled = [
        f for f in requested
        if f in KNOWN_PROTOCOL_FEATURES and f in supported
    ]
    for feature in requested:
        if feature not in KNOWN_PROTOCOL_FEATURES:
            logger.warning("Unknown protocol feature %r from %s — ignored",
                           feature, session_id)
        elif feature not in supported:
            logger.info("Protocol feature %r not available — not enabled for %s",
                        feature, session_id)

    if "opus" in enabled:
        deps.connection_manager().register_codec(session_id, create_session_codecs())
        logger.info(
            "Opus negotiated for %s (16 kHz up / 24 kHz down, 20 ms, 32 kbps)",
            session_id,
        )

    await send_fn(capabilities_ack(enabled, session_id=session_id))


@register("ping")
async def handle_ping(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    await send_fn(
        signal_frame(
            "pong",
            session_id=session_id,
            metadata=msg.metadata.copy() if msg.metadata else {},
        )
    )


@register("resume_conversation")
async def handle_resume_conversation(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    cid = (msg.metadata or {}).get("conversation_id", "")
    if not cid:
        await send_fn(
            signal_frame(
                "conversation_resume_failed",
                session_id=session_id,
                metadata={"error": "missing conversation_id"},
            )
        )
        return
    success = assistant.resume_conversation(cid)
    status = "conversation_resumed" if success else "conversation_resume_failed"

    # Track channel context for audio fan-out
    from . import deps
    channel_slug: str | None = None
    if success:
        ch_store = deps.app_context().channel_store
        if ch_store is not None:
            channel = ch_store.get_by_conversation_id(cid)
            if channel is not None:
                channel_slug = channel.slug
    deps.connection_manager().set_session_channel(session_id, channel_slug)

    await send_fn(
        signal_frame(
            status,
            session_id=session_id,
            metadata={"conversation_id": cid},
        )
    )


@register("new_conversation")
async def handle_new_conversation(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    new_cid = assistant.new_conversation()
    from . import deps
    deps.connection_manager().set_session_channel(session_id, None)
    await send_fn(
        signal_frame(
            "conversation_created",
            session_id=session_id,
            metadata={"conversation_id": new_cid},
        )
    )


@register("subscribe_channels")
async def handle_subscribe_channels(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    slugs = (msg.metadata or {}).get("channels", [])
    if not slugs or not isinstance(slugs, list):
        return
    from . import deps
    deps.subscription_manager().subscribe(session_id, slugs)
    await send_fn(
        signal_frame(
            "channels_subscribed",
            session_id=session_id,
            metadata={"channels": slugs},
        )
    )


@register("unsubscribe_channels")
async def handle_unsubscribe_channels(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    slugs = (msg.metadata or {}).get("channels", [])
    if not slugs or not isinstance(slugs, list):
        return
    from . import deps
    deps.subscription_manager().unsubscribe(session_id, slugs)
    await send_fn(
        signal_frame(
            "channels_unsubscribed",
            session_id=session_id,
            metadata={"channels": slugs},
        )
    )


@register("stop_channel_audio")
async def handle_stop_channel_audio(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_fn: SendFn,
) -> None:
    """Interrupt in-progress channel audio.

    If `channel_slug` is provided in metadata, only that channel is stopped.
    Otherwise all channels this session is subscribed to are stopped.
    """
    from . import deps
    service = deps.channel_audio_service()
    if service is None:
        return
    meta = msg.metadata or {}
    slug = meta.get("channel_slug")
    if isinstance(slug, str) and slug:
        service.interrupt(slug)
    else:
        # Stop every channel this session is currently subscribed to
        for s in deps.subscription_manager().get_subscriptions(session_id):
            service.interrupt(s)
