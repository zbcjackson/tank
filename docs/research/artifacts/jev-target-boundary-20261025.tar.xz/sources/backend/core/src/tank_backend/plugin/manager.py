"""Plugin lifecycle manager — discovery, loading, registration, validation."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

from .manifest import (
    MANIFEST_FILENAME,
    PluginManifest,
    read_manifest_from_yaml,
    read_plugin_manifest,
)
from .registry import ExtensionRegistry

if TYPE_CHECKING:
    from ..config.app_config import AppConfig

logger = logging.getLogger(__name__)

# Maps config.yaml feature names to extension types declared in manifests.
FEATURE_TYPE_MAP: dict[str, str] = {
    "asr": "asr",
    "tts": "tts",
    "speaker": "speaker_id",
}

# Known extension type used by connector plugins. Connectors are
# multi-instance (config.yaml declares a list of instances, each pointing
# at one extension), so they don't fit the ``FEATURE_TYPE_MAP`` shape and
# get their own validator below.
CONNECTOR_EXT_TYPE = "connector"

# Backward-compatible alias
SLOT_TYPE_MAP = FEATURE_TYPE_MAP


class ConfigError(Exception):
    """Raised when config.yaml has invalid extension references."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__(
            "Config validation failed:\n" + "\n".join(f"  - {e}" for e in errors)
        )


@dataclass
class ExtensionEntry:
    """Per-extension enable/disable in plugins.yaml."""

    name: str
    enabled: bool = True


@dataclass
class PluginEntry:
    """Per-plugin entry in plugins.yaml."""

    name: str
    enabled: bool = True
    extensions: dict[str, ExtensionEntry] = field(default_factory=dict)


def validate_feature_refs(app_config: AppConfig, registry: ExtensionRegistry) -> None:
    """Validate config.yaml extension refs against a registry.

    Checks:
      1. Referenced extension exists in registry.
      2. Extension type matches the feature's expected type.

    Raises:
        ConfigError: Listing all violations found.
    """
    errors: list[str] = []
    for feature_name, expected_type in FEATURE_TYPE_MAP.items():
        feature_cfg = app_config.get_feature_config(feature_name)
        if not feature_cfg.enabled or not feature_cfg.extension:
            continue

        if not registry.has(feature_cfg.extension):
            errors.append(
                f"Feature '{feature_name}': extension '{feature_cfg.extension}' "
                f"is not registered (not installed or disabled)"
            )
            continue

        ext_manifest = registry.get(feature_cfg.extension)
        if ext_manifest is not None and ext_manifest.type != expected_type:
            errors.append(
                f"Feature '{feature_name}': extension '{feature_cfg.extension}' "
                f"has type '{ext_manifest.type}', expected '{expected_type}'"
            )

    if errors:
        raise ConfigError(errors)


# Backward-compatible alias
validate_slot_refs = validate_feature_refs


def validate_connector_refs(app_config: AppConfig, registry: ExtensionRegistry) -> None:
    """Validate ``config.yaml`` ``connectors:`` entries against the registry.

    Runs after :func:`validate_feature_refs`. Checks that every enabled
    connector instance references an extension that exists and declares
    ``type: connector``. Disabled instances are skipped so operators can
    keep draft configs in-tree.
    """
    errors: list[str] = []
    for instance_cfg in app_config.connectors.instances:
        if not instance_cfg.enabled:
            continue

        if not registry.has(instance_cfg.extension):
            errors.append(
                f"Connector '{instance_cfg.instance}': extension "
                f"'{instance_cfg.extension}' is not registered "
                "(not installed or disabled)"
            )
            continue

        ext_manifest = registry.get(instance_cfg.extension)
        if ext_manifest is not None and ext_manifest.type != CONNECTOR_EXT_TYPE:
            errors.append(
                f"Connector '{instance_cfg.instance}': extension "
                f"'{instance_cfg.extension}' has type '{ext_manifest.type}', "
                f"expected '{CONNECTOR_EXT_TYPE}'"
            )

    if errors:
        raise ConfigError(errors)


class PluginManager:
    """Lifecycle orchestrator: discovery → loading → registration → validation.

    Reads ``plugins.yaml`` to know which plugins/extensions are enabled,
    reads each plugin's ``plugin.yaml`` manifest, and populates an
    :class:`ExtensionRegistry` with the enabled extensions.
    """

    def __init__(
        self,
        plugins_yaml_path: Path | None = None,
        plugins_dir: Path | None = None,
    ) -> None:
        self._plugins_yaml_path = plugins_yaml_path
        self._plugins_dir = plugins_dir
        self._registry = ExtensionRegistry()
        self._entries: dict[str, PluginEntry] = {}

    @property
    def registry(self) -> ExtensionRegistry:
        return self._registry

    # ── Discovery ──────────────────────────────────────────────

    def discover_plugins(self) -> dict[str, PluginManifest]:
        """Scan the ``plugins/`` directory for ``plugin.yaml`` manifests."""
        plugins_dir = self._resolve_plugins_dir()
        found: dict[str, PluginManifest] = {}
        if not plugins_dir.is_dir():
            logger.warning("Plugins directory not found: %s", plugins_dir)
            return found
        for manifest_path in sorted(plugins_dir.glob(f"*/{MANIFEST_FILENAME}")):
            try:
                manifest = read_manifest_from_yaml(manifest_path)
                if manifest.plugin_name in found:
                    raise RuntimeError(f"Duplicate plugin ID: {manifest.plugin_name}")
                found[manifest.plugin_name] = manifest
                logger.debug("Discovered plugin: %s", manifest.plugin_name)
            except (ValueError, KeyError) as exc:
                logger.warning(
                    "Skipping invalid manifest %s: %s", manifest_path, exc
                )
        return found

    def generate_plugins_yaml(self) -> Path:
        """Discover plugins and write ``plugins.yaml`` (all enabled).

        Returns the path to the generated file.
        """
        plugins = self.discover_plugins()

        # Build entries from discovered manifests (all enabled by default)
        for name, manifest in plugins.items():
            self._entries[name] = PluginEntry(
                name=name,
                extensions={
                    ext.name: ExtensionEntry(name=ext.name, enabled=True)
                    for ext in manifest.extensions
                },
            )

        path = self._resolve_plugins_yaml_path()
        self._write_plugins_yaml()
        logger.info("Generated %s with %d plugin(s)", path, len(self._entries))
        return path

    # ── Loading ────────────────────────────────────────────────

    def load_all(self) -> ExtensionRegistry:
        """Main entry point. Read plugins.yaml, register enabled extensions.

        If ``plugins.yaml`` does not exist, auto-generates it via discovery.
        If it exists but new plugin directories have appeared since it was
        written, the new plugins are appended (enabled by default) and the
        file is rewritten — so a developer who drops a new plugin into
        ``plugins/`` and restarts gets it loaded without hand-editing
        ``plugins.yaml``.
        """
        path = self._resolve_plugins_yaml_path()

        if not path.exists():
            logger.info("plugins.yaml not found — running auto-discovery")
            self.generate_plugins_yaml()

        self._entries = self._read_plugins_yaml(path)

        # Merge in any plugins that appeared on disk after the yaml was written.
        discovered = self.discover_plugins()
        new_plugins = [name for name in discovered if name not in self._entries]
        if new_plugins:
            for name in new_plugins:
                manifest = discovered[name]
                self._entries[name] = PluginEntry(
                    name=name,
                    extensions={
                        ext.name: ExtensionEntry(name=ext.name, enabled=True)
                        for ext in manifest.extensions
                    },
                )
            self._write_plugins_yaml()
            logger.info(
                "Auto-registered %d new plugin(s) in plugins.yaml: %s",
                len(new_plugins), ", ".join(sorted(new_plugins)),
            )

        for plugin_name, entry in self._entries.items():
            if not entry.enabled:
                logger.debug("Plugin %s is disabled, skipping", plugin_name)
                continue
            self._register_plugin(plugin_name, entry)

        logger.info(
            "Loaded %d extension(s) from %d plugin(s)",
            len(self._registry),
            len(self._entries),
        )
        return self._registry

    # ── Lifecycle helpers ──────────────────────────────────────

    def install(self, plugin_name: str) -> None:
        """Add a plugin to plugins.yaml with all extensions enabled."""
        manifest = read_plugin_manifest(
            plugin_name, plugins_dir=self._resolve_plugins_dir(),
        )
        entry = PluginEntry(
            name=plugin_name,
            extensions={
                ext.name: ExtensionEntry(name=ext.name, enabled=True)
                for ext in manifest.extensions
            },
        )
        self._entries[plugin_name] = entry
        self._write_plugins_yaml()

        # Register immediately
        self._register_plugin(plugin_name, entry)

    def uninstall(self, plugin_name: str) -> None:
        """Remove a plugin from plugins.yaml and unregister its extensions."""
        entry = self._entries.pop(plugin_name, None)
        if entry is None:
            return
        for ext_name in entry.extensions:
            self._registry.unregister(f"{plugin_name}:{ext_name}")
        self._write_plugins_yaml()

    def enable_plugin(self, plugin_name: str) -> None:
        """Enable a plugin and register its extensions."""
        entry = self._entries.get(plugin_name)
        if entry is None:
            return
        entry.enabled = True
        self._register_plugin(plugin_name, entry)
        self._write_plugins_yaml()

    def disable_plugin(self, plugin_name: str) -> None:
        """Disable a plugin and unregister its extensions."""
        entry = self._entries.get(plugin_name)
        if entry is None:
            return
        entry.enabled = False
        for ext_name in entry.extensions:
            self._registry.unregister(f"{plugin_name}:{ext_name}")
        self._write_plugins_yaml()

    def enable_extension(self, plugin_name: str, ext_name: str) -> None:
        """Enable a single extension within a plugin."""
        entry = self._entries.get(plugin_name)
        if entry is None or ext_name not in entry.extensions:
            return
        entry.extensions[ext_name].enabled = True
        # Re-register the whole plugin to pick up the change
        self._register_plugin(plugin_name, entry)
        self._write_plugins_yaml()

    def disable_extension(self, plugin_name: str, ext_name: str) -> None:
        """Disable a single extension within a plugin."""
        entry = self._entries.get(plugin_name)
        if entry is None or ext_name not in entry.extensions:
            return
        entry.extensions[ext_name].enabled = False
        self._registry.unregister(f"{plugin_name}:{ext_name}")
        self._write_plugins_yaml()

    # ── Validation ─────────────────────────────────────────────

    def validate_config(self, app_config: AppConfig) -> None:
        """Validate config.yaml extension refs against the registry.

        Checks:
          1. Referenced extension exists in registry.
          2. Extension type matches the slot's expected type.

        Raises:
            ConfigError: Listing all violations found.
        """
        validate_feature_refs(app_config, self._registry)

    # ── Internal ───────────────────────────────────────────────

    def _resolve_plugins_yaml_path(self) -> Path:
        """Return the path to plugins.yaml, next to config.yaml."""
        if self._plugins_yaml_path is not None:
            return self._plugins_yaml_path

        from ..config.app_config import find_config_yaml

        config_yaml = find_config_yaml()
        return config_yaml.parent / "plugins.yaml"

    def _resolve_plugins_dir(self) -> Path:
        """Return the path to the ``plugins/`` directory."""
        if self._plugins_dir is not None:
            return self._plugins_dir

        from .manifest import _find_plugins_dir

        return _find_plugins_dir()

    def _read_plugins_yaml(self, path: Path) -> dict[str, PluginEntry]:
        """Parse plugins.yaml into PluginEntry objects."""
        try:
            raw = yaml.safe_load(path.read_text()) or {}
        except FileNotFoundError:
            return {}

        entries: dict[str, PluginEntry] = {}
        for plugin_name, plugin_data in raw.items():
            if not isinstance(plugin_data, dict):
                continue

            ext_entries: dict[str, ExtensionEntry] = {}
            for ext_name, ext_data in plugin_data.get("extensions", {}).items():
                enabled = ext_data.get("enabled", True) if isinstance(ext_data, dict) else True
                ext_entries[ext_name] = ExtensionEntry(name=ext_name, enabled=enabled)

            entries[plugin_name] = PluginEntry(
                name=plugin_name,
                enabled=plugin_data.get("enabled", True),
                extensions=ext_entries,
            )
        return entries

    def _register_plugin(self, plugin_name: str, entry: PluginEntry) -> None:
        """Read manifest and register enabled extensions."""
        try:
            manifest = read_plugin_manifest(
                plugin_name, plugins_dir=self._resolve_plugins_dir(),
            )
        except ImportError:
            logger.warning(
                "Plugin '%s' listed in plugins.yaml but not found", plugin_name
            )
            return

        for ext in manifest.extensions:
            ext_entry = entry.extensions.get(ext.name)
            if ext_entry is not None and not ext_entry.enabled:
                logger.debug(
                    "Extension %s:%s is disabled, skipping", plugin_name, ext.name
                )
                continue
            self._registry.register(plugin_name, ext)

    def _write_plugins_yaml(self) -> None:
        """Persist current entries back to plugins.yaml."""
        path = self._resolve_plugins_yaml_path()
        data: dict[str, Any] = {}
        for name, entry in sorted(self._entries.items()):
            ext_data: dict[str, Any] = {}
            for ext_name, ext_entry in entry.extensions.items():
                ext_data[ext_name] = {"enabled": ext_entry.enabled}
            data[name] = {
                "enabled": entry.enabled,
                "extensions": ext_data,
            }
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(data, default_flow_style=False, sort_keys=True))
