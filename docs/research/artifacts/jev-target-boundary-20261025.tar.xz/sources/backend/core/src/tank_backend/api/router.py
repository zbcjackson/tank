"""WebSocket router for real-time interaction."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

import numpy as np
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from tank_contracts import encode_audio_frame
from tank_protocol import (
    MessageType,
    WebsocketAttachment,
    WebsocketMessage,
    conversation_metadata_updated,
)
from tank_protocol import (
    attachment as attachment_frame,
)
from tank_protocol import (
    signal as signal_frame,
)
from tank_protocol import (
    text as text_frame,
)
from tank_protocol import (
    transcript as transcript_frame,
)
from tank_protocol import (
    update as update_frame,
)
from tank_protocol.handshake import handshake_metadata

from ..audio.input.types import AudioFrame
from ..audio.opus_codec import (
    DOWNLINK_SAMPLE_RATE,
    OpusDecodeError,
    supported_protocol_features,
    uplink_sample_rate,
)
from ..audio.output.types import AudioChunk
from ..core.content import ContentBlocks, DocumentBlock, ImageBlock, modality_for_mime
from ..core.events import (
    ConversationMetadataUpdate,
    DisplayMessage,
    SignalMessage,
    UIMessage,
    UpdateType,
)
from . import deps
from .auth import WS_AUTH_CLOSE_CODE, WS_AUTH_CLOSE_REASON, check_ws_auth
from .signal_handlers import DisconnectSignal
from .signal_handlers import dispatch as dispatch_signal

if TYPE_CHECKING:
    from ..core.assistant import Assistant

logger = logging.getLogger("ApiRouter")

router = APIRouter()


def _resample_pcm16(data: bytes, src_rate: int, dst_rate: int) -> bytes:
    """Resample int16 mono PCM from src_rate to dst_rate via linear interpolation.

    Used to adapt TTS output (e.g. 24kHz) to a client's requested rate (e.g. a
    hardware device fixed at 16kHz). Returns the original bytes if rates match
    or the buffer is empty.
    """
    if src_rate == dst_rate or not data:
        return data
    src = np.frombuffer(data, dtype=np.int16)
    if src.size == 0:
        return data
    dst_len = max(1, round(src.size * dst_rate / src_rate))
    # Sample positions in the source signal for each output sample.
    src_idx = np.linspace(0, src.size - 1, num=dst_len)
    resampled = np.interp(src_idx, np.arange(src.size), src.astype(np.float32))
    return resampled.astype(np.int16).tobytes()


def _to_downlink_rate(chunk: AudioChunk) -> bytes:
    """PCM16 mono bytes at the negotiated opus downlink rate."""
    if chunk.sample_rate == DOWNLINK_SAMPLE_RATE:
        return chunk.data
    return _resample_pcm16(chunk.data, chunk.sample_rate, DOWNLINK_SAMPLE_RATE)


def _parse_attachments(
    raw: list[Any],
    session_id: str,
) -> ContentBlocks:
    """Turn client-sent attachment dicts into typed ContentBlocks.

    Each entry is ``{media_uri, mime_type}``. Non-dict entries and
    attachments with foreign session ids are dropped with a warning —
    this is defence-in-depth; the upload endpoint is the primary gate.
    Modality is inferred from MIME to pick the right block type.
    """
    blocks: list = []
    for entry in raw:
        if not isinstance(entry, dict):
            logger.warning("Dropping non-dict attachment: %r", entry)
            continue
        media_uri = entry.get("media_uri")
        mime_type = entry.get("mime_type")
        if not media_uri or not mime_type:
            logger.warning("Dropping attachment missing media_uri/mime_type")
            continue
        if not media_uri.startswith(f"media://{session_id}/"):
            logger.warning(
                "Dropping cross-session attachment: uri=%s session=%s",
                media_uri, session_id,
            )
            continue
        modality = modality_for_mime(mime_type)
        if modality == "image":
            blocks.append(ImageBlock(source=media_uri, mime_type=mime_type))
        elif modality == "file":
            blocks.append(
                DocumentBlock(source=media_uri, mime_type=mime_type)
            )
        else:
            # Audio/video not yet in Phase 2 scope; ignore quietly.
            logger.info(
                "Attachment modality %s not yet carried on user input; "
                "dropping %s",
                modality, media_uri,
            )
    return blocks


def _resolve_user_name(user_id: str | None) -> str:
    """Resolve a user_id from WebSocket metadata to a display name for Brain."""
    recognizer = deps.app_context().voiceprint_recognizer
    if not user_id or recognizer is None or not recognizer.enabled:
        return "Guest"
    repo = recognizer.repository
    if repo is None:
        return "Guest"
    speaker = repo.get_speaker(user_id)
    return speaker.name if speaker else "Guest"


def _negotiable_protocol_features() -> list[str]:
    """Features this server can negotiate (protocol plan P1-1/P1-2/P1-3).

    ``config`` is pure backend logic — always available; ``opus`` depends
    on the binding (``audio/opus_codec``). ``resume`` lands with P2.
    """
    return ["config", *supported_protocol_features()]


def _ready_metadata(assistant: Assistant) -> dict[str, Any]:
    """Metadata for the connection-lifetime ``signal: ready`` frame.

    Carries the pipeline feature flags, the wire capture rate, the active
    conversation, and the protocol handshake block (protocol plan P1-1:
    ``protocol_version`` + ``protocol_features``) — additive keys; older
    clients ignore what they don't know.
    """
    metadata: dict[str, Any] = {
        "capabilities": assistant.capabilities,
        "pipeline_sample_rate": assistant.pipeline_sample_rate,
        **handshake_metadata(_negotiable_protocol_features()),
    }
    conv_id = assistant.brain.conversation_id
    if conv_id:
        metadata["conversation_id"] = conv_id
    return metadata


async def _handle_config_message(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_ws_msg: Callable[[WebsocketMessage], Awaitable[None]],
) -> None:
    """Session hot-config (protocol P1-3): validate-then-apply; a rejected
    patch leaves the session untouched and answers ``signal: error``."""
    config = msg.metadata.get("config")
    if config is None:
        config = {}
    try:
        assistant.apply_session_config(config)
    except ValueError as e:
        logger.warning("Rejected config from %s: %s", session_id, e)
        await send_ws_msg(
            signal_frame("error", metadata={"error": f"config rejected: {e}"})
        )


async def _handle_context_inject(
    assistant: Assistant,
    msg: WebsocketMessage,
    session_id: str,
    send_ws_msg: Callable[[WebsocketMessage], Awaitable[None]],
) -> None:
    """Context-only injection (protocol P1-3): append to the conversation
    without triggering a turn; rejected injections answer ``signal: error``."""
    role = msg.metadata.get("role")
    if role is None:
        role = "user"
    try:
        assistant.inject_context(msg.content, role=role)
    except ValueError as e:
        logger.warning("Rejected context_inject from %s: %s", session_id, e)
        await send_ws_msg(
            signal_frame("error", metadata={"error": f"context_inject rejected: {e}"})
        )


def _ui_msg_to_ws_msg(
    msg: UIMessage, session_id: str, conversation_id: str | None = None,
) -> WebsocketMessage | None:
    """Convert a UIMessage to a WebsocketMessage."""
    if isinstance(msg, SignalMessage):
        return signal_frame(
            msg.signal_type,
            msg_id=msg.msg_id,
            session_id=session_id,
            metadata=msg.metadata.copy() if msg.metadata else {},
        )
    if isinstance(msg, ConversationMetadataUpdate):
        # Scope to the matching session so a title generated for one
        # conversation never leaks into another open tab's sidebar.
        if msg.conversation_id != conversation_id:
            return None
        metadata: dict[str, Any] = {"conversation_id": msg.conversation_id}
        if msg.title is not None:
            metadata["title"] = msg.title
        return conversation_metadata_updated(
            session_id=session_id,
            metadata=metadata,
        )
    if isinstance(msg, DisplayMessage):
        metadata = msg.metadata.copy() if msg.metadata else {}
        if msg.msg_id:
            turn = metadata.get("turn", 0)
            step_type = msg.update_type.name.lower()
            step_id = f"{msg.msg_id}_{step_type}_{turn}"
            if msg.update_type == UpdateType.TOOL:
                index = metadata.get("index", 0)
                step_id += f"_{index}"
            elif msg.update_type == UpdateType.APPROVAL:
                approval_id = metadata.get("approval_id", "")
                if approval_id:
                    step_id = f"{msg.msg_id}_approval_{approval_id}"
            metadata["step_id"] = step_id
        if msg.update_type.name != "TEXT":
            return update_frame(
                str(msg.update_type),
                content=msg.text,
                speaker=msg.speaker,
                is_final=msg.is_final,
                msg_id=msg.msg_id,
                session_id=session_id,
                metadata=metadata,
            )
        factory = transcript_frame if msg.is_user else text_frame
        return factory(
            msg.text,
            speaker=msg.speaker,
            is_final=msg.is_final,
            msg_id=msg.msg_id,
            session_id=session_id,
            metadata=metadata,
        )
    logger.warning(f"Unknown UI message type: {type(msg)}")
    return None


def _worker_activity_to_ws_msg(
    payload: dict[str, Any], session_id: str,
) -> WebsocketMessage | None:
    """Convert a worker_activity bus event into an UPDATE WebSocket message.

    These lightweight frames let the frontend accumulate per-tool activity
    on the parent agent HUD window without waiting for terminal events.
    """
    task_id = payload.get("task_id", "")
    if not task_id:
        return None

    tool_name = payload.get("tool_name", "")
    tool_status = payload.get("tool_status", "calling")
    parent_msg_id = payload.get("parent_msg_id")
    msg_id = parent_msg_id or f"worker_{task_id}"
    step_id = f"{msg_id}_tool_0_worker_{task_id}"

    return update_frame(
        "ACTIVITY.WORKER_ACTIVITY",
        speaker="Brain",
        msg_id=msg_id,
        session_id=session_id,
        metadata={
            "step_id": step_id,
            "task_id": task_id,
            "tool_name": tool_name,
            "tool_status": tool_status,
            "tool_args": payload.get("tool_args", ""),
        },
    )


_WORKER_STATUS_MAP = {
    "started": "calling",
    "completed": "success",
    "failed": "error",
    "cancelled": "error",
    "timeout": "error",
    "partial": "error",
    "unknown": "error",
    "needs_input": "error",
    "stopped": "error",
}


def _worker_event_to_ws_msg(
    payload: dict[str, Any], session_id: str,
) -> WebsocketMessage | None:
    """Convert a worker bus event into an UPDATE WebSocket message.

    Reuses the existing ACTIVITY.TOOL / agent HUD machinery on the frontend.
    The step_id is stable across events for the same task_id so the frontend
    upserts the same step (calling → executing → success/error).
    """
    event = payload.get("event", "")
    task_id = payload.get("task_id", "")
    if not task_id:
        return None

    status = _WORKER_STATUS_MAP.get(event)
    if status is None:
        return None

    description = payload.get("description", "")
    parent_msg_id = payload.get("parent_msg_id")
    msg_id = parent_msg_id or f"worker_{task_id}"
    step_id = f"{msg_id}_tool_0_worker_{task_id}"

    arguments = json.dumps(
        {"description": description, "background": True},
        ensure_ascii=False,
    )

    content = ""
    if event == "completed":
        content = payload.get("output", "") or ""
    elif event in ("failed", "cancelled", "timeout"):
        content = payload.get("error", "") or event
    elif event in ("partial", "unknown", "needs_input", "stopped"):
        content = f"{event}: {payload.get('output') or ''}"

    is_final = event != "started"

    return update_frame(
        "ACTIVITY.TOOL",
        content=content,
        speaker="Brain",
        is_final=is_final,
        msg_id=msg_id,
        session_id=session_id,
        metadata={
            "step_id": step_id,
            "name": "agent",
            "arguments": arguments,
            "status": status,
            "turn": 0,
            "index": 0,
        },
    )


def _attachment_payload_to_ws_msg(
    payload: dict, session_id: str,
) -> WebsocketMessage | None:
    """Convert an ``outbound_attachment`` bus payload into a
    :class:`WebsocketMessage` the browser can consume.

    Called from the WebSocket endpoint's bus subscriber. The payload
    shape mirrors ``Assistant.emit_outbound_attachment``:

    .. code-block:: python

        {"msg_id": ..., "blocks": [ImageBlock, ...], "caption": str | None}

    For each :class:`ImageBlock` in ``blocks`` we emit one
    :class:`WebsocketAttachment`. ``media://<session>/<file>`` URIs
    are rewritten to ``/api/media/<session>/<file>`` so the browser
    can fetch them via a regular ``<img src>``. Public ``http(s)://``
    URLs pass through unchanged — ``echo_image`` produces those, and
    the browser doesn't need any intermediary.

    Non-image blocks (future audio/video kinds) are skipped for now;
    Phase 17 only ships the image renderer on the frontend side.

    Returns ``None`` when no image blocks survive conversion — the
    caller should not emit an empty ATTACHMENT frame (confuses the
    client into rendering an attachment bubble with nothing inside).
    """
    blocks = payload.get("blocks") or ()
    caption = payload.get("caption")
    msg_id = payload.get("msg_id")

    attachments: list[WebsocketAttachment] = []
    for block in blocks:
        if not isinstance(block, ImageBlock):
            continue
        source = block.source or ""
        if source.startswith("media://"):
            # Session-scoped: strip the ``media://`` scheme and
            # prepend the public media route. We don't verify the
            # session segment matches ``session_id`` here — the
            # ``MediaStore.get`` call inside the endpoint handler
            # does that for us, and a cross-session mismatch would
            # surface as a 404 on the browser's fetch (not a WebSocket
            # frame drop, which would be harder to debug).
            stripped = source[len("media://"):]
            url = f"/api/media/{stripped}"
        else:
            # http(s)://, data:, absolute paths — pass through. The
            # browser will fail its own fetch for unsupported schemes;
            # we don't try to be clever here.
            url = source
        attachments.append(WebsocketAttachment(
            kind="image",
            url=url,
            mime_type=block.mime_type or "image/jpeg",
            caption=caption,
        ))

    if not attachments:
        return None

    return attachment_frame(
        attachments,
        # ``content`` carries the caption so clients that don't
        # inspect the ``attachments`` array still see the text (and
        # the markdown/plain-text heuristics that apply to TEXT frames
        # apply here too).
        content=caption or "",
        speaker="Brain",
        msg_id=msg_id,
        session_id=session_id,
    )


@router.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """Pipeline-based WebSocket endpoint using Assistant."""
    await websocket.accept()

    # Connection auth (protocol plan P0-2). Checked before any session or
    # assistant work; a rejection is an immediate close so clients see a
    # meaningful close code instead of a hanging handshake.
    provided_token = websocket.query_params.get("token")
    if not check_ws_auth(deps.app_context().app_config.auth, provided_token):
        logger.warning("WebSocket auth rejected for session %s", session_id)
        await websocket.close(
            code=WS_AUTH_CLOSE_CODE, reason=WS_AUTH_CLOSE_REASON,
        )
        return

    logger.info(f"WebSocket connected: {session_id}")

    # Optional client-requested output sample rate (e.g. hardware device fixed
    # at 16kHz). When set, TTS audio is resampled per-chunk before sending.
    # Other clients (web/CLI) omit it and receive native TTS rate.
    output_rate_raw = websocket.query_params.get("output_rate")
    output_rate: int | None = None
    if output_rate_raw:
        try:
            output_rate = int(output_rate_raw)
        except ValueError:
            logger.warning("Invalid output_rate query param: %r", output_rate_raw)

    ws_connected = True
    loop = asyncio.get_running_loop()

    # Serialize all sends. Without this, a frame pushed from one task (audio,
    # text, worker events) can call the transport's drain() concurrently with
    # another send — or with the library's auto-PONG reply to a client ping —
    # which trips an AssertionError in the websockets legacy protocol and
    # drops the connection. The lock guarantees one send completes before the
    # next begins.
    send_lock = asyncio.Lock()

    async def _locked_send_text(text: str) -> None:
        async with send_lock:
            await websocket.send_text(text)

    async def _locked_send_bytes(payload: bytes) -> None:
        async with send_lock:
            await websocket.send_bytes(payload)

    assistant, is_new = await deps.connection_manager().get_or_create_assistant(session_id)

    # Load persisted conversation history for this session
    assistant.set_session_id(session_id)

    if not is_new:
        logger.info(f"WebSocket reattached to existing session: {session_id}")

    # Bus-based UI push: forward UI messages to WebSocket
    def on_ui_message(msg: UIMessage) -> None:
        if not ws_connected:
            return
        ws_msg = _ui_msg_to_ws_msg(msg, session_id, assistant.brain.conversation_id)
        if ws_msg is None:
            return
            return

        async def _send() -> None:
            if not ws_connected:
                return
            try:
                await _locked_send_text(ws_msg.model_dump_json())
            except Exception as e:
                logger.debug(f"Send error: {e}")

        asyncio.run_coroutine_threadsafe(_send(), loop)

    # Atomic swap on reattach to avoid a window with no callbacks;
    # append on new session.
    if is_new:
        assistant.subscribe_ui(on_ui_message)
    else:
        assistant.set_ui_callback(on_ui_message)

    # Playback callback: send audio chunks over WebSocket
    # Also fans out to other subscribers if this session is on a channel.
    def on_playback_chunk(chunk: AudioChunk) -> None:
        if not ws_connected:
            return

        mgr = deps.connection_manager()
        codec = mgr.get_codec(session_id)
        channel_slug = mgr.get_session_channel(session_id)
        subscribers: set[str] = set()
        if channel_slug is not None:
            subscribers = deps.subscription_manager().get_subscribers(channel_slug)
            subscribers.discard(session_id)  # don't double-send to self

        # Opus downlink (P1-2): self (if negotiated) and any opus channel
        # subscriber share one OPUS_PROFILE, so a single packet stream serves
        # them all. When the talking session stayed on raw PCM, opus
        # subscribers are served via the manager's shared channel encoder.
        packets: list[bytes] = []
        if codec is not None:
            packets = codec.downlink.feed(_to_downlink_rate(chunk))
        elif any(mgr.get_codec(sid) is not None for sid in subscribers):
            channel_encoder = mgr.get_channel_encoder()
            if channel_encoder is not None:
                packets = channel_encoder.feed(_to_downlink_rate(chunk))

        # PCM header frame: self in PCM mode (resampled to its output_rate)
        # and PCM channel subscribers. On an opus connection the negotiated
        # downlink rate replaces output_rate, so the frame carries the
        # chunk's native rate for those subscribers.
        data = chunk.data
        out_rate = chunk.sample_rate
        if (
            codec is None
            and output_rate is not None
            and output_rate != chunk.sample_rate
        ):
            data = _resample_pcm16(chunk.data, chunk.sample_rate, output_rate)
            out_rate = output_rate
        frame = encode_audio_frame(data, out_rate, chunk.channels)

        async def _send_chunk() -> None:
            if not ws_connected:
                return
            try:
                if codec is not None:
                    for packet in packets:
                        await _locked_send_bytes(packet)
                else:
                    await _locked_send_bytes(frame)
            except Exception as e:
                logger.debug(f"Audio send error: {e}")

            # Fan out to other subscribers of the same channel
            if channel_slug is None:
                return
            for sid in subscribers:
                send_fn = mgr.get_binary_sender(sid)
                if send_fn is None:
                    continue
                try:
                    if mgr.get_codec(sid) is not None:
                        for packet in packets:
                            await send_fn(packet)
                    else:
                        await send_fn(frame)
                except Exception:
                    logger.debug("Fan-out audio send failed for %s", sid)

        asyncio.run_coroutine_threadsafe(_send_chunk(), loop)

    assistant.set_playback_callback(on_playback_chunk)

    # Phase 17: outbound-attachment bridge for the web UI. Subscribe
    # to the same bus event that _ImageDispatcher consumes on the
    # connector side. When a tool returns an image (via
    # Assistant.emit_outbound_attachment or ToolManager's hook), we
    # convert the payload to an ATTACHMENT frame so the browser's
    # MessageStep renderer draws it as part of the conversation.
    def on_outbound_attachment(bus_msg: Any) -> None:
        if not ws_connected:
            return
        payload = bus_msg.payload or {}
        ws_msg = _attachment_payload_to_ws_msg(payload, session_id)
        if ws_msg is None:
            return

        async def _send_attachment() -> None:
            if not ws_connected:
                return
            try:
                await _locked_send_text(ws_msg.model_dump_json())
            except Exception as e:
                logger.debug(f"Attachment send error: {e}")

        asyncio.run_coroutine_threadsafe(_send_attachment(), loop)

    assistant._bus.subscribe(  # noqa: SLF001
        "outbound_attachment", on_outbound_attachment,
    )

    # Live push for background worker activity. Converts worker bus events
    # into UPDATE frames so the frontend HUD shows agent windows in real-time.
    def on_worker_event(bus_msg: Any) -> None:
        if not ws_connected:
            return
        payload = bus_msg.payload or {}
        ws_msg = _worker_event_to_ws_msg(payload, session_id)
        if ws_msg is None:
            return

        async def _send_worker() -> None:
            if not ws_connected:
                return
            try:
                await _locked_send_text(ws_msg.model_dump_json())
            except Exception as e:
                logger.debug(f"Worker event send error: {e}")

        asyncio.run_coroutine_threadsafe(_send_worker(), loop)

    assistant._bus.subscribe("worker", on_worker_event)  # noqa: SLF001

    # Live push for per-tool activity inside background workers.
    def on_worker_activity(bus_msg: Any) -> None:
        if not ws_connected:
            return
        payload = bus_msg.payload or {}
        ws_msg = _worker_activity_to_ws_msg(payload, session_id)
        if ws_msg is None:
            return

        async def _send_activity() -> None:
            if not ws_connected:
                return
            try:
                await _locked_send_text(ws_msg.model_dump_json())
            except Exception as e:
                logger.debug(f"Worker activity send error: {e}")

        asyncio.run_coroutine_threadsafe(_send_activity(), loop)

    assistant._bus.subscribe("worker_activity", on_worker_activity)  # noqa: SLF001

    # Helper for signal handlers to send messages
    async def send_ws_msg(msg: WebsocketMessage) -> None:
        if ws_connected:
            try:
                await _locked_send_text(msg.model_dump_json())
            except Exception as e:
                logger.debug(f"Send error: {e}")

    try:
        ready_msg = signal_frame(
            "ready",
            session_id=session_id,
            metadata=_ready_metadata(assistant),
        )
        await _locked_send_text(ready_msg.model_dump_json())

        # Register sender for cross-session broadcast (channel notifications)
        async def _broadcast_send(json_str: str) -> None:
            if ws_connected:
                await _locked_send_text(json_str)

        async def _binary_send(data: bytes) -> None:
            if ws_connected:
                await _locked_send_bytes(data)

        deps.connection_manager().register_sender(session_id, _broadcast_send)
        deps.connection_manager().register_binary_sender(session_id, _binary_send)

        while True:
            data = await websocket.receive()

            if "bytes" in data:
                # Binary: push audio into pipeline
                raw = data["bytes"]
                # Opus connection (P1-2): one packet per binary message →
                # decode to PCM16 at the negotiated uplink rate. Mono by
                # profile; audio_format/output_rate don't apply.
                codec = deps.connection_manager().get_codec(session_id)
                if codec is not None:
                    try:
                        raw = codec.uplink.decode_packet(raw)
                    except OpusDecodeError as e:
                        logger.warning(
                            "Undecodable opus packet from %s: %s", session_id, e
                        )
                        continue
                    cap_rate = uplink_sample_rate()
                    cap_ch = 1
                else:
                    cap_rate = assistant.capture_sample_rate
                    cap_ch = assistant.capture_channels
                pipeline_rate = assistant.pipeline_sample_rate
                # Downmix stereo → mono if needed
                if cap_ch > 1:
                    samples = np.frombuffer(raw, dtype=np.int16).reshape(-1, cap_ch)
                    raw = samples[:, 0].tobytes()
                # Resample to the pipeline rate if the client captures differently
                if cap_rate != pipeline_rate:
                    raw = _resample_pcm16(raw, cap_rate, pipeline_rate)
                pcm_data = (
                    np.frombuffer(raw, dtype=np.int16).astype(np.float32)
                    / 32768.0
                )
                frame = AudioFrame(
                    pcm=pcm_data, sample_rate=pipeline_rate, timestamp_s=time.time()
                )
                assistant.push_audio(frame)

            elif "text" in data:
                msg_json = json.loads(data["text"])
                msg = WebsocketMessage(**msg_json)

                if msg.type == MessageType.SIGNAL:
                    handled = await dispatch_signal(
                        msg.content, assistant, msg, session_id, send_ws_msg,
                    )
                    if not handled:
                        logger.warning("Unknown signal: %s", msg.content)

                elif msg.type == MessageType.INPUT:
                    user_id = msg.metadata.get("user_id")
                    user_name = _resolve_user_name(user_id)
                    raw_attachments = msg.metadata.get("attachments") or []
                    attachments = _parse_attachments(raw_attachments, session_id)
                    assistant.process_input(
                        msg.content, user=user_name, attachments=attachments,
                    )

                elif msg.type == MessageType.CONFIG:
                    await _handle_config_message(
                        assistant, msg, session_id, send_ws_msg,
                    )

                elif msg.type == MessageType.CONTEXT_INJECT:
                    await _handle_context_inject(
                        assistant, msg, session_id, send_ws_msg,
                    )

    except (WebSocketDisconnect, DisconnectSignal):
        logger.info(f"WebSocket disconnected: {session_id}")
    except RuntimeError as e:
        error_text = str(e)
        if "disconnect message has been received" in error_text or (
            "TCPTransport closed=True" in error_text
            and "the handler is closed" in error_text
        ):
            # uvloop can close the transport while the assistant is starting,
            # before receive() has observed the client's disconnect frame.
            logger.info(f"WebSocket disconnected: {session_id}")
        else:
            logger.error(f"WebSocket error in {session_id}: {e}", exc_info=True)
    except Exception as e:
        logger.error(f"WebSocket error in {session_id}: {e}", exc_info=True)
    finally:
        ws_connected = False
        mgr = deps.connection_manager()
        mgr.unregister_sender(session_id)
        mgr.unregister_binary_sender(session_id)
        mgr.unregister_codec(session_id)
        deps.subscription_manager().remove_session(session_id)
        mgr.detach_websocket(session_id)
        logger.info(f"WebSocket disconnected: {session_id}")
