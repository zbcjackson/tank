"""AgentRunner — single execution method for all agents.

Brain uses it for the main agent. The ``agent`` tool uses it for sub-agents.
Skills use it for fork mode. All agents get approval, UI streaming, and
lifecycle management consistently through this one entry point.
"""

from __future__ import annotations

import asyncio
import copy
import json
import logging
import time
import uuid
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable
from typing import TYPE_CHECKING, Any, cast

from ..llm.model_data import ModelDataScope
from ..tools.computer_native import join_on_cancel
from .base import AgentOutput, AgentOutputType, AgentState
from .definition import AgentDefinition
from .llm_agent import LLMAgent
from .resources import DESKTOP_RESOURCE, DesktopCleanup, DesktopResource
from .subagent import (
    JsonValue,
    SubAgentAuthorization,
    SubAgentBudget,
    SubAgentCleanupError,
    SubAgentContext,
    SubAgentObserver,
    SubAgentRequest,
    SubAgentStopped,
    validate_task_input,
)
from .subagent_adapter import SubAgentAdapter
from .task_observer import TaskObserver

if TYPE_CHECKING:
    from ..llm.llm import LLM
    from ..llm.model_call import ModelCallPolicy, ModelCapture
    from ..llm.profile import LLMProfile
    from ..pipeline.bus import Bus
    from ..tools.manager import ToolManager
    from .approval import PendingToolCallStore, ToolApprovalPolicy
    from .task_runtime import ExecutionRecord

logger = logging.getLogger(__name__)

MAX_AGENT_DEPTH = 3
MAX_CONCURRENT_AGENTS = 5

# Tools that sub-agents should never have (prevent recursion, meta-tools)
GLOBAL_DISALLOWED_FOR_SUBAGENTS: frozenset[str] = frozenset({
    "agent",          # prevent recursive spawning by default
    "list_skills",    # meta — not useful inside a sub-agent
    "create_skill",   # meta
    "install_skill",  # meta
})


class AgentRunner:
    """Unified agent execution engine."""

    def __init__(
        self,
        llm: LLM,
        tool_manager: ToolManager,
        bus: Bus,
        approval_policy: ToolApprovalPolicy,
        pending_store: PendingToolCallStore,
        definitions: dict[str, AgentDefinition],
        resolver: Any = None,
        max_depth: int = MAX_AGENT_DEPTH,
        max_concurrent: int = MAX_CONCURRENT_AGENTS,
        toolsets_config: Any = None,
        app_config: Any = None,
        registry: Any = None,
        desktop_resource: DesktopResource | None = None,
        llm_factory: Callable[[LLMProfile], LLM] | None = None,
    ) -> None:
        from ..llm.profile import create_llm_from_profile

        self._llm_factory = llm_factory or create_llm_from_profile
        self._llm = llm
        self._tool_manager = tool_manager
        self._bus = bus
        self._approval_policy = approval_policy
        self._pending_store = pending_store
        self._definitions = definitions
        self._resolver = resolver
        self._max_depth = max_depth
        self._max_concurrent = max_concurrent
        self._active_agents: dict[str, _AgentTracker] = {}
        self._toolsets_config = toolsets_config
        self._app_config = app_config
        # None = this context can only run built-in agents.
        self._registry = registry
        self._desktop_resource = desktop_resource or DESKTOP_RESOURCE

        # Create own PromptAssembler for sub-agent prompt building
        from ..prompts.assembler import PromptAssembler

        self._prompt_assembler = PromptAssembler(bus=bus)

    @property
    def definitions(self) -> dict[str, AgentDefinition]:
        return self._definitions

    def get_definition(self, name: str) -> AgentDefinition | None:
        return self._definitions.get(name)

    # ------------------------------------------------------------------
    # The single execution method
    # ------------------------------------------------------------------

    def extension_permissions(self, agent_def: AgentDefinition) -> frozenset[str]:
        if self._registry is None:
            raise RuntimeError("Subagent requires an ExtensionRegistry")
        manifest = self._registry.get_manifest(agent_def.extension)
        if manifest is None or manifest.type != "subagent":
            raise ValueError(
                f"Subagent extension '{agent_def.extension}' is missing or has wrong type"
            )
        manifest.check_runtime_api()
        return frozenset(manifest.permissions) | (
            {"network"}
            if (agent_def.model is not None or agent_def.decision_model is not None
                or agent_def.visual_model is not None) else set()
        )

    def _uses_desktop(self, agent_def: AgentDefinition) -> bool:
        if agent_def.grounding is not None:
            return True
        if agent_def.extension:
            return "desktop" in self.extension_permissions(agent_def)
        tools = agent_def.tool_filter
        if tools is None and agent_def.toolset:
            tools = self._resolve_toolset(agent_def.toolset)
        return tools is not None and any(
            self._approval_policy.category_for(t) == "computer" for t in tools
        )

    async def run_agent(
        self, agent_def: AgentDefinition, messages: list[dict[str, Any]],
        parent_agent_id: str | None = None, background: bool = False,
        token_budget: int | None = None, allowed_categories: set[str] | None = None,
        *, task_id: str | None = None,
        authorization: SubAgentAuthorization | None = None,
        deadline: float | None = None, observer: SubAgentObserver | None = None,
        max_steps: int | None = None,
        max_actions: int | None = None, max_observations: int | None = None,
        audit: Callable[[ExecutionRecord], Awaitable[None]] | None = None,
        model_policy: ModelCallPolicy | None = None,
        model_capture: ModelCapture | None = None,
        model_data_scope: ModelDataScope | None = None,
        desktop_cleanup: DesktopCleanup | None = None,
        task_input: dict[str, JsonValue] | None = None,
        user_input: Callable[[str], Awaitable[str]] | None = None,
    ) -> AsyncIterator[AgentOutput]:
        task_input = validate_task_input(task_input)
        if task_input is not None and not agent_def.extension:
            raise ValueError("task_input requires an extension agent")
        decision_profile = (self._app_config.decision_models.get(agent_def.decision_model)
                            if agent_def.decision_model and self._app_config is not None else None)
        decision_images = decision_profile is not None and decision_profile.images
        default_scope = (
            ModelDataScope() if (agent_def.extension and agent_def.visual_model is None
                                and not decision_images)
            else ModelDataScope(frozenset({"text", "image"}), 32 * 1024 * 1024))
        if model_data_scope is not None and (
            not model_data_scope.allowed_types <= default_scope.allowed_types
            or model_data_scope.max_request_bytes > default_scope.max_request_bytes
        ):
            raise ValueError("model data scope exceeds the host allowance")
        model_data_scope = model_data_scope or default_scope
        context = None
        if agent_def.grounding is not None:
            deadline = deadline if deadline is not None else time.monotonic() + 600
            context = SubAgentContext(
                authorization or SubAgentAuthorization(frozenset({"desktop", "network"})),
                SubAgentBudget(limit=(
                    agent_def.token_budget if token_budget is None else token_budget
                )),
                asyncio.Event(), deadline, observer, max_steps,
                audit=audit, model_policy=model_policy, model_capture=model_capture,
                model_data_scope=model_data_scope,
            )
            context.check("desktop")
        if agent_def.extension:
            deadline = deadline if deadline is not None else time.monotonic() + 600
            permissions = self.extension_permissions(agent_def)
            authorization = authorization or SubAgentAuthorization()
            for permission in permissions:
                authorization.check(permission)
            context = SubAgentContext(
                authorization, SubAgentBudget(limit=(
                    agent_def.token_budget if token_budget is None else token_budget
                )), asyncio.Event(), deadline, TaskObserver(self._bus, observer), max_steps,
                audit=audit, model_policy=model_policy, model_capture=model_capture,
                execution_policy=self._approval_policy, approval_resolver=self._resolver,
                max_actions=max_actions, max_observations=max_observations,
                user_input=user_input,
                model_data_scope=model_data_scope,
            )
            context.check()
        if context is None:
            context = SubAgentContext(
                authorization or SubAgentAuthorization(frozenset({"network"})),
                SubAgentBudget(
                    limit=agent_def.token_budget if token_budget is None else token_budget,
                ),
                asyncio.Event(), deadline, observer, max_steps,
                audit=audit, model_policy=model_policy, model_capture=model_capture,
                model_data_scope=model_data_scope,
            )
        outputs = self._run_agent(
            agent_def, messages, parent_agent_id, background, token_budget,
            allowed_categories, context=context, task_id=task_id, task_input=task_input,
        )
        uses_desktop = self._uses_desktop(agent_def) or desktop_cleanup is not None

        async def close_outputs() -> None:
            try:
                await join_on_cancel(outputs.aclose())
            finally:
                if not agent_def.extension:
                    await join_on_cancel(context.runtime.aclose())

        async def clean_inputs() -> None:
            assert desktop_cleanup is not None
            try:
                result = await desktop_cleanup.finish()
            except Exception as exc:
                result = {"confirmed": False, "error_type": type(exc).__name__}
            confirmed = result.get("confirmed") is True
            if not confirmed:
                self._desktop_resource.quarantine("desktop input cleanup unconfirmed")
            if observer is not None:
                observer.on_event("desktop_cleanup", result)
            if not confirmed:
                raise SubAgentCleanupError("desktop input cleanup unconfirmed")

        try:
            if uses_desktop:
                async with self._desktop_resource.acquire(deadline=deadline):
                    started = False
                    try:
                        if desktop_cleanup is not None:
                            await desktop_cleanup.begin()
                            started = True
                        async with asyncio.timeout_at(deadline if agent_def.grounding else None):
                            async for output in outputs:
                                yield output
                    finally:
                        try:
                            await close_outputs()
                        finally:
                            if started:
                                await join_on_cancel(clean_inputs())
            else:
                try:
                    async for output in outputs:
                        yield output
                finally:
                    await close_outputs()
        except SubAgentCleanupError as exc:
            if uses_desktop:
                self._desktop_resource.quarantine(str(exc))
            raise
        finally:
            context.cancel.set()

    async def _run_agent(
        self,
        agent_def: AgentDefinition,
        messages: list[dict[str, Any]],
        parent_agent_id: str | None = None,
        background: bool = False,
        token_budget: int | None = None,
        allowed_categories: set[str] | None = None,
        *, context: SubAgentContext, task_id: str | None = None,
        task_input: dict[str, JsonValue] | None = None,
    ) -> AsyncGenerator[AgentOutput, None]:
        """Run an agent to completion, yielding all outputs.

        Called by run_agent with the original task context.

        Args:
            agent_def: The agent definition (system prompt, tool config).
            messages: Initial messages (task description or full conversation).
            parent_agent_id: Parent agent ID for depth tracking.
            background: Run without blocking the parent.
            token_budget: Override agent_def.token_budget.
        """
        # --- Depth check ---
        depth = self._get_depth(parent_agent_id)
        if depth >= self._max_depth:
            logger.warning(
                "Agent depth limit reached (%d/%d) for '%s'",
                depth, self._max_depth, agent_def.name,
            )
            yield AgentOutput(
                type=AgentOutputType.TOOL_RESULT,
                content=f"Cannot spawn agent '{agent_def.name}': "
                        f"max depth {self._max_depth} reached.",
                metadata={"status": "error"},
            )
            return

        # --- Concurrent agent check ---
        active_count = sum(
            1 for t in self._active_agents.values() if t.active
        )
        if active_count >= self._max_concurrent:
            logger.warning(
                "Concurrent agent limit reached (%d/%d)",
                active_count, self._max_concurrent,
            )
            yield AgentOutput(
                type=AgentOutputType.TOOL_RESULT,
                content=f"Cannot spawn agent: max concurrent "
                        f"agents ({self._max_concurrent}) reached.",
                metadata={"status": "error"},
            )
            return

        # --- Create agent ---
        agent_id = f"agent_{uuid.uuid4().hex[:8]}"
        tracker = _AgentTracker(
            agent_id=agent_id,
            agent_name=agent_def.name,
            parent_id=parent_agent_id,
            depth=depth,
        )

        # Resolve tools: all tools minus disallowed, filtered by toolset
        exclude = set(agent_def.disallowed_tools)
        if parent_agent_id is not None:
            # Sub-agents get global disallowed tools
            exclude |= GLOBAL_DISALLOWED_FOR_SUBAGENTS

        # Inline allowlist takes priority, then named toolset profile
        tool_filter: list[str] | None = None
        if agent_def.tool_filter is not None:
            tool_filter = list(agent_def.tool_filter)
        elif agent_def.toolset:
            tool_filter = self._resolve_toolset(agent_def.toolset)

        exclude_tools = exclude or None

        effective_budget = agent_def.token_budget if token_budget is None else token_budget
        usage = context.budget

        available_tools: set[str] = set()
        if not agent_def.extension:
            available_tools = {
                tool["function"]["name"]
                for tool in self._tool_manager.get_openai_tools(exclude=exclude_tools)
                if tool_filter is None or tool["function"]["name"] in tool_filter
            }
        context_messages = messages
        if task_input is not None:
            context_messages = [*messages, {
                "role": "user", "content": json.dumps(task_input, ensure_ascii=False),
            }]
        system_prompt = self._build_sub_agent_prompt(agent_def, context_messages, available_tools)
        owned_grounders: list[LLM] = []

        def task_llm(value: LLM) -> LLM:
            if callable(getattr(type(value), "bind_task", None)):
                return value.bind_task(context, task_id or agent_id)
            return value

        if agent_def.extension:
            context.check()
            for permission in self.extension_permissions(agent_def):
                context.authorization.check(permission)
            config = (self._app_config.subagents.get(agent_def.extension, {})
                      if self._app_config is not None else {})
            from .subagent import SubAgent

            plugin = None
            try:
                if agent_def.model is not None:
                    profiles = self._app_config.llm_profiles if self._app_config is not None else {}
                    if agent_def.model not in profiles:
                        raise ValueError("subagent model profile is not configured")
                    context.runtime.configure_model(task_id or agent_id, profiles[agent_def.model])
                if agent_def.visual_model is not None:
                    profiles = self._app_config.llm_profiles if self._app_config is not None else {}
                    if agent_def.visual_model not in profiles:
                        raise ValueError("subagent visual model profile is not configured")
                    context.runtime.configure_visual_model(
                        task_id or agent_id, profiles[agent_def.visual_model])
                if agent_def.decision_model is not None:
                    from ..llm.decision_profile import configure_decision_profile

                    profiles = (self._app_config.decision_models
                                if self._app_config is not None else {})
                    configure_decision_profile(
                        context.runtime, task_id or agent_id, agent_def.decision_model,
                        profiles,
                    )
                plugin = self._registry.instantiate(agent_def.extension, dict(config))
                if not isinstance(plugin, SubAgent):
                    raise TypeError("Subagent factory must return SubAgent")
                task = next((m.get("content", "") for m in reversed(messages)
                             if m.get("role") == "user" and isinstance(m.get("content"), str)), "")
                agent = SubAgentAdapter(agent_def.name, plugin, SubAgentRequest(
                    task=task, context=system_prompt, task_id=task_id or agent_id,
                    task_input=task_input,
                ), context)
            except BaseException:
                try:
                    await join_on_cancel(context.runtime.aclose())
                finally:
                    if isinstance(plugin, SubAgent):
                        await join_on_cancel(plugin.aclose())
                raise
        else:
            # Resolve LLM: use agent-specific model profile if declared
            if agent_def.model and self._app_config is not None:
                agent_llm = self._llm_factory(
                    self._app_config.get_llm_profile(agent_def.model)
                )
                owned_grounders.append(agent_llm)
            else:
                agent_llm = self._llm

            agent_llm = task_llm(agent_llm)
            tool_manager = self._tool_manager
            if agent_def.grounding is not None:
                from dataclasses import replace

                from ..tools.computer_grounding import GroundingAdapter
                from ..tools.computer_locate import SPLIT_PROMPT, LocateSession, LocateTool

                config = agent_def.grounding
                from ..tools.computer_frame import FrameTool

                session_tools = {n: t for n, t in self._tool_manager.tools.items()
                                 if n in available_tools}
                if not isinstance(session_tools.get("screenshot"), FrameTool):
                    raise ValueError("Split grounding requires an allowed macOS screenshot tool")
                for profile in (config.profile, config.fallback_profile):
                    if profile is not None and (
                        self._app_config is None or profile not in self._app_config.llm_profiles
                    ):
                        raise ValueError(f"Unknown grounding profile: {profile}")
                llms = {"primary": agent_llm}
                for key, profile in (("primary", config.profile),
                                     ("fallback", config.fallback_profile)):
                    if profile is not None:
                        assert self._app_config is not None
                        llms[key] = self._llm_factory(self._app_config.llm_profiles[profile])
                        owned_grounders.append(llms[key])
                        llms[key] = task_llm(llms[key])
                from ..tools.computer_ax import AX_PROMPT, AXSession
                from ..tools.computer_integrated import (
                    IntegratedSession,
                    IntegratedTool,
                    integrated_prompt,
                )

                if config.mode == "ax":
                    session = AXSession(
                        session_tools, llms, context, agent_id, config.ax_action)
                else:
                    session_class = (
                        IntegratedSession if config.mode == "integrated" else LocateSession
                    )
                    tool_class = (
                        IntegratedTool if config.mode == "integrated" else LocateTool
                    )
                    session = session_class(session_tools, llms, GroundingAdapter(
                        "point" if config.protocol == "legacy" else config.protocol,
                        config.nullable_style, config.strict,
                        config.detail, config.status_field,
                    ), context, agent_id)
                    if isinstance(session, IntegratedSession):
                        session.config = config
                tool_class = (
                    IntegratedTool if config.mode == "integrated" else LocateTool
                )
                tool_manager = copy.copy(self._tool_manager)
                tool_manager.tools = dict(session_tools)
                tool_manager.tool_metadata = dict(self._tool_manager.tool_metadata)
                # Raw held-button tools bypass reference validation. Keep them out of split mode.
                for name in ("computer_batch", "mouse_down", "mouse_up"):
                    tool_manager.tools.pop(name, None)
                for name, tool in list(tool_manager.tools.items()):
                    if tool.get_metadata().category == "computer":
                        tool_manager.register_tool(tool_class(session, name))
                if config.mode in {"split", "ax"}:
                    tool_manager.register_tool(LocateTool(session, "locate"))
                tool_manager.register_tool(tool_class(session, "computer_batch"))
                tool_manager.set_session_id(agent_id)
                if tool_filter is not None and config.mode in {"split", "ax"}:
                    tool_filter.append("locate")
                available_tools = {
                    t["function"]["name"]
                    for t in tool_manager.get_openai_tools(exclude=exclude_tools)
                    if tool_filter is None or t["function"]["name"] in tool_filter
                }
                mode_prompt = (
                    AX_PROMPT if config.mode == "ax"
                    else integrated_prompt(config) if config.mode == "integrated"
                    else SPLIT_PROMPT
                )
                # Override the coordinate contract without losing task-specific instructions.
                system_prompt = self._build_sub_agent_prompt(
                    replace(
                        agent_def, system_prompt=agent_def.system_prompt + "\n\n"
                        + mode_prompt,
                    ),
                    messages, available_tools,
                )

            approval_policy: Any = self._approval_policy
            classifier = getattr(approval_policy, "_llm", None)
            if (classifier is not None
                    and callable(getattr(type(classifier), "bind_task", None))):
                approval_policy = copy.copy(approval_policy)
                approval_policy._llm = task_llm(classifier)
            if agent_def.grounding is not None:
                approval_policy = copy.copy(approval_policy)
                approval_policy._tool_metadata = tool_manager.tool_metadata
            if allowed_categories and approval_policy is not None:
                from .approval import ScopedPolicy

                approval_policy = ScopedPolicy(approval_policy, allowed_categories)
            agent = LLMAgent(
                name=f"agent_{agent_def.name}",
                llm=agent_llm,
                tool_manager=tool_manager,
                approval_policy=approval_policy,
                system_prompt=system_prompt,
                tool_filter=tool_filter,
                exclude_tools=exclude_tools,
                resolver=self._resolver,
                session_id=agent_id,
                pending_store=self._pending_store,
                bus=self._bus,
                task_context=context,
            )

        # A failed factory must not occupy a concurrent-agent slot.
        self._active_agents[agent_id] = tracker
        state = AgentState(
            messages=cast(Any, list(messages)),
            metadata={
                "agent_id": agent_id,
                "agent_name": agent_def.name,
                "parent_agent_id": parent_agent_id,
            },
        )

        logger.info(
            "AgentRunner: starting '%s' (id=%s, depth=%d, token_budget=%d, bg=%s)",
            agent_def.name, agent_id, depth, effective_budget, background,
        )
        self._post_bus_event("agent_started", agent_id, agent_def.name)

        start = time.monotonic()
        outputs = agent.run(state)
        try:
            async for output in outputs:
                # Usage is already recorded in the task context; do not forward it.
                if output.type == AgentOutputType.USAGE:
                    continue

                # Stream all outputs to caller
                yield output

        except SubAgentStopped as e:
            # A controlled stop (budget exhaustion, policy) is not an agent
            # failure: surface it as text plus structured stop metadata so
            # callers can record the reason without parsing the message.
            logger.warning(
                "Agent '%s' (id=%s) stopped: %s", agent_def.name, agent_id, e,
            )
            yield AgentOutput(
                type=AgentOutputType.TOKEN,
                content=f"\n[Agent '{agent_def.name}' stopped: {e}]",
                metadata={"stop_reason": e.reason},
            )
            if e.task_result is not None:
                yield e.task_result.to_output()
        except Exception as e:
            if agent_def.extension:
                raise
            logger.error(
                "Agent '%s' (id=%s) error: %s",
                agent_def.name, agent_id, e, exc_info=True,
            )
            yield AgentOutput(
                type=AgentOutputType.TOOL_RESULT,
                content=f"Agent error: {e!s}",
                metadata={"status": "error"},
            )
        finally:
            tracker.active = False
            close = getattr(outputs, "aclose", None)
            if close is not None:
                await close()
            if not agent_def.extension:
                await join_on_cancel(context.runtime.aclose())
            for grounder in owned_grounders:
                await grounder.client.close()
            elapsed = time.monotonic() - start
            logger.info(
                "AgentRunner: '%s' (id=%s) finished in %.1fs, %d tokens used",
                agent_def.name, agent_id, elapsed, usage.total_tokens,
            )
            self._post_bus_event("agent_finished", agent_id, agent_def.name)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_depth(self, parent_agent_id: str | None) -> int:
        """Calculate depth from parent chain."""
        if parent_agent_id is None:
            return 0
        tracker = self._active_agents.get(parent_agent_id)
        if tracker is None:
            return 1
        return tracker.depth + 1

    def _resolve_toolset(self, toolset_name: str) -> list[str] | None:
        """Resolve a toolset profile name to a tool allowlist.

        Returns None if the profile is empty (= all tools) or not found.
        """
        if not toolset_name:
            return None
        config = getattr(self, '_toolsets_config', None)
        if config is None:
            logger.warning("Toolset '%s' requested but no toolsets config available", toolset_name)
            return None
        profile = config.profiles.get(toolset_name)
        if profile is None:
            logger.warning("Toolset profile '%s' not found in config", toolset_name)
            return None
        if not profile.tools:
            return None  # Empty tools list = all tools
        return list(profile.tools)

    def _build_sub_agent_prompt(
        self,
        agent_def: AgentDefinition,
        messages: list[dict[str, Any]],
        available_tools: set[str],
    ) -> str:
        """Build a sub-agent's system prompt.

        Combines the agent definition's own prompt with workspace rules
        relevant to the task's paths and base security rules.
        """
        parts: list[str] = [agent_def.system_prompt]

        if "ask_user" in available_tools:
            parts.append(
                "--- Clarification ---\n"
                "If you need clarification from the user before you can proceed "
                "(e.g., choosing between options, missing critical info), call the "
                "`ask_user` tool with your question. Your execution will pause "
                "until the user responds. Do NOT write questions in your final "
                "output — use `ask_user` instead so the system can route the "
                "question properly and resume your work with the answer."
            )
        else:
            parts.append(
                "--- Clarification ---\n"
                "If critical information is missing and you cannot proceed, "
                "stop and report what information is needed in your final output."
            )

        # Append workspace rules relevant to paths mentioned in messages
        paths = self._extract_paths_from_messages(messages)
        workspace_rules = self._prompt_assembler.get_workspace_rules_for(paths)
        if workspace_rules:
            parts.append("--- Workspace Rules ---\n" + workspace_rules)

        # Always append base security rules
        base_rules = self._prompt_assembler.get_base_rules()
        if base_rules:
            parts.append("--- Security Rules ---\n" + base_rules)

        return "\n\n".join(parts)

    @staticmethod
    def _extract_paths_from_messages(messages: list[dict[str, Any]]) -> list[str]:
        """Extract file/directory paths from message content (simple heuristic)."""
        import re

        path_re = re.compile(r"(?:~|/)[^\s,;\"'`\]\)}>]+")
        paths: list[str] = []
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                paths.extend(path_re.findall(content))
        return paths

    def _post_bus_event(
        self, event: str, agent_id: str, agent_name: str,
    ) -> None:
        if self._bus is None:
            return
        from ..pipeline.bus import BusMessage

        self._bus.post(BusMessage(
            type="agent",
            source="agent_runner",
            payload={
                "event": event,
                "agent_id": agent_id,
                "agent_name": agent_name,
            },
            timestamp=time.time(),
        ))


class _AgentTracker:
    """Tracks an active agent for depth/concurrency enforcement."""

    __slots__ = ("agent_id", "agent_name", "parent_id", "depth", "active")

    def __init__(
        self,
        agent_id: str,
        agent_name: str,
        parent_id: str | None,
        depth: int,
    ) -> None:
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.parent_id = parent_id
        self.depth = depth
        self.active = True
