"""Tools for inspecting and controlling worker dispatches.

Phase 2 step 4 of the workflow & orchestration roadmap (see
``backend/ORCHESTRATION.md``).

Three tools, all read- or control-side companions to ``agent``:

- ``agent_status`` — inspect a single worker by ``task_id``.
- ``agent_stop``   — request cancellation of an in-flight worker.
- ``list_active_agents`` — enumerate workers currently in ``status=running``.

All three return ``ToolResult`` with a JSON-encoded ``content`` and a
short ``display`` summary, matching the rest of the tool surface.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from ..tools.base import BaseTool, ToolInfo, ToolParameter, ToolResult
from .store import WorkerStore, worker_to_dict
from .supervisor import WorkerSupervisor

logger = logging.getLogger(__name__)


class AgentStatusTool(BaseTool):
    """Inspect a worker dispatch by ``task_id``.

    Optional ``wait=True`` blocks (up to ``timeout_ms``) until the run
    reaches a terminal status. The wait is cooperative — the LLM is
    free to call other tools instead of blocking, but ``wait=True`` is
    convenient for "kick off → check back" patterns.
    """

    def __init__(self, store: WorkerStore, supervisor: WorkerSupervisor) -> None:
        self._store = store
        self._supervisor = supervisor

    def get_info(self) -> ToolInfo:
        return ToolInfo(
            name="agent_status",
            description=(
                "Get the status and output of a worker dispatched via "
                "the agent tool. Pass wait=true to block until the run "
                "reaches a terminal status."
            ),
            parameters=[
                ToolParameter(
                    name="task_id",
                    type="string",
                    description="The task_id returned by a prior agent(...) call.",
                    required=True,
                ),
                ToolParameter(
                    name="wait",
                    type="boolean",
                    description=(
                        "Block until the run is no longer 'running'. "
                        "Defaults to false."
                    ),
                    required=False,
                ),
                ToolParameter(
                    name="timeout_ms",
                    type="integer",
                    description=(
                        "Max wait time when wait=true, in milliseconds. "
                        "Default 60000 (60s)."
                    ),
                    required=False,
                ),
            ],
        )

    async def execute(self, **kwargs: Any) -> ToolResult:
        task_id = kwargs["task_id"]
        wait = bool(kwargs.get("wait", False))
        timeout_ms = int(kwargs.get("timeout_ms", 60000))

        if wait:
            run = await self._supervisor.wait(
                task_id, timeout=max(timeout_ms, 0) / 1000.0,
            )
        else:
            run = self._store.get(task_id)

        if run is None:
            return ToolResult(
                content=json.dumps(
                    {"error": f"task_id '{task_id}' not found"},
                    ensure_ascii=False,
                ),
                display=f"Task {task_id} not found.",
                error=True,
            )

        payload = worker_to_dict(run)
        return ToolResult(
            content=json.dumps(payload, ensure_ascii=False),
            display=f"Task {task_id}: {run.status}",
        )


class AgentStopTool(BaseTool):
    """Cancel an in-flight worker.

    Idempotent: stopping an already-terminal worker is not an error,
    just a no-op. The LLM can use ``agent_status`` to confirm the
    eventual terminal state.
    """

    def __init__(self, store: WorkerStore, supervisor: WorkerSupervisor) -> None:
        self._store = store
        self._supervisor = supervisor

    def get_info(self) -> ToolInfo:
        return ToolInfo(
            name="agent_stop",
            description=(
                "Cancel a worker dispatch. The worker transitions to "
                "status='cancelled' once the cancellation is observed. "
                "Idempotent — safe to call on already-finished workers."
            ),
            parameters=[
                ToolParameter(
                    name="task_id",
                    type="string",
                    description="The task_id to cancel.",
                    required=True,
                ),
            ],
        )

    async def execute(self, **kwargs: Any) -> ToolResult:
        task_id = kwargs["task_id"]
        existing = self._store.get(task_id)
        if existing is None:
            return ToolResult(
                content=json.dumps(
                    {"error": f"task_id '{task_id}' not found"},
                    ensure_ascii=False,
                ),
                display=f"Task {task_id} not found.",
                error=True,
            )
        if existing.status != "running":
            return ToolResult(
                content=json.dumps(
                    {
                        "task_id": task_id,
                        "status": existing.status,
                        "note": "already terminal",
                    },
                    ensure_ascii=False,
                ),
                display=f"Task {task_id} already {existing.status}; nothing to stop.",
            )
        cancelled = self._supervisor.stop(task_id)
        if not cancelled:
            return ToolResult(
                content=json.dumps(
                    {
                        "task_id": task_id,
                        "status": "running",
                        "note": (
                            "no in-process task; worker may be running on "
                            "another process or already winding down"
                        ),
                    },
                    ensure_ascii=False,
                ),
                display=f"Task {task_id} could not be stopped from this process.",
            )
        return ToolResult(
            content=json.dumps(
                {"task_id": task_id, "status": "cancelling"},
                ensure_ascii=False,
            ),
            display=f"Cancellation requested for task {task_id}.",
        )


class ListActiveAgentsTool(BaseTool):
    """List worker dispatches that are currently running."""

    def __init__(self, store: WorkerStore) -> None:
        self._store = store

    def get_info(self) -> ToolInfo:
        return ToolInfo(
            name="list_active_agents",
            description=(
                "List worker dispatches currently running. Returns "
                "task_id, agent_def, description, started_at for each."
            ),
            parameters=[],
        )

    async def execute(self, **_kwargs: Any) -> ToolResult:
        runs = self._store.list_active()
        items = [worker_to_dict(r, include_output=False) for r in runs]
        if not items:
            return ToolResult(
                content=json.dumps({"workers": []}, ensure_ascii=False),
                display="No active workers.",
            )
        return ToolResult(
            content=json.dumps({"workers": items}, ensure_ascii=False),
            display=f"{len(items)} active worker(s).",
        )


class AgentReplyTool(BaseTool):
    """Send an answer to a waiting worker, resuming its execution."""

    def __init__(self, store: WorkerStore, supervisor: WorkerSupervisor) -> None:
        self._store = store
        self._supervisor = supervisor

    def get_info(self) -> ToolInfo:
        return ToolInfo(
            name="agent_reply",
            description=(
                "Send an answer to a worker that asked a question "
                "(status='waiting'). The worker resumes with your answer."
            ),
            parameters=[
                ToolParameter(
                    name="task_id",
                    type="string",
                    description="The task_id of the waiting worker",
                    required=True,
                ),
                ToolParameter(
                    name="answer",
                    type="string",
                    description="Your answer to the worker's question",
                    required=True,
                ),
            ],
        )

    async def execute(self, **kwargs: Any) -> ToolResult:
        task_id = kwargs["task_id"]
        answer = kwargs["answer"]

        run = self._store.get(task_id)
        if run is None:
            return ToolResult(
                content=json.dumps(
                    {"error": f"task_id '{task_id}' not found"},
                    ensure_ascii=False,
                ),
                display=f"Task {task_id} not found.",
                error=True,
            )
        if run.status != "waiting":
            return ToolResult(
                content=json.dumps(
                    {
                        "task_id": task_id,
                        "status": run.status,
                        "error": f"Worker is '{run.status}', not 'waiting'",
                    },
                    ensure_ascii=False,
                ),
                display=f"Task {task_id} is '{run.status}', not waiting.",
                error=True,
            )

        resumed = await self._supervisor.resume_with_answer(task_id, answer)
        if not resumed:
            return ToolResult(
                content=json.dumps(
                    {"task_id": task_id, "error": "failed to resume"},
                    ensure_ascii=False,
                ),
                display=f"Failed to resume task {task_id}.",
                error=True,
            )

        return ToolResult(
            content=json.dumps(
                {"task_id": task_id, "status": "running"},
                ensure_ascii=False,
            ),
            display=f"Resumed worker {task_id} with your answer.",
        )
