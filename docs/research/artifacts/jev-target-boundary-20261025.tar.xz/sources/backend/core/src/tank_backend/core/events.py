from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, auto


@dataclass(frozen=True)
class AudioOutputRequest:
    """Single item for audio output queue: text to speak."""

    content: str
    language: str = "auto"
    voice: str | None = None
    # Assistant message id. Groups the sentence batches of one streamed
    # turn (a long reply arrives as N requests sharing one msg_id).
    msg_id: str | None = None


class InputType(Enum):
    TEXT = auto()
    AUDIO = auto()
    SYSTEM = auto()


class UpdateType(Enum):
    """Types of updates for a streaming message."""

    THOUGHT = auto()  # Thinking process
    TEXT = auto()  # Final response text
    TOOL = auto()  # Unified tool step: calling → executing → success/error
    APPROVAL = auto()  # Tool approval request pending user response
    MESSAGE = auto()  # Complete message added to conversation (for persistence)
    USAGE = auto()  # Token usage report for budget enforcement


@dataclass(frozen=True)
class SignalMessage:
    """System signal for UI state changes (e.g., processing_started, processing_ended)."""

    signal_type: str
    msg_id: str | None = None
    metadata: dict = field(default_factory=dict)


@dataclass(frozen=True)
class DisplayMessage:
    """Content message for UI display (user input, assistant response, etc.)."""

    speaker: str  # e.g. "User", "Brain", or voiceprint id
    text: str
    is_user: bool
    is_final: bool = True
    msg_id: str | None = None
    update_type: UpdateType = UpdateType.TEXT
    metadata: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ConversationMetadataUpdate:
    """Out-of-band update to a conversation's metadata (e.g. a new title).

    Carried over the same ``ui_message`` bus channel as ``SignalMessage``
    and ``DisplayMessage`` so the WebSocket forwarder can route it without
    a separate subscription. The forwarder only emits it on the matching
    session's socket — see ``api/router.py``.
    """

    conversation_id: str
    title: str | None = None


# Type alias for messages in the UI queue
UIMessage = SignalMessage | DisplayMessage | ConversationMetadataUpdate


@dataclass
class BrainInputEvent:
    type: InputType
    text: str
    user: str
    language: str | None
    confidence: float | None
    timestamp: float = field(default_factory=time.time)
    metadata: dict = field(default_factory=dict)
    # Speculative turn identity: set on audio inputs from VAD endpointing.
    # ``turn_revision > 0`` means the utterance reopens a previously
    # committed turn — the context manager replaces the original user
    # message instead of appending a second one.
    turn_id: str | None = None
    turn_revision: int = 0


class BrainInterrupted(Exception):
    """Raised when Brain LLM processing is interrupted by user speech."""
