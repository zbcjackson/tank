"""Independent result/geometry/lineage audit; run with live path, output path."""
import base64, hashlib, json, math, statistics, sys
from pathlib import Path
p=Path(sys.argv[1]); out=Path(sys.argv[2])
r=json.loads((p/'result.json').read_text()); f=json.loads((p/'freeze.json').read_text()); public=json.loads((p/'public.json').read_text()); labels=json.loads((p/'private.json').read_text()); previews=json.loads((p/'previews.json').read_text())
cases={c['id']:c for c in public['cases']}
provenance=json.loads((p/'provenance.json').read_text())
for q in provenance:
 oldroot=Path(q['original_root']); record=q['record']; info=record['images'][0]
 assert hashlib.sha256((oldroot/info['path']).read_bytes()).hexdigest()==info['sha256']
 assert (p/'images'/f"{q['source']}-base.png").read_bytes()==(oldroot/info['path']).read_bytes()
 assert (p/'images'/f"{q['source']}-full.png").read_bytes()==(oldroot/info['path']).read_bytes()
 manifest_name='jev-post-crop-live-validation-20261019-manifest.json' if q['source'].startswith('textedit') else 'jev-image-native-pilot-20261019-manifest.json'
 manifest=json.loads((Path('/Users/zbcjackson/src/tank/docs/research/artifacts')/manifest_name).read_text())
 assert manifest['files']['live/'+info['path']]['sha256']==info['sha256']
 assert manifest['files']['live/calls.jsonl']['sha256']==q['calls_sha256']
 assert hashlib.sha256((oldroot/'calls.jsonl').read_bytes()).hexdigest()==q['calls_sha256']
sha=lambda b:hashlib.sha256(b).hexdigest()
assert all(sha((p/n).read_bytes())==h for n,h in f['files'].items())
root=Path('/Users/zbcjackson/src/tank/backend')
assert all(sha((root/n).read_bytes())==h for n,h in f['source_sha256'].items())
assert [{k:v for k,v in x.items() if k in ('id','case','view','model','phase')} for x in r['rows']]==f['schedule']
calls=[json.loads(l) for l in (p/'calls.jsonl').read_text().splitlines()]; requests={x['trial']:x for x in calls if 'request'in x}; responses={x['trial']:x for x in calls if 'response'in x}
assert len(requests)==len(responses)==len(r['spend']['requests'])
assert len(calls)==2*len(requests)
usage={}; details=[]
for row in r['rows']:
 if row['status']=='not_run':continue
 cid=row['case']; case=cases[cid]; view=public['views'][case['source']][row['view']]; label=labels[cid]; n=len(label['rectangles']); expected='none' if n==0 else 'one' if n==1 else 'several'
 req=requests[row['id']]; resp=responses[row['id']]; assert req['call_id']==resp['call_id'];assert req['request']==previews[row['id']]
 png=(p/view['path']).read_bytes()
 if row['model']=='jev':
  assert req['images']==[{'sha256':sha(png),'part':'asset-0'}]
  raw=resp['response']; a={'cardinality':raw['cardinality']['choice'],'box':raw['box']}; it,ot=raw['input_tokens'],raw['output_tokens']
 else:
  for m in req['request']['messages']:
   if isinstance(m['content'],list):
    for x in m['content']:
     if x['type']=='image_url':assert base64.b64decode(x['image_url']['url'].split(',',1)[1])==png
  raw=resp['response']; text=raw['choices'][0]['message']['content']; assert text==row['raw_text']; parsed=json.loads(text);assert set(parsed)=={'cardinality','bbox_2d'}
  a={'cardinality':parsed['cardinality'],'box':None if parsed['bbox_2d'] is None else [v/1000 for v in parsed['bbox_2d']]};it,ot=raw['usage']['prompt_tokens'],raw['usage']['completion_tokens']
  usage[row['id']]={'provider':raw.get('provider'),'reported_cost_usd':raw['usage'].get('cost'),'reasoning_tokens':raw['usage'].get('completion_tokens_details',{}).get('reasoning_tokens')}
 assert a['cardinality']==row['answer']['cardinality'];assert a['box']==row['answer']['box']
 ledger=r['spend']['requests'][req['call_id']];assert ledger['input_tokens']==it and ledger['output_tokens']==ot and ledger['trial']==row['id'] and ledger['status']=='known';assert it+ot==row['known_tokens']
 # Use independent affine composition per axis to map prepared coordinates to Quartz.
 sc={'cardinality_correct':a['cardinality']==expected,'geometry_valid':True,'center_hit':False,'whole_hit':False,'correct':a['cardinality']==expected and expected!='one','screen_point':None,'offset':None,'iou':None}
 if a['cardinality']=='one':
  box=a['box'];w,h=view['size'];cl,ct,cr,cb=view['content'];rl,rt,rr,rb=view['roi']; bw,bh=label['base_size'];xl,yt,xr,yb=label['crop'];ox,oy=label['origin']
  valid=all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and 0<=v<=1 for v in box) and cl<=box[0]*w<box[2]*w<=cr and ct<=box[1]*h<box[3]*h<=cb
  sc['geometry_valid']=valid
  if valid:
   sx=(rr-rl)/(cr-cl)*(xr-xl)/bw; sy=(rb-rt)/(cb-ct)*(yb-yt)/bh
   tx=xl+ox+(rl-cl*(rr-rl)/(cr-cl))*(xr-xl)/bw;ty=yt+oy+(rt-ct*(rb-rt)/(cb-ct))*(yb-yt)/bh
   edges=[tx+sx*box[0]*w,ty+sy*box[1]*h,tx+sx*box[2]*w,ty+sy*box[3]*h]
   point=[min(xr+ox-1,math.floor(tx+sx*w*(box[0]+box[2])/2+.5)),min(yb+oy-1,math.floor(ty+sy*h*(box[1]+box[3])/2+.5))];sc['screen_point']=point
   if n==1:
    x,y,tw,th=label['rectangles'][0];inset=min(tw,th)/10;hit=x+inset<=point[0]<=x+tw-inset and y+inset<=point[1]<=y+th-inset
    sc.update(center_hit=hit,correct=hit,whole_hit=x<=point[0]<x+tw and y<=point[1]<y+th,offset=[point[0]-x-tw/2,point[1]-y-th/2])
    intersect=max(0,min(x+tw,edges[2])-max(x,edges[0]))*max(0,min(y+th,edges[3])-max(y,edges[1]));sc['iou']=intersect/(tw*th+(edges[2]-edges[0])*(edges[3]-edges[1])-intersect)
 for k,v in sc.items():
  assert math.isclose(v,row['score'][k],abs_tol=1e-10) if k=='iou' and v is not None else v==row['score'][k],(row['id'],k,v,row['score'][k])
 details.append({'id':row['id'],'case':cid,'layout':case['layout'],'model':row['model'],'view':row['view'],'phase':row['phase'],'expected':expected,'status':row['status'],'choice':a['cardinality'],'box':a['box'],**sc,'input_tokens':it,'output_tokens':ot,'elapsed_ms':row['elapsed_ms'],'cleanup_confirmed':row['cleanup_confirmed']})
assert r['spend']==json.loads((p/'spend.jsonl').read_text().splitlines()[-1])
assert sum(d['input_tokens']+d['output_tokens'] for d in details)==r['spend']['batch']['known_tokens']

def aggregate(rows):
 unique=[d for d in rows if d['expected']=='one']; lat=[d['elapsed_ms'] for d in rows]
 return {'rows':len(rows),'returned':sum(d['status']=='returned' for d in rows),'cardinality_correct':sum(d['cardinality_correct'] for d in rows),'correct':sum(d['correct'] for d in rows),'unique':len(unique),'center_hit':sum(d['center_hit'] for d in unique),'whole_hit':sum(d['whole_hit'] for d in unique),'invalid_geometry':sum(not d['geometry_valid'] for d in rows),'false_unique':sum(d['choice']=='one' and d['expected']!='one' for d in rows),'mean_iou_unique':statistics.mean(d['iou'] or 0 for d in unique) if unique else None,'mean_ms':statistics.mean(lat) if lat else None,'median_ms':statistics.median(lat) if lat else None,'input_tokens':sum(d['input_tokens'] for d in rows),'output_tokens':sum(d['output_tokens'] for d in rows)}
groups=[]
for model in ('jev','peer'):
 for view in ('full','region'):
  ds=[d for d in details if d['phase']=='main' and d['model']==model and d['view']==view];groups.append({'model':model,'view':view,**aggregate(ds)})
app_groups=[{'model':m,'view':v,'layout':a,**aggregate([d for d in details if d['model']==m and d['view']==v and d['layout']==a])}for m in ('jev','peer')for v in ('full','region')for a in ('textedit','calculator')]
models=[]
for model in ('jev','peer'):
 ds=[d for d in details if d['model']==model];g=aggregate(ds);models.append({'model':model,**g,'estimated_nano_usd':g['input_tokens']*(42 if model=='jev' else 825)+g['output_tokens']*(0 if model=='jev' else 4125)})
s={'freeze':f['sha256'],'completed':r['completed'],'stop_reason':r['spend']['stop_reason'],'planned':len(r['rows']),'requests':len(requests),'controls':aggregate([d for d in details if d['phase']=='control']),'groups':groups,'app_groups':app_groups,'models':models,'details':details,'peer_usage':usage,'cleanup_confirmed':sum(d['cleanup_confirmed'] for d in details),'desktop_operations':r['desktop_operations'],'source_files':len(f['source_sha256']),'frozen_files':len(f['files']),'unknown_requests':[cid for cid,q in r['spend']['requests'].items()if q['status']!='known'],'cost_status':r['spend']['cost_status']}
s['target_groups']=[{'target':t,'model':m,'view':v,**aggregate([d for d in details if d['phase']=='main' and d['case'].split('-',2)[2]==t and d['model']==m and d['view']==v])}for t in ('italic','typeface','equals','clear','many','absent')for m in ('jev','peer')for v in ('full','region')]
s['reported_peer_cost_usd']=sum(q['reported_cost_usd'] for q in usage.values() if q['reported_cost_usd'] is not None)
s['reasoning_tokens']=sum(q['reasoning_tokens'] or 0 for q in usage.values())
out.write_text(json.dumps(s,indent=2)+'\n'); print(json.dumps({k:v for k,v in s.items()if k not in ('details','peer_usage')},indent=2))
