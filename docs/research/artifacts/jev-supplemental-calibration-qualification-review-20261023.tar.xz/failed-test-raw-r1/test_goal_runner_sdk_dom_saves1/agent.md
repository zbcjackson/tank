---
name: ladder
extension: agent-computer-use:agent
decision-model: decision
---
Save name.
