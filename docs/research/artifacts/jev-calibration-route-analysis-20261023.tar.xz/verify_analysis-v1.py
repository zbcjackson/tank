"""Second arithmetic/denominator check, independent of analysis helpers."""
from pathlib import Path
from decimal import Decimal
import collections
import csv
import hashlib
import itertools
import json
import socket

def deny(*args, **kwargs):
    raise AssertionError('independent verification forbids network')
socket.getaddrinfo = deny
socket.socket.connect = deny
socket.socket.connect_ex = deny
ROOT = Path('/private/tmp/tank-jev-route-analysis-20261023')
raw = json.loads((ROOT / 'inputs/live/result.json').read_text())
data = json.loads((ROOT / 'derived-v2/analysis.json').read_text())
by_id = {t['id']: t for t in data['trials']}
assert len(by_id) == 96
calls_by_id = {c['call_id']: c for c in data['calls']}
assert len(calls_by_id) == 337
for row in raw['rows']:
    trial = by_id[row['id']]
    events = [e for e in row['events'] if e['kind'] == 'model_call' and e.get('phase') == 'finished']
    total = Decimal(str(row['elapsed_ms'])) / 1000
    sdk = sum((Decimal(str(e['elapsed_ms'])) / 1000 for e in events), Decimal(0))
    assert abs(total - Decimal(str(trial['elapsed_s']))) < Decimal('0.000001')
    assert abs(sdk - Decimal(str(trial['sdk_s']))) < Decimal('0.000001')
    assert abs(total - sdk - Decimal(str(trial['remainder_s']))) < Decimal('0.000001')
    assert sum(e['prompt_tokens'] + e['completion_tokens'] for e in events) == trial['tokens']
    assert len(events) == trial['calls'] == len(row['calls'])
    for event in events:
        call = calls_by_id[event['call_id']]
        assert call['provider'] == ('jev' if event['purpose'] == 'computer_use.jev' else 'peer')
        assert (call['call_class'] == 'visual_fallback') == (event['purpose'] == 'computer_use.visual_fallback')
        assert abs(call['sdk_s'] * 1000 - event['elapsed_ms']) < 1e-6
    routes = collections.Counter(e['reason'] for e in row['events'] if e['kind'] == 'computer_use_route')
    assert routes['jev_eligible'] == trial['eligible_steps']
    assert routes['visual_required'] == trial['ineligible_steps']
for record in data['strata']:
    rows = [r for r in raw['rows'] if r['arm'] == record['arm']
            and (record['product'] == 'all' or r['product'] == record['product'])
            and (record['condition'] == 'all' or r['condition'] == record['condition'])
            and (record['group'] == 'all' and r['group'] != 'negative'
                 or record['group'] != 'all' and r['group'] == record['group'])]
    assert len(rows) == record['n']
    mean = sum(Decimal(str(r['elapsed_ms'])) for r in rows) / len(rows) / 1000
    assert abs(mean - Decimal(str(record['elapsed_s_mean']))) < Decimal('0.000001')
with (ROOT / 'derived-v2/trials.csv').open() as stream:
    csv_rows = list(csv.DictReader(stream))
assert len(csv_rows) == 96 and {r['id'] for r in csv_rows} == set(by_id)
for row in csv_rows:
    assert abs(float(row['elapsed_s']) - by_id[row['id']]['elapsed_s']) < 1e-12
pairs = data['pairs']
assert len(pairs) == 48 and len({p['case'] for p in pairs}) == 48
assert len({p['cluster_id'] for p in pairs if p['positive']}) == 20
checks = 0
for product, condition, positive in itertools.product(('all', 'sqlite-web', 'linkding'),
                                                    ('all', 'cold', 'prewarmed'), (True, False)):
    base = [p for p in pairs if (product == 'all' or p['product'] == product)
            and (condition == 'all' or p['condition'] == condition) and p['positive'] == positive]
    for path in ['all', *sorted({p['jt_path'] for p in base})]:
        selected = [p for p in base if path == 'all' or p['jt_path'] == path]
        assert selected
        ids = {p['case'] for p in selected}
        rows = [r for r in data['trials'] if r['case'] in ids]
        assert len(rows) == 2 * len(selected)
        assert sum(r['arm'] == 'v' for r in rows) == sum(r['arm'] == 'jt' for r in rows)
        checks += 1
assert sum(t['tokens'] for t in data['trials']) == 4412681
assert all(t['success'] for t in data['trials'])
assert all(t['remainder_s'] >= 0 for t in data['trials'])
report = {'raw_task_events_recomputed': 96, 'raw_model_events_recomputed': 337,
          'strata_recomputed': len(data['strata']), 'csv_rows_verified': 96,
          'paired_filter_cases': checks, 'matched_conditions': 48, 'seed_clusters': 24,
          'positive_seed_clusters': 20, 'network_attempts': 0}
(ROOT / 'independent-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
