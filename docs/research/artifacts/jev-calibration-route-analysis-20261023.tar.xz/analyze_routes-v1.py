"""Descriptive re-analysis of frozen records; no execution or model imports."""
from pathlib import Path
from urllib.parse import urlsplit
import collections
import csv
import hashlib
import json
import math
import socket
import statistics

def deny(*args, **kwargs):
    raise AssertionError('offline analysis forbids network')
socket.getaddrinfo = deny
socket.socket.connect = deny
socket.socket.connect_ex = deny

ROOT = Path('/private/tmp/tank-jev-route-analysis-20261023')
INPUT = ROOT / 'inputs/live'
OUT = ROOT / 'derived-v1'
OUT.mkdir(exist_ok=False)
source = json.loads((INPUT / 'result.json').read_text())
frozen = json.loads((INPUT / 'freeze.json').read_text())
cases = {case['id']: case for case in frozen['cases']}
ledger = source['spend']['requests']
assert source['sha256'] == frozen['sha256'] and source['completed'] is True
assert source['spend']['stop_reason'] is None
assert len(source['rows']) == 96 and len(cases) == 48
assert [r['id'] for r in source['rows']] == [s['id'] for s in frozen['schedule']]
controls = {'none', 'ambiguous', 'need_more_context', 'escalate'}
calls = []
steps = []
trials = []
seen = set()
def unique_object(pairs):
    value = {}
    for key, item in pairs:
        assert key not in value
        value[key] = item
    return value
def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
def candidate_identity(candidate, packet):
    effects = [
        ('checkbox:checked' if candidate['role'] == 'checkbox'
         and (fact['key'].startswith('dom:checked:') or fact['key'] == 'checkbox:' + candidate['label'])
         else fact['key'], fact['value'])
        for fact in candidate['effect']
    ]
    checks = packet['state']['value_change_checks']
    changes = [(checks[k]['key'], checks[k]['source_ref'], checks[k]['before'])
               for k in candidate.get('change_refs', [])]
    return encoded([candidate['role'], candidate['label'], candidate['ancestors'],
                    candidate['current_value'], candidate['input_key'], effects, changes])
def phase_of(path, candidates):
    if len(candidates) == 1 and next(iter(candidates.values()))['label'] == 'Retry':
        return 'retry'
    if '/edit' in path or '/update/' in path:
        return 'editor'
    if path in ('/', '/bookmarks', '/bookmarks/', '/work_items/'):
        return 'list'
    return 'other'
for raw in source['rows']:
    case = cases[raw['case']]
    assert raw['attempted'] is True and raw['status'] == 'finished'
    assert raw['cleanup_confirmed'] is True
    assert raw['strict_completed'] is True if not case['negative'] else raw['negative_passed'] is True
    journal_path = INPUT / raw['id'] / 'calls.jsonl'
    journal = [json.loads(line) for line in journal_path.read_text().splitlines()]
    requested = [item for item in journal if 'request' in item]
    responses = {item['call_id']: item['response'] for item in journal if 'response' in item}
    assert requested == raw['calls'] and len(journal) == len(requested) * 2
    assert len(responses) == len(requested)
    starts = {}
    finishes = {}
    route_events = {}
    active = None
    for index, event in enumerate(raw['events']):
        if event['kind'] == 'computer_use_route':
            assert event['observation_id'] not in route_events
            route_events[event['observation_id']] = (index, event)
        if event['kind'] != 'model_call':
            continue
        cid = event['call_id']
        if event['phase'] == 'started':
            assert active is None and cid not in starts
            starts[cid] = index
            active = cid
        elif event['phase'] == 'finished':
            assert active == cid and cid not in finishes
            finishes[cid] = (index, event)
            active = None
    assert active is None and set(starts) == set(finishes) == set(responses)
    row_calls = []
    row_steps = {}
    for request_index, item in enumerate(requested):
        cid = item['call_id']
        assert cid not in seen
        seen.add(cid)
        request = item['request']
        peer = 'messages' in request
        provider = 'peer' if peer else 'jev'
        packet = json.loads(request['messages'][1]['content'][0]['text']) if peer else request
        snap = packet['state']['snapshot']
        oid = snap['observation_id']
        route_index, route = route_events[oid]
        finish_index, event = finishes[cid]
        assert route_index < starts[cid] < finish_index
        assert event['status'] == 'returned' and request['model'] == frozen['models'][provider]['model']
        assert ledger[cid]['status'] == 'known' and ledger[cid]['trial'] == raw['id']
        reply = responses[cid]
        if peer:
            assert len(reply['choices']) == 1 and reply['choices'][0]['finish_reason'] == 'stop'
            message = reply['choices'][0]['message']
            assert not message.get('refusal') and not message.get('tool_calls')
            response = json.loads(message['content'], object_pairs_hook=unique_object)
            assert isinstance(response, dict) and set(response) == {'choice'}
            choice = response['choice']
            usage = reply['usage']
            inputs, outputs = usage['prompt_tokens'], usage['completion_tokens']
            assert len(item['images']) == 1
        else:
            choice = reply['choice']
            inputs, outputs = reply['input_tokens'], reply['output_tokens']
            assert not item['images']
        assert type(inputs) is int and type(outputs) is int and inputs >= 0 and outputs >= 0
        assert (inputs, outputs) == (event['prompt_tokens'], event['completion_tokens'])
        assert (inputs, outputs) == (ledger[cid]['input_tokens'], ledger[cid]['output_tokens'])
        offered = packet['questions']['next_action']['criteria']
        assert isinstance(choice, str) and choice in offered
        candidates = {key: value for key, value in offered.items() if isinstance(value, dict)}
        facts = {fact['key']: fact['value'] for fact in snap['facts']}
        path = urlsplit(facts['status:Page URL']).path
        phase = phase_of(path, candidates)
        identities = collections.defaultdict(list)
        for alias, candidate in candidates.items():
            identities[candidate_identity(candidate, packet)].append(alias)
        duplicate_groups = [aliases for aliases in identities.values() if len(aliases) > 1]
        generic = [alias for alias, c in candidates.items() if not c['label'].strip() or c['label'] == c['role']]
        assert (bool(duplicate_groups or generic)) == (route['reason'] == 'visual_required')
        if not peer:
            call_class = 'jev_text'
            assert route['reason'] == 'jev_eligible' and raw['arm'] == 'jt'
        elif event['purpose'] == 'computer_use.visual_fallback':
            call_class = 'visual_fallback'
            assert raw['arm'] == 'jt' and route['reason'] == 'jev_eligible'
            previous = row_calls[-1]
            assert previous['provider'] == 'jev' and previous['choice'] in controls and previous['observation_id'] == oid
            prior_packet = requested[request_index - 1]['request']
            assert prior_packet['state'] == packet['state'] and prior_packet['questions'] == packet['questions']
        elif route['reason'] == 'visual_required':
            call_class = 'visual_direct_ineligible'
        else:
            assert raw['arm'] == 'v' and route['reason'] == 'jev_eligible'
            call_class = 'visual_baseline_eligible'
        call = {
            'trial_id': raw['id'], 'case': raw['case'], 'cluster_id': raw['cluster_id'],
            'product': raw['product'], 'condition': raw['condition'], 'group': raw['group'],
            'scenario': case['kind'], 'positive': not bool(case['negative']), 'arm': raw['arm'],
            'call_id': cid, 'observation_id': oid, 'provider': provider,
            'route_reason': route['reason'], 'call_class': call_class, 'purpose': event['purpose'],
            'page_path': path, 'page_phase': phase, 'candidate_count': len(candidates),
            'duplicate_group_count': len(duplicate_groups),
            'duplicate_labels': sorted({candidates[aliases[0]]['label'] for aliases in duplicate_groups}),
            'generic_candidate_count': len(generic),
            'choice': choice, 'control': choice in controls,
            'chosen_label': candidates[choice]['label'] if choice in candidates else None,
            'chosen_operation': candidates[choice]['operation'] if choice in candidates else None,
            'image': peer, 'input_tokens': inputs, 'output_tokens': outputs,
            'sdk_s': event['elapsed_ms'] / 1000,
        }
        calls.append(call)
        row_calls.append(call)
        if oid not in row_steps:
            step = {k: call[k] for k in ('trial_id', 'case', 'cluster_id', 'product', 'condition',
                'group', 'scenario', 'positive', 'arm', 'observation_id', 'route_reason',
                'page_path', 'page_phase', 'candidate_count', 'duplicate_group_count',
                'duplicate_labels', 'generic_candidate_count')}
            step.update(call_ids=[], call_classes=[], sdk_s=0.0)
            row_steps[oid] = step
        step = row_steps[oid]
        step['call_ids'].append(cid)
        step['call_classes'].append(call_class)
        step['sdk_s'] += call['sdk_s']
    assert set(row_steps) == set(route_events)
    steps.extend(row_steps.values())
    sdk = sum(c['sdk_s'] for c in row_calls)
    total = raw['elapsed_ms'] / 1000
    assert sdk <= total + .001
    observed = [e for e in raw['events'] if e['kind'] == 'computer_use_observe' and e.get('phase') == 'returned']
    observe_s = sum(e['elapsed_ms'] for e in observed) / 1000
    assert observe_s <= total - sdk + .001
    counts = collections.Counter(c['call_class'] for c in row_calls)
    timing = {name: sum(c['sdk_s'] for c in row_calls if c['call_class'] == name)
              for name in ('jev_text', 'visual_direct_ineligible', 'visual_baseline_eligible', 'visual_fallback')}
    path_class = ('visual_baseline' if raw['arm'] == 'v' else
                  'control_then_visual' if counts['visual_fallback'] else
                  'mixed_text_visual' if counts['jev_text'] and sum(c['image'] for c in row_calls) else
                  'text_only' if counts['jev_text'] else 'visual_bypass_only')
    trial = {k: raw[k] for k in ('id', 'case', 'cluster_id', 'condition', 'product', 'group')}
    trial.update(scenario=case['kind'], positive=not bool(case['negative']), arm=raw['arm'],
                 success=raw['strict_completed'] if not case['negative'] else raw['negative_passed'],
                 elapsed_s=total, capped_s=raw['capped_completion_ms'] / 1000,
                 sdk_s=sdk, remainder_s=total - sdk, observed_s=observe_s,
                 incomplete_observations=sum(e.get('complete') is not True for e in observed),
                 calls=len(row_calls), images=sum(c['image'] for c in row_calls),
                 jev=counts['jev_text'], fallbacks=counts['visual_fallback'],
                 eligible_steps=sum(s['route_reason'] == 'jev_eligible' for s in row_steps.values()),
                 ineligible_steps=sum(s['route_reason'] == 'visual_required' for s in row_steps.values()),
                 path_class=path_class, sdk_by_class_s=timing,
                 tokens=sum(c['input_tokens'] + c['output_tokens'] for c in row_calls),
                 call_ids=[c['call_id'] for c in row_calls])
    assert raw['usage']['total_tokens'] == trial['tokens'] and raw['usage']['unknown_calls'] == 0
    trials.append(trial)
assert len(calls) == len(seen) == len(ledger) == 337
assert len(steps) == 336 and sum(c['image'] for c in calls) == 279
assert sum(c['provider'] == 'jev' for c in calls) == 58
assert sum(t['tokens'] for t in trials) == source['spend']['batch']['known_tokens'] == 4412681
assert sum(t['positive'] for t in trials) == 80 and all(t['success'] for t in trials)
assert len({t['cluster_id'] for t in trials}) == 24
pairs = []
for cid in cases:
    v, jt = [next(t for t in trials if t['case'] == cid and t['arm'] == arm) for arm in ('v', 'jt')]
    pair = {'case': cid, 'cluster_id': v['cluster_id'], 'product': v['product'],
            'condition': v['condition'], 'group': v['group'], 'scenario': v['scenario'],
            'positive': v['positive'], 'jt_path': jt['path_class'],
            'v_id': v['id'], 'jt_id': jt['id'], 'v_s': v['elapsed_s'], 'jt_s': jt['elapsed_s'],
            'delta_s': jt['elapsed_s'] - v['elapsed_s'],
            'sdk_delta_s': jt['sdk_s'] - v['sdk_s'],
            'remainder_delta_s': jt['remainder_s'] - v['remainder_s'],
            'image_delta': jt['images'] - v['images'], 'v_images': v['images'], 'jt_images': jt['images']}
    assert abs(pair['delta_s'] - pair['sdk_delta_s'] - pair['remainder_delta_s']) < 1e-9
    pairs.append(pair)
def aggregate(selected):
    result = {'n': len(selected), 'seed_clusters': len({t['cluster_id'] for t in selected}),
              'success': sum(t['success'] for t in selected)}
    for key in ('elapsed_s', 'sdk_s', 'remainder_s', 'observed_s', 'calls', 'images', 'jev',
                'fallbacks', 'eligible_steps', 'ineligible_steps', 'tokens'):
        result[key + '_sum'] = sum(t[key] for t in selected)
        result[key + '_mean'] = result[key + '_sum'] / len(selected)
    result['sdk_by_class_mean_s'] = {key: sum(t['sdk_by_class_s'][key] for t in selected) / len(selected)
                                   for key in selected[0]['sdk_by_class_s']}
    result['median_s'] = statistics.median(t['elapsed_s'] for t in selected)
    result['p95_s'] = sorted(t['elapsed_s'] for t in selected)[math.ceil(.95 * len(selected)) - 1]
    return result
strata = []
for product in ('all', 'sqlite-web', 'linkding'):
    for condition in ('all', 'cold', 'prewarmed'):
        for group in ('all', 'normal', 'recovery', 'negative'):
            for arm in ('v', 'jt'):
                selected = [t for t in trials if t['arm'] == arm
                            and (product == 'all' or t['product'] == product)
                            and (condition == 'all' or t['condition'] == condition)
                            and (group == 'all' and t['positive'] or group != 'all' and t['group'] == group)]
                if selected:
                    strata.append({'product': product, 'condition': condition, 'group': group,
                                   'arm': arm, 'cohort': 'negative' if group == 'negative' else 'positive',
                                   **aggregate(selected)})
summary = {
    'input_archive_sha256': '11d5c73c56b1637349fa5984d5e1243e0d08e9442654d9b0e3c3c80a2bb1a972',
    'freeze_sha256': frozen['sha256'], 'trials': len(trials), 'seed_clusters': 24,
    'positive_trials': 80, 'negative_trials': 16, 'paired_conditions': len(pairs),
    'sdk_calls': len(calls), 'images': 279, 'jev_calls': 58, 'fallbacks': 1, 'known_tokens': 4412681,
    'route_steps': len(steps), 'description_only': True, 'formal_N': None,
    'no_network_or_credentials': True,
    'sdk_time_definition': 'Serialized model-call boundary; includes network/provider service and local SDK/capture/accounting overhead.',
    'remainder_definition': 'Task elapsed minus non-overlapping SDK boundary sums; contains setup/observe/capture/dispatch/cleanup/readback and other unseparated work.',
    'limitations': ['Selected fixed application/template calibration; 24 clusters, not 96 independent samples.',
                    'Route-path subsets are post-treatment descriptions, not randomized causal effects.',
                    'Provider/cache state uncontrolled; residual is not isolated host CPU time.',
                    'No invoice/current pricing, no formal adoption, image/Box quality or new model comparison.'],
}
data = {'summary': summary, 'trials': trials, 'calls': calls, 'steps': steps, 'pairs': pairs, 'strata': strata}
(OUT / 'analysis.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
for name, rows in [('trials', trials), ('calls', calls), ('steps', steps), ('pairs', pairs), ('strata', strata)]:
    (OUT / (name + '.json')).write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    with (OUT / (name + '.csv')).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: encoded(v) if isinstance(v, (dict, list)) else v for k, v in row.items()})
print(json.dumps(summary, ensure_ascii=False))
print(json.dumps([s for s in strata if s['condition'] == 'all' and s['group'] == 'all'], ensure_ascii=False))
