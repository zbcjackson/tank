"""Read whitelisted immutable data/source text; never execute archived code."""
from pathlib import Path
import hashlib
import json
import os
import socket
import tarfile

def deny(*args, **kwargs):
    raise AssertionError('offline input reading forbids network')
socket.getaddrinfo = deny
socket.socket.connect = deny
socket.socket.connect_ex = deny

ROOT = Path('/private/tmp/tank-jev-route-analysis-20261023')
REPO = Path('/Users/zbcjackson/src/tank')
ARCHIVE = REPO / 'docs/research/artifacts/jev-calibration-route-20261021.tar.xz'
MANIFEST = ARCHIVE.with_name('jev-calibration-route-20261021-xz-manifest.json')
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(1048576), b''):
            h.update(data)
    return h.hexdigest()
manifest = json.loads(MANIFEST.read_text())
assert sha(ARCHIVE) == manifest['sha256'] == '11d5c73c56b1637349fa5984d5e1243e0d08e9442654d9b0e3c3c80a2bb1a972'
index = {item['name']: item for item in manifest['members']}
assert len(index) == len(manifest['members'])
wanted = {
    name for name in index
    if name in {'live/result.json', 'live/freeze.json', 'support/tank-calibration-analyze.py'}
    or name.startswith('live/source/')
    or name.startswith('live/') and name.count('/') == 2
       and name.rsplit('/', 1)[-1] in {'row.json', 'calls.jsonl', 'calibration-receipt.json'}
}
def resolve(name):
    seen = set()
    while 'hardlink_to' in index[name]:
        assert name not in seen
        seen.add(name)
        name = index[name]['hardlink_to']
    return name
targets = {resolve(name) for name in wanted}
payloads = ROOT / 'payloads'
payloads.mkdir()
found = {}
with tarfile.open(ARCHIVE, 'r|xz') as bundle:
    for member in bundle:
        if member.name not in targets:
            continue
        assert member.isfile()
        stream = bundle.extractfile(member)
        assert stream is not None
        path = payloads / index[member.name]['sha256']
        value = hashlib.sha256()
        with path.open('xb') as output:
            for data in iter(lambda: stream.read(1048576), b''):
                output.write(data)
                value.update(data)
        assert value.hexdigest() == index[member.name]['sha256']
        assert path.stat().st_size == index[member.name]['bytes']
        found[member.name] = path
assert set(found) == targets
inputs = ROOT / 'inputs'
for name in sorted(wanted):
    target = inputs / name
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.is_absolute() or inputs in target.parents
    os.link(found[resolve(name)], target)
    assert sha(target) == index[name]['sha256']
bindings = {name: index[name] for name in sorted(wanted)}
(ROOT / 'input-member-bindings.json').write_text(json.dumps(bindings, indent=2) + '\n')
old = sorted((REPO / 'docs/research/artifacts').iterdir())
assert len(old) == 66 and all(path.is_file() for path in old)
(ROOT / 'prior-artifacts66-sha256.json').write_text(json.dumps({p.relative_to(REPO).as_posix(): sha(p) for p in old}, indent=2) + '\n')
report = {'archive_sha256': manifest['sha256'], 'manifest_sha256': sha(MANIFEST),
          'selected_members': len(wanted), 'resolved_regular_payloads': len(targets),
          'old_artifacts': len(old), 'network_attempts': 0, 'archived_code_executed': False}
(ROOT / 'input-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
