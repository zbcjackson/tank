"""Independent before/after DB, UI, HTTP, SDK and ledger audit. No host scorer imports."""
import argparse,base64,copy,hashlib,json,math,os,sqlite3,statistics
from contextlib import closing
from decimal import Decimal
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);p.add_argument('--mode',choices=('fake','live'),required=True);a=p.parse_args();root=a.root
h=lambda b:hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def physical(path,product):
 with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True))as db:
  assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';db.row_factory=sqlite3.Row;db.execute('BEGIN');schema=[list(r)for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
  if product=='sqlite-web':return {'records':[dict(r)for r in db.execute('SELECT * FROM work_items ORDER BY id')],'writes':[dict(r)for r in db.execute('SELECT * FROM _writes ORDER BY rowid')],'schema':schema}
  names=[r[0]for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'bookmarks_%' ORDER BY name")];assert len(names)==10;tables={n:[dict(r)for r in db.execute('SELECT * FROM '+n+' ORDER BY rowid')]for n in names};tags={r['id']:r['name']for r in tables['bookmarks_tag']};records=[]
  for r in tables['bookmarks_bookmark']:
   q={k:r[k]for k in('id','url','title','description','notes','owner_id')};q.update({k:bool(r[k])for k in('unread','shared','is_archived')});q['tag_names']=sorted(tags[x['tag_id']]for x in tables['bookmarks_bookmark_tags']if x['bookmark_id']==r['id']);records.append(q)
  return {'records':records,'tables':tables,'schema':schema}
def canonical(x,product):return {**x,('records'if product=='linkding'else'rows'):sorted(x['records'],key=lambda r:r['id'])if product=='linkding'else sorted(x['rows'])}
def declared(expected,actual):
 if isinstance(expected,dict):return isinstance(actual,dict)and all(k in actual and declared(v,actual[k])for k,v in expected.items())
 if isinstance(expected,list):return isinstance(actual,list)and len(expected)==len(actual)and all(declared(x,y)for x,y in zip(expected,actual))
 return expected==actual
def response_choice(reply,peer):
 def unique(pairs):
  value={}
  for key,item in pairs:
   if key in value:raise ValueError('duplicate choice key')
   value[key]=item
  return value
 try:
  if peer:
   choices=reply['choices']
   if len(choices)!=1:raise ValueError('one completion required')
   completion=choices[0];message=completion['message']
   if completion['finish_reason']!='stop' or message.get('refusal') or message.get('tool_calls') or message.get('function_call'):raise ValueError('incomplete completion')
   value=json.loads(message['content'],object_pairs_hook=unique)
  else:value={'choice':reply['choice']}
  if not isinstance(value,dict) or set(value)!={'choice'} or not isinstance(value['choice'],str):raise ValueError('one string choice required')
  return value['choice'],None
 except (ValueError,TypeError,KeyError,IndexError,AttributeError):return None,'invalid_response'
f=json.loads((root/'freeze.json').read_text());assert h(encoded({k:v for k,v in f.items()if k!='sha256'}).encode())==f['sha256'];result=json.loads((root/'result.json').read_text());assert result['sha256']==f['sha256'];assert len(result['rows'])==len(f['schedule'])==96 and len(f['cases'])==48
for name,digest in f['source_sha256'].items():assert h((root/'source'/name).read_bytes())==digest
rows=[];calls=[];all_ids=set();unknown=[];ledger=result['spend']['requests']
for schedule,row in zip(f['schedule'],result['rows']):
 assert all(row[k]==v for k,v in schedule.items());case=next(c for c in f['cases']if c['id']==row['case']);product=case['product'];d=root/row['id'];item={k:row[k]for k in('id','case','arm','cluster_id','condition','product','group','status')};item.update(positive=not bool(case['negative']),strict=False,negative_passed=False,capped_ms=120000,cleanup=row['cleanup_confirmed'],calls=[],attempted=row.get('attempted',row['status']!='not_run'))
 if row['status']=='not_run':rows.append(item);continue
 before=physical(d/'before.db',product)if(d/'before.db').exists()else None;after=physical(d/'after.db',product)if(d/'after.db').exists()else None;business=schema=list_match=editor_seen=path_match=False;target=None;posts=[];observations=row.get('product_observations',[]);steps=row.get('result',{}).get('details',{}).get('progress',{}).get('recent_steps',[])
 goal=case['goal'];identity=goal['outcomes'][0]['conditions'][0]['key'].removeprefix('status:Editor seen:');target_id=int(identity.rsplit('/',1)[-1]);title=next(x['value']for x in goal['inputs']if x['key']=='title')
 if before is not None and after is not None:
  assert before==row['database_before']and after==row['database'];assert len(before['records'])==4;schema=before['schema']==after['schema'];target=next((r for r in before['records']if r['id']==target_id),None);expected=copy.deepcopy(before)
  if not case['negative']:
   assert target is not None
   next(r for r in expected['records']if r['id']==target_id)['title']=title
   if product=='sqlite-web':
    expected['writes']=after['writes'];writes=after['writes'];business=len(writes)==1 and writes[0]['operation']=='update'and writes[0]['id']==target_id
   else:
    old=next(r for r in expected['tables']['bookmarks_bookmark']if r['id']==target_id);new=next(r for r in after['tables']['bookmarks_bookmark']if r['id']==target_id);business=new['date_modified']>old['date_modified'];old.update(title=title,date_modified=new['date_modified'])
   business=bool(business and expected==after)
  else:business=before==after
  http=row['http'];posts=[(i,v)for i,v in enumerate(http)if v['method']=='POST'];list_path='/bookmarks'if product=='linkding'else'/work_items/content/';edit_path=f'/bookmarks/{target_id}/edit'if product=='linkding'else'/work_items/update/'+base64.urlsafe_b64encode(f'[{target_id}]'.encode()).decode().rstrip('=')+'/'
  lists=[i for i,v in enumerate(http)if v['method']=='GET'and v['path']==list_path and str(v['status']).startswith('200 ')];edits=[i for i,v in enumerate(http)if v['method']=='GET'and v['path']==edit_path and str(v['status']).startswith('200 ')];path_match=bool(len(posts)==1 and posts[0][1]['path']==edit_path and str(posts[0][1]['status']).startswith('302 ')and any(i<j<posts[0][0]for i in lists for j in edits)and any(i>posts[0][0]for i in lists))
  faults=[v for v in http if v['injected']];assert len(faults)<=(1 if case['recovery']else 0);assert all(v['method']=='GET'and str(v['status']).startswith('503 ')for v in faults)
  for o in observations:
   if product=='linkding':e=o['editor'];editor_seen|=bool(e and e['id']==str(target_id)and e['url']==identity and o['list']['path']==edit_path)
   else:editor_seen|=o['editor_id']==str(target_id)and o['list']['path']==edit_path
  if row.get('list_readback'):
   wanted_rows=copy.deepcopy(before['records'])
   for r in wanted_rows:
    if r['id']==target_id:r['title']=title
   if product=='linkding':wanted={'path':list_path,'records':[{'id':str(r['id']),'title':r['title'],'url':r['url'],'description':'keep | '+r['description']}for r in wanted_rows]}
   else:wanted={'path':list_path,'columns':['id','title','notes'],'rows':[[str(r[k])for k in('id','title','notes')]for r in wanted_rows]}
   list_match=canonical(row['list_readback'],product)==canonical(wanted,product)
  strict=bool(not case['negative']and row['status']=='finished'and row.get('result',{}).get('status')=='completed'and row['cleanup_confirmed']and row['app_unchanged']and row.get('trial_source_unchanged',True)and row['elapsed_ms']<=120000 and business and schema and list_match and editor_seen and path_match)
  negative=False
  negative_eligible=bool(row['status']=='finished'and row['cleanup_confirmed']and row['app_unchanged']and row.get('trial_source_unchanged',product!='linkding')and row['elapsed_ms']<=120000)
  if case['negative']=='missing':negative=bool(negative_eligible and business and target is None and not posts and row.get('result',{}).get('reason')in('none','escalate')and not any(s['dispatch_status']in('sent','unknown')for s in steps))
  if case['negative']=='revoked':negative=bool(negative_eligible and business and editor_seen and not posts and row.get('revocation',{}).get('before_native_dispatch')and row['revocation']['path']==edit_path and row.get('result',{}).get('reason')=='error')
  assert strict==row['strict_completed']and negative==row.get('negative_passed',False),f'acceptance disagreement:{row["id"]}'
  item.update(strict=strict,negative_passed=negative,business=business,schema=schema,list_match=list_match,editor_seen=editor_seen,path_match=path_match,posts=len(posts),faults=len(faults))
 raw=[json.loads(line)for line in(d/'calls.jsonl').read_text().splitlines()]if(d/'calls.jsonl').exists()else[];responses={q['call_id']:q['response']for q in raw if'response'in q};reply_indices={q['call_id']:i for i,q in enumerate(raw)if'response'in q};started={e['call_id']for e in row.get('events',[])if e['kind']=='model_call'and e.get('phase')=='started'};finished={e['call_id']:e for e in row.get('events',[])if e['kind']=='model_call'and e.get('phase')=='finished'};observed={o['observation_id']:o for o in observations};controls={};model_ms=known=0
 for index,q in enumerate(raw):
  if'request'not in q:continue
  cid=q['call_id'];assert cid not in all_ids;all_ids.add(cid);req=q['request'];peer='messages'in req;packet=json.loads(req['messages'][1]['content'][0]['text'])if peer else req;assert req['model']==f['models']['peer'if peer else'jev']['model'];assert declared(goal,packet['state']['goal']);assert 'private_acceptance'not in encoded(packet)and 'oracle'not in encoded(packet);snap=packet['state']['snapshot'];o=observed[snap['observation_id']];facts={v['key']:v['value']for v in snap['facts']};assert json.loads(facts['status:Records'])==o['records'];key='status:List records'if product=='linkding'else'status:List rows';assert json.loads(facts[key])==canonical(o['list'],product);history=o['seen_editor_urls']if product=='linkding'else o['seen_editors'];assert {k.removeprefix('status:Editor seen:')for k,v in facts.items()if k.startswith('status:Editor seen:')and v=='true'}==set(history)
  event=finished.get(cid,{});attempted=cid in started and event.get('status')!='not_started';offered=packet['questions']['next_action']['criteria'];call={'call_id':cid,'model':'peer'if peer else'jev','purpose':event.get('purpose'),'phase':o['list']['path'],'observation_id':snap['observation_id'],'attempted':attempted,'choice':None,'label':None,'known_tokens':None,'input_tokens':None,'output_tokens':None,'image':False,'sdk_ms':event.get('elapsed_ms'),'reported_peer_cost_usd':None,'fallback_from':None}
  if peer:
   imgs=[v for m in req['messages']if isinstance(m['content'],list)for v in m['content']if v['type']=='image_url'];assert len(imgs)==len(q['images'])==1;data=base64.b64decode(imgs[0]['image_url']['url'].split(',',1)[1],validate=True);assert data==(d/q['images'][0]['path']).read_bytes()and h(data)==q['images'][0]['sha256'];assert data[:8]==b'\x89PNG\r\n\x1a\n';assert [int.from_bytes(data[k:k+4],'big')for k in(16,20)]==[1280,720];candidates={k:v for k,v in offered.items()if isinstance(v,dict)};assert set(packet['image_candidates'])==set(candidates)
   for x,y,w,ht in packet['image_candidates'].values():assert 0<=x<x+w<=1280 and 0<=y<y+ht<=720
   call.update(image=True,image_path=q['images'][0]['path'],image_sha256=h(data),bounds=packet['image_candidates'])
  if attempted:
   assert cid in ledger and ledger[cid]['trial']==row['id'];i,u=event.get('prompt_tokens'),event.get('completion_tokens')
   if type(i)is int and type(u)is int:
    assert i>=0 and u>=0 and ledger[cid]['input_tokens']==i and ledger[cid]['output_tokens']==u;call.update(known_tokens=i+u,input_tokens=i,output_tokens=u);known+=i+u;rates=f['price_nano_usd']['peer'if peer else'jev'];call['estimate_nano_usd']=i*rates[0]+u*rates[1]
   else:unknown.append(cid)
  reply=responses.get(cid);binding=encoded(packet['state']['binding'])
  if reply is not None:
   choice,invalid=response_choice(reply,peer);call.update(choice=choice,label=offered[choice].get('label')if isinstance(offered.get(choice),dict)else None,valid_choice=invalid is None and choice in offered,invalid_response=invalid);assert reply_indices[cid]>index
   if call['known_tokens']is not None:
    usage=reply['usage']if peer else {'prompt_tokens':reply['input_tokens'],'completion_tokens':reply['output_tokens']};assert usage['prompt_tokens']==call['input_tokens']and usage['completion_tokens']==call['output_tokens']
    if peer and usage.get('cost')is not None:call['reported_peer_cost_usd']=str(usage['cost'])
   if not peer and choice in('none','ambiguous','need_more_context','escalate'):controls[binding]={'call_id':cid,'packet':packet,'index':reply_indices[cid]}
  if peer and call['purpose']=='computer_use.visual_fallback':
   previous=controls[binding];assert previous['index']<index and previous['packet']['state']==packet['state']and previous['packet']['questions']==packet['questions'];call['fallback_from']=previous['call_id']
  if call['sdk_ms']is not None:model_ms+=call['sdk_ms']
  calls.append(call);item['calls'].append(call)
 if'usage'in row:assert row['usage']['total_tokens']==known and row['usage']['unknown_calls']==sum(c['attempted']and c['known_tokens']is None for c in item['calls'])
 if'elapsed_ms'in row:
  assert model_ms<=row['elapsed_ms']+1;item.update(elapsed_ms=row['elapsed_ms'],model_ms=model_ms,other_ms=row['elapsed_ms']-model_ms,capped_ms=row['elapsed_ms']if item['strict']else 120000,steps=steps,result_status=row.get('result',{}).get('status'),reason=row.get('result',{}).get('reason'))
 rows.append(item)
attempted=[c for c in calls if c['attempted']];assert set(ledger)=={c['call_id']for c in attempted};assert sum(c['known_tokens']or 0 for c in attempted)==result['spend']['batch']['known_tokens'];summary={'mode':a.mode,'sha256':f['sha256'],'planned':96,'attempted_trials':sum(r['attempted']for r in rows),'finished':sum(r['status']=='finished'for r in rows),'positive_planned':80,'positive_strict':sum(r['strict']for r in rows),'negative_planned':16,'negative_passed':sum(r['negative_passed']for r in rows),'cleanup':sum(r['cleanup']for r in rows),'SDK_calls':len(attempted),'image_calls':sum(c['image']for c in attempted),'known_tokens':sum(c['known_tokens']or 0 for c in attempted),'unknown_calls':unknown,'stop_reason':result['spend']['stop_reason'],'controls':[{'call_id':c['call_id'],'choice':c['choice'],'model':c['model']}for c in attempted if c['choice']in('none','ambiguous','need_more_context','escalate')],'fallbacks':[{'text':c['fallback_from'],'image':c['call_id']}for c in attempted if c['fallback_from']],'rows':rows,'arms':[],'clusters':[],'formal_confirmation_N':None,'analysis_kind':('fake SDK wiring only; artificial usage/latency, not model performance'if a.mode=='fake'else'calibration descriptive; no adoption or confirmatory CI claim')}
for arm in('v','jt'):
 subset=[r for r in rows if r['arm']==arm];positive=[r for r in subset if r['positive']];negative=[r for r in subset if not r['positive']];acalls=[c for r in subset for c in r['calls']if c['attempted']];times=[r['capped_ms']/1000 for r in positive];summary['arms'].append({'arm':arm,'positive_planned':len(positive),'positive_strict':sum(r['strict']for r in positive),'negative_planned':len(negative),'negative_passed':sum(r['negative_passed']for r in negative),'mean_capped_s':statistics.mean(times),'median_capped_s':statistics.median(times),'p95_capped_s':sorted(times)[math.ceil(.95*len(times))-1],'SDK_calls':len(acalls),'image_calls':sum(c['image']for c in acalls),'known_tokens':sum(c['known_tokens']or 0 for c in acalls),'estimate_usd':str(Decimal(sum(c.get('estimate_nano_usd',0)for c in acalls))/Decimal(10**9))if a.mode=='live'else None,'reported_peer_cost_usd':str(sum((Decimal(c['reported_peer_cost_usd'])for c in acalls if c['reported_peer_cost_usd']is not None),Decimal(0)))if a.mode=='live'else None})
for cluster_id in sorted({r['cluster_id']for r in rows if r['positive']}):
 subset=[r for r in rows if r['cluster_id']==cluster_id];means={arm:statistics.mean(r['capped_ms']/1000 for r in subset if r['arm']==arm)for arm in('v','jt')};summary['clusters'].append({'id':cluster_id,'product':subset[0]['product'],'v_s':means['v'],'jt_s':means['jt'],'difference_s':means['jt']-means['v'],'v_all_success':all(r['strict']for r in subset if r['arm']=='v'),'jt_all_success':all(r['strict']for r in subset if r['arm']=='jt')})
summary['purposes']={purpose:sum(c['purpose']==purpose for c in attempted)for purpose in sorted({str(c['purpose'])for c in attempted})};summary['paired_cluster_difference_sd_s']=statistics.stdev(r['difference_s']for r in summary['clusters']);summary['clusters_positive']=len(summary['clusters']);summary['clusters_negative']=len({r['cluster_id']for r in rows if not r['positive']});a.output.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in('rows','clusters','controls','fallbacks')},ensure_ascii=False))
