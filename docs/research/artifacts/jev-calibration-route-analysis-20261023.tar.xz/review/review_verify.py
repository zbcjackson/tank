"""Reviewer-owned independent audit of existing records. No archived code execution."""
from pathlib import Path
from decimal import Decimal
from collections import Counter, defaultdict
import csv
import hashlib
import itertools
import json
import socket


def deny(*args, **kwargs):
    raise AssertionError('review is offline')


socket.getaddrinfo = deny
socket.socket.connect = deny
socket.socket.connect_ex = deny
root = Path('/private/tmp/tank-jev-route-analysis-20261023')
out = Path('/private/tmp/tank-jev-route-analysis-review-20261023')
repo = Path('/Users/zbcjackson/src/tank')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


old = json.loads((root / 'prior-artifacts66-sha256.json').read_text())
assert len(old) == 66
assert all(sha(repo / path) == digest for path, digest in old.items())
manifest = json.loads((repo / 'docs/research/artifacts/jev-calibration-route-20261021-xz-manifest.json').read_text())
assert manifest['sha256'] == sha(repo / 'docs/research/artifacts/jev-calibration-route-20261021.tar.xz')
assert sha(repo / 'docs/research/artifacts/jev-calibration-route-20261021-xz-manifest.json') == '029bfb3b235acfe3a75dac1e13c7e56e42ffe0fc501138540d7d4d19966ca9e2'
bindings = json.loads((root / 'input-member-bindings.json').read_text())
assert len(bindings) == 327
assert all(sha(root / 'inputs' / name) == entry['sha256'] for name, entry in bindings.items())
raw = json.loads((root / 'inputs/live/result.json').read_text())
freeze = json.loads((root / 'inputs/live/freeze.json').read_text())
data = json.loads((root / 'derived-v2/analysis.json').read_text())
case_index = {c['id']: c for c in freeze['cases']}
trial_index = {t['id']: t for t in data['trials']}
call_index = {c['call_id']: c for c in data['calls']}
step_index = {(s['trial_id'], s['observation_id']): s for s in data['steps']}
assert len(trial_index) == 96 and len(call_index) == 337 and len(step_index) == 336
all_calls = []
all_steps = []
recomputed = {}
for row in raw['rows']:
    trial = trial_index[row['id']]
    spec = case_index[row['case']]
    assert (trial['case'], trial['product'], trial['condition'], trial['arm'], trial['cluster_id']) == (row['case'], row['product'], row['condition'], row['arm'], row['cluster_id'])
    assert trial['positive'] == (not bool(spec['negative']))
    assert trial['success'] is True and row['cleanup_confirmed'] is True
    journal = [json.loads(line) for line in (root / 'inputs/live' / row['id'] / 'calls.jsonl').read_text().splitlines()]
    requests = [event for event in journal if 'request' in event]
    replies = {event['call_id']: event['response'] for event in journal if 'response' in event}
    finished = {e['call_id']: e for e in row['events'] if e['kind'] == 'model_call' and e.get('phase') == 'finished'}
    routes = {e['observation_id']: e for e in row['events'] if e['kind'] == 'computer_use_route'}
    assert len(requests) == len(replies) == len(finished)
    class_s = defaultdict(Decimal)
    step_oids = set()
    image_n = jev_n = fallback_n = token_n = 0
    for item in requests:
        request = item['request']
        cid = item['call_id']
        call = call_index[cid]
        assert call['trial_id'] == row['id']
        visual = 'messages' in request
        packet = json.loads(request['messages'][1]['content'][0]['text']) if visual else request
        oid = packet['state']['snapshot']['observation_id']
        route = routes[oid]['reason']
        values = packet['questions']['next_action']['criteria']
        candidates = {k: v for k, v in values.items() if isinstance(v, dict)}
        # Reconstruct exactly the frozen ActionDetails identity with source-ref aliasing.
        identities = []
        for candidate in candidates.values():
            effects = []
            for fact in candidate['effect']:
                key = fact['key']
                if candidate['role'] == 'checkbox' and (key.startswith('dom:checked:') or key == 'checkbox:' + candidate['label']):
                    key = 'checkbox:checked'
                effects.append([key, fact['value']])
            changes = [packet['state']['value_change_checks'][ref] for ref in candidate.get('change_refs', [])]
            signatures = [candidate[key] for key in ('role', 'label', 'ancestors', 'current_value', 'input_key')]
            signatures.extend([effects, [[c['key'], c['source_ref'], c['before']] for c in changes]])
            identities.append(json.dumps(signatures, sort_keys=True, ensure_ascii=False))
        duplicates = len(set(identities)) != len(identities)
        generic = any(not c['label'].strip() or c['label'] == c['role'] for c in candidates.values())
        assert (duplicates or generic) == (route == 'visual_required')
        assert not generic
        event = finished[cid]
        expected_class = ('jev_text' if not visual else
                          'visual_fallback' if event['purpose'] == 'computer_use.visual_fallback' else
                          'visual_direct_ineligible' if route == 'visual_required' else 'visual_baseline_eligible')
        assert call['call_class'] == expected_class and call['image'] == visual
        class_s[expected_class] += Decimal(str(event['elapsed_ms'])) / 1000
        elapsed = Decimal(str(event['elapsed_ms'])) / 1000
        assert abs(elapsed - Decimal(str(call['sdk_s']))) < Decimal('1e-12')
        reply = replies[cid]
        usage = reply['usage'] if visual else reply
        usage_keys = ('prompt_tokens', 'completion_tokens') if visual else ('input_tokens', 'output_tokens')
        inputs, outputs = [usage[key] for key in usage_keys]
        assert (inputs, outputs) == (call['input_tokens'], call['output_tokens'])
        assert (inputs, outputs) == (event['prompt_tokens'], event['completion_tokens'])
        image_n += visual
        jev_n += not visual
        fallback_n += expected_class == 'visual_fallback'
        token_n += inputs + outputs
        step_oids.add(oid)
        all_calls.append(call)
    assert set(routes) == step_oids
    all_steps.extend(step_index[(row['id'], oid)] for oid in step_oids)
    total = Decimal(str(row['elapsed_ms'])) / 1000
    sdk = sum(class_s.values(), Decimal(0))
    rest = total - sdk
    assert rest >= 0
    for key, value in {'elapsed_s': total, 'sdk_s': sdk, 'remainder_s': rest}.items():
        assert abs(value - Decimal(str(trial[key]))) < Decimal('1e-11')
    for key, value in class_s.items():
        assert abs(value - Decimal(str(trial['sdk_by_class_s'][key]))) < Decimal('1e-11')
    assert (image_n, jev_n, fallback_n, token_n) == (trial['images'], trial['jev'], trial['fallbacks'], trial['tokens'])
    expected_path = ('visual_baseline' if row['arm'] == 'v' else
                     'control_then_visual' if fallback_n else
                     'mixed_text_visual' if jev_n and image_n else
                     'text_only' if jev_n else 'visual_bypass_only')
    assert trial['path_class'] == expected_path
    recomputed[row['id']] = dict(total=total, sdk=sdk, remainder=rest)
assert len(all_calls) == 337 and len(all_steps) == 336
assert sum(c['image'] for c in all_calls) == 279
assert sum(t['tokens'] for t in data['trials']) == 4412681
for pair in data['pairs']:
    v, jt = [trial_index[pair[key]] for key in ('v_id', 'jt_id')]
    assert pair['case'] == v['case'] == jt['case']
    assert v['arm'] == 'v' and jt['arm'] == 'jt'
    assert pair['jt_path'] == jt['path_class']
    assert abs(pair['delta_s'] - (jt['elapsed_s'] - v['elapsed_s'])) < 1e-12
for kind in ('trials', 'calls', 'steps', 'pairs', 'strata'):
    rows = data[kind]
    assert json.loads((root / 'derived-v2' / (kind + '.json')).read_text()) == rows
    with (root / 'derived-v2' / (kind + '.csv')).open() as stream:
        csv_rows = list(csv.DictReader(stream))
    assert len(csv_rows) == len(rows)
    for actual, expected in zip(csv_rows, rows):
        for key, value in expected.items():
            serialized = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')) if isinstance(value, (dict, list)) else '' if value is None else str(value)
            assert actual[key] == serialized, (kind, key)
for stratum in data['strata']:
    rows = [t for t in data['trials'] if t['arm'] == stratum['arm']
            and (stratum['product'] == 'all' or t['product'] == stratum['product'])
            and (stratum['condition'] == 'all' or t['condition'] == stratum['condition'])
            and ((stratum['group'] == 'all' and t['positive']) or t['group'] == stratum['group'])]
    assert len(rows) == stratum['n']
    for key in ('elapsed_s', 'sdk_s', 'remainder_s', 'observed_s', 'calls', 'images', 'jev', 'fallbacks', 'eligible_steps', 'ineligible_steps', 'tokens'):
        total = sum(Decimal(str(t[key])) for t in rows)
        assert abs(Decimal(str(stratum[key + '_sum'])) - total) < Decimal('1e-9')
        assert abs(Decimal(str(stratum[key + '_mean'])) - total / len(rows)) < Decimal('1e-9')
filters = 0
for product, condition, positive in itertools.product(('all', 'sqlite-web', 'linkding'), ('all', 'cold', 'prewarmed'), (True, False)):
    base = [p for p in data['pairs'] if (product == 'all' or p['product'] == product) and (condition == 'all' or p['condition'] == condition) and p['positive'] == positive]
    for scenario in ['all', *{p['scenario'] for p in base}]:
        by_scenario = [p for p in base if scenario == 'all' or p['scenario'] == scenario]
        for path in ['all', *{p['jt_path'] for p in by_scenario}]:
            selected = [p for p in by_scenario if path == 'all' or p['jt_path'] == path]
            selected_cases = {p['case'] for p in selected}
            rows = [t for t in data['trials'] if t['case'] in selected_cases]
            assert len(selected) > 0 and len(rows) == len(selected) * 2
            assert Counter(t['arm'] for t in rows) == {'v': len(selected), 'jt': len(selected)}
            filters += 1
canvas = Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-route-cost-analysis.canvas.tsx')
assert canvas.read_bytes() == (root / 'jev-route-cost-analysis.canvas.tsx').read_bytes()
canvas_payload = json.JSONDecoder().raw_decode(canvas.read_text().split('const DATA:Data=', 1)[1])[0]
assert canvas_payload == json.loads((root / 'canvas-data.json').read_text())
for kind, rows in canvas_payload.items():
    assert len(rows) == len(data[kind])
    assert all({key: original[key] for key in selected} == selected for original, selected in zip(data[kind], rows))
report = {'old_artifacts_unchanged': 66, 'input_members_verified': 327, 'trials': 96, 'calls': 337, 'route_steps': 336, 'all_json_csv_cells_verified': True, 'strata_verified': 72, 'full_scenario_path_filters': filters, 'network_attempts': 0, 'archived_code_executed': False}
(out / 'review-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
