from pathlib import Path
import json

ROOT = Path('/private/tmp/tank-jev-route-analysis-20261023')
data = json.loads((ROOT / 'derived-v2/analysis.json').read_text())
keys = {
 'trials': 'id case cluster_id product condition group scenario positive arm success elapsed_s sdk_s remainder_s calls images jev fallbacks eligible_steps ineligible_steps path_class sdk_by_class_s tokens',
 'calls': 'trial_id case arm provider call_class sdk_s page_phase choice chosen_label chosen_operation candidate_count duplicate_labels observation_id call_id',
 'steps': 'trial_id case arm product page_phase route_reason duplicate_labels candidate_count',
 'pairs': 'case cluster_id product condition group scenario positive jt_path v_id jt_id v_s jt_s delta_s v_images jt_images',
}
payload = {name: [{key: row[key] for key in fieldlist.split()} for row in data[name]] for name, fieldlist in keys.items()}
types = """import { Stack, Row, Grid, H1, H2, Text, Stat, Table, Select, Callout, BarChart, useState, useHostTheme } from "cursor/canvas";
type Classes="jev_text"|"visual_direct_ineligible"|"visual_baseline_eligible"|"visual_fallback";
type Trial={id:string;case:string;cluster_id:string;product:string;condition:string;group:string;scenario:string;positive:boolean;arm:string;success:boolean;elapsed_s:number;sdk_s:number;remainder_s:number;calls:number;images:number;jev:number;fallbacks:number;eligible_steps:number;ineligible_steps:number;path_class:string;sdk_by_class_s:Record<Classes,number>;tokens:number};
type Call={trial_id:string;case:string;arm:string;provider:string;call_class:string;sdk_s:number;page_phase:string;choice:string;chosen_label:string|null;chosen_operation:string|null;candidate_count:number;duplicate_labels:string[];observation_id:string;call_id:string};
type Step={trial_id:string;case:string;arm:string;product:string;page_phase:string;route_reason:string;duplicate_labels:string[];candidate_count:number};
type Pair={case:string;cluster_id:string;product:string;condition:string;group:string;scenario:string;positive:boolean;jt_path:string;v_id:string;jt_id:string;v_s:number;jt_s:number;delta_s:number;v_images:number;jt_images:number};
type Data={trials:Trial[];calls:Call[];steps:Step[];pairs:Pair[]};
"""
body = """
const sum=(rows:Trial[],pick:(row:Trial)=>number)=>rows.reduce((n,row)=>n+pick(row),0);
const mean=(rows:Trial[],pick:(row:Trial)=>number)=>sum(rows,pick)/rows.length;
const f=(n:number)=>n.toFixed(2);
const signed=(n:number)=>(n>0?"+":"")+f(n);
const pathNames:Record<string,string>={all:"全部实际JT路径",visual_bypass_only:"全程直接视觉",mixed_text_visual:"文字与直接视觉混合",control_then_visual:"发生文字弃权接管",text_only:"仅文字"};
const phaseNames:Record<string,string>={list:"列表",editor:"编辑",retry:"Retry"};
const scenarioNames:Record<string,string>={normal_unique:"正常：唯一标题","normal_same-title":"正常：同名标题","normal_shuffled-seed":"正常：记录顺序变化",recovery_list:"恢复：列表GET",recovery_editor:"恢复：编辑GET",negative_missing:"负例：缺目标",negative_revoked:"负例：撤权"};
const shortClass:Record<Classes,string>={jev_text:"Jev文字",visual_direct_ineligible:"直接视觉",visual_baseline_eligible:"V文字准入步骤",visual_fallback:"弃权后接管"};
const classNames:Record<Classes,string>={jev_text:"Jev文字调用",visual_direct_ineligible:"未满足文字准入：直接视觉",visual_baseline_eligible:"满足文字准入：V仍使用视觉",visual_fallback:"Jev控制回复后的视觉接管"};
export default function RouteCostAnalysis(){
 const theme=useHostTheme();
 const [product,setProduct]=useState("all"),[condition,setCondition]=useState("all"),[cohort,setCohort]=useState("positive"),[scenario,setScenario]=useState("all"),[path,setPath]=useState("all"),[detail,setDetail]=useState("");
 const base=DATA.pairs.filter(p=>(product==="all"||p.product===product)&&(condition==="all"||p.condition===condition)&&p.positive===(cohort==="positive"));
 const scenarios=Array.from(new Set(base.map(p=>p.scenario))).sort();
 const selectedScenario=scenarios.includes(scenario)?scenario:"all";
 const byScenario=base.filter(p=>selectedScenario==="all"||p.scenario===selectedScenario);
 const paths=Array.from(new Set(byScenario.map(p=>p.jt_path))).sort();
 const selectedPath=paths.includes(path)?path:"all";
 const pairs=byScenario.filter(p=>selectedPath==="all"||p.jt_path===selectedPath);
 if(!pairs.length)return null;
 const cases=new Set(pairs.map(p=>p.case));
 const rows=DATA.trials.filter(r=>cases.has(r.case));
 const v=rows.filter(r=>r.arm==="v"),jt=rows.filter(r=>r.arm==="jt");
 const seeds=new Set(pairs.map(p=>p.cluster_id)).size;
 const active= pairs.find(p=>p.case===detail)??pairs[0];
 const detailCalls=DATA.calls.filter(c=>c.case===active.case);
 const scope=cohort==="positive"?"正例任务":"负例退出";
 const classes:Classes[]=["jev_text","visual_direct_ineligible","visual_baseline_eligible","visual_fallback"];
 const nonzeroClasses=classes.filter(k=>sum(v,r=>r.sdk_by_class_s[k])+sum(jt,r=>r.sdk_by_class_s[k])>0);
 const routeSteps=DATA.steps.filter(s=>cases.has(s.case)&&s.arm==="jt");
 const routeGroups=Array.from(new Set(routeSteps.map(s=>s.product+"|"+s.page_phase))).sort();
 const source="来源：2026-10-21真实96项不可变归档；2026-10-23离线复算。当前"+pairs.length+"对 / "+seeds+"个seed；每臂"+pairs.length+"次。";
 const components=classes.map(k=>[classNames[k],f(mean(v,r=>r.sdk_by_class_s[k])),f(mean(jt,r=>r.sdk_by_class_s[k])),signed(mean(jt,r=>r.sdk_by_class_s[k])-mean(v,r=>r.sdk_by_class_s[k]))]);
 components.push(["其余未细分时间",f(mean(v,r=>r.remainder_s)),f(mean(jt,r=>r.remainder_s)),signed(mean(jt,r=>r.remainder_s)-mean(v,r=>r.remainder_s))]);
 components.push(["任务总时间",f(mean(v,r=>r.elapsed_s)),f(mean(jt,r=>r.elapsed_s)),signed(mean(jt,r=>r.elapsed_s)-mean(v,r=>r.elapsed_s))]);
 return <Stack gap={24} style={{maxWidth:1250,margin:"0 auto",padding:24,background:theme.bg.editor,color:theme.text.primary}}>
  <Stack gap={8}>
   <Text size="small" tone="secondary">已有96项真实校准 · 80正例 / 16负例 · 本轮无新模型调用</Text>
   <H1>收益差异首先出现在文字准入覆盖</H1>
   <Text>sqlite-web的Jev只参与Retry；linkding的编辑步骤大量进入文字路线。重复导航候选会触发整组转视觉，当前结果反映模型与准入规则共同作用。</Text>
   <Text tone="secondary">原完整批次两臂各40/40正例、8/8负例通过。JT全部96项图片111次，V168次；总SDK分别169与168次。正式N未冻结，费用不在本面板估算。</Text>
  </Stack>
  <Callout tone="info">这是已有数据的描述性拆分。24个seed并非96个独立样本；按实际JT路径筛选是事后子集，不能据此宣告该路径的因果收益或通用视觉能力。SDK边界耗时含网络、服务和局部SDK/回执开销。</Callout>
  <Row gap={12} wrap>
   <Select value={product} onChange={setProduct} options={[{value:"all",label:"全部应用"},{value:"sqlite-web",label:"sqlite-web"},{value:"linkding",label:"linkding"}]}/>
   <Select value={condition} onChange={setCondition} options={[{value:"all",label:"冷 / 预热均保留"},{value:"cold",label:"冷启动"},{value:"prewarmed",label:"本地预热"}]}/>
   <Select value={cohort} onChange={setCohort} options={[{value:"positive",label:"正例完成耗时"},{value:"negative",label:"负例退出耗时"}]}/>
   <Select value={selectedScenario} onChange={setScenario} options={[{value:"all",label:"全部当前场景"},...scenarios.map(s=>({value:s,label:scenarioNames[s]??s}))]}/>
   <Select value={selectedPath} onChange={setPath} options={[{value:"all",label:pathNames.all},...paths.map(p=>({value:p,label:pathNames[p]??p}))]}/>
  </Row>
  <Row gap={32} wrap>
   <Stat label={scope+"均时 V → JT"} value={f(mean(v,r=>r.elapsed_s))+" → "+f(mean(jt,r=>r.elapsed_s))+" s"}/>
   <Stat label="对应图片调用 V → JT" value={sum(v,r=>r.images)+" → "+sum(jt,r=>r.images)}/>
   <Stat label="JT任务更快的配对（描述）" value={pairs.filter(p=>p.delta_s<0).length+" / "+pairs.length}/>
   <Stat label="当前配对 / seed" value={pairs.length+" / "+seeds}/>
  </Row>
  <Grid columns="repeat(auto-fit,minmax(350px,1fr))" gap={24}>
   <Stack gap={8}>
    <H2>{scope}：总计与调用边界</H2>
    <Text size="small" tone="secondary">横轴：计时范围；纵轴：每次执行均值（秒）。图例为V与JT。</Text>
    <BarChart categories={["任务总计","SDK调用边界","其余未细分"]} series={[{name:"V",tone:"neutral",data:[mean(v,r=>r.elapsed_s),mean(v,r=>r.sdk_s),mean(v,r=>r.remainder_s)]},{name:"JT",tone:"info",data:[mean(jt,r=>r.elapsed_s),mean(jt,r=>r.sdk_s),mean(jt,r=>r.remainder_s)]}]} valueSuffix=" s" height={250} showValues/>
    <Text size="small" tone="tertiary">{source}</Text>
   </Stack>
   <Stack gap={8}>
    <H2>SDK耗时按实际路径拆分</H2>
    <Text size="small" tone="secondary">横轴：调用路径；纵轴：每次执行分摊均值（秒）。零值路径不重复显示。</Text>
    <BarChart categories={nonzeroClasses.map(k=>shortClass[k])} series={[{name:"V",tone:"neutral",data:nonzeroClasses.map(k=>mean(v,r=>r.sdk_by_class_s[k]))},{name:"JT",tone:"info",data:nonzeroClasses.map(k=>mean(jt,r=>r.sdk_by_class_s[k]))}]} valueSuffix=" s" height={250} showValues/>
    <Text size="small" tone="tertiary">{source}</Text>
   </Stack>
  </Grid>
  <Stack gap={8}>
   <H2>时间差的算术分解</H2>
   <Table headers={["组成（秒/执行）","V","JT","JT−V"]} rows={components} columnAlign={["left","right","right","right"]}/>
   <Text size="small" tone="secondary">各分量加总为任务总时间。其余时间包含设置、观察、截图、派发、清理、回读和未细分开销；不能解释为纯宿主CPU时间。两臂直视调用耗时的差也不能自动归为路由效果，供应方和缓存状态未受控。</Text>
  </Stack>
  {routeGroups.length>0&&<Stack gap={8}>
   <H2>JT准入发生在哪些页面</H2>
   <Table headers={["应用 / 页面","文字可用步骤 / 全部","重复描述标签","当前候选均值"]} rows={routeGroups.map(key=>{
    const group=routeSteps.filter(s=>s.product+"|"+s.page_phase===key);
    const parts=key.split("|");const duplicates=Array.from(new Set(group.flatMap(s=>s.duplicate_labels)));
    return [parts[0]+" / "+(phaseNames[parts[1]]??parts[1]),group.filter(s=>s.route_reason==="jev_eligible").length+" / "+group.length,duplicates.join("、")||"无重复描述",f(group.reduce((n,s)=>n+s.candidate_count,0)/group.length)];
   })}/>
   <Text size="small" tone="secondary">按唯一observation计步骤，接管不会重复计数。归档版规则检查整个候选集的语义身份；重复项可让本来有清楚字段名的页面也直接走视觉。本轮没有删除候选或改变守卫。</Text>
  </Stack>}
  <Stack gap={8}>
   <H2>保留全部配对的结果</H2>
   <Table headers={["应用 / 场景","条件","V(s)","JT(s)","JT−V(s)","图片 V/JT","JT路径"]} rows={pairs.map(p=>[p.product+" / "+(scenarioNames[p.scenario]??p.scenario),p.condition==="cold"?"冷":"预热",f(p.v_s),f(p.jt_s),signed(p.delta_s),p.v_images+" / "+p.jt_images,pathNames[p.jt_path]??p.jt_path])} striped/>
   <Text size="small" tone="secondary">同一个seed的冷/预热仍相关。正例与负例通过上方切换分开查看，不混入同一个完成速度均值。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>单个配对的调用证据</H2>
   <Select value={active.case} onChange={setDetail} options={pairs.map(p=>({value:p.case,label:p.case}))}/>
   <Table headers={["策略","通道 / 路径","页面","选择","SDK(s)","候选数","重复标签"]} rows={detailCalls.map(c=>[c.arm.toUpperCase(),(c.provider==="jev"?"Jev":"视觉")+" / "+(classNames[c.call_class as Classes]??c.call_class),phaseNames[c.page_phase]??c.page_phase,c.chosen_label??c.choice,f(c.sdk_s),c.candidate_count,c.duplicate_labels.join("、")||"无"])} striped/>
   <Text size="small" tone="tertiary">配对ID：{active.case}。逐调用ID、输入成员SHA与完整数值在本轮分析归档中，保留原337份SDK关联。</Text>
  </Stack>
  <Stack gap={8}>
   <H2>值得继续验证的准入假设</H2>
   <Text>优先保留“已区分的编辑/Retry步骤交Jev，未满足准入的列表交视觉”的状态级路由。它比按应用统一切换更贴合已观察路径。</Text>
   <Text>先离线验证重复导航是否能在保持权限、完整观察及目标区分契约的前提下作语义等价归组；当前数据没有证明扩大准入后Jev仍能选对，也未测量相应速度。</Text>
   <Text tone="secondary">若追加小规模真实验证，应固定同一视觉基线、完整配对及新任务，单独检验准入覆盖变化。此面板不改变旧评分、不推出因果或生产采用结论，也不把一次接管成功当作稳定成功率。</Text>
  </Stack>
 </Stack>;
}
"""
source = types + 'const DATA:Data=' + json.dumps(payload, ensure_ascii=False, separators=(',', ':')) + ';\n' + body
target = Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-route-cost-analysis.canvas.tsx')
target.write_text(source)
(ROOT / 'jev-route-cost-analysis.canvas.tsx').write_text(source)
(ROOT / 'canvas-data.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
config={'extends':'/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/tsconfig.json','include':[str(target)]}
(ROOT / 'tsconfig-canvas.json').write_text(json.dumps(config,indent=2)+'\n')
print(json.dumps({'canvas':str(target),'trials':len(payload['trials']),'calls':len(payload['calls']),'steps':len(payload['steps']),'pairs':len(payload['pairs'])}))
