import base64,json
from pathlib import Path
p=Path('/private/tmp/tank-linkding-qualified-20261020');s=json.loads((p/'summary.json').read_text());a=json.loads(Path('/private/tmp/tank-linkding-animation-20261020/result.json').read_text());f=json.loads((p/'task-freeze.json').read_text());data={'summary':s,'animation':a,'freeze':{'sha256':f['sha256'],'cases':f['cases'],'model_execution_eligible':False},'screenshots':[]}
for row in s['rows']:
 images={phase:'data:image/png;base64,'+base64.b64encode((p/row['id']/(phase+'.png')).read_bytes()).decode()for phase in('list','editor','returned')}
 data['screenshots'].append({'id':row['id'],'images':images})
code='''import {H1,H2,Text,Stack,Row,Grid,Stat,Table,Button,useState,useHostTheme} from "cursor/canvas";
const data=DATA;
export default function SecondProductQualification(){
 const theme=useHostTheme();const[index,setIndex]=useState(0);const[phase,setPhase]=useState<"list"|"editor"|"returned">("editor");const row=data.summary.rows[index];const image=data.screenshots[index].images[phase];const animation=data.animation.samples[0].animation[0];
 return <Stack gap={22} style={{padding:24,maxWidth:1180,margin:"0 auto",color:theme.text.primary}}>
  <Stack gap={8}>
   <Text size="small" tone="secondary">2026-10-20 · linkding 1.47.0 原版 · 第二真实产品资格检查</Text>
   <H1>隐藏动画阻断编辑页视觉准入</H1>
   <Text>四个原生脚本流程都能正确保存并返回列表；宿主在编辑页拒绝图片。当前没有健康的 V/JT 比较条件，尚未调用真实模型。</Text>
  </Stack>
  <Row gap={36}><Stat value="4/4" label="原生脚本业务核验"/><Stat value="0/16" label="编辑页图片准入"/><Stat value="16/16" label="列表页图片准入"/><Stat value="0" label="模型请求"/></Row>
  <Grid columns="1.1fr 1fr" gap={28}>
   <Stack gap={10}>
    <H2>可复查的拒绝原因</H2>
    <Text>唯一活动动画为 {animation.name}，周期 {animation.timing.duration}ms、无限循环；目标 i.form-icon.loading 的 computed visibility = hidden。原版 CSS 的 ::after 仍在运行。</Text>
    <Text>附加只读检查 5/5 被拒绝，5 张 PNG 字节相同：{data.summary.pixel_sha256}。没有取消动画或修改产品样式；caret 使用现有宿主处理。</Text>
    <Text>这是捕获门对不可见动画的误拒绝证据。下一步以回归测试定义可见运动、伪元素与过期帧的边界，修复后再建可执行 freeze。</Text>
   </Stack>
   <Stack gap={10}>
    <H2>新任务与边界</H2>
    <Text>目标为列表顶部或底部的两条书签：只改标题，保留 URL、描述、标签及其他字段，允许服务自动更新目标 date_modified。核对单 POST、返回 DOM、物理 SQLite 全字段与 schema。</Text>
    <Text>已冻结两种任务规格和四项拟议 V/JT 顺序。此 digest 是资格/声明式任务记录，不是可执行模型批准：</Text>
    <Text size="small" tone="secondary">{data.freeze.sha256}</Text>
    <Text>列表因重复 keep 标签被整体路由至 visual_required；两条 Edit 的祖先也未携带所属书签文本。32/32 观察完整，无 iframe/shadow-root 阻塞。</Text>
   </Stack>
  </Grid>
  <Stack gap={10}>
   <H2>逐流程证据</H2>
   <Row gap={8}>{data.summary.rows.map((r,i)=><Button key={r.id} onClick={()=>setIndex(i)}>{i+1} · 目标{r.target} · {r.initial_position==="top"?"顶部":"底部"}</Button>)}</Row>
   <Text>{row.id} · 原生流程/业务/schema/HTTP/清理全部通过。它由脚本选择 Edit、填入并保存，不是 Controller 或模型成功率。</Text>
   <Table headers={["状态","观察时机","候选准入","候选数","图片准入"]} rows={row.observations.map(o=>[o.phase,o.timing,o.reason,o.candidates,o.capture==="accepted"?"通过":o.capture_reason])}/>
   <Row gap={8}><Button onClick={()=>setPhase("list")}>初始列表</Button><Button onClick={()=>setPhase("editor")}>编辑页</Button><Button onClick={()=>setPhase("returned")}>返回列表</Button></Row>
   <img src={image} alt={`${row.id} ${phase} actual product screenshot`} style={{width:"100%",border:`1px solid ${theme.stroke.secondary}`}}/>
   <Text size="small" tone="secondary">实际 1280×720 CSS 像素截图；编辑页展示图为本地诊断截图，未通过模型图片准入，未发送给模型。来源：qualification/{row.id}/{phase}.png。</Text>
  </Stack>
  <Text size="small" tone="secondary">来源：docs/research/jev-second-product-qualification.md 与新归档的 summary/result/task-freeze/SQLite/HTTP。四流程×四状态×两个观察时机＝32，不是32独立应用；附加5次仅诊断。446应用文件前后不变，442原始文件匹配官方归档，旧15归档/manifest保持。早期设置失败和探索文件保留为不完整诊断，不混入四项冻结流程。仅类型检查，未声明宿主UI渲染验收。</Text>
 </Stack>;
}
'''.replace('DATA',json.dumps(data,ensure_ascii=False,separators=(',',':')))
Path('/private/tmp/jev-second-product-qualification.canvas.tsx').write_text(code)
print({'bytes':len(code.encode()),'rows':len(s['rows'])})
