import json, os, sys
from pathlib import Path
APP = Path('/private/tmp/linkding-1.47.0')
sys.path.insert(0, str(APP))
os.environ['DJANGO_SETTINGS_MODULE'] = 'bookmarks.settings'
os.environ['LD_DISABLE_BACKGROUND_TASKS'] = 'true'
import django
django.setup()
from django.contrib.auth.models import User
from django.test import Client
from django.utils import timezone
from bookmarks.models import Bookmark, Tag
from bookmarks.services.bookmarks import create_bookmark
out = Path(sys.argv[2])
if sys.argv[1] == 'seed':
    Bookmark.objects.all().delete()
    Tag.objects.all().delete()
    User.objects.all().delete()
    from django.db import connection
    with connection.cursor() as cur:
        cur.execute("DELETE FROM sqlite_sequence WHERE name in ('bookmarks_bookmark', 'bookmarks_tag', 'auth_user')")
    user = User.objects.create_user(username='qualification-user', password='synthetic-local-only', email='qualification@example.test')
    for n in (1, 2):
        bookmark = Bookmark(url=f'https://example.test/item-{n}', title=f'Draft bookmark {n}', description=f'Keep description {n}', notes='', owner=user, unread=False, shared=False)
        create_bookmark(bookmark, 'keep', user)
    client = Client()
    client.force_login(user)
    from django.conf import settings
    cookie = client.cookies[settings.SESSION_COOKIE_NAME].value
    (out / 'auth.json').write_text(json.dumps({'name': settings.SESSION_COOKIE_NAME, 'value': cookie}))
    (out / 'seed.json').write_text(json.dumps(list(Bookmark.objects.order_by('id').values()), default=str, indent=2))
elif sys.argv[1] == 'serve':
    from django.contrib.staticfiles.handlers import StaticFilesHandler
    from django.core.wsgi import get_wsgi_application
    from wsgiref.simple_server import make_server, WSGIRequestHandler
    app = StaticFilesHandler(get_wsgi_application())
    class Quiet(WSGIRequestHandler):
        def log_message(self, *args): pass
    def logged(environ, start_response):
        def status_line(status, headers, exc_info=None):
            with (out / 'http.jsonl').open('a') as f:
                f.write(json.dumps({'method':environ['REQUEST_METHOD'], 'path':environ['PATH_INFO'], 'query':environ.get('QUERY_STRING', ''), 'status':status})+'\n')
            return start_response(status, headers, exc_info)
        return app(environ, status_line)
    with make_server('127.0.0.1', 0, logged, handler_class=Quiet) as server:
        (out/'ready.json').write_text(json.dumps({'port':server.server_port}))
        server.serve_forever()
