"""New immutable qualification archive; verify and preserve 15 older archives."""
import hashlib,io,json,os,re,tarfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path('/Users/zbcjackson/src/tank');OUT=Path('/private/tmp/tank-linkding-qualified-20261020');ART=ROOT/'docs/research/artifacts';h=lambda b:hashlib.sha256(b).hexdigest();old=json.loads(Path('/private/tmp/tank-linkding-old-artifacts-20261020.json').read_text());assert len(old)==30
for name,sha in old.items():assert h((ROOT/name).read_bytes())==sha
files={}
for prefix,path in [('qualification',OUT),('animation',Path('/private/tmp/tank-linkding-animation-20261020')),('exploration-single-thread',Path('/private/tmp/tank-linkding-probe-20261020')),('exploration-threaded-partial',Path('/private/tmp/tank-linkding-probe2-20261020'))]:
 for p in path.rglob('*'):
  if p.is_file():files[prefix+'/'+str(p.relative_to(path))]=p
files['app/linkding-v1.47.0-original.tar.gz']=Path('/private/tmp/tank-linkding-v1.47.0.tar.gz')
f=json.loads((OUT/'task-freeze.json').read_text());APP=Path('/private/tmp/linkding-1.47.0');original=f['product']['original_file_sha256'];installed=f['product']['app_file_sha256']
for name,sha in installed.items():
 p=APP/name;assert h(p.read_bytes())==sha
 if name not in original:files['app/generated/'+name]=p
for p in Path('/private/tmp').glob('tank-linkding-*.py'):files['analysis/'+p.name]=p
for p in Path('/private/tmp').glob('tank-linkding-*.log'):files['verification/'+p.name]=p
files['analysis/old-artifacts.json']=Path('/private/tmp/tank-linkding-old-artifacts-20261020.json')
files['analysis/jev-second-product-qualification.canvas.tsx']=Path('/private/tmp/jev-second-product-qualification.canvas.tsx')
values={**dotenv_values(ROOT/'backend/core/.env'),**os.environ};secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)];assert secrets
for name,p in files.items():assert not any(v in p.read_bytes()for v in secrets),name
archive=ART/'jev-second-product-qualification-20261020.tar.gz';manifest=ART/'jev-second-product-qualification-20261020-manifest.json';assert not archive.exists()and not manifest.exists()
m={'date':'2026-10-20','baseline_commit':'38bc1eba','plan_commit':'249d42ea','kind':'no-model-qualification','task_spec_sha256':f['sha256'],'model_execution_eligible':False,'credential_values_scanned':len(secrets),'old_files_unchanged':old,'files':{}}
with tarfile.open(archive,'w:gz')as t:
 for name,p in sorted(files.items()):
  b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b));m['files'][name]={'bytes':len(b),'sha256':h(b)}
m['archive_sha256']=h(archive.read_bytes());m['archive_bytes']=archive.stat().st_size
with tarfile.open(archive)as t:
 assert set(t.getnames())==set(files)
 for member in t.getmembers():
  b=t.extractfile(member).read();assert len(b)==m['files'][member.name]['bytes']and h(b)==m['files'][member.name]['sha256']
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'members':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':m['archive_bytes'],'sha256':m['archive_sha256'],'old_archives':15,'credential_values':len(secrets)}))
