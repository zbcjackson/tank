"""Independent readback: no host benchmark/scoring imports."""
import collections,hashlib,json,sqlite3
from contextlib import closing
from pathlib import Path
ROOT=Path('/Users/zbcjackson/src/tank');OUT=Path('/private/tmp/tank-linkding-qualified-20261020');APP=Path('/private/tmp/linkding-1.47.0')
h=lambda b:hashlib.sha256(b).hexdigest()
def physical(p):
 with closing(sqlite3.connect(p.as_uri()+'?mode=ro',uri=True))as db:
  db.row_factory=sqlite3.Row;db.execute('BEGIN');names=[r[0]for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'bookmarks_%' ORDER BY name")]
  return {'tables':{n:[dict(r)for r in db.execute('SELECT * FROM '+n+' ORDER BY rowid')]for n in names},'schema':[list(r)for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]}
r=json.loads((OUT/'result.json').read_text());rows=[]
for row in r['rows']:
 p=OUT/row['id'];before=physical(p/'before.db');after=physical(p/'after.db');assert before==json.loads((p/'database-before.json').read_text());assert after==row['after']==json.loads((p/'database-after.json').read_text());assert before['schema']==after['schema'];target=row['target'];expected=json.loads(json.dumps(before['tables']))
 old=next(x for x in expected['bookmarks_bookmark']if x['id']==target);new=next(x for x in after['tables']['bookmarks_bookmark']if x['id']==target);assert new['date_modified']>old['date_modified'];old['title']=f'Launch bookmark {target}';old['date_modified']=new['date_modified'];assert expected==after['tables'];assert row['cleanup']and row['script_completed']and row['model_calls']==0
 http=row['http'];posts=[(i,x)for i,x in enumerate(http)if x['method']=='POST'];assert len(posts)==1;pi,post=posts[0];edit=f'/bookmarks/{target}/edit';assert post['path']==edit and post['status']=='302 Found';lists=[i for i,x in enumerate(http)if x['method']=='GET'and x['path']=='/bookmarks'and x['status']=='200 OK'];edits=[i for i,x in enumerate(http)if x['method']=='GET'and x['path']==edit and x['status']=='200 OK'];assert any(i<j<pi for i in lists for j in edits)and any(i>pi for i in lists)
 assert len(row['observations'])==8
 phases=[]
 for o in row['observations']:
  assert o['snapshot']['complete']and o['dom']['frames']==0 and o['dom']['shadow']==[];assert o['dom']['viewport']=={'width':1280,'height':720};phase=o['phase'];listphase=phase in ('list','returned');assert o['actions']['reason']==('visual_required'if listphase else'jev_eligible');assert len(o['actions']['actions'])==(12 if listphase else 5 if phase=='editor'else 6)
  if listphase:
   assert o['capture']['status']=='accepted';frame=o['raw_frame'];png=p/frame['path'];assert h(png.read_bytes())==frame['frame']['image_sha256'];assert o['capture']['frame']==frame['frame'];bounds=dict(frame['bounds'])
   for a in o['actions']['actions']:
    x,y,w,ht=bounds[a['target_ref']];assert 0<=x<x+w<=1280 and 0<=y<y+ht<=720
   expected_title=lambda n:f'Launch bookmark {n}'if phase=='returned'and n==target else f'Draft bookmark {n}'
   visible=o['dom']['list'];assert [v['id']for v in visible]==['2','1'];assert {v['id']:v['title']for v in visible}=={str(n):expected_title(n)for n in(1,2)}
   assert all(v['href']==f'https://example.test/item-{v["id"]}'and v['description']==f'keep | Keep description {v["id"]}'for v in visible)
   keep=[d for d in o['actions']['details']if d['label']=='keep'and['section','Bookmark list']in d['ancestors']];assert len(keep)==2 and keep[0]['effect']==keep[1]['effect']and keep[0]['ancestors']==keep[1]['ancestors']
   editdetails=[d for d in o['actions']['details']if d['label']=='Edit'];assert len(editdetails)==2 and editdetails[0]['ancestors']==editdetails[1]['ancestors']
  else:
   assert o['capture']['status']=='refused'and o['capture']['reason']=='unstable_visual_frame';assert 'raw_frame'not in o;assert len(o['dom']['animations'])==1;assert o['dom']['animations'][0]=={'state':'running','pending':False}
   title=next(i for i in o['dom']['inputs']if i['name']=='title');assert title['value']==(f'Draft bookmark {target}'if phase=='editor'else f'Launch bookmark {target}')
   if phase=='filled':assert any(d['label']=='Save'for d in o['actions']['details'])
  phases.append({'phase':phase,'timing':o['timing'],'reason':o['actions']['reason'],'candidates':len(o['actions']['actions']),'capture':o['capture']['status'],'capture_reason':o['capture'].get('reason')})
 rows.append({'id':row['id'],'target':target,'initial_position':'bottom'if target==1 else'top','script_completed':True,'business_match':True,'schema_match':True,'bookmarks_tables_checked':len(before['tables']),'post_requests':1,'http_path_match':True,'cleanup':True,'observations':phases})
a=json.loads(Path('/private/tmp/tank-linkding-animation-20261020/result.json').read_text());assert a['cleanup']and a['model_calls']==0 and len(a['samples'])==5;hashes=[]
for s in a['samples']:
 assert s['capture']=='unstable_visual_frame'and len(s['animation'])==1;anim=s['animation'][0];assert anim['name']=='loading'and anim['timing']=={'duration':500,'iterations':'Infinity'}and anim['target']['visibility']=='hidden';png=Path('/private/tmp/tank-linkding-animation-20261020')/s['png'];assert h(png.read_bytes())==s['sha256'];hashes.append(s['sha256'])
assert len(set(hashes))==1
old=json.loads(Path('/private/tmp/tank-linkding-old-artifacts-20261020.json').read_text());assert len(old)==30
for name,sha in old.items():assert h((ROOT/name).read_bytes())==sha
bf=json.loads((OUT/'app-files-before.json').read_text());af=json.loads((OUT/'app-files-after.json').read_text());assert bf==af
for name,sha in bf.items():assert h((APP/name).read_bytes())==sha
assert not json.loads((OUT/'server-cleanup.json').read_text())['alive_after_signal']
summary={'kind':'no-model-qualification','controls':len(rows),'script_completed':len(rows),'business_matched':len(rows),'cleanup':len(rows),'observations':sum(len(r['observations'])for r in rows),'complete_observations':32,'captures_accepted':16,'captures_refused':16,'editor_captures_accepted':0,'editor_captures_total':16,'additional_animation_probes':5,'additional_refused':5,'additional_unique_png':1,'model_calls':0,'old_archives_unchanged':15,'app_files_unchanged':len(bf),'rows':rows,'pixel_sha256':hashes[0],'qualification_passed':False,'blocker':'hidden infinite loading pseudo-element animation rejected as unstable_visual_frame; visible-motion safety unchanged','limit':'scripted native control; no Controller, real model, quality or speed comparison'}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='rows'},ensure_ascii=False))
