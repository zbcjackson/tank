"""Read-only animation/pixel attribution; no cancellation or page style patch."""
import asyncio,dataclasses,hashlib,json
from pathlib import Path
from agent_computer_use.channels.dom import BrowserConfig,ManagedChromiumChannel
from tank_backend.agents.subagent import SubAgentAuthorization,SubAgentBudget,SubAgentContext
OUT=Path('/private/tmp/tank-linkding-animation-20261020');SERVER=Path('/private/tmp/tank-linkding-probe2-20261020');AUTH=Path('/private/tmp/tank-linkding-qualified-20261020/control-4-target-2/auth.json')
async def main():
 OUT.mkdir(exist_ok=False);origin='http://127.0.0.1:'+str(json.loads((SERVER/'ready.json').read_text())['port']);ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event());ctx.runtime.bind('animation-diagnostic');ch=ManagedChromiumChannel(BrowserConfig(scope='linkding',url=origin+'/bookmarks'));result={'samples':[],'model_calls':0}
 try:
  await ch.start(ctx);await ch.page.context.add_cookies([{**json.loads(AUTH.read_text()),'url':origin}]);await ch.page.goto(origin+'/bookmarks',timeout=5000);await ch.page.locator('li[data-bookmark-id="1"]').get_by_role('link',name='Edit',exact=True).click(timeout=5000);await ch.page.get_by_label('Title',exact=True).wait_for(timeout=5000)
  for n in range(5):
   if n:await asyncio.sleep(.25)
   snap=await ch.observe('linkding',ctx)
   anim=await ch.page.evaluate('''() => document.getAnimations().map(a=>{const e=a.effect?.target,s=e?getComputedStyle(e):null,t=a.effect?.getTiming();return {name:a.animationName,playState:a.playState,pending:a.pending,timing:{duration:t?.duration,iterations:String(t?.iterations)},target:e?{tag:e.tagName,id:e.id,classes:e.className,outerHTML:e.outerHTML,visibility:s.visibility,display:s.display,opacity:s.opacity,animation:s.animation,rect:e.getBoundingClientRect().toJSON(),ancestors:[...function*(n){for(;n;n=n.parentElement)yield n}(e)].map(p=>({tag:p.tagName,visibility:getComputedStyle(p).visibility,display:getComputedStyle(p).display}))}:null}})''')
   try:await ch.capture(snap,ctx);capture='accepted'
   except Exception as exc:capture=str(exc)
   png=await ch.visual_png();name=f'sample-{n}.png';(OUT/name).write_bytes(png)
   result['samples'].append({'sample':n,'animation':anim,'capture':capture,'png':name,'sha256':hashlib.sha256(png).hexdigest(),'viewport':await ch.page.evaluate('({width:innerWidth,height:innerHeight})'),'dom_revision':ch.view.revision})
  (OUT/'editor.html').write_text(await ch.page.content())
 finally:
  await ch.aclose();await ctx.runtime.aclose();result['cleanup']=ch.closed and not ch.browser.is_connected();(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'captures':[s['capture']for s in result['samples']],'unique_png':len({s['sha256']for s in result['samples']}),'animations':result['samples'][0]['animation'],'cleanup':result['cleanup']},ensure_ascii=False))
asyncio.run(main())
