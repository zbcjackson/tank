"""No model SDK configured: public host qualification plus scripted product control."""
import asyncio, dataclasses, hashlib, json, shutil, sqlite3, sys, time
from contextlib import closing
from pathlib import Path
from agent_computer_use.channels.dom import BrowserConfig, ManagedChromiumChannel
from agent_computer_use.contracts import GoalContract
from agent_computer_use.action_builder import ActionBuilder
from agent_computer_use.visual_selector import VisualSelector
from agent_computer_use.model_view import decision_question
from tank_backend.agents.subagent import SubAgentAuthorization, SubAgentBudget, SubAgentContext
from tank_backend.llm.model_data import ModelDataScope
APP=Path('/private/tmp/linkding-1.47.0');PYTHON=APP/'.venv/bin/python'
OUT=Path('/private/tmp/tank-linkding-qualified-20261020')
SERVER=Path('/private/tmp/tank-linkding-probe2-20261020')
def serial(o):
    if dataclasses.is_dataclass(o): return dataclasses.asdict(o)
    if hasattr(o,'model_dump'): return o.model_dump(mode='json')
    raise TypeError(type(o).__name__)
def save(path, data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=serial)+'\n')
def db():
    with closing(sqlite3.connect((APP/'data/db.sqlite3').as_uri()+'?mode=ro',uri=True)) as con:
        con.row_factory=sqlite3.Row;con.execute('BEGIN')
        names=[r[0]for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'bookmarks_%' ORDER BY name")]
        return {'tables':{n:[dict(r)for r in con.execute('SELECT * FROM '+n+' ORDER BY rowid')]for n in names},'schema':[list(r)for r in con.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]}
DOM="""() => ({url:location.href,title:document.title,frames:document.querySelectorAll('iframe,frame').length,shadow:[...document.querySelectorAll('*')].filter(e=>e.shadowRoot).map(e=>e.tagName),viewport:{width:innerWidth,height:innerHeight},list:[...document.querySelectorAll('li[data-bookmark-id]')].map(e=>({id:e.dataset.bookmarkId,text:e.innerText,title:e.querySelector('.title a')?.innerText,href:e.querySelector('.title a')?.href,description:e.querySelector('.description')?.innerText})),animations:document.getAnimations().map(a=>({state:a.playState,pending:a.pending})),forms:[...document.forms].map(e=>({action:e.action,method:e.method})),inputs:[...document.querySelectorAll('input,textarea')].filter(e=>e.type!=='hidden').map(e=>({id:e.id,type:e.type,name:e.name,value:e.value,rect:e.getBoundingClientRect().toJSON()}))})"""
async def main():
    OUT.mkdir(exist_ok=False)
    protocol={'kind':'qualification-only-not-model-execution-freeze','revision':1,'model_calls':0,'native_script_controls':4,'targets':[1,2,1,2],'phases':['list','editor','filled','returned'],'probes':['immediate','fresh-after-250ms'],'viewport':[1280,720],'tasks':[{'target':n,'old_title':f'Draft bookmark {n}','new_title':f'Launch bookmark {n}','preserve':'all other bookmark fields except server date_modified; all other bookmark rows, tags and associations'}for n in (1,2)],'native_script_is_not_model_or_controller_success':True,'native_script_timeout_ms':5000,'host_capture_guards':'unchanged','source_baseline':'38bc1eba','source_archive_sha256':hashlib.sha256(Path('/private/tmp/tank-linkding-v1.47.0.tar.gz').read_bytes()).hexdigest()}
    save(OUT/'protocol.json',protocol)
    app_files={str(p.relative_to(APP)):hashlib.sha256(p.read_bytes()).hexdigest()for p in APP.rglob('*')if p.is_file()and not set(p.relative_to(APP).parts)&{'.venv','node_modules','data','__pycache__'}and p.suffix!='.pyc'}
    save(OUT/'app-files-before.json',app_files)
    rows=[]
    for index,target in enumerate(protocol['targets']):
        path=OUT/f'control-{index+1}-target-{target}';path.mkdir()
        proc=await asyncio.create_subprocess_exec(str(PYTHON),'/private/tmp/tank-linkding-qualification-app.py','seed',str(path),cwd=APP,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
        output,_=await proc.communicate();(path/'seed.log').write_bytes(output)
        assert proc.returncode==0,output.decode()
        before=db();save(path/'database-before.json',before);shutil.copyfile(APP/'data/db.sqlite3',path/'before.db')
        http_start=len((SERVER/'http.jsonl').read_text().splitlines())
        origin='http://127.0.0.1:'+str(json.loads((SERVER/'ready.json').read_text())['port'])
        ch=ManagedChromiumChannel(BrowserConfig(scope='linkding',url=origin+'/bookmarks'))
        events=[]
        class Observer:
            def on_event(self,kind,metadata):events.append({'kind':kind,**metadata})
        ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})),SubAgentBudget(),asyncio.Event(),observer=Observer(),model_data_scope=ModelDataScope(frozenset({'text','image'}),32*1024*1024));ctx.runtime.bind(path.name)
        visual=VisualSelector(ch);visual.register(ctx)
        intent=f'Find bookmark titled Draft bookmark {target} at https://example.test/item-{target}. Change only its title to Launch bookmark {target}, save, and confirm the returned bookmark list. Preserve other fields and records.'
        goal=GoalContract.from_input({'schema_version':2,'goal_id':path.name,'scope':'linkding','authorization_ref':'current_task','intent':intent,'objective':intent,'allowed_operations':['click','fill'],'inputs':[{'key':'title','purpose':'Requested title','field_label':'Title','value':f'Launch bookmark {target}'}],'completion':[{'key':'status:Confirmed bookmark title','value':f'Launch bookmark {target}'}]})
        row={'id':path.name,'target':target,'goal':goal.model_dump(mode='json'),'observations':[],'script_completed':False}
        try:
            await ch.start(ctx)
            auth=json.loads((path/'auth.json').read_text());await ch.page.context.add_cookies([{**auth,'url':origin}]);await ch.page.goto(origin+'/bookmarks',timeout=5000)
            await ch.page.wait_for_function("customElements.get('ld-form') !== undefined && document.readyState === 'complete'",timeout=5000)
            for phase in protocol['phases']:
                if phase=='editor':
                    await ch.page.locator(f'li[data-bookmark-id="{target}"]').get_by_role('link',name='Edit',exact=True).click(timeout=5000)
                    await ch.page.wait_for_url(f'**/bookmarks/{target}/edit?**',timeout=5000)
                    await ch.page.get_by_label('Title',exact=True).wait_for(timeout=5000)
                if phase=='filled':await ch.page.get_by_label('Title',exact=True).fill(f'Launch bookmark {target}',timeout=5000)
                if phase=='returned':
                    await ch.page.get_by_role('button',name='Save',exact=True).click(timeout=5000);await ch.page.wait_for_url(origin+'/bookmarks',timeout=5000)
                    await ch.page.get_by_role('link',name=f'Launch bookmark {target}',exact=True).wait_for(timeout=5000)
                for timing in protocol['probes']:
                    if timing!='immediate':await asyncio.sleep(.25)
                    snap=await ch.observe('linkding',ctx);actions=ActionBuilder(visual=True).build(path.name,1,goal,snap)
                    entry={'phase':phase,'timing':timing,'snapshot':snap,'actions':actions,'public_question':decision_question(goal,snap,actions)}
                    try:
                        frame=await visual.capture_frame(snap,actions,ctx)
                        entry['capture']={'status':'accepted','frame':frame.frame,'bounds':frame.bounds}
                    except Exception as exc:entry['capture']={'status':'refused','type':type(exc).__name__,'reason':str(exc)}
                    frame=ch.visual_frame
                    if frame is not None:
                        name=f'{phase}-{timing}.png';(path/name).write_bytes(frame.png);entry['raw_frame']={'path':name,'frame':frame.frame,'bounds':frame.bounds}
                    entry['dom']=await ch.page.evaluate(DOM)
                    row['observations'].append(entry);save(path/'row.json',row)
                    print(json.dumps({'control':row['id'],'phase':phase,'timing':timing,'complete':snap.complete,'reason':actions.reason,'candidates':len(actions.actions),'capture':entry['capture']},default=serial))
                (path/f'{phase}.html').write_text(await ch.page.content());(path/f'{phase}.png').write_bytes(await ch.page.screenshot(type='png'))
            row['script_completed']=True
        except Exception as exc:
            row['error']={'type':type(exc).__name__,'reason':str(exc)};print(row['error'])
        finally:
            await ch.aclose();await ctx.runtime.aclose();row['cleanup']=ch.closed and not ch.browser.is_connected()
            row['events']=events;row['after']=db();save(path/'database-after.json',row['after']);shutil.copyfile(APP/'data/db.sqlite3',path/'after.db')
            row['http']=[json.loads(s)for s in (SERVER/'http.jsonl').read_text().splitlines()[http_start:]]
            row['model_calls']=sum(e['kind']=='model_call'for e in events)
            row['host_actions']=ctx.budget.actions_used if hasattr(ctx.budget,'actions_used')else ctx.budget.snapshot()
            save(path/'row.json',row);rows.append(row);save(OUT/'result.json',{'protocol':protocol,'rows':rows})
    after={str(p.relative_to(APP)):hashlib.sha256(p.read_bytes()).hexdigest()for p in APP.rglob('*')if p.is_file()and not set(p.relative_to(APP).parts)&{'.venv','node_modules','data','__pycache__'}and p.suffix!='.pyc'}
    save(OUT/'app-files-after.json',after);assert app_files==after
    print(json.dumps({'controls':len(rows),'script_completed':sum(r['script_completed']for r in rows),'captures':{s:sum(o['capture']['status']==s for r in rows for o in r['observations'])for s in ('accepted','refused')},'cleanup':sum(r['cleanup']for r in rows),'model_calls':sum(r['model_calls']for r in rows)}))
asyncio.run(main())
