import asyncio, json
from pathlib import Path
from dataclasses import asdict
from agent_computer_use.channels.dom import BrowserConfig, ManagedChromiumChannel
from agent_computer_use.contracts import GoalContract
from agent_computer_use.action_builder import ActionBuilder
from tank_backend.agents.subagent import SubAgentAuthorization, SubAgentBudget, SubAgentContext
OUT=Path('/private/tmp/tank-linkding-probe-20261020')
async def main():
    port=json.loads((OUT/'ready.json').read_text())['port']; origin=f'http://127.0.0.1:{port}'
    ch=ManagedChromiumChannel(BrowserConfig(scope='linkding', url=origin+'/bookmarks'))
    ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop','network'})), SubAgentBudget(),asyncio.Event());ctx.runtime.bind('initial-probe')
    goal=GoalContract.from_input({'schema_version':2,'goal_id':'second-product','scope':'linkding','authorization_ref':'current_task','intent':'Find Draft bookmark 1, change only its title to Launch bookmark 1, save and confirm the returned list. Keep other fields and bookmarks unchanged.','objective':'Edit bookmark title','allowed_operations':['click','fill'],'inputs':[{'key':'title','purpose':'Requested title','field_label':'Title','value':'Launch bookmark 1'}],'completion':[{'key':'status:Confirmed bookmark title','value':'Launch bookmark 1'}]})
    receipts=[]
    try:
        await ch.start(ctx)
        auth=json.loads((OUT/'auth.json').read_text());await ch.page.context.add_cookies([{**auth,'url':origin}]);await ch.page.goto(origin+'/bookmarks/');await ch.page.wait_for_load_state('networkidle')
        for phase in ('list','editor','filled'):
            if phase=='editor':
                await ch.page.locator('li[data-bookmark-id="1"]').get_by_role('link',name='Edit',exact=True).click();await ch.page.wait_for_url('**/bookmarks/1/edit?**');await ch.page.wait_for_load_state('networkidle')
            if phase=='filled': await ch.page.get_by_label('Title',exact=True).fill('Launch bookmark 1')
            snap=await ch.observe('linkding',ctx);actions=ActionBuilder(visual=True).build('second-product',1,goal,snap)
            raw=await ch.page.evaluate('''() => ({url:location.href,title:document.title,frames:document.querySelectorAll('iframe,frame').length,shadow:[...document.querySelectorAll('*')].filter(e=>e.shadowRoot).map(e=>e.tagName),viewport:{width:innerWidth,height:innerHeight},list:[...document.querySelectorAll('li[data-bookmark-id]')].map(e=>({id:e.dataset.bookmarkId,text:e.innerText})),inputs:[...document.querySelectorAll('input,textarea')].map(e=>({id:e.id,type:e.type,name:e.name,value:e.type==='hidden'?'[omitted]':e.value,rect:e.getBoundingClientRect().toJSON()}))})''')
            item={'phase':phase,'snapshot':asdict(snap),'actions':asdict(actions),'dom':raw}
            try:
                frame=await ch.capture(snap,ctx);(OUT/f'{phase}-bound.png').write_bytes(frame.png);item['capture']={'status':'captured','bounds':frame.bounds,'frame':asdict(frame.frame)}
            except Exception as e: item['capture']={'status':'refused','type':type(e).__name__,'reason':str(e)}
            (OUT/f'{phase}.html').write_text(await ch.page.content());(OUT/f'{phase}.png').write_bytes(await ch.page.screenshot(type='png'))
            receipts.append(item)
            print(json.dumps({'phase':phase,'complete':snap.complete,'elements':len(snap.elements),'reason':actions.reason,'candidates':len(actions.actions),'capture':item['capture']['status'],'shadow':raw['shadow'],'frames':raw['frames'],'controls':[{'role':d.role,'label':d.label,'ancestors':d.ancestors}for d in actions.details]},ensure_ascii=False))
    finally:
        await ch.aclose();await ctx.runtime.aclose();(OUT/'probe.json').write_text(json.dumps({'observations':receipts,'cleanup':ch.closed and not ch.browser.is_connected()},ensure_ascii=False,indent=2))
asyncio.run(main())
