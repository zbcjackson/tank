"""Independent exact-distribution checks; no model or qualification runner."""
import json
import math
from pathlib import Path
from scipy.stats import beta, binom, norm

root=Path('/private/tmp/tank-jev-confirmation-prep-20261021-v5')
analysis=json.loads((root/'sample-size-analysis.json').read_text())
minima=[]
for row in analysis['zero_event_precision']:
    n=row['zero_events_min_N_for_two_sided95_upper']
    margin=row['upper_bad_event_probability']
    assert 1-.025**(1/n)<=margin<1-.025**(1/(n-1))
for row in analysis['binary_sensitivity']:
    target=row['independent_Bernoulli_units']
    margin=row['margin']
    probability=row['assumed_bad_event_probability']
    found=None
    for n in range(1,target+1):
        k=int(binom.ppf(.025,n,margin))
        while k>=0 and binom.cdf(k,n,margin)>.025:
            k-=1
        power=float(binom.cdf(k,n,probability)) if k>=0 else 0.
        if power>=.8:
            found=(n,k,power)
            break
    assert found is not None and found[0]==target and found[1]==row['critical_max_events']
    assert math.isclose(found[2],row['conditional_power'],abs_tol=1e-12)
    assert beta.ppf(.975,found[1]+1,target-found[1])<=margin
    minima.append(found)
for row in analysis['time_sensitivity']:
    n=math.ceil(((norm.isf(.025)+norm.isf(.2))*row['assumed_paired_SD_seconds']/abs(row['assumed_mean_difference_seconds']))**2)
    assert n==row['normal_approx_independent_pairs']
counterexample=[]
for n in (5521,5544):
    k=int(binom.ppf(.025,n,.02))
    k-=int(binom.cdf(k,n,.02)>.025)
    counterexample.append({'N':n,'critical_max_events':k,'power':float(binom.cdf(k,n,.015))})
assert counterexample[0]['power']>=.8>counterexample[1]['power']
assert 2*2*(6*4+6*3+4*5+4*4)==312
assert 48*(24+2*24)==3456 and 96*120/3600==3.2
report={'zero_event_N':[r['zero_events_min_N_for_two_sided95_upper'] for r in analysis['zero_event_precision']],
        'binary_minima':minima,'rounding_counterexample':counterexample,
        'illustrative_positive_SDK':312,'conditional_upper_SDK':3456,'deadline_sum_hours':3.2}
Path('/private/tmp/tank-jev-confirmation-review1-math.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
