"""Independent physical, HTTP, candidate and sample-size audit; no host/scorer imports."""
from pathlib import Path
import copy,hashlib,json,math,sqlite3
from contextlib import closing
ROOT=Path('/private/tmp/tank-jev-confirmation-prep-20261021-v5');OUT=Path('/private/tmp/tank-jev-confirmation-review1-independent.json')
def read(p):return json.loads(p.read_text())
def physical(p,product):
 with closing(sqlite3.connect(p.as_uri()+'?mode=ro',uri=True))as db:
  db.row_factory=sqlite3.Row;db.execute('BEGIN');schema=[list(r)for r in db.execute('SELECT type,name,sql FROM sqlite_master ORDER BY type,name')]
  if product=='sqlite-web':return {'records':[dict(r)for r in db.execute('SELECT * FROM work_items ORDER BY id')],'writes':[dict(r)for r in db.execute('SELECT * FROM _writes ORDER BY rowid')],'schema':schema}
  names=[r[0]for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'AND name LIKE'bookmarks_%'ORDER BY name")];tables={n:[dict(r)for r in db.execute('SELECT * FROM '+n+' ORDER BY rowid')]for n in names};assert len(names)==10
  return {'tables':tables,'schema':schema}
protocol=read(ROOT/'protocol.json');tasks=read(ROOT/'calibration-tasks.json');result=read(ROOT/'qualification/result.json');assert len(tasks)==len(result['rows'])==24;assert not protocol['model_execution_eligible'];rows=[]
for c,r in zip(tasks,result['rows']):
 assert c['id']==r['id'];d=ROOT/'qualification'/r['id'];before=physical(d/'before.db',c['product']);after=physical(d/'after.db',c['product']);want=copy.deepcopy(before)
 if c['group']!='negative':
  records=want['records']if c['product']=='sqlite-web'else want['tables']['bookmarks_bookmark'];b=next(x for x in records if x['id']==c['target']);b['title']=c['public_goal']['inputs'][0]['value']
  if c['product']=='sqlite-web':
   assert len(after['writes'])==1 and after['writes'][0]['operation']=='update'and after['writes'][0]['id']==c['target'];want['writes']=after['writes']
  else:
   a=next(x for x in after['tables']['bookmarks_bookmark']if x['id']==c['target']);assert a['date_modified']>b['date_modified'];b['date_modified']=a['date_modified']
 business=want==after;assert business==r['business_match']
 http=[json.loads(s)for s in(d/'proxy/http.jsonl').read_text().splitlines()];assert http==r['http'];posts=[x for x in http if x['method']=='POST'];assert len(posts)==(0 if c['group']=='negative'else 1);assert all(not x['injected']for x in posts);faults=[x for x in http if x['injected']];assert len(faults)==(1 if c['group']=='recovery'else 0);assert all(x['method']=='GET'and x['status']==503 for x in faults)
 # A complete page image is different from a usable whole-action candidate set.
 states=[]
 for o in r['observations']:
  image_ok=o['capture']=='accepted'
  if image_ok:
   png=(d/o['png']).read_bytes();assert png[:8]==b'\x89PNG\r\n\x1a\n'and int.from_bytes(png[16:20],'big')==1280 and int.from_bytes(png[20:24],'big')==720
  states.append({'phase':o['phase'],'complete':o['snapshot']['complete'],'ready':o['snapshot']['ready'],'reason':o['actions']['reason'],'candidates':len(o['actions']['actions']),'total_candidates':o['actions']['total_candidates'],'capture':o['capture'],'png':o.get('png')})
 list_state=next(s for s in states if s['phase']=='list');model_list_eligible=bool(list_state['complete']and list_state['ready']and list_state['candidates']and list_state['capture']=='accepted')
 revoked=bool(c['family']=='revoked'and isinstance(r.get('negative_evidence'),dict)and r['negative_evidence']['type']=='SubAgentStopped'and business and not posts)
 assert r['model_calls']==0 and not any(e['kind']=='model_call'for e in r['events']);assert r['cleanup']
 # Full actual returned list independently compared against the public title change.
 if c['group']!='negative':
  v=r['returned_list'];expected=c['private_acceptance']['records']
  if c['product']=='sqlite-web':assert sorted(v['rows'])==sorted([[str(x[k])for k in('id','title','notes')]for x in expected])
  else:assert sorted((x['id'],x['title'],x['url'])for x in v['list']['records'])==sorted((str(x['id']),x['title'],x['url'])for x in expected)
 rows.append({'id':c['id'],'product':c['product'],'group':c['group'],'business':business,'script_finished':r.get('script_finished',False),'cleanup':r['cleanup'],'reported_qualified':r['qualified'],'list_model_eligible':model_list_eligible,'revocation_guard_verified':revoked,'missing_target_verified':c['family']=='missing'and business and not posts,'states':states})
a=read(ROOT/'sample-size-analysis.json')
for z in a['zero_event_precision']:
 n=z['zero_events_min_N_for_two_sided95_upper'];bound=z['upper_bad_event_probability'];assert 1-.025**(1/n)<=bound and 1-.025**(1/(n-1))>bound
for z in a['binary_sensitivity']:
 if 'N_over'in z:continue
 n=z['independent_Bernoulli_units'];k=z['critical_max_events']
 def cdf(p,k):return sum(math.exp(math.lgamma(n+1)-math.lgamma(i+1)-math.lgamma(n-i+1)+i*math.log(p)+(n-i)*math.log1p(-p))for i in range(k+1))
 assert cdf(z['margin'],k)<=.025+1e-10 and cdf(z['margin'],k+1)>.025-1e-10;assert abs(cdf(z['assumed_bad_event_probability'],k)-z['conditional_power'])<1e-8
summary={'planned':24,'executed':len(rows),'native_fixture_business_pass':sum(r['business']and r['script_finished']for r in rows),'cleanup':sum(r['cleanup']for r in rows),'model_list_eligible':sum(r['list_model_eligible']for r in rows),'positive_model_list_eligible':sum(r['list_model_eligible']and r['group']!='negative'for r in rows),'positive_planned':20,'revocation_guards':sum(r['revocation_guard_verified']for r in rows),'missing_targets':sum(r['missing_target_verified']for r in rows),'capture_accepted':sum(s['capture']=='accepted'for r in rows for s in r['states']),'observations':sum(len(r['states'])for r in rows),'model_calls':0,'formal_confirmation_N':None,'rows':rows,'sample_math_independently_checked':True}
OUT.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='rows'}))
