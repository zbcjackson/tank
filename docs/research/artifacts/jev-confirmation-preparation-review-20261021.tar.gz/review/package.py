"""Add an immutable review supplement without rewriting the original archive."""
import gzip
import hashlib
import io
import json
import os
import re
import tarfile
from pathlib import Path
from dotenv import dotenv_values

repo=Path('/Users/zbcjackson/src/tank')
temporary=Path('/private/tmp')
sha=lambda content:hashlib.sha256(content).hexdigest()
prefix='tank-jev-confirmation-review1-'
items={
    'review/protocol-addendum.json':temporary/(prefix+'protocol-addendum.json'),
    'review/independent-qualification.json':temporary/(prefix+'independent.json'),
    'review/evidence-check.py':temporary/(prefix+'check.py'),
    'review/evidence-check.json':temporary/(prefix+'check.json'),
    'review/qualification-audit.py':temporary/(prefix+'audit.py'),
    'review/math-check.py':temporary/(prefix+'math-check.py'),
    'review/math-check.json':temporary/(prefix+'math.json'),
    'review/package.py':Path(__file__),
    'presentation/jev-confirmation-preparation.canvas.tsx':Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-confirmation-preparation.canvas.tsx'),
}
values={**dotenv_values(repo/'backend/core/.env'),**os.environ}
credentials={s.encode() for k,s in values.items() if s and len(s)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)}
assert len(credentials)==21
original=repo/'docs/research/artifacts/jev-confirmation-preparation-20261021.tar.gz'
assert sha(original.read_bytes())=='9af2212aba1f931fdfbcb1ba4f4a262eb7a434eb4eb1183bb1f01ed4507a3ae0'
members=[]
for name,path in sorted(items.items()):
    content=path.read_bytes()
    assert not any(secret in content for secret in credentials),name
    members.append({'name':name,'bytes':len(content),'sha256':sha(content)})
target=repo/'docs/research/artifacts/jev-confirmation-preparation-review-20261021.tar.gz'
manifest_path=target.with_name('jev-confirmation-preparation-review-20261021-manifest.json')
assert not target.exists() and not manifest_path.exists()
with target.open('xb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
    for member in members:
        content=items[member['name']].read_bytes()
        assert sha(content)==member['sha256']
        info=tarfile.TarInfo(member['name'])
        info.size=len(content);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(content))
with tarfile.open(target) as archive:
    assert len(archive.getmembers())==len(members)
    for expected in members:
        file=archive.extractfile(expected['name'])
        assert file is not None
        content=file.read()
        assert len(content)==expected['bytes'] and sha(content)==expected['sha256']
        assert not any(secret in content for secret in credentials)
manifest={'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),
          'original_archive_sha256':sha(original.read_bytes()),'reviewed_baseline':'7bf3ddbf','reviewed_head':'2c05061b',
          'review_round':1,'model_execution_eligible':False,'formal_N':None,
          'actual_credentials_scanned':len(credentials),'credential_matches':0,'members':members}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
