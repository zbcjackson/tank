"""Read-only preparation evidence review: no product, Controller or model imports."""
import base64
import hashlib
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path
from dotenv import dotenv_values
from PIL import Image

repo = Path('/Users/zbcjackson/src/tank')
raw = Path('/private/tmp/tank-jev-confirmation-prep-20261021-v5')
archive_path = repo/'docs/research/artifacts/jev-confirmation-preparation-20261021.tar.gz'
manifest = json.loads(archive_path.with_name('jev-confirmation-preparation-20261021-manifest.json').read_text())
sha = lambda content: hashlib.sha256(content).hexdigest()
assert sha(archive_path.read_bytes()) == manifest['sha256']
assert archive_path.stat().st_size == manifest['bytes'] == 26837499
env = {**dotenv_values(repo/'backend/core/.env'), **os.environ}
credentials = {s.encode() for k,s in env.items() if s and len(s)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)}
assert len(credentials) == 21
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert len(members)==len(manifest['members'])==len({m.name for m in members})==1878
    for member, expected in zip(members,manifest['members']):
        entry=archive.extractfile(member)
        assert member.isfile() and entry is not None and member.name==expected['name']
        content=entry.read()
        assert len(content)==expected['bytes'] and sha(content)==expected['sha256']
        assert not any(secret in content for secret in credentials), member.name
        if member.name.startswith('v5/'):
            assert content == (raw/member.name.removeprefix('v5/')).read_bytes()
    entry=archive.extractfile('verification/product-source-copy-inventory.json')
    assert entry is not None
    inventory=json.loads(entry.read())
    assert len(inventory)==36
    expected_source=json.loads((raw/'qualification-freeze.json').read_text())['apps']['linkding']['source_files']
    assert len(expected_source)==446
    assert all(source==expected_source for source in inventory.values())
    entry=archive.extractfile('presentation/jev-confirmation-preparation.canvas.tsx')
    assert entry is not None
    archived_panel=entry.read()
old=json.loads(Path('/private/tmp/tank-jev-confirmation-old-artifacts.json').read_text())
assert len(old)==34
for name, expected in old.items():
    assert sha((repo/name).read_bytes())==expected['sha256']
    assert subprocess.check_output(['git','rev-parse','7bf3ddbf:'+name],cwd=repo,text=True).strip()==expected['baseline_blob']
freeze=json.loads((raw/'qualification-freeze.json').read_text())
assert manifest['qualification_sha256']==freeze['sha256']=='85484800240de47aa985759407acdf27c9920c96089307f20d597799ee37edd7'
for name, expected in freeze['source_sha256'].items():
    assert sha((repo/'backend'/name).read_bytes())==expected
    assert sha((raw/'qualification-source/runtime'/name).read_bytes())==expected
assert len(freeze['source_sha256'])==35
task_bytes=(raw/'calibration-tasks.json').read_bytes()
for suffix in ('v3','v4'):
    root=Path('/private/tmp/tank-jev-confirmation-prep-20261021-'+suffix)
    assert (root/'calibration-tasks.json').read_bytes()==task_bytes
    previous=json.loads((root/'qualification-freeze.json').read_text())
    assert previous['source_sha256']==freeze['source_sha256']
    previous_result=json.loads((root/'qualification/result.json').read_text())
    assert previous_result['planned']==len(previous_result['rows'])==24
for suffix in ('','-v2'):
    assert not (Path('/private/tmp/tank-jev-confirmation-prep-20261021'+suffix)/'qualification/result.json').exists()
tasks=json.loads(task_bytes)
result=json.loads((raw/'qualification/result.json').read_text())
audit=json.loads(Path('/private/tmp/tank-jev-confirmation-review1-independent.json').read_text())
panel_path=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-confirmation-preparation.canvas.tsx')
panel=panel_path.read_bytes()
# The original presentation is preserved in the immutable archive; a reviewed caption may differ.
parse=lambda value: json.loads(re.search(r'^const DATA:.*?=(.*);$',value.decode(),re.M).group(1))
data=parse(panel)
assert data==parse(archived_panel)
math=json.loads((raw/'sample-size-analysis.json').read_text())
for key,source in (('binary','binary_sensitivity'),('precision','zero_event_precision')):
    assert len(data[key])==len(math[source])
    for shown,actual in zip(data[key],math[source]):
        assert all(actual[k]==v for k,v in shown.items())
assert data['fixture']==24 and data['observations']==data['captures']==104 and data['guards']==2
sql_counts=[]
screenshots=[]
for shown, task, row, independent in zip(data['rows'],tasks,result['rows'],audit['rows']):
    assert shown['id']==task['id']==row['id']==independent['id']
    assert shown['product']==task['product'] and shown['group']==task['group'] and shown['target']==task['target']
    assert shown['intent']==task['public_goal']['intent'] and shown['business']==independent['business']
    listing=next(o for o in row['observations'] if o['phase']=='list')
    assert shown['reason']==listing['actions']['reason'] and shown['candidate_count']==0
    assert shown['complete']==listing['snapshot']['complete']
    assert shown['total_candidates']==listing['actions']['total_candidates']
    if task['product']=='sqlite-web':
        sql_counts.append((task['id'],shown['total_candidates']))
        assert shown['complete'] and shown['reason']=='candidate_limit'
    else:
        assert not shown['complete'] and shown['reason']=='scope_incomplete'
        assert any(e['role']=='list' and len(e.get('value',''))==4096 for e in listing['snapshot']['elements'])
    for state, actual in zip(shown['states'],independent['states']):
        for key,value in state.items():assert value==actual[key]
    content=base64.b64decode(shown['image'].split(',',1)[1],validate=True)
    image_path=raw/'qualification'/task['id']/listing['png']
    assert content==image_path.read_bytes()
    with Image.open(image_path) as image:
        image.load();assert image.format=='PNG' and image.size==(1280,720)
    screenshots.append(str(image_path))
assert len(screenshots)==len(tasks)==24
assert sorted(n for _,n in sql_counts)==[37]*10+[38]*2
for product in ('all','sqlite-web','linkding'):
    for group in ('all','normal','recovery','negative'):
        assert any((product=='all' or r['product']==product) and (group=='all' or r['group']==group) for r in data['rows'])
report={'round':1,'baseline':'7bf3ddbf','reviewed':'2c05061b','archive_sha256':manifest['sha256'],
        'members':len(members),'actual_credential_values':len(credentials),'credential_matches':0,
        'old_archive_and_manifest_files_unchanged':len(old),'runtime_sources_unchanged':35,
        'deduplicated_source_copies':len(inventory),'canvas_list_PNG_byte_checks':len(screenshots),
        'list_candidate_counts_sqlite':sql_counts,'independent_summary':{k:v for k,v in audit.items() if k!='rows'},
        'screenshots':screenshots}
Path('/private/tmp/tank-jev-confirmation-review1-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='screenshots'}))
