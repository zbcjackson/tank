"""Archive immutable live evidence and independently verified source bytes."""
import hashlib,json,os,re,subprocess,sys,tarfile
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/zbcjackson/src/tank');artifacts=root/'docs/research/artifacts';live=Path(sys.argv[1]);review=sys.argv[2]
h=lambda b:hashlib.sha256(b).hexdigest()
old={}
for p in sorted(artifacts.glob('*-manifest.json')):
 if not (p.name.startswith('jev-') or p.name.startswith('dom-visual-freshness-')):continue
 prior=subprocess.run(['git','show','ce76f7cd:'+str(p.relative_to(root))],cwd=root,capture_output=True)
 if prior.returncode:continue
 assert prior.stdout==p.read_bytes()
 m=json.loads(prior.stdout);archive=p.with_name(p.name.replace('-manifest.json','.tar.gz'))
 assert h(archive.read_bytes())==m['archive_sha256'];old[archive.name]=m['archive_sha256']
assert len(old)==10
result=json.loads((live/'result.json').read_text());f=json.loads((live/'freeze.json').read_text());assert result['sha256']==f['sha256']
files={'live/'+str(p.relative_to(live)):p for p in live.rglob('*')if p.is_file()}
for n,sha in f['source_sha256'].items():
 p=root/'backend'/n;assert h(p.read_bytes())==sha;files['source/'+n]=p
for name in ('analyze.py','summary.json','pack.py'):
 p=Path('/private/tmp/tank-route-followup-'+name);files['analysis/'+p.name]=p
for p in sorted(Path('/private/tmp').glob('tank-route-followup-*.log')):files['verification/'+p.name]=p
old_prepare=Path('/private/tmp/tank-route-followup-live-20261019/freeze.json')
if old_prepare.exists() and old_prepare!=live/'freeze.json':files['superseded-prepare/freeze.json']=old_prepare
values={**dotenv_values(root/'backend/core/.env'),**os.environ}
secrets=[v.encode()for k,v in values.items()if v and len(v)>=8 and re.search('API_KEY|TOKEN|PASSWORD|SECRET',k,re.I)];assert secrets
for n,p in files.items():assert not any(s in p.read_bytes()for s in secrets),f'credential found: {n}'
archive=artifacts/'jev-vision-route-followup-20261019.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tf:
 for n,p in sorted(files.items()):tf.add(p,arcname=n,recursive=False)
manifest={'date':'2026-10-19','baseline_commit':'ce76f7cd','plan_commit':'f3aa2acd','implementation_commit':'6e28a019','first_review_commit':review,'freeze_sha256':result['sha256'],'archive_sha256':h(archive.read_bytes()),'credential_values_scanned':len(secrets),'old_archives_unchanged':old,'files':{n:{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for n,p in sorted(files.items())}}
with tarfile.open(archive,'r:gz')as tf:
 assert set(tf.getnames())==set(files)
 for m in tf.getmembers():
  b=tf.extractfile(m).read();assert h(b)==manifest['files'][m.name]['sha256']and len(b)==manifest['files'][m.name]['bytes']
archive.with_name('jev-vision-route-followup-20261019-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(files),'pngs':sum(n.endswith('.png')for n in files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'old_archives':len(old),'credential_values':len(secrets)}))
