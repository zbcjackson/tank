"""Bounded, read-only native freshness diagnosis. No model or input dispatch."""
import asyncio, hashlib, io, json, linecache, sys, time
from dataclasses import asdict, fields
from pathlib import Path
from unittest.mock import patch
from PIL import Image, ImageChops
from benchmarks.computer_use import jev_image_ablation as recipe, s4_ax
from agent_computer_use import create_subagent
from agent_computer_use.channels import native
from agent_computer_use.contracts import Action, Binding, Target
from tank_backend.agents.subagent import SubAgentAuthorization, SubAgentBudget, SubAgentContext
from tank_backend.agents.task_runtime import TaskOperation
from tank_backend.tools.computer_native import run_native
from tank_backend.tools.computer_observation import Observation

OUTPUT=Path(sys.argv[1]);OUTPUT.mkdir(exist_ok=False)
SOURCE=Path(native.__file__)
REPORT={'source_sha256':{str(SOURCE):hashlib.sha256(SOURCE.read_bytes()).hexdigest(),str(Path(__file__)):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'model_calls':0,'input_attempts':[],'rows':[]}
def persist(): (OUTPUT/'result.json').write_text(json.dumps(REPORT,indent=2)+'\n')
def no_input(*args,**kwargs):
 REPORT['input_attempts'].append('unexpected input');persist();raise RuntimeError('diagnostic forbids task input')
def compare(a,b):
 ia=Image.open(io.BytesIO(a)).convert('RGB');ib=Image.open(io.BytesIO(b)).convert('RGB')
 assert ia.size==ib.size
 delta=ImageChops.difference(ia,ib)
 return {'bbox':delta.getbbox(),'changed_pixels':sum(v!=(0,0,0) for v in delta.get_flattened_data()),'size':ia.size}

def traced_current(channel,binding,action,ctx,row,label):
 detail={}
 def trace(frame,event,arg):
  if frame.f_code is not native.NativeAXChannel.current.__code__:return None
  if event=='return':
   detail.update(line=frame.f_lineno,source=linecache.getline(str(SOURCE),frame.f_lineno).strip(),accepted=arg is not None)
   local=frame.f_locals
   if 'fresh_frame' in local:
    fresh=local['fresh_frame'];old=local['captured'].frame
    detail['scene_equal']=old.scene_sha256==fresh.scene_sha256
    detail['fresh_frame']=asdict(fresh)
    recreated,png=Observation.capture(local['png'],session_id=ctx.runtime.task_id,display_id=old.display_id,window_id=old.window_id,window_bounds=old.window_bounds,display_geometry=old.display_geometry)
    assert recreated.scene_sha256==fresh.scene_sha256
    path=row['id']+'-'+label+'-current.png';(OUTPUT/path).write_bytes(png);detail['fresh_png']=path
    detail['pixels']=compare(local['captured'].png,png)
   if 'fresh' in local and local.get('old') is not None:
    old=local['old'];fresh=local['fresh']
    detail['ax_difference']=['missing'] if fresh is None else [f.name for f in fields(old) if f.name!='index' and getattr(old,f.name)!=getattr(fresh,f.name)]
    detail['ax_old']={k:getattr(old,k) for k in ('role','title','identifier','value','frame','enabled')}
   detail['window_equal']=channel.bound_window(ctx)==channel.window
  return trace
 prior=sys.gettrace();sys.settrace(trace)
 try:actual=channel.current(binding,action,ctx)
 finally:sys.settrace(prior)
 assert detail['accepted']==(actual is not None)
 return detail

async def main():
 recipe.preflight()
 # Four new owned contexts; no candidate is ever dispatched.
 for position in range(2):
  for scene in ('scene-01','scene-02'):
   scope=f'{scene}-p{position}'
   row={'id':scope,'captures':[],'checks':[],'cleanup':None};REPORT['rows'].append(row);persist()
   owner=s4_ax.OwnedApplication({'id':scope,'application':'textedit','dispatch':'ax_press','repeat':0,'max_decisions':0,'move_window':bool(position)},rtf=recipe.documents()[scene])
   observer=s4_ax.PilotObserver();ctx=SubAgentContext(SubAgentAuthorization(frozenset({'desktop'})),SubAgentBudget(),asyncio.Event(),deadline=time.monotonic()+30,observer=observer)
   ctx.runtime.bind(scope);plugin=None
   try:
    config=owner.start();recipe.select_heading(owner,config)
    plugin=create_subagent({'macos':{'profiles':{'com.apple.TextEdit':s4_ax.macos_policy()['profiles']['com.apple.TextEdit']}}});channel=plugin.controller.source
    await channel.bind(Target(application='com.apple.TextEdit'),scope,ctx)
    observe=TaskOperation('diagnostic.observe',frozenset({'desktop'}),'read',lambda ignored:channel.observe(scope,ctx));ctx.runtime.register(observe)
    capture=TaskOperation('diagnostic.capture',frozenset({'desktop'}),'read',lambda snap:channel.capture(snap,ctx));ctx.runtime.register(capture)
    check=TaskOperation('diagnostic.current',frozenset({'desktop'}),'read',lambda label:run_native(traced_current,channel,binding,action,ctx,row,label));ctx.runtime.register(check)
    snap=await ctx.runtime.execute(observe,None);assert snap.complete
    body=[e for e in snap.elements if 'fill' in e.actions and e.label=='First Text View'];assert len(body)==1
    binding=Binding('diagnostic',1,snap.observation_id,scope,snap.generation,'c');action=Action('never-dispatched',body[0].ref,'fill',recipe.VARIANTS['north'])
    start=time.monotonic();last=None
    for i,delay in enumerate((0,.1,.1,.2,.5,1,1)):
     await asyncio.sleep(delay)
     if i:
      d=await ctx.runtime.execute(check,str(i));row['checks'].append({'delay':delay,'at_seconds':time.monotonic()-start,**d});persist()
     shot=await ctx.runtime.execute(capture,snap);name=f'{scope}-{i}.png';(OUTPUT/name).write_bytes(shot.png)
     row['captures'].append({'path':name,'at_seconds':time.monotonic()-start,'frame':asdict(shot.frame),'delta':compare(last.png,shot.png) if last else None});last=shot
     persist()
    row['body']=owner.read_values();assert row['body']=={'document':recipe.BODY}
    api=s4_ax.computer_ax._load_ax();target=next(v for _,v in channel.source.targets if v.identifier=='First Text View')
    selected=api['AXUIElementCopyAttributeValue'](target.element.native,'AXSelectedText',None);assert selected==(0,'Jev visual probe');row['selected_text']=selected
    row['setup_actions']=owner.setup_actions;row['binding']=config.model_dump(mode='json');row['known_tokens']=ctx.budget.total_tokens;row['events']=observer.events
    assert ctx.runtime.decision_model is None and ctx.budget.total_tokens==0
   except Exception as exc:
    row['error_type']=type(exc).__name__;row['error']=str(exc);raise
   finally:
    try:
     await ctx.runtime.aclose()
     if plugin is not None:await plugin.aclose()
    finally:row['cleanup']=owner.close();persist()
   if not row['cleanup']['confirmed']:raise RuntimeError('cleanup failed')
 REPORT['completed']=True;persist()

with patch.object(native,'ax_set_value',no_input),patch.object(native,'ax_press',no_input),patch.object(s4_ax.computer_use_macos,'_click_macos',no_input):
 asyncio.run(main())
print(json.dumps({'completed':REPORT['completed'],'rows':len(REPORT['rows']),'model_calls':0,'task_inputs':len(REPORT['input_attempts'])}))
