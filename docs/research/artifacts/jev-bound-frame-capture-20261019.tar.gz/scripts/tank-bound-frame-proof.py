"""Actual capture/Observation pipeline; synthetic screencapture only, real sips."""
import hashlib,io,json,subprocess
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from tank_backend.tools import computer_use_macos as macos
from tank_backend.tools.computer_observation import Observation
from benchmarks.computer_use.jev_image_ablation import freeze_inputs
OUT=Path('/private/tmp/tank-bound-frame-proof-20261019');OUT.mkdir(exist_ok=False)
root=Path('/private/tmp/tank-frame-diagnostics-20261019-resample');geometry=(4,0,0,1920,1080,3840,2160);bounds=(213,77,840,954)
real_run=subprocess.run;state={'data':b''};commands=[]
def run(args,**kwargs):
 commands.append(args)
 if args[0]=='screencapture':
  Path(args[-1]).write_bytes(state['data']);return subprocess.CompletedProcess(args,0,'','')
 return real_run(args,**kwargs)
rows=[]
with patch.object(macos,'_active_displays',lambda:(geometry,)),patch.object(macos.subprocess,'run',run):
 for mode in ('logical','backing'):
  images=[];frames=[]
  for label in ('a','b','inside'):
   state['data']=(root/('a-backing.png' if label=='inside' else label+'-backing.png')).read_bytes()
   if label=='inside':
    image=Image.open(io.BytesIO(state['data']));image.putpixel((bounds[2]*2-1,400),(0,0,0));stream=io.BytesIO();image.save(stream,'PNG');state['data']=stream.getvalue()
   start=len(commands);raw=macos._capture_screenshot_macos(include_cursor=False,display=4,backing=mode=='backing')
   frame,png=Observation.capture(raw,session_id='synthetic-proof',display_id=4,window_id=1,window_bounds=bounds,display_geometry=geometry)
   (OUT/f'{mode}-{label}.png').write_bytes(png);frames.append(frame);images.append(png)
   rows.append({'mode':mode,'id':label,'frame':asdict(frame),'commands':commands[start:]})
  outside_equal=frames[0].scene_sha256==frames[1].scene_sha256
  assert outside_equal==(mode=='backing')
  if mode=='backing':assert images[0]==images[1]
  assert frames[0].scene_sha256!=frames[2].scene_sha256
report={'rows':rows,'repository_sources':freeze_inputs(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'capture_boundary':'synthetic screencapture bytes, real sips for unchanged logical default; original production backing capture branch and Observation','backing_outside_equal':True,'backing_inside_equal':False,'legacy_outside_equal':False,'model_calls':0,'task_inputs':0}
(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in {'rows','repository_sources'}}))
