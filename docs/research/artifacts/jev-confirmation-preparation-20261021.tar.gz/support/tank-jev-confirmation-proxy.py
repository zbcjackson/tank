"""Loopback-only qualification proxy. One explicit diagnostic GET failure, never POST."""
import argparse,http.client,json,threading,time
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
p=argparse.ArgumentParser();p.add_argument('--upstream',type=int,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--fault');a=p.parse_args();failed=False;lock=threading.Lock()
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def request(self):
  global failed
  path=self.path.split('?',1)[0]
  with lock:
   injected=bool(a.fault and not failed and self.command=='GET'and path==a.fault)
   if injected:failed=True
  body=self.rfile.read(int(self.headers.get('Content-Length','0')))
  if injected:
   status=503;data=b'<!doctype html><title>Qualification diagnostic GET failure</title><h1>Service unavailable</h1><p>Injected once by the qualification proxy, not the product page. No upstream GET or POST occurred.</p><a href="?retry=1">Retry</a>';headers=[('Content-Type','text/html; charset=utf-8')]
  else:
   connection=http.client.HTTPConnection('127.0.0.1',a.upstream,timeout=10)
   try:
    connection.request(self.command,self.path,body=body,headers={k:v for k,v in self.headers.items()if k.lower()not in('connection','transfer-encoding','content-length')});reply=connection.getresponse();status=reply.status;headers=reply.getheaders();data=reply.read()
   finally:connection.close()
  self.send_response(status)
  for k,v in headers:
   if k.lower()not in('connection','content-length','transfer-encoding'):self.send_header(k,v)
  self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  with lock:
   with(a.output/'http.jsonl').open('a')as out:out.write(json.dumps({'method':self.command,'path':path,'query':self.path.partition('?')[2],'status':status,'injected':injected,'at_monotonic':time.monotonic()})+'\n')
 do_GET=request;do_POST=request;do_HEAD=request
(a.output/'http.jsonl').touch(exist_ok=False)
with ThreadingHTTPServer(('127.0.0.1',0),Handler)as server:
 (a.output/'ready.json').write_text(json.dumps({'port':server.server_port})+'\n');server.serve_forever()
