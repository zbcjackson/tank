"""Preserve every preparation/qualification phase; deduplicate unmodified product source."""
from pathlib import Path
import gzip,hashlib,io,json,os,re,tarfile
from dotenv import dotenv_values
repo=Path('/Users/zbcjackson/src/tank');tmp=Path('/private/tmp');items={};inventory={}
def add(p,name):assert name not in items;items[name]=p
for suffix in ('','-v2','-v3','-v4','-v5'):
 root=tmp/('tank-jev-confirmation-prep-20261021'+suffix);prefix='draft1'if not suffix else suffix[1:]
 for p in sorted(root.rglob('*')):
  relative=p.relative_to(root)
  if p.is_file()and 'app'not in relative.parts and '__pycache__'not in relative.parts and p.suffix!='.pyc':add(p,prefix+'/'+str(relative))
 for app in root.glob('qualification/*/app'):
  files={str(p.relative_to(app)):hashlib.sha256(p.read_bytes()).hexdigest()for p in app.rglob('*')if p.is_file()and not set(p.relative_to(app).parts)&{'data','__pycache__'}and p.suffix!='.pyc'}
  expected=json.loads((root/'qualification-freeze.json').read_text())['apps']['linkding']['source_files'];assert files==expected;inventory[prefix+'/'+str(app.relative_to(root))]=files
for p in sorted(tmp.iterdir()):
 if p.is_file()and p.name.startswith('tank-jev-confirmation-')and p.suffix in('.py','.log','.json')and p.name not in('tank-jev-confirmation-package.log',):add(p,'support/'+p.name)
final=tmp/'tank-jev-confirmation-prep-20261021-v5';f=json.loads((final/'qualification-freeze.json').read_text())
for name,digest in f['apps']['linkding']['source_files'].items():
 p=Path(f['apps']['linkding']['root'])/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;add(p,'official-linkding-source/'+name)
canvas=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-confirmation-preparation.canvas.tsx');add(canvas,'presentation/'+canvas.name)
old=json.loads((tmp/'tank-jev-confirmation-old-artifacts.json').read_text());assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==v['sha256']for n,v in old.items())
v={**dotenv_values(repo/'backend/core/.env'),**os.environ};keys={s.encode()for k,s in v.items()if s and len(s)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)};assert len(keys)==21
extra={'verification/product-source-copy-inventory.json':(json.dumps(inventory,indent=2)+'\n').encode(),'verification/scan.json':(json.dumps({'actual_credential_values':len(keys),'matches':0,'old_archive_manifest_files':len(old),'old_files_unchanged':True,'source_copies_deduplicated':len(inventory),'no_raw_DB_PNG_HTTP_or_failed_phase_removed':True,'deduplication':'unmodified pertrial app sources reference one official source set plus every percopy hash; app/data DB already retained as physical before/after backups'},indent=2)+'\n').encode()}
members=[]
for name in sorted(set(items)|set(extra)):
 data=extra[name]if name in extra else items[name].read_bytes();assert not any(k in data for k in keys),name;members.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=repo/'docs/research/artifacts/jev-confirmation-preparation-20261021.tar.gz';assert not archive.exists()
with archive.open('wb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w')as tar:
 for m in members:
  data=extra[m['name']]if m['name']in extra else items[m['name']].read_bytes();assert hashlib.sha256(data).hexdigest()==m['sha256'];info=tarfile.TarInfo(m['name']);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as tar:
 assert len(tar.getmembers())==len(members)
 for m in members:
  file=tar.extractfile(m['name']);assert file is not None;data=file.read();assert len(data)==m['bytes']and hashlib.sha256(data).hexdigest()==m['sha256'];assert not any(k in data for k in keys)
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'baseline':'7bf3ddbf','qualification_sha256':f['sha256'],'members':members,'old_files':len(old),'actual_credentials_scanned':len(keys),'credential_matches':0,'source_copies_deduplicated':len(inventory),'model_calls':0}
archive.with_name('jev-confirmation-preparation-20261021-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items()if k!='members'}));print('members',len(members))
