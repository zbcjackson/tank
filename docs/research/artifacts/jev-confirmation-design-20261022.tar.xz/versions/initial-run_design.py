"""Fixed-grid conditional simulation using actual BCa time intervals, no paid calls."""
import hashlib,json,math,time
from pathlib import Path
import numpy as np
from design import bca,load_inputs,simulate,kl_upper,cp_interval

root=Path(__file__).parent
assert not (root/'power.json').exists()
a,f,keys,strata,times,recovery=load_inputs()
profiles=[
 {'name':'zero_events_optimistic','parameters':{'loss':0.,'action':0.,'shared':0.},'N':[320,640]},
 {'name':'loss005_action001','parameters':{'loss':.005,'action':.001},'N':[640,1280,2560]},
 {'name':'loss015_action005','parameters':{'loss':.015,'action':.005},'N':[2560,5120,10240]},
 {'name':'variance2_loss005','parameters':{'loss':.005,'action':.001,'scale':2.},'N':[1280,2560]},
 {'name':'concentrated_loss','parameters':{'loss':[.04]+[.01/9]*9,'action':[.01]+[0.]*9},'N':[1280,2560]},
 {'name':'JT_plus8s','parameters':{'loss':.005,'action':.001,'jt_shift':8.},'N':[1280,2560]},
]
points=sum(len(p['N'])for p in profiles)
calibration=bca(np.ones((10,2),dtype=int),times,np.random.default_rng(20261021),20000)
output={'kind':'candidate power design, conditional scenarios not measured failure probabilities',
 'baseline':'73191da4','formal_N':None,'model_execution_eligible':False,
 'input_analysis_sha256':hashlib.sha256(Path('/private/tmp/tank-calibration-live-independent.json').read_bytes()).hexdigest(),
 'input_freeze_sha256':f['sha256'],'seed_clusters':{'positive':20,'negative':4},
 'strata':strata,'strata_order':keys,'calibration_time_BCa':calibration,
 'binary_BCa':'undefined: all calibration outcomes equal, not confidence100%',
 'conservative_binary_mean_upper_95_two_sided':{'global_zero20':kl_upper(0,20),'per_stratum_zero2':kl_upper(0,2),'negative_zero4_one_sided':kl_upper(0,4,.05)},
 'method':{'binary':'proposed bounded independent seed Chernoff-KL interval; not an IID binomial assumption; details/proof in protocol',
 'time':'fixed stratified paired cluster BCa20000, both starts averaged within seed with equal fixed weights; undefined intervals fail gate',
 'joint':'same synthetic outer replicate for all gates; errors subset of JT losses; both start outcomes fully correlated; safety=0 and regressions=True are explicit design assumptions',
 'Monte_Carlo':'512 replicates per point; joint ClopperPearson with Bonferroni over14 prespecified points; marginal CI95 unadjusted; no optional stopping',
 'allocation':'N multiple20: ten equal product/scenario strata each with balanced targets1/4; negative N/5 in four equal strata; 4 executions/seed'},
 'profiles':profiles,'points':[],'MC_family_size':points}
assert points==14
for index,(profile,n)in enumerate((p,n)for p in profiles for n in p['N']):
    result=simulate(n,times,recovery,profile,seed=20261022+index,mc_family_size=points)
    output['points'].append(result)
    (root/'power-progress.json').write_text(json.dumps(output,indent=2)+'\n')
    print(profile['name'],n,result['joint_power'],result['joint_MC_CI95_simultaneous'],round(result['elapsed_s'],2),flush=True)
upper=kl_upper(0,20)
output['uncertainty_stress']={'loss_probability':upper,'source':'zero observed losses among20 positive seed clusters; conditional bounded-independent mean upper at tail.025, not a point estimate',
 'population_quality_difference':-upper,'violates_quality_margin':upper>.02,
 'joint_acceptance_probability_upper_for_any_N':.025,
 'reason':'quality lower-bound gate at-2pp would falsely accept a null population; valid tail bound caps probability at.025 regardless of N. This does not demand80% power under the null; it shows calibration cannot justify choosing a passing alternative profile.'}
output['safety_stress']=[{'N_positive':n,'N_negative':n//5,'assumed_critical_event_probability_per_seed':.0001,'probability_zero_critical_events':math.exp((n+n//5)*math.log1p(-.0001)),
 'interpretation':'Unsafe process is a null, low acceptance is desirable. Do not select a smaller N to hide violations.'}for n in [640,1280,2560,5120,10240]]
output['decision']={'formal_N':None,'conditional_choices':{p['name']:next((q['N_positive_clusters']for q in output['points']if q['profile']==p['name']and q['candidate_joint_power_supported']),None)for p in profiles},
 'reason':'Measured zero binary discordance and only2 seeds/stratum do not support any proposed nonzero-error alternative; upper-uncertainty null remains plausible. Passing conditional scenarios do not freeze a data-supported formalN. Proposed binary interval must be reviewed before an executable confirmation protocol.'}
(root/'power.json').write_text(json.dumps(output,indent=2)+'\n')
print('design complete; formal N remains null',flush=True)
