"""Offline candidate design. No model clients or credentials. Clusters keep both starts."""
import hashlib
import json
import math
from pathlib import Path
from scipy.special import ndtr, ndtri
from scipy.stats import beta
import numpy as np

TAIL=.025
TAU=120.

def kl(q,p):
    return (q*math.log(q/p) if q else 0.)+((1-q)*math.log((1-q)/(1-p)) if q<1 else 0.)

def kl_upper(q,n,alpha=TAIL):
    if not 0<=q<=1 or n<=0 or not 0<alpha<1:raise ValueError('bounded mean, positive clusters and valid tail required')
    if q==0:return -math.expm1(math.log(alpha)/n)
    if q==1:return 1.
    lo,hi=q,1.
    for _ in range(64):
        mid=(lo+hi)/2
        if mid==1 or n*kl(q,mid)>-math.log(alpha):hi=mid
        else:lo=mid
    return (lo+hi)/2

def capped(strict,elapsed_ms):
    if not strict:return TAU
    if elapsed_ms is None or not 0<=elapsed_ms<=TAU*1000:raise ValueError('verified success needs a valid full clock')
    return elapsed_ms/1000

def gates(m):
    specs={'quality_point':('ge',.95),'quality_lower':('ge',.90),
        'quality_difference_lower':('ge',-.02),'family_min_point':('ge',.90),
        'recovery_point':('ge',.90),'recovery_lower':('ge',.80),
        'recovery_difference_lower':('ge',-.05),'unexpected_difference_upper':('le',.01),
        'speed_point':('le',.90),'speed_upper':('lt',1.),'safety_events':('le',0),
        'regressions':('eq',True)}
    result={}
    for key,(op,threshold) in specs.items():
        value=m.get(key)
        result[key]=bool(value is not None and {'ge':lambda:value>=threshold,
            'le':lambda:value<=threshold,'lt':lambda:value<threshold,'eq':lambda:value==threshold}[op]())
    return result

def bca(counts,times,rng,resamples=20000):
    counts=np.asarray(counts);times=np.asarray(times)
    ns=counts.sum(axis=1)
    if counts.ndim!=2 or times.shape!=(*counts.shape,2) or np.any(counts<0) or np.any(ns<2) or not np.all(ns==ns[0]):raise ValueError('balanced strata with at least two paired clusters')
    n=int(ns[0]);means=np.einsum('sk,skj->sj',counts,times)/n
    average=means.mean(axis=0);point=float(average[1]/average[0])
    sample=np.zeros((resamples,2))
    for c,t in zip(counts,times):sample+=rng.multinomial(n,c/n,size=resamples)@t/n/len(ns)
    distribution=sample[:,1]/sample[:,0]
    if np.ptp(distribution)<1e-14:return {'point':point,'interval':None,'reason':'degenerate','resamples':resamples}
    percentile=(np.sum(distribution<point)+.5*np.sum(distribution==point))/resamples
    numerator=denominator=0.
    for c,t,mean in zip(counts,times,means):
        deleted=average+(mean-t)/(n-1)/len(ns)
        jack=deleted[:,1]/deleted[:,0]
        u=(n-1)*(np.dot(c,jack)/n-jack)
        numerator+=np.dot(c,u**3)/n**3;denominator+=np.dot(c,u**2)/n**2
    if not 0<percentile<1 or denominator==0:return {'point':point,'interval':None,'reason':'undefined_BCa','resamples':resamples}
    acceleration=numerator/(6*denominator**1.5);z0=float(ndtri(percentile));z=ndtri([.025,.975]);adjusted=ndtr(z0+(z0+z)/(1-acceleration*(z0+z)))
    if not np.all(np.isfinite(adjusted)) or not 0<=adjusted[0]<=adjusted[1]<=1:return {'point':point,'interval':None,'reason':'undefined_BCa','resamples':resamples}
    interval=np.quantile(distribution,adjusted)
    return {'point':point,'interval':interval.tolist(),'bias_z':z0,'acceleration':float(acceleration),'resamples':resamples}

def load_inputs():
    root=Path('/private/tmp/tank-calibration-live-20261021-r1')
    analysis=Path('/private/tmp/tank-calibration-live-independent.json')
    assert hashlib.sha256(analysis.read_bytes()).hexdigest()=='95895d3da6fc7c24885bfc4c82a42696933593a0ccd90cad5d8f3676ba4d95a9'
    a=json.loads(analysis.read_text());f=json.loads((root/'freeze.json').read_text())
    assert a['sha256']==f['sha256']=='2e071288e1e781733df0ecaba20d6bc539e3dee03fd1303c60f49f4d27e3ce2c'
    cases={c['id']:c for c in f['cases']};strata={};clusters={}
    for r in a['rows']:clusters.setdefault(r['cluster_id'],[]).append(r)
    assert len(a['rows'])==96 and len(clusters)==24
    for cid,rows in clusters.items():
        assert len(rows)==4 and {(r['condition'],r['arm'])for r in rows}=={(c,a)for c in ('cold','prewarmed')for a in ('v','jt')}
        if not rows[0]['positive']:continue
        case=cases[rows[0]['case']]
        family=case['family'] if case['group']=='normal' else 'recovery-'+case['fault_stage']
        key=case['product']+'/'+family
        values=[np.mean([capped(r['strict'],r.get('elapsed_ms'))for r in rows if r['arm']==arm])for arm in ('v','jt')]
        strata.setdefault(key,[]).append({'cluster':cid,'times':values,'target':case['target']})
    assert len(strata)==10 and all(len(v)==2 for v in strata.values())
    keys=sorted(strata);times=np.array([[c['times']for c in strata[k]]for k in keys]);recovery=np.array(['recovery-'in k for k in keys])
    return a,f,keys,strata,times,recovery

def cp_interval(successes,n,alpha=.05):
    return [float(beta.ppf(alpha/2,successes,n-successes+1))if successes else 0.,float(beta.ppf(1-alpha/2,successes+1,n-successes))if successes<n else 1.]

def scenario_support(base,loss,action,shared=.005,scale=1.,jt_shift=0.):
    loss=np.broadcast_to(loss,(len(base),));action=np.broadcast_to(action,(len(base),));shared=np.broadcast_to(shared,(len(base),))
    if np.any(action<0) or np.any(action>loss) or np.any(loss+shared>=1):raise ValueError('coherent joint outcome probabilities required')
    center=base.mean(axis=1,keepdims=True);expanded=np.clip(center+scale*(base-center),.001,TAU);expanded[:,:,1]=np.clip(expanded[:,:,1]+jt_shift,.001,TAU)
    support=[];prob=[]
    for stratum,l,a,s in zip(expanded,loss,action,shared):
        times=[];p=[]
        for pair in stratum:
            times.extend([pair,[pair[0],TAU],[pair[0],TAU],[TAU,TAU]])
            p.extend([(1-l-s)/2,(l-a)/2,a/2,s/2])
        support.append(times);prob.append(p)
    return np.array(support),np.array(prob)

def metrics(counts,times,recovery,speed_result,safety_events=0):
    n=int(counts.sum());states=counts.reshape((len(counts),2,4)).sum(axis=1)
    loss=int(states[:,1:3].sum());action=int(states[:,2].sum());failure=int(states[:,1:].sum())
    rn=int(counts[recovery].sum());rs=states[recovery];rf=int(rs[:,1:].sum());rl=int(rs[:,1:3].sum())
    return {'quality_point':1-failure/n,'quality_lower':1-kl_upper(failure/n,n),
        'quality_difference_lower':-kl_upper(loss/n,n),
        'family_min_point':float(np.min(1-states[:,1:].sum(axis=1)/states.sum(axis=1))),
        'recovery_point':1-rf/rn,'recovery_lower':1-kl_upper(rf/rn,rn),
        'recovery_difference_lower':-kl_upper(rl/rn,rn),
        'unexpected_difference_upper':kl_upper(action/n,n),
        'speed_point':speed_result['point'],'speed_upper':speed_result['interval'][1]if speed_result['interval']else None,
        'safety_events':safety_events,'regressions':True}

def simulate(n,base,recovery,profile,*,replicates=512,resamples=20000,seed=20261022,mc_family_size=1):
    if n%20:raise ValueError('N must balance ten strata and both target positions')
    support,prob=scenario_support(base,**profile['parameters']);rng=np.random.default_rng(seed);results=[]
    import time
    started=time.monotonic()
    for _ in range(replicates):
        counts=np.array([rng.multinomial(n//10,p)for p in prob])
        result=bca(counts,support,rng,resamples)
        values=metrics(counts,support,recovery,result)
        checks=gates(values);results.append(checks)
    marginal={k:sum(q[k]for q in results)for k in results[0]};passed=sum(all(q.values())for q in results);ci=cp_interval(passed,replicates,alpha=.05/mc_family_size)
    return {'N_positive_clusters':n,'N_negative_clusters':n//5,'scheduled_trials':n*24//5,'profile':profile['name'],
        'replicates':replicates,'bootstrap_resamples_per_replicate':resamples,'marginal':{k:{'passed':v,'power':v/replicates,'MC_CI95':cp_interval(v,replicates)}for k,v in marginal.items()},
        'joint_passed':passed,'joint_power':passed/replicates,'joint_MC_CI95_simultaneous':ci,'MC_family_size':mc_family_size,
        'candidate_joint_power_supported':ci[0]>=.8,'elapsed_s':time.monotonic()-started}
