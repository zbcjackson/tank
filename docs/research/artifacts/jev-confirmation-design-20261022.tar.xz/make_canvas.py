import json
from pathlib import Path
root=Path(__file__).parent
p=json.loads((root/'power.json').read_text());v=json.loads((root/'candidate-validation.json').read_text());b=json.loads((root/'reserved-bank/manifest.json').read_text());resources=json.loads((root/'resource-preview.json').read_text())
names={'zero_events_optimistic':'零事件乐观假设','zero':'零事件乐观假设','loss005_action001':'相对失误0.5% / 额外动作0.1%',
 'loss015_action005':'相对失误1.5% / 额外动作0.5%','variance2_loss005':'低失误＋残差×2','variance2_loss015':'高失误＋残差×2',
 'concentrated_loss':'低失误集中一层','concentrated_loss005':'低失误集中一层','concentrated_loss015':'高失误集中一层','JT_plus8s':'JT每任务增加8秒'}
labels={'quality_point':'质量点≥95%','quality_lower':'质量下界≥90%','quality_difference_lower':'质量差下界≥−2pp','family_min_point':'每主要族点≥90%',
 'recovery_point':'恢复点≥90%','recovery_lower':'恢复下界≥80%','recovery_difference_lower':'恢复差下界≥−5pp','unexpected_difference_upper':'额外业务动作差上界≤+1pp',
 'speed_point':'封顶均时比≤0.90','speed_upper':'时间区间上界<1','safety_events':'关键安全事件0（前提）','regressions':'治理回归通过（前提）'}
def point(q):
 return {'profile':q['profile'],'name':names[q['profile']],'n':q['N_positive_clusters'],'negative':q['N_negative_clusters'],'trials':q['scheduled_trials'],
  'power':q['joint_power'],'lower':q['joint_MC_CI95_simultaneous'][0],'upper':q['joint_MC_CI95_simultaneous'][1]}
validation=[{**point(q),'gates':[{'key':k,'name':labels[k],'power':val['power'],'passed':val['passed']}for k,val in q['marginal'].items()]}for q in v['results']]
data={'explore':[point(q)for q in p['points']],'validation':validation,'strata':b['strata'],'bankSeeds':b['seed_clusters'],'goals':b['condition_goals'],
 'timeBCa':p['calibration_time_BCa']['interval'],'ratio':p['calibration_time_BCa']['point'],'upper20':p['conservative_binary_mean_upper_95_two_sided']['global_zero20'],
 'upper2':p['conservative_binary_mean_upper_95_two_sided']['per_stratum_zero2'],'resources':resources,'masterCommitment':b['seed_commitment'],'dataSha':b['cases_sha256']}
code=r'''import {Stack,Row,H1,H2,Text,Stat,Table,Select,Callout,BarChart,useState,useHostTheme} from "cursor/canvas";
type Point={profile:string;name:string;n:number;negative:number;trials:number;power:number;lower:number;upper:number};
type Validation=Point&{gates:{key:string;name:string;power:number;passed:number}[]};
const DATA:{explore:Point[];validation:Validation[];strata:Record<string,number>;bankSeeds:number;goals:number;timeBCa:number[];ratio:number;upper20:number;upper2:number;resources:{positive_seed_clusters:number;negative_seed_clusters:number;trials:number;historical_wall_hours:number;historical_estimate_usd:number;historical_known_tokens:number;task_deadline_sum_hours:number}[];masterCommitment:string;dataSha:string}=__DATA__;
const pct=(q:number)=>(q*100).toFixed(2)+"%";
export default function ConfirmationDesign(){const theme=useHostTheme();const[profile,setProfile]=useState("loss005_action001");const[selected,setSelected]=useState(DATA.validation[0].profile);const points=DATA.explore.filter(q=>q.profile===profile);const validation=DATA.validation.find(q=>q.profile===selected)??DATA.validation[0];
return <Stack gap={24} style={{maxWidth:1180,margin:"0 auto",padding:24,background:theme.bg.editor,color:theme.text.primary}}>
<Stack gap={8}><Text size="small" tone="secondary">2026-10-22 · V/JT正式确认设计 · 离线仿真</Text><H1>条件方案可复核，正式N仍未准入</H1><Text>候选10240正例簇＋2048负例簇，对应49152次执行。它只在七个声明的合成分布下达到条件功效；本轮没有新增模型实验或启动正式确认。</Text></Stack>
<Row gap={32} wrap><Stat value="20 / 10" label="已测正例seed / 固定分层"/><Stat value="81.78%" label="七情形最弱联合MC同时下界"/><Stat value={DATA.bankSeeds.toLocaleString()} label="新数据seed保留库（未原生资格）"/><Stat value="0" label="本轮新增模型调用"/></Row>
<Callout tone="warning">每层只有2个选定校准seed，零失误不能当真实失误率0。按原准备的不足/不稳规则保留pilot；区间候选、保留库与正式执行器尚需审查/资格。零假设下不应要求80%采纳率；null压力情形失败本身不禁止确认。</Callout>
<Stack gap={8}><H2>为什么速度区间过门仍不能直接采用</H2><Table headers={["项目","当前计算","解释"]} rows={[["校准封顶均时比",`${DATA.ratio.toFixed(6)}，BCa [${DATA.timeBCa.map(q=>q.toFixed(6)).join(", ")}]`,"固定分层配对seed诊断，不是正式确认"],["0/20的稀疏失误条件上界",pct(DATA.upper20),"在独立/代表性假设下的诊断；不是新任务总体保证"],["每层0/2的条件上界",pct(DATA.upper2),"每层样本很少，不能从退化bootstrap推出100%可靠"]]}/><Text size="small" tone="secondary">原门保留：质量/恢复/额外业务动作/速度/安全全部同时满足；负例另报。二项界候选为有界seed平均量Chernoff-KL，时间保留BCa20000；不是把相关冷暖当独立样本。</Text></Stack>
<Stack gap={8}><H2>探索：全部门同时通过的条件概率（%）</H2><Select value={profile} onChange={setProfile} options={Array.from(new Map(DATA.explore.map(q=>[q.profile,{value:q.profile,label:q.name}])).values())}/><Text size="small" tone="secondary">横轴：正例seed簇数N；纵轴：条件通过概率（%）。512个合成外层结果/点，每个时间区间20000次bootstrap。</Text><BarChart categories={points.map(q=>q.n.toLocaleString())} series={[{name:"联合通过点估计",data:points.map(q=>q.power*100),tone:"info"},{name:"MC同时95%下界（探索14点族）",data:points.map(q=>q.lower*100),tone:"neutral"}]} yMax={100} yMin={0} height={260} referenceLines={[{value:80,label:"目标80%",tone:"neutral"}]} valueSuffix="%"/><Table headers={["N正例","N负例","执行次数","联合概率","MC同时区间"]} rows={points.map(q=>[q.n,q.negative,q.trials,pct(q.power),`${pct(q.lower)}–${pct(q.upper)}`])}/><Text size="small" tone="tertiary">来源：power.json · 2026-10-22。只列已计算点，不补零、不插值继承功效。参数是假设，非观测错误率；JT增加8秒是每完整任务，属于压力/null诊断。</Text></Stack>
<Stack gap={8}><H2>固定10240后，用新随机流复核</H2><Table headers={["指定生成分布","联合通过估计","MC同时95%区间（验证7分布族）"]} rows={DATA.validation.map(q=>[q.name,pct(q.power),`${pct(q.lower)}–${pct(q.upper)}`])}/><Text>七个分布均包含明确的时间/失误/相关性假设。残差×2经过截断，不是方差×2；额外业务错误是JT失败子集，两启动条件错误完全相关。关键安全事件0、回归通过是设计前提，未由仿真证明。</Text><Select value={validation.profile} onChange={setSelected} options={DATA.validation.map(q=>({value:q.profile,label:q.name}))}/><Table headers={["同一外层结果中的门","通过数 / 512","边际通过概率"]} rows={validation.gates.map(q=>[q.name,`${q.passed}/512`,pct(q.power)])}/><Text size="small" tone="secondary">来源：candidate-validation.json。不是把各门概率相乘。验证族单独控制MC不确定性，不声称探索和验证合起来同时95%；未检验任意参数组合。</Text></Stack>
<Stack gap={8}><H2>保留库：数据新，布局与数值ID保持</H2><Table headers={["固定层","seed数","两条件目标数"]} rows={Object.entries(DATA.strata).map(([k,n])=>[k,n,n*2])}/><Text>{DATA.goals.toLocaleString()}份目标全部通过当前GoalContract解析，新数据指纹与24校准case无交集。没有原生业务/图片/候选资格或可执行schedule。原ID1/4、四行原版应用与模板保持，不冒称新布局或新应用。</Text><Text size="small" tone="secondary">正例步长40平衡十层、两目标位置、两先运行arm；另一启动条件反转。N/5负例分四层是分配规则，不是新错误率门。bank commitment：{DATA.masterCommitment}；cases SHA256：{DATA.dataSha}。</Text></Stack>
<Stack gap={8}><H2>资源预览：按上一批机械外推</H2><Table headers={["正例 / 负例簇","执行次数","串行墙钟(h)","历史费率估算(USD)","期限和(h)"]} rows={DATA.resources.map(q=>[`${q.positive_seed_clusters} / ${q.negative_seed_clusters}`,q.trials,q.historical_wall_hours.toFixed(1),q.historical_estimate_usd.toFixed(2),q.task_deadline_sum_hours.toFixed(1)])}/><Text size="small" tone="secondary">来源：2026-10-21校准49分钟、4412681已知tokens及冻结历史费率。不是当前报价、实际账单或耗时保证；失败、服务变化及批次开销可改变。期限和不是批次墙钟硬上界。</Text></Stack>
<Stack gap={8}><H2>已核验与后续前置</H2><Text>7项行为测试、SciPy独立BCa（包含非零加速项）、独立求根/精确尾概率、56项精确边际概率复核通过。未修改生产源码或默认配置；旧校准原档保持。</Text><Text>下一阶段先做新bank与执行器的原生/SDK假HTTP资格，再单独预注册补充校准。若选“零事件双侧95%上界≤0.5%”信息目标，解析门槛736，平衡重算为760正例＋152负例（3648次）。这只是未执行提案；有错误照实保留，不追加到过门，不消耗确认保留库。</Text></Stack>
</Stack>}
'''
target=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-confirmation-design.canvas.tsx')
assert not target.exists();target.write_text(code.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':'))));print(target.stat().st_size)
