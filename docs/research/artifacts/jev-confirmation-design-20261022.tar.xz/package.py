"""Freeze offline design evidence and preserve all inputs/versions; never execute models."""
import hashlib,io,json,lzma,os,re,tarfile
from pathlib import Path
from dotenv import dotenv_values

root=Path(__file__).parent;repo=Path('/Users/zbcjackson/src/tank');sha=lambda b:hashlib.sha256(b).hexdigest()
canvas=Path('/Users/zbcjackson/.cursor/projects/Users-zbcjackson-src-tank/canvases/jev-confirmation-design.canvas.tsx')
presentation=root/'presentation';presentation.mkdir(exist_ok=False)
(presentation/canvas.name).write_bytes(canvas.read_bytes())
assert(root/'canvas-tsc.log').read_bytes()==b''
assert'7 passed'in(root/'tests-final.log').read_text()
assert'56 exact marginal'in(root/'power-independent.log').read_text()
files={str(p.relative_to(root)):p for p in root.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.suffix!='.pyc'}
assert'freeze.json'not in files
protocol=json.loads((root/'protocol-v2.json').read_text());assert protocol['formal_N']is None and not protocol['model_execution_eligible']
frozen={'kind':'offline design freeze, not executable model approval','baseline':'73191da4','active_protocol':'protocol-v2.json','formal_N':None,'model_execution_eligible':False,'files':{n:sha(p.read_bytes())for n,p in files.items()}}
frozen['sha256']=sha(json.dumps(frozen,sort_keys=True,separators=(',',':')).encode())
(root/'freeze.json').write_text(json.dumps(frozen,indent=2)+'\n');files['freeze.json']=root/'freeze.json'
old=json.loads((root/'old-artifacts.json').read_text());assert len(old)==42
assert all(sha((repo/n).read_bytes())==v['sha256']for n,v in old.items())
values={**dotenv_values(repo/'backend/core/.env'),**os.environ}
credentials={s.encode()for k,s in values.items()if s and len(s)>=8 and re.search(r'(API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|PUBLIC_KEY)',k,re.I)};assert len(credentials)==21
members=[]
for name,p in sorted(files.items()):
 data=p.read_bytes();assert not any(s in data for s in credentials),name
 members.append({'name':name,'bytes':len(data),'sha256':sha(data)})
target=repo/'docs/research/artifacts/jev-confirmation-design-20261022.tar.xz'
manifest_path=target.with_name('jev-confirmation-design-20261022-manifest.json');assert not target.exists()and not manifest_path.exists()
with target.open('xb')as output,lzma.LZMAFile(output,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as archive:
 for member in members:
  data=files[member['name']].read_bytes();assert sha(data)==member['sha256'];info=tarfile.TarInfo(member['name']);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
with tarfile.open(target,mode='r|xz')as archive:
 count=0
 for actual,expected in zip(archive,members,strict=True):
  assert actual.name==expected['name'];stream=archive.extractfile(actual);assert stream is not None;data=stream.read();assert len(data)==expected['bytes']and sha(data)==expected['sha256'];assert not any(s in data for s in credentials);count+=1
 assert count==len(members)
manifest={'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'design_freeze_sha256':frozen['sha256'],'members':members,'old_files_unchanged':42,'actual_credentials_scanned':21,'matches':0,'formal_N':None,'model_calls_added':0}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items()if k!='members'}));print('members',len(members))
