import math
import numpy as np
import pytest
from design import gates, kl_upper, bca, capped

def test_zero_and_all_events_have_analytic_bound():
    assert kl_upper(0,20)==pytest.approx(1-.025**(1/20))
    assert kl_upper(0,368)<.01<kl_upper(0,367)
    assert kl_upper(1,20)==1
    for bad in (-.1,1.1):
        with pytest.raises(ValueError):kl_upper(bad,20)

def test_completion_clock_caps_failed_and_unrun():
    assert capped(False,1200)==120
    assert capped(False,None)==120
    assert capped(True,3500)==3.5
    with pytest.raises(ValueError):capped(True,None)
    with pytest.raises(ValueError):capped(True,120001)

def test_all_mandatory_gates_are_conjunctive():
    good=dict(quality_point=1.,quality_lower=.99,quality_difference_lower=-.001,
        family_min_point=1.,recovery_point=1.,recovery_lower=.99,
        recovery_difference_lower=-.001,unexpected_difference_upper=.001,
        speed_point=.8,speed_upper=.9,safety_events=0,regressions=True)
    assert all(gates(good).values())
    bad=dict(quality_point=.949,quality_lower=.899,quality_difference_lower=-.021,
        family_min_point=.899,recovery_point=.899,recovery_lower=.799,
        recovery_difference_lower=-.051,unexpected_difference_upper=.011,
        speed_point=.901,speed_upper=1.,safety_events=1,regressions=False)
    for key,value in bad.items():
        assert not all(gates({**good,key:value}).values()),key
    assert not all(gates({**good,'speed_upper':None}).values())

def test_degenerate_bca_is_undefined():
    times=np.array([[[10.,10.],[10.,10.]]]*10)
    counts=np.ones((10,2),dtype=int)
    assert bca(counts,times,np.random.default_rng(1),20000)['interval'] is None

def test_bca_two_conditions_are_one_seed_and_ratio_of_means():
    times=np.array([[[10.,3.],[30.,12.]]]*10)
    counts=np.ones((10,2),dtype=int)
    result=bca(counts,times,np.random.default_rng(1),20000)
    assert result['point']==pytest.approx(15/40)
    assert not math.isclose(result['point'],(.3+.4)/2)
    assert result['interval'][0]<result['point']<result['interval'][1]
