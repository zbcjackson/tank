import json
from bank import build,validate

def test_new_reserved_bank_has_complete_goals_and_is_not_executable(tmp_path):
    manifest=build(tmp_path,40,b'new-test-seed-not-a-credential')
    assert manifest['formal_N'] is None and manifest['model_execution_eligible'] is False
    assert manifest['seed_clusters']==48 and manifest['condition_goals']==96
    assert 'schedule' not in manifest
    checked=validate(tmp_path)
    assert checked['new_seed_clusters']==48 and checked['overlap_with_calibration']==0
    rows=[json.loads(s)for s in (tmp_path/'cases.jsonl').read_text().splitlines()]
    for r in rows:
        assert r['goal']['goal_id']==r['id']
        assert len(r['seed'])==4
        assert r['goal']['completion'][0]['key']=='status:Records'
        if r['negative']=='revoked':
            wanted=json.loads(r['goal']['completion'][0]['value'])
            assert next(q for q in wanted if q['id']==r['target'])['title']!=next(q for q in r['seed']if q['id']==r['target'])['title']

def test_first_arm_is_balanced_within_each_target_and_start(tmp_path):
    from collections import Counter
    build(tmp_path,40,b'balanced-target-order-test')
    counts=Counter()
    for line in(tmp_path/'cases.jsonl').read_text().splitlines():
        r=json.loads(line)
        if not r['negative']:counts[r['reserved_stratum'],r['target'],r['condition'],r['reserved_arm_order'][0]]+=1
    for stratum,target,condition,arm in counts:
        assert counts[stratum,target,condition,'v']==counts[stratum,target,condition,'jt']
