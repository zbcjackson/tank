# Candidate inference and interpretation

This is an offline design, not confirmation. The original preparation requires
pilot status when the calibration is insufficient or unstable; two selected
seeds per product/scenario cell do not identify rare errors or a response-time
tail law. Failure to attain 80% acceptance under a null does not itself prohibit
a confirmatory experiment. A design can be fixed under externally justified
alternatives, but the seven simulated alternatives here are hypothetical and the
new task bank/runner have not passed native execution qualification. Formal N is
therefore left null; 10240 positive +2048 negative clusters is a conditional,
reviewable allocation, not permission for49152 model trials.

## Bounded cluster binary interval

Let Z_i in[0,1] be a seed's average over the two starts. For positive quality
Z_i is the failure fraction; for paired noninferiority it is the fraction with
V success and JT failure; wins may be ignored conservatively. Both starts stay
together. Equal stratum weights and equal allocations make each seed weight1/N.
Strata need not share a mean. Seed independence and transfer to the future
generator remain assumptions; selecting new labels does not establish them.

For any real lambda, convexity gives E exp(lambda Z_i) <=
1-p_i+p_i exp(lambda). Independence and concavity of log bound the product by
(1-pbar+pbar exp(lambda))^N. Markov optimization yields lower-tail bound
P(Zbar<=q) <= exp[-N D(q||pbar)] for q<pbar, with Bernoulli KL D.
Invert at tail alpha=.025: N D(q||U)=log40. At q=0,
U=1-.025^(1/N); at q=1 U=1. The other tail follows by complement.
This is a conservative inequality inversion, not an exact IID ClopperPearson
interval for all counts. Zero-event equality with the exact binomial formula
does not make the general interval exact or remove the independence assumption.

The paired quality difference >=-E loss and the unexpected-action difference
<=E JT-only excess, so lower=-U(loss) and upper=U(excess) are sufficient bounds.
The same construction applies to the fixed recovery subset. Each endpoint is
tested on the same simulated outcome; no product of independent endpoint powers
is used. An all-required-gates decision is an intersection-union decision: a
false population gate bounds the probability that all gates pass. Simultaneous
family coverage for separate descriptive statements is a distinct question.

## Time and simulation

Time retains the prior fixed-stratum paired seed BCa algorithm,20000 resamples.
Start conditions are averaged inside the seed, not resampled separately. The
statistic is a ratio of fixed-mixture mean capped times, not a mean of ratios.
Stratified jackknife acceleration includes seed multiplicities. Undefined BCa
intervals remain undefined and fail the time CI gate. Independent SciPy checks
include an asymmetric example with nonzero acceleration, not only a symmetric
case where a broken formula could accidentally yield zero.

Each stratum's two observed time pairs supply a finite empirical support. A
coherent joint four-state outcome assigns both success, JT loss without excess,
JT loss with excess, or shared safe failure. Failure time is120s. Loss/excess
rates are hypothetical; both starts' outcomes are fully correlated. Residual
scale2 is followed by clipping, so it is not a claim of exactly doubled variance.
The +8s stress adds seconds per whole JT task, not per SDK call.

The14-point exploration has its own Bonferroni MC family. Candidate10240 and
seven distributions were fixed before a fresh RNG validation with512 outer
draws each; all gates share each draw. CP MC intervals use alpha=.05/7 there.
Passing uses the joint MC lower>=.80, never only marginal powers or an inherited
lower-N estimate. It establishes conditional simulation power for those seven
distributions only, not a uniform guarantee over all possible alternatives.

Critical-event rates above zero are unsafe nulls. More observations finding a
violation is desirable; smaller N must not be selected to hide it. Negative
allocation N/5 preserves the prior ratio; it is not a new negative-error cutoff.
Correct-exit bounds remain reported separately.

## Sources

- Hoeffding(1963), Probability Inequalities for Sums of Bounded Random Variables,
  DOI10.1080/01621459.1963.10500830. Publisher search metadata verified; full
  publisher text returned403. The derivation above is provided in full rather
  than claiming to have read inaccessible pages.
- NIST confidence intervals:
  https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm
- SciPy bootstrap reference, paired resampling and degenerate BCa warning:
  https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html
  Actual installed version1.17.1 is recorded; the public web reference currently
  displays1.18.0. The independent test uses installed1.17.1, including its xp
  argument. The first failed verifier and original log are retained.
