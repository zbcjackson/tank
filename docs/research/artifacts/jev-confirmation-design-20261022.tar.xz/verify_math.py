"""Independent SciPy algorithms, expanded clusters and exact finite-support checks."""
import json,math
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
from scipy.stats import bootstrap,binom,binomtest
from scipy.stats._resampling import _bca_interval
from scipy._lib._array_api import array_namespace
from design import bca,kl_upper,load_inputs

root=Path(__file__).parent
_,_,keys,strata,base,recovery=load_inputs()
checks=[]
for n in (20,183,368,640,1280):
    exact=binomtest(0,n).proportion_ci().high
    assert math.isclose(kl_upper(0,n),exact,abs_tol=1e-10)
    for margin in (.01,.02):
        critical=max((k for k in range(n+1)if kl_upper(k/n,n)<=margin),default=-1)
        risk=float(binom.cdf(critical,n,margin))
        assert risk<=.025+1e-12
        checks.append({'n':n,'margin':margin,'critical':critical,'exact_null_acceptance':risk})

heterogeneous=[]
for probabilities in ([.005]*10+[.195]*10,[.01,.99]*10):
    pmf=np.array([1.])
    for p in probabilities:pmf=np.convolve(pmf,[1-p,p])
    mean=np.mean(probabilities);tail=sum(float(pmf[k])for k in range(21)if kl_upper(k/20,20)<mean)
    assert tail<=.025
    heterogeneous.append({'mean':float(mean),'coverage_failure_exact':tail})

def independent_statistic(times):
    def stat(*indices,axis=-1):
        average=np.stack([times[s][np.asarray(v,dtype=int)].mean(axis=axis-1)for s,v in enumerate(indices)]).mean(axis=0)
        return average[...,1]/average[...,0]
    return stat

intervals=[]
for label,times,counts in [('calibration',base,np.ones((10,2),dtype=int)),
    ('asymmetric',np.array([[[10.,5.],[70.,90.]]]*10),np.array([[3,1]]*10))]:
    data=tuple(np.repeat(np.arange(times.shape[1]),c)for c in counts)
    stat=independent_statistic(times)
    reference=bootstrap(data,statistic=stat,paired=False,vectorized=True,method='BCa',n_resamples=20000,batch=1000,rng=np.random.default_rng(1847))
    mine=bca(counts,times,np.random.default_rng(20261021),20000)
    _,_,acceleration=_bca_interval(data,stat,axis=-1,alpha=.025,theta_hat_b=reference.bootstrap_distribution,batch=1000,xp=array_namespace(*data))
    assert math.isclose(float(acceleration),mine['acceleration'],abs_tol=1e-10)
    assert abs(float(reference.confidence_interval.low)-mine['interval'][0])<.01
    assert abs(float(reference.confidence_interval.high)-mine['interval'][1])<.01
    intervals.append({'label':label,'independent_SciPy_interval':list(map(float,reference.confidence_interval)),
        'custom_interval':mine['interval'],'independent_acceleration':float(acceleration),'custom_acceleration':mine['acceleration']})

def independent_upper(q,n):
    if q==0:return 1-.025**(1/n)
    if q==1:return 1.
    return brentq(lambda p:n*(q*math.log(q/p)+(1-q)*math.log((1-q)/(1-p)))+math.log(.025),q,1-1e-13)
for n in (20,640,1280):
    for k in (1,2,3):assert abs(independent_upper(k/n,n)-kl_upper(k/n,n))<1e-10

out={'versions':{'numpy':np.__version__},'zero_event_and_null_tail_checks':checks,
    'heterogeneous_exact_PoissonBinomial':heterogeneous,'BCa_independent_SciPy':intervals,
    'KL_independent_brentq_matches':True,'model_calls':0}
(root/'math-independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
