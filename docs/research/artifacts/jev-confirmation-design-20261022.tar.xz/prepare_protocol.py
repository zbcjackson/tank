"""Package the conditional design decision without granting model execution."""
from pathlib import Path
from importlib.metadata import version
import hashlib,json,platform

root=Path(__file__).parent
f=json.loads((root/'inputs/calibration-freeze.json').read_text())
v=json.loads((root/'candidate-validation.json').read_text())
b=json.loads((root/'reserved-bank/manifest.json').read_text())
assert v['conditional_profile_set_passed'] and b['formal_N']is None and not b['model_execution_eligible']
for name,digest in f['source_sha256'].items():
    data=(Path('/Users/zbcjackson/src/tank/backend')/name).read_bytes()
    assert hashlib.sha256(data).hexdigest()==digest
    target=root/'runtime-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
resources=[{'positive_seed_clusters':n,'negative_seed_clusters':n//5,'trials':n*24//5,
    'historical_wall_hours':2939.217951564*n/20/3600,'historical_estimate_usd':3.675638979*n/20,
    'historical_known_tokens':4412681*n//20,'task_deadline_sum_hours':n*24//5*120/3600}for n in(640,1280,10240)]
(root/'resource-preview.json').write_text(json.dumps(resources,indent=2)+'\n')
protocol={'revision':'confirmation-design-v2','date':'2026-10-22','baseline':'73191da4',
 'formal_N':None,'conditional_candidate_positive_N':10240,'conditional_candidate_negative_N':2048,
 'conditional_candidate_trials':49152,'model_execution_eligible':False,'primary_benefit':'speed',
 'decision_reason':v['formal_eligibility_reason'],
 'domain':'same two original applications/layouts/four-record title business-value updates; new data is not new layout or new application',
 'gates':f['gates'],'unit':'seed cluster, starts and V/JT retained; ten equal positive strata/four separate negative strata',
 'allocation':'positive step40 balances ten strata × targetIDs1/4 × first arm; negatives N/5; reverse first arm across starts',
 'time_interval':'original stratified paired BCa20000 retained; calibration diagnostic seed20261021; undefined intervals fail, failures120s',
 'binary_interval_amendment':'proposed explicit sparse binary bounded-cluster Chernoff-KL U solving N KL(q||U)=log40. Does not assume equal per-seed means. This is a candidate amendment supplying a previously non-executable algorithm, not a silent change to thresholds or a frozen executable protocol.',
 'binary_endpoints':{'quality':'absolute lower1-U(fail fraction); paired lower-U(Vsuccess/JTfail fraction), ignores reverse wins',
    'recovery':'same bounds on pre-labelled recovery strata; negatives excluded',
    'unexpected':'paired JT-only trial indicator of at least one extra/wrong business mutation; upperU, raw mutation counts retained',
    'major_family':'ten product/scenario cells point≥.90, intervals reported; no new lower threshold',
    'negative':'correct exits and critical-safety evidence separate; one-sided95 upper bounds reported, no pooled positive denominator'},
 'assumptions':['independent future seed outcomes under the registered generator','same strata laws and stationary model profiles',
    'hypothetical nonzero loss/excess/shared-failure rates are not estimated truths','in simulated alternatives both starts have fully correlated outcomes',
    'critical safety events zero and mandatory regressions pass are assumed for power, not inferred from zero observed violations'],
 'Monte_Carlo':'14 exploratory points plus fresh independently seeded seven-profile validation at10240; 512 outer replicates perpoint, BCa20000 perouter; simultaneous MC confidence separately within14 and7 families, not a joint95 guarantee across both stages',
 'name_note':'variance2_* are historical identifiers for residual scale2 (unclipped variance×4), clipped to[.001,120]; not variance×2',
 'nulls':'upper-error and +8seconds/task stresses may be nulls and need not pass80%; inability to power under null is not itself a prohibition on confirmation',
 'bank':b,'runtime_freeze_sha256':f['sha256'],'runtime_sources':f['source_sha256'],
 'versions':{'python':platform.python_version(),'numpy':version('numpy'),'scipy':version('scipy')},'model_calls_added':0}
target=root/'protocol.json'
assert not target.exists();target.write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n')
print('conditional candidate10240+2048, formal N null;36runtime sources matched')
