"""Fresh MC validation after exploratory selection; fixed candidate and profiles."""
import json
from pathlib import Path
from design import load_inputs,simulate
root=Path(__file__).parent
assert not(root/'candidate-validation.json').exists()
_,_,keys,_,base,recovery=load_inputs()
profiles=[
 {'name':'zero','parameters':{'loss':0.,'action':0.,'shared':0.}},
 {'name':'loss005_action001','parameters':{'loss':.005,'action':.001}},
 {'name':'loss015_action005','parameters':{'loss':.015,'action':.005}},
 {'name':'variance2_loss005','parameters':{'loss':.005,'action':.001,'scale':2.}},
 {'name':'concentrated_loss005','parameters':{'loss':[.04]+[.01/9]*9,'action':[.01]+[0.]*9}},
 {'name':'variance2_loss015','parameters':{'loss':.015,'action':.005,'scale':2.}},
 {'name':'concentrated_loss015','parameters':{'loss':[.075]+[.075/9]*9,'action':[.05]+[0.]*9}},
]
spec={'candidate_N':10240,'formal_N':None,'model_execution_eligible':False,'replicates':512,'bootstrap_resamples':20000,
 'family_size':7,'seed_base':9920261022,'profiles':profiles,'status':'Fresh conditional validation; alternatives fixed before these new MC draws; not calibrated population truths. Null stress need not achieve80% acceptance.',
 'selection':'Exploration selected a candidate maximum; this independently seeded validation does not inherit power from a smaller N or exploratory winner.'}
(root/'candidate-validation-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
rows=[]
for index,profile in enumerate(profiles):
 result=simulate(10240,base,recovery,profile,replicates=512,resamples=20000,seed=spec['seed_base']+index,mc_family_size=7)
 rows.append(result);print(profile['name'],result['joint_power'],result['joint_MC_CI95_simultaneous'],flush=True)
out={**spec,'results':rows,'conditional_profile_set_passed':all(r['candidate_joint_power_supported']for r in rows),
 'formal_eligibility_reason':'Conditional planning result only. Calibration has2 selected seeds per stratum, no well-identified rare-error or tail law; choosing alternatives is not warranted by zero events. Original preparation requires pilot status when estimates insufficient/unstable; new bank lacks native qualification and an adapted executable freeze. Null-stress failure alone is not a statistical prohibition on a confirmatory trial.'}
(root/'candidate-validation.json').write_text(json.dumps(out,indent=2)+'\n')
