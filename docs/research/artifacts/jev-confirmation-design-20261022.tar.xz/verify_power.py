"""Exact independent count-distribution checks for the seven selected-N models."""
from pathlib import Path
import json,math
import numpy as np
from scipy.optimize import brentq
from scipy.signal import fftconvolve
from scipy.stats import binom,binomtest

root=Path(__file__).parent
v=json.loads((root/'candidate-validation.json').read_text());n=v['candidate_N'];ns=n//10
order=json.loads((root/'power.json').read_text())['strata_order'];recovery=np.array(['recovery-'in k for k in order])

def critical(total,margin):
    # Independent continuous root + integer check, rather than source bisection.
    if -total*math.log1p(-margin)<math.log(40):return -1
    def f(q):return total*((q*math.log(q/margin)if q else 0)+(1-q)*math.log((1-q)/(1-margin)))-math.log(40)
    q=brentq(f,0,margin);k=int(math.floor(q*total))
    while k+1<total*margin and f((k+1)/total)>=0:k+=1
    while k>=0 and f(k/total)<-1e-10:k-=1
    return k

def count_pmf(probabilities):
    pmf=np.array([1.])
    for p in probabilities:
        chunk=binom.pmf(np.arange(ns+1),ns,float(p))
        pmf=fftconvolve(pmf,chunk)
    pmf=np.maximum(pmf,0);return pmf/pmf.sum()

out=[]
for profile,result in zip(v['profiles'],v['results']):
    p=profile['parameters'];loss=np.broadcast_to(p['loss'],(10,));action=np.broadcast_to(p['action'],(10,));failure=loss+p.get('shared',.005)
    exact={}
    for name,prob,total,margin,point in [
        ('quality_difference_lower',loss,n,.02,None),('unexpected_difference_upper',action,n,.01,None),
        ('quality_lower',failure,n,.1,None),('quality_point',failure,n,None,.05),
        ('recovery_lower',failure[recovery],n*4//10,.2,None),
        ('recovery_difference_lower',loss[recovery],n*4//10,.05,None),
        ('recovery_point',failure[recovery],n*4//10,None,.1)]:
        k=critical(total,margin)if margin is not None else int(total*point)
        pmf=count_pmf(prob);exact[name]=float(pmf[:k+1].sum())
    exact['family_min_point']=float(np.prod(binom.cdf(int(.1*ns),ns,failure)))
    for key,probability in exact.items():
        measured=result['marginal'][key]['passed'];pvalue=float(binomtest(measured,512,p=min(1.,max(0.,probability))).pvalue)
        assert pvalue>=.05/(7*8),(profile['name'],key,pvalue)
    binary_frechet=max(0.,1-sum(1-p for p in exact.values()))
    out.append({'profile':profile['name'],'exact_marginal_probabilities':exact,
        'binary_joint_Frechet_lower':binary_frechet,'measured_allgate_power':result['joint_power'],
        'note':'Frechet is a bound, not a product assuming endpoint independence. Full joint also needs time and safety.'})
(root/'power-independent.json').write_text(json.dumps({'checks':out,'all56_exact_marginal_consistency_tests_passed':True,'model_calls':0},indent=2)+'\n')
print('56 exact marginal count checks passed; no model calls')
